import request from '../utils/request';

// 登陆
export async function fakeAccountLogin(params) {
  params.mobile = params.userName;
  params.pwd = md5(params.pwd);
  return request('/api/admin/adminUser/login', {
    method: 'POST',
    body: params,
  });
}
// 管理员列表
export async function queryManage(params) {
  return request(
    `/api/admin/adminUser/list`, {
      method: 'GET',
      body: params,
    }
  );
}
// 新活动开奖

export async function openAPrize(params) {
  return request('/api/admin/activity/openAPrize', {
    method: 'GET',
    body: params,
  });
}
// 发送卡券posterOpenAPrizeButton
export async function commentAwardPrizes(params) {
  return request('/api/admin/comment/awardPrizes', {
    method: 'POST',
    body: params,
  });
}
// 新活动设置中奖

export async function activityPrizeSetUp(params) {
  return request('/api/admin/activity/prizeSetUp', {
    method: 'POST',
    body: params,
  });
}
// 管理员列表分页
export async function queryManageCount(params) {
  return request(
    `/api/admin/adminUser/count`, {
      method: 'GET',
      body: params,
    }
  );
}
// 新查询图文
export async function activityGetarticlesummary(params) {
  return request(
    `/api/admin/activity/getarticlesummary`, {
      method: 'GET',
      body: params,
    }
  );
}
// 新活动发送中奖通知
export async function activityAgainNotice(params) {
  return request(
    `/api/admin/activity/againNotice`, {
      method: 'GET',
      body: params,
    }
  );
}
// 获取单个素材接口
export async function materialGet(params) {
  return request(
    `/api/admin/material/get`, {
      method: 'POST',
      body: params,
    }
  );
}
//门店编辑
export async function shopUpdate(params) {
  return request(
    `/api/admin/shop/update`, {
      method: 'POST',
      body: params,
    }
  );
}
//同步素材
export async function materialSyncMaterial(params) {
  return request(
    `/api/admin/material/syncMaterial`, {
      method: 'GET',
      body: params,
    }
  );
}
//获取单个门店
export async function shopGet(params) {
  return request(
    `/api/admin/shop/get`, {
      method: 'GET',
      body: params,
    }
  );
}

// 积分海报助力情况
export async function activityHelpList(params) {
  return request(
    `/api/admin/activity/helpList`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function activityHelpCount(params) {
  return request(
    `/api/admin/activity/helpCount`, {
      method: 'GET',
      body: params,
    }
  );
}

// 重新发送中奖通知
export async function commentAgainNotice(params) {
  return request(
    `/api/admin/comment/againNotice`, {
      method: 'POST',
      body: params,
    }
  );
}
// 保存题目

export async function activitySaveSubject(params) {
  return request('/api/admin/activity/saveSubject', {
    method: 'POST',
    body: params,
  });
}
// 获取单个活动信息
export async function activityGet(params) {
  return request('/api/admin/activity/get', {
    method: 'GET',
    body: params,
  });
}
// 题目列表
export async function activitySelectSubjectList(params) {
  return request(
    `/api/admin/activity/selectSubjectList`, {
      method: 'GET',
      body: params,
    }
  );
}


export async function activitySelectSubjectCount(params) {
  return request(
    `/api/admin/activity/selectSubjectCount`, {
      method: 'GET',
      body: params,
    }
  );
}

//  新活动参与列表
export async function activityUserList(params) {
  return request('/api/admin/activity/userList', {
    method: 'GET',
    body: params,
  });
}

export async function activityUserCount(params) {
  return request('/api/admin/activity/userCount', {
    method: 'GET',
    body: params,
  });
}
// 新活动回复
export async function activityReplyComment(params) {
  return request('/api/admin/activity/replyComment', {
    method: 'POST',
    body: params,
  });
}
//  新活动删除
export async function deleteNewActivity(params) {
  return request('/api/admin/activity/delete', {
    method: 'POST',
    body: params,
  });
}
//  新活动添加
export async function addNewActivity(params) {
  return request('/api/admin/activity/save', {
    method: 'POST',
    body: params,
  });
}
//  门店添加

export async function addShop(params) {
  return request('/api/admin/shop/add', {
    method: 'POST',
    body: params,
  });
}
//  添加管理员
export async function addManage(params) {
  return request('/api/admin/adminUser/add', {
    method: 'POST',
    body: params,
  });
}
//  粉丝
export async function userCount(params) {
  return request(
    `/api/admin/user/count`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function userList(params) {
  return request(
    `/api/admin/user/list`, {
      method: 'GET',
      body: params,
    }
  );
}
// 用户行为
export async function userActionList(params) {
  return request(
    `/api/admin/userAction/list`,{
    method:'GET',
    body:params,
  })
}

export async function userActionCount(params) {
  return request(
    `/api/admin/userAction/count`,{
    method:'GET',
    body:params,
  })
}

export async function updateManager(params) {
  return request('/api/admin/adminUser/update', {
    method: 'POST',
    body: params,
  });
}
//  关联微信校验
export async function adminUservalidate(params) {
  return request('/api/admin/adminUser/validate', {
    method: 'POST',
    body: params,
  });
}
//  获取单个账号详情
export async function adminUserGet(params) {
  return request(
    `/api/admin/adminUser/get`, {
      method: 'GET',
      body: params,
    }
  );
}
//  重置密码
export async function adminUsermodiPwd(params) {
  return request('/api/admin/adminUser/update', {
    method: 'POST',
    body: params,
  });
}
//  切换账号
export async function switchAdminUser(params) {
  return request(
    `/api/admin/adminUser/switch`, {
      method: 'GET',
      body: params,
    }
  );
}
//  门店列表
export async function shop(params) {
  return request(
    `/api/admin/shop/list`, {
      method: 'GET',
      body: params,
    }
  );
}

export async function shopcount(params) {
  return request(
    `/api/admin/shop/count`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function shopdelete(params) {
  return request('/api/admin/shop/delete', {
    method: 'POST',
    body: params,
  });
}
//  同步公众门店
export async function shopSync(params) {
  return request(
    `/api/admin/shop/sync`, {
      method: 'GET',
      body: params,
    }
  );
}

//  到店人数列表
export async function shopDataList(params) {
  return request(
    `/api/admin/shop/shopDataList`, {
      method: 'GET',
      body: params,
    }
  );
}

//  到店人数统计
export async function shopDataCount(params) {
  return request(
    `/api/admin/shop/shopDataCount`, {
      method: 'GET',
      body: params,
    }
  );
}
//  新增到店人数
export async function addShopData(params) {
  return request(
    `/api/admin/shop/addShopData`, {
      method: 'POST',
      body: params,
    }
  );
}
//  获取素材list
export async function materialList(params) {
  return request(
    `/api/admin/material/list`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function materialCount(params) {
  return request(
    `/api/admin/material/count`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function materialDelete(params) {
  return request('/api/admin/material/delete', {
    method: 'POST',
    body: params,
  });
}
//  关键词回复
export async function autoReplyList(params) {
  return request(
    `/api/admin/autoReply/list`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function autoReplyCount(params) {
  return request(
    `/api/admin/autoReply/count`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function autoReplyUpdate(params) {
  return request('/api/admin/autoReply/update', {
    method: 'POST',
    body: params,
  });
}
export async function autoReplyAdd(params) {
  return request('/api/admin/autoReply/add', {
    method: 'POST',
    body: params,
  });
}
export async function getAuthorizerByAdminUserId(params) {
  return request(
    `/api/admin/authorizer/getAuthorizerByAdminUserId`, {
      method: 'GET',
      body: params,
    }
  );
}

export async function selfMenuList(params) {
  return request(
    `/api/admin/selfMenu/list`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function selfMenuUpdate(params) {
  return request('/api/admin/selfMenu/update', {
    method: 'POST',
    body: params,
  });
}
export async function selfMenuAdd(params) {
  return request('/api/admin/selfMenu/add', {
    method: 'POST',
    body: params,
  });
}
export async function selfMenuDelete(params) {
  return request('/api/admin/selfMenu/delete', {
    method: 'POST',
    body: params,
  });
}

export async function selfMenuSyncMenu(params) {
  return request('/api/admin/selfMenu/syncMenu', {
    method: 'POST',
    body: params,
  });
}
export async function messageList(params) {
  return request(
    `/api/admin/mpMessage/list`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function messageCount(params) {
  return request(
    `/api/admin/mpMessage/count`, {
      method: 'GET',
      body: params,
    }
  );
}
//  二维码
export async function qrcodeList(params) {
  return request(
    `/api/admin/qrcode/list`, {
      method: 'GET',
      body: params,
    }
  );
}
// 数据统计-关注渠道

export async function dataCountChannelAnalysis(params) {
  return request(
    `/api/admin/dataCount/channelAnalysis`, {
      method: 'GET',
      body: params,
    }
  );
}

export async function dataCountChannelAnalysisExportExcel(params) {
  return request(
    `/api/admin/dataCount/exportExcel`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function qrcodeCount(params) {
  return request(
    `/api/admin/qrcode/count`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function qrcodeDelete(params) {
  return request('/api/admin/qrcode/delete', {
    method: 'POST',
    body: params,
  });
}
export async function qrcodeUpdate(params) {
  return request('/api/admin/qrcode/update', {
    method: 'POST',
    body: params,
  });
}
export async function qrcodeAdd(params) {
  return request('/api/admin/qrcode/add', {
    method: 'POST',
    body: params,
  });
}

export async function qrcodeListAdd(params) {
  return request('/api/admin/qrcode/batchAdd', {
    method: 'POST',
    body: params,
  });
}

export async function qrCodeBatchDownload(params) {
  return request('/api/admin/qrcode/batchDown', {
    method: 'GET',
    body: params,
  });
}

//  获取公众号关联的小程序
export async function wxWxamplinkget(params) {
  return request('/api/admin/wx/wxamplinkget', {
    method: 'POST',
    body: params,
  });
}
//  获取模板列表
export async function wxGetTemplateList(params) {
  return request(
    `/api/admin/wx/getTemplateList`, {
      method: 'GET',
      body: params,
    }
  );
}
//  获取草稿列表
export async function getTemplatedRaftlist(params) {
  return request(
    `/api/admin/wx/getTemplatedRaftlist`, {
      method: 'GET',
      body: params,
    }
  );
}

export async function wxAddToTemplate(params) {
  return request('/api/admin/wx/addToTemplate', {
    method: 'POST',
    body: params,
  });
}
export async function wxDeleteTemplate(params) {
  return request('/api/admin/wx/deleteTemplate', {
    method: 'POST',
    body: params,
  });
}
//  发布版本
export async function wxReleaseVsersion(params) {
  return request('/api/admin/wx/releaseVsersion', {
    method: 'POST',
    body: params,
  });
}
//  小程序列表
export async function pageList(params) {
  return request(
    `/api/admin/page/list`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function pageCount(params) {
  return request(
    `/api/admin/page/count`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function pageAdd(params) {
  return request('/api/admin/page/add', {
    method: 'POST',
    body: params,
  });
}
export async function pageUpdate(params) {
  return request('/api/admin/page/update', {
    method: 'POST',
    body: params,
  });
}
export async function pageDelete(params) {
  return request('/api/admin/page/delete', {
    method: 'POST',
    body: params,
  });
}
//  二维码数据分析
export async function qrcodeGetAnalysisData(params) {
  return request(
    `/api/admin/qrcode/getAnalysisData`, {
      method: 'GET',
      body: params,
    }
  );
}
//  获取授权信息
export async function wxGetAuthInfo(params) {
  return request(
    `/api/admin/wx/getAuthInfo`, {
      method: 'GET',
      body: params,
    }
  );
};
//  获取最新版本信息
export async function wxGetNewestVersion(params) {
  return request(
    `/api/admin/ver/getNewestVersion`, {
      method: 'GET',
      body: params,
    }
  );
};
//  删除题目
export async function activityDeleteSubject(params) {
  console.log(params)
  return request(
    `/api/admin/activity/deleteSubject`, {
      method: 'POST',
      body: params,
    }
  );
}

export async function guessCount(params) {
  return request(
    `/api/admin/guess/count`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function guessSelectGuessList(params) {
  return request(
    `/api/admin/guess/selectGuessList`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function posterCount(params) {
  return request(
    `/api/admin/poster/count`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function posterList(params) {
  return request(
    `/api/admin/poster/list`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function posterAdd(params) {
  return request('/api/admin/poster/add', {
    method: 'POST',
    body: params,
  });
}

export async function posterOpenAPrize(params) {
  return request('/api/admin/poster/openAPrize', {
    method: 'POST',
    body: params,
  });
}
export async function posterDelete(params) {
  return request('/api/admin/poster/delete', {
    method: 'POST',
    body: params,
  });
}
//  参与情况
export async function posterParticipation(params) {
  return request(
    `/api/admin/poster/participation`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function posterParticipationCount(params) {
  return request(
    `/api/admin/poster/participationCount`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function posterGET(params) {
  return request(
    `/api/admin/poster/get`, {
      method: 'GET',
      body: params,
    }
  );
}

export async function posterUpdate(params) {
  return request('/api/admin/poster/update', {
    method: 'POST',
    body: params,
  });
}
//  解除关联
export async function wxampunlink(params) {
  return request('/api/admin/wx/wxampunlink', {
    method: 'POST',
    body: params,
  });
}
export async function wxgetAuthParams(params) {
  return request(
    `/api/admin/wx/getAuthParams`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function getCategoryAndVer(params) {
  return request(
    `/api/admin/ver/getCategoryAndVer`, {
      method: 'GET',
      body: params,
    }
  );
}
//  取消中奖
export async function commentPrizeSetUp(params) {
  return request('/api/admin/comment/prizeSetUp', {
    method: 'POST',
    body: params,
  });
}
//  取消精选
export async function commentUnmarkelectOrMarkelect(params) {
  return request('/api/admin/comment/unmarkelectOrMarkelect', {
    method: 'POST',
    body: params,
  });
}
//  新版活动
export async function activityList(params) {
  return request(
    `/api/admin/activity/list`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function activityCount(params) {
  return request(
    `/api/admin/activity/count`, {
      method: 'GET',
      body: params,
    }
  );
}


//  统计
export async function cardStatList(params) {
  return request(
    `/api/admin/card/statList`, {
      method: 'GET',
      body: params,
    }
  );
}
// 用户分析昨日指标
export async function userDataKpi(params) {
  return request(
    `/api/admin/userData/kpi`, {
      method: 'GET',
      body: params,
    }
  );
}

// 用户分析数据表
export async function userDataListAn(params) {
  return request(
    `/api/admin/userData/list`, {
      method: 'GET',
      body: params,
    }
  );
}

// 推文分析


export async function articleList(params) {
  return request(
    `/api/admin/article/list`, {
      method: 'GET',
      body: params,
    }
  );
}

//  提交审核

export async function findPageByTemlateId(params) {
  return request(
    `/api/admin/ver/findPageByTemlateId`, {
      method: 'GET',
      body: params,
    }
  );
}
//  撤回审核
export async function undocodeaudit(params) {
  return request(
    `/api/admin/ver/undocodeaudit`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function againReleaseVsersion(params) {
  return request(
    `/api/admin/wx/againReleaseVsersion`, {
      method: 'POST',
      body: params,
    }
  );
}
//  提交审核
export async function submitAudit(params) {
  return request('/api/admin/ver/submitAudit', {
    method: 'POST',
    body: params,
  });
}
//  解除关联
export async function verUntie(params) {
  return request(
    `/api/admin/ver/untie`, {
      method: 'GET',
      body: params,
    }
  );
}
//  助力明细
export async function posterAssistanceSituationCount(params) {
  return request(
    `/api/admin/poster/assistanceSituationCount`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function posterAssistanceSituation(params) {
  return request(
    `/api/admin/poster/assistanceSituation`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function guessDelete(params) {
  return request('/api/admin/guess/delete', {
    method: 'POST',
    body: params,
  });
}
export async function guessSelectGuessOne(params) {
  return request(
    `/api/admin/guess/selectGuessOne`, {
      method: 'GET',
      body: params,
    }
  );
}
//  新活动设置或取消精选

export async function activityUnmarkelectOrMarkelect(params) {
  return request('/api/admin/activity/unmarkelectOrMarkelect', {
    method: 'POST',
    body: params,
  });
}
export async function guessUpdate(params) {
  return request('/api/admin/guess/update', {
    method: 'POST',
    body: params,
  });
}
export async function guessAdd(params) {
  return request('/api/admin/guess/add', {
    method: 'POST',
    body: params,
  });
}
export async function guessSelectSubjectListByGuessId(params) {
  return request(
    `/api/admin/guess/selectSubjectListByGuessId`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function guessCountSelectGuessUserListByGuessId(params) {
  return request(
    `/api/admin/guess/countSelectGuessUserListByGuessId`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function guessSelectGuessUserListByGuessId(params) {
  return request(
    `/api/admin/guess/selectGuessUserListByGuessId`, {
      method: 'GET',
      body: params,
    }
  );
}
//  优惠券
export async function cardList(params) {
  return request(
    `/api/admin/card/list`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function cardCount(params) {
  return request(
    `/api/admin/card/count`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function cardDelete(params) {
  return request('/api/admin/card/delete', {
    method: 'POST',
    body: params,
  });
}
export async function userCardList(params) {
  return request(
    `/api/admin/userCard/list`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function userCardCount(params) {
  return request(
    `/api/admin/userCard/count`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function cardAdd(params) {
  return request('/api/admin/card/add', {
    method: 'POST',
    body: params,
  });
}
export async function cardGet(params) {
  return request(
    `/api/admin/card/get`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function cardUpdate(params) {
  return request(
    "/api/admin/card/update",{
      method: 'POST',
      body: params,
    }
  );
}
//  活动
export async function commentCount(params) {
  return request(
    `/api/admin/comment/count`, {
      method: 'GET',
      body: params,
    }
  );
}

export async function commentList(params) {
  return request(
    `/api/admin/comment/list`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function commentDelete(params) {
  return request('/api/admin/comment/delete', {
    method: 'POST',
    body: params,
  });
}
export async function commentAdd(params) {
  return request('/api/admin/comment/add', {
    method: 'POST',
    body: params,
  });
}
export async function commentUpdate(params) {
  return request('/api/admin/comment/update', {
    method: 'POST',
    body: params,
  });
}

//  图文查询
export async function commentGetarticlesummary(params) {
  return request(
    `/api/admin/comment/getarticlesummary`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function commentGet(params) {
  return request(
    `/api/admin/comment/get`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function commentUserCount(params) {
  return request(
    `/api/admin/comment/commentUserCount`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function commentUserAllCount(params) {
  return request(
    `/api/admin/comment/commentUserAllCount`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function commentUserList(params) {
  return request(
    `/api/admin/comment/commentUserList`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function commentSyncComment(params) {
  return request('/api/admin/comment/syncComment', {
    method: 'POST',
    body: params,
  });
}
export async function activitySyncComment(params) {
  return request('/api/admin/activity/syncComment', {
    method: 'POST',
    body: params,
  });
}
export async function replyComment(params) {
  return request('/api/admin/comment/replyComment', {
    method: 'POST',
    body: params,
  });
}
//  朋友圈转发抽奖
export async function circleCount(params) {
  return request(
    `/api/admin/circle/count`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function circleList(params) {
  return request(
    `/api/admin/circle/list`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function circleParticipationCount(params) {
  return request(
    `/api/admin/circle/participationCount`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function circleDelete(params) {
  return request('/api/admin/circle/delete', {
    method: 'POST',
    body: params,
  });
}
export async function circleSelectParticipation(params) {
  return request(
    `/api/admin/circle/selectParticipation`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function circleAdd(params) {
  return request('/api/admin/circle/add', {
    method: 'POST',
    body: params,
  });
}
export async function circleGet(params) {
  return request(
    `/api/admin/circle/get`, {
      method: 'GET',
      body: params,
    }
  );
}
export async function circleUpdate(params) {
  return request('/api/admin/circle/update', {
    method: 'POST',
    body: params,
  });
}
//  随机抽奖
export async function circleLuckDraw(params) {
  return request('/api/admin/circle/luckDraw', {
    method: 'POST',
    body: params,
  });
}
//  新活动系统随机抽奖
export async function acitivityLuckDraw(params) {
  return request('/api/admin/activity/luckDraw', {
    method: 'POST',
    body: params,
  });
}

//  通知中奖客户
export async function circleSendNotice(params) {
  return request(`/api/admin/circle/sendNotice`, {
      method: 'GET',
      body: params,
    }
  );
}
//  取消中奖
export async function circleIsPrize(params) {
  return request('/api/admin/circle/isPrize', {
    method: 'POST',
    body: params,
  });
}
//  重新通知
export async function circleAgainNotice(params) {
  return request(
    `/api/admin/circle/againNotice`, {
      method: 'GET',
      body: params,
    }
  );
}

//  小程序模版设置列表
export async function miniTplList(params) {
  return request(
    `/api/admin/miniTpl/get`, {
      method: 'GET',
      body: params,
    }
  );
}

//  小程序模版设置保存或更新
export async function miniTplSave(params) {
  return request(
    `/api/admin/miniTpl/save`, {
      method: 'POST',
      body: params,
    }
  );
}

//  单个菜单新增
export async function menuAdd(params) {
  return request(
    '/api/admin/menu/save',{
      method:'POST',
      body:params,
    }
  )
}

//  删除菜单
export async function menuDelete(params) {
  return request(
    '/api/admin/menu/delete',{
      method:'POST',
      body:params,
    }
  )
}

//  查询菜单
export async function menuList(params) {
  return request(
    '/api/admin/menu/list', {
      method: 'GET',
      body: params,
    }
  );
}

//  保存菜单数组
export async function menuListSave(params) {
  return request(
    '/api/admin/menu/saveMenuList',{
      method:'POST',
      body:params,
    }
  )
}

// 角色列表
export async function roleList(params) {
  return request(
    '/api/admin/role/list', {
      method: 'POST',
      body: params,
    }
  );
}
// 桌台列表
export async function deskList(params) {
  return request(
    '/api/admin/desk/list',{
      method:'GET',
      body:params,
    }
  )
}
// 桌台设置有效无效
export async function deskUpdate(params) {
  return request(
    '/api/admin/desk/update', {
      method: 'POST',
      body: params,
    }
  );
}
// 分类设置有效无效
export async function cateUpdate(params) {
  return request(
    '/api/admin/cate/update', {
      method: 'POST',
      body: params,
    }
  );
}

// 新建桌台
export async function deskAdd(params) {
  return request(
    '/api/admin/desk/add', {
      method: 'POST',
      body: params,
    }
  );
}

// 新建分类
export async function cateAdd(params) {
  return request(
    '/api/admin/cate/add', {
      method: 'POST',
      body: params,
    }
  );
}



// 分类列表
export async function cateList(params) {
  return request(
    '/api/admin/cate/list', {
      method: 'GET',
      body: params,
    }
  );
}
// 分类列表
export async function cateCount(params) {
  return request(
    '/api/admin/cate/count', {
      method: 'GET',
      body: params,
    }
  );
}



// 桌台列表数量
export async function deskCount(params) {
  return request(
    '/api/admin/desk/count',{
      method:'GET',
      body:params,
    }
  )
}

// 角色列表统计
export async function roleCount(params) {
  return request(
    '/api/admin/role/count',{
      method:'GET',
      body:params,
    }
  )
}

// 角色删除
export async function roleDelete(params) {
  return request(
    '/api/admin/role/delete',{
      method:'POST',
      body:params,
    }
  )
}

// 角色新增
export async function roleAdd(params) {
  return request(
    '/api/admin/role/save',{
      method:'POST',
      body:params,
    }
  )
}

// 获取角色对应的菜单
export async function roleMenuList(params) {
  return request(
    '/api/admin/role/getMenuId',{
      method:'GET',
      body:params,
    }
  )
}

// 保存角色对应的菜单
export async function saveRoleMenu(params) {
  return request(
    '/api/admin/role/saveRoleMenuRef',{
      method:'POST',
      body:params,
    }
  )
}

// 获取排档列表
export async function scheduleList(params) {
  return request(
    '/api/admin/sch/list',{
      method:'GET',
      body:params,
    }
  )
}

// 新增排档
export async function addSchedule(params) {
  return request(
    '/api/admin/sch/add',{
      method:'POST',
      body:params,
    }
  )
}

// 新增排档
export async function updateSchedule(params) {
  return request(
    '/api/admin/sch/update',{
      method:'POST',
      body:params,
    }
  )
}

// 删除排档
export async function deleteSchedule(params) {
  return request(
    '/api/admin/sch/delete',{
      method:'POST',
      body:params,
    }
  )
}
