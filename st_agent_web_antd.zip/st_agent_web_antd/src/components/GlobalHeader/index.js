/* eslint-disable lines-between-class-members,react/sort-comp,class-methods-use-this,react/no-unused-state,react/no-unused-state,react/destructuring-assignment,import/newline-after-import,prefer-destructuring,no-case-declarations,prefer-arrow-callback,default-case,spaced-comment */
import React, { PureComponent } from 'react';
import { Menu, Icon, Spin, Tag, Dropdown, Avatar,message, Divider, Tooltip,Modal,Form,Input} from 'antd';
import moment from 'moment';
import groupBy from 'lodash/groupBy';
import Debounce from 'lodash-decorators/debounce';
import { Link } from 'dva/router';
import NoticeIcon from '../NoticeIcon';
import HeaderSearch from '../HeaderSearch';
import styles from './index.less';
import { getStore, removeStore } from '../../assets/js/mUtils';
import { connect } from 'dva';

const FormItem = Form.Item;
@connect(({ user, loading }) => ({
  user,
  loading: loading.models.user,
}))
export default class GlobalHeader extends PureComponent {
  constructor(props){
    super(props)
    this.state={
      msg:"",
      visible: false,
    }
  }
  componentWillUnmount() {
    this.triggerResizeEvent.cancel();
  }
  getNoticeData() {
    const { notices } = this.props;
    if (notices == null || notices.length === 0) {
      return {};
    }
    const newNotices = notices.map(notice => {
      const newNotice = { ...notice };
      if (newNotice.datetime) {
        newNotice.datetime = moment(notice.datetime).fromNow();
      }
      // transform id to item key
      if (newNotice.id) {
        newNotice.key = newNotice.id;
      }
      if (newNotice.extra && newNotice.status) {
        const color = {
          todo: '',
          processing: 'blue',
          urgent: 'red',
          doing: 'gold',
        }[newNotice.status];
        newNotice.extra = (
          <Tag color={color} style={{ marginRight: 0 }}>
            {newNotice.extra}
          </Tag>
        );
      }
      return newNotice;
    });
    return groupBy(newNotices, 'type');
  }

  toggle = () => {
    const { collapsed, onCollapse } = this.props;
    onCollapse(!collapsed);
    this.triggerResizeEvent();
  };
  showModal = () => {
    this.setState({
      visible: true,
    });
  };
  hideModal=()=>{
    this.setState({
      visible: false,
    });
  };
  //修改密码
  submit = () => {
    const {dispatch}=this.props;
    if(getStore("userInfo")){
      if(this.state.newPwd&&this.state.oldPwd&&this.state.newPwdOne){
        if(this.state.newPwd===this.state.newPwdOne){
          dispatch({
            type:"user/passwordChange",
            payload:{
              adminUserId:JSON.parse(getStore("userInfo")).user.adminUserId,
              oldPwd:md5(this.state.oldPwd),
              newPwd:md5(this.state.newPwd),
            },
          }).then(function(result) {
            switch (result.code) {
              case "200":
                message.success("修改成功")
                const confirm = Modal.confirm;
                confirm({
                  title: '提示?',
                  content: '修改成功!',
                  onOk() {
                    removeStore("userInfo");
                    window.location.href=`${window.location.origin}/#/user/`;
                  },
                  onCancel() {

                  },
                });
                break;
              case "500":
                message.error("修改失败")
                break;
            }
          })
        }
      }
    }
  }
  oldPwd=e=>{
    this.setState({
      oldPwd:e.target.value,
    })
  };
  newPwd=e=>{
    this.setState({
      newPwd:e.target.value,
    })
  };
  newPwdOne=e=>{
    this.setState({
      newPwdOne:e.target.value,
    });
  };
  onBlurNewPwdOne=e=>{
    if(e.target.value!==this.state.newPwd){
      this.setState({
        msg:"两次密码不相同",
      })
    }else{
      this.setState({
        msg:"",
      })
    }
  }
  /* eslint-disable*/
  @Debounce(600)
  triggerResizeEvent() {
    const event = document.createEvent('HTMLEvents');
    event.initEvent('resize', true, false);
    window.dispatchEvent(event);
  }
  render() {
    const {
      currentUser = {},
      collapsed,
      fetchingNotices,
      isMobile,
      logo,
      onNoticeVisibleChange,
      onMenuClick,
      onNoticeClear,
    } = this.props;
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 8 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 },
      },
    };

    const menu = (
      <Menu className={styles.menu} selectedKeys={[]} onClick={onMenuClick}>
        {/*<Menu.Item disabled>*/}
          {/*<Icon type="user" />个人中心*/}
        {/*</Menu.Item>*/}
        {/*<Menu.Item disabled>*/}
          {/*<Icon type="setting" />设置*/}
        {/*</Menu.Item>*/}
        {/*<Menu.Item key="triggerError">*/}
          {/*<Icon type="close-circle" />触发报错*/}
        {/*</Menu.Item>*/}
        {/*<Menu.Divider />*/}
        <Menu.Item key="changePassword" onClick={this.showModal}>
          <Icon type="setting" />修改密码
        </Menu.Item>
        <Menu.Divider />
        <Menu.Item key="logout">
          <Icon type="logout" />退出登录
        </Menu.Item>
      </Menu>
    );
    const noticeData = this.getNoticeData();
    return (
      <div className={styles.header}>
        {isMobile && [
          <Link to="/" className={styles.logo} key="logo">
            <img src={logo} alt="logo" width="32" />
          </Link>,
          <Divider type="vertical" key="line" />,
        ]}
        <Icon
          className={styles.trigger}
          type={collapsed ? 'menu-unfold' : 'menu-fold'}
          onClick={this.toggle}
        />
        <div className={styles.right}>
          {/*<HeaderSearch*/}
            {/*className={`${styles.action} ${styles.search}`}*/}
            {/*placeholder="站内搜索"*/}
            {/*dataSource={['搜索提示一', '搜索提示二', '搜索提示三']}*/}
            {/*onSearch={value => {*/}
              {/*//console.log('input', value); // eslint-disable-line*/}
            {/*}}*/}
            {/*onPressEnter={value => {*/}
              {/*//console.log('enter', value); // eslint-disable-line*/}
            {/*}}*/}
          {/*/>*/}
          {/*<Tooltip title="使用文档">*/}
            {/*<a*/}
              {/*target="_blank"*/}
              {/*href="http://pro.ant.design/docs/getting-started"*/}
              {/*rel="noopener noreferrer"*/}
              {/*className={styles.action}*/}
            {/*>*/}
              {/*<Icon type="question-circle-o" />*/}
            {/*</a>*/}
          {/*</Tooltip>*/}
          {/*<NoticeIcon*/}
            {/*className={styles.action}*/}
            {/*count={currentUser.notifyCount}*/}
            {/*onItemClick={(item, tabProps) => {*/}
              {/*//console.log(item, tabProps); // eslint-disable-line*/}
            {/*}}*/}
            {/*onClear={onNoticeClear}*/}
            {/*onPopupVisibleChange={onNoticeVisibleChange}*/}
            {/*loading={fetchingNotices}*/}
            {/*popupAlign={{ offset: [20, -16] }}*/}
          {/*>*/}
            {/*<NoticeIcon.Tab*/}
              {/*list={noticeData['通知']}*/}
              {/*title="通知"*/}
              {/*emptyText="你已查看所有通知"*/}
              {/*emptyImage="https://gw.alipayobjects.com/zos/rmsportal/wAhyIChODzsoKIOBHcBk.svg"*/}
            {/*/>*/}
            {/*<NoticeIcon.Tab*/}
              {/*list={noticeData['消息']}*/}
              {/*title="消息"*/}
              {/*emptyText="您已读完所有消息"*/}
              {/*emptyImage="https://gw.alipayobjects.com/zos/rmsportal/sAuJeJzSKbUmHfBQRzmZ.svg"*/}
            {/*/>*/}
            {/*<NoticeIcon.Tab*/}
              {/*list={noticeData['待办']}*/}
              {/*title="待办"*/}
              {/*emptyText="你已完成所有待办"*/}
              {/*emptyImage="https://gw.alipayobjects.com/zos/rmsportal/HsIsxMZiWKrNUavQUXqx.svg"*/}
            {/*/>*/}
          {/*</NoticeIcon>*/}
          <Dropdown overlay={menu}>
              <span className={`${styles.action} ${styles.account}`}>
                <Icon type="user" style={{marginRight:"10px"}} />
                <span className={styles.name}>{getStore("userInfo")?JSON.parse(getStore("userInfo")).user.userName:""}</span>
              </span>
          </Dropdown>
        </div>
        <Modal
          title="修改密码"
          visible={this.state.visible}
          onOk={this.submit}
          onCancel={this.hideModal}
          okText="确认"
          cancelText="取消"
        >
          <Form onSubmit={this.handleSubmit}>
            <FormItem
              style={{marginLeft:"-100px"}}
              {...formItemLayout}
              label="输入原密码"
            >
              <Input type="password" onChange={this.oldPwd}/>
            </FormItem>
            <FormItem
              style={{marginLeft:"-100px"}}
              {...formItemLayout}
              label="输入新密码"
            >
              <Input type="password" onChange={this.newPwd} />
            </FormItem>
            <FormItem
              style={{marginLeft:"-100px"}}
              {...formItemLayout}
              label="确认新密码"
            >
              <Input type="password" onChange={this.newPwdOne} onBlur={this.onBlurNewPwdOne}/>
            </FormItem>
            <span style={{color:"red"}}>{this.state.msg}</span>
          </Form>
        </Modal>
      </div>
    );
  }
}
