/* eslint-disable prefer-destructuring */
import React, { PureComponent } from 'react';
import {Button,Row,Col,Input} from 'antd';
import StandardTable from '../../components/StandardTable';
import activityConst from './cardConst';

const activityTypes = activityConst.activityTypes;

class SelectActivityList extends PureComponent{


  render(){
    const {activityList,selectedRows,loading,onSelectedActivity,activityChange,activityFun,getActivityList} = this.props;
    const columns = [
      {
        title: '活动名称',
        key: 'activityName',
        dataIndex: 'activityName',
      },
      {
        title: '活动类型',
        key: 'type',
        dataIndex: 'type',
        render: (text, record) => (
          <div>
            {
              activityTypes.map(item => (
                <div key={item.value}>{item.value===record.type?item.name:""}</div>
              ))
            }
          </div>
        ),
      },
      {
        title: '操作',
        width: 180,
        align:"right",
        fixed: 'right',
        render: (text, record) => (
          <Button type="primary" onClick={() => onSelectedActivity(record)}>
            选中
          </Button>
        ),
      },
    ];
    return (
      <div>
        <Row>
          <Col xl={4} lg={4} md={4} sm={24} xs={24}>
            <Input placeholder="请输入活动" style={{marginBottom:"10px"}} onChange={activityFun} />
          </Col>
          <Col xl={2} lg={2} md={2} sm={24} xs={24}>
            <Button type="primary" style={{marginLeft:"10px"}} onClick={getActivityList}>查询</Button>
          </Col>
        </Row>
        <StandardTable
          selectedRows={selectedRows}
          loading={loading}
          data={activityList}
          columns={columns}
          onChange={activityChange}
        />
      </div>

    )
  }

}
export default SelectActivityList;
