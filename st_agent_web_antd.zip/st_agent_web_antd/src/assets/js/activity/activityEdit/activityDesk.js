/* eslint-disable prefer-destructuring */
import React, { PureComponent } from 'react';

import {Button,Row,Col,Input,Icon,Upload,Form,Radio} from 'antd';
const FormItem = Form.Item;
const { TextArea } = Input;
const RadioGroup = Radio.Group;

import activityConst from '../../cardConst';
import styles from '../../../../routes/newActivity/newActivity.less';

const activityTypes = activityConst.activityTypes;

class ActivityDesk extends PureComponent{


  render(){
    const {
      imageUrlAbstr,
      action,
      imageUrlAbstrCoverUrl,
      handleChangeAbstractCoverUrl,
      uploadButton1,
      uploadButtones,
      handleChangeAbstract,
      handleChangeAbstractEsMoment,
      styles,
      form,
      photoUrlsArr,
      deletePhotoUrl,
      formItemLayout,
      rules,
      uploadButton2,
      activityGetInfo,
    } = this.props;
    return (
      <div>
        {/*<FormItem {...formItemLayout} label="海报图片">*/}
          {/*{form.getFieldDecorator('imageUrlAbstr', {*/}
            {/*initialValue: imageUrlAbstr,*/}
            {/*rules: [{ required: true, message: '请上传海报图片' }],*/}
          {/*})(<Upload*/}
            {/*name="file"*/}
            {/*listType="picture-card"*/}
            {/*className={styles.antUpload}*/}
            {/*showUploadList={false}*/}
            {/*action={action}*/}
            {/*onChange={handleChangeAbstract}*/}
          {/*>*/}
            {/*{imageUrlAbstr ? (*/}
              {/*<img*/}
                {/*src={imageUrlAbstr}*/}
                {/*alt="avatar"*/}
                {/*style={{ width: '100px', height: '100px' }}*/}
              {/*/>*/}
            {/*) : uploadButton2}*/}
          {/*</Upload>)}*/}
        {/*</FormItem>*/}
        {/*<FormItem {...formItemLayout} label="封面图片">*/}
          {/*{form.getFieldDecorator('coverUrl', {*/}
            {/*initialValue:imageUrlAbstrCoverUrl,*/}
            {/*rules: [{ required: true, message: '请上传封面图片' }],*/}
          {/*})(<Upload*/}
            {/*name="file"*/}
            {/*listType="picture-card"*/}
            {/*className={styles.antUpload}*/}
            {/*showUploadList={false}*/}
            {/*action={action}*/}
            {/*onChange={handleChangeAbstractCoverUrl}*/}
          {/*>*/}
            {/*{imageUrlAbstrCoverUrl ? (*/}
              {/*<img*/}
                {/*src={imageUrlAbstrCoverUrl}*/}
                {/*alt="avatar"*/}
                {/*style={{ width: '100px', height: '100px' }}*/}
              {/*/>*/}
            {/*) : uploadButton1}*/}
          {/*</Upload>)}*/}
        {/*</FormItem>*/}
        <FormItem {...formItemLayout} label="活动图片">
          {form.getFieldDecorator('photoUrls', {
            initialValue:photoUrlsArr,
            rules: [{ required: true, message: '请上传活动图片' }],
          })(
            <div>
              <ul style={{listStyle:"none",marginLeft:"-40px",float:"left",marginRight:"10px"}}>
                {
                  photoUrlsArr?photoUrlsArr.map((item,index) => {
                    return(
                      <li key={index} style={{position:"relative",float:"left",marginRight:"10px",marginBottom:"10px"}}><img alt="" src={item} style={{width:100,height:100}} />
                        <span
                          onClick={() => deletePhotoUrl(index,item)}
                          style={{position: "absolute",
                            right: "15px"}}
                        ><Icon
                          type="close-circle"
                          style={{
                            float: 'right',
                            marginRight: '20px',
                            cursor: 'pointer',
                            position:"absolute",
                          }}
                        />
                                  </span>
                      </li>
                    )
                  }):""
                }
                <li><Upload
                  name="file"
                  listType="picture-card"
                  className={styles.antUpload}
                  showUploadList={false}
                  action={action}
                  multiple={true}
                  onChange={handleChangeAbstractEsMoment}
                >
                  {uploadButtones}
                </Upload>
                </li>
              </ul>

            </div>)}

        </FormItem>
        <FormItem {...formItemLayout} label="规则">
          {form.getFieldDecorator('rules',{
            initialValue: activityGetInfo ?activityGetInfo.extraInfo.rules: ' ',
          })(<TextArea
            placeholder="请输入规则"
            rows="4"
            onChange={rules}
          />)}
        </FormItem>
      </div>
    )
  }

}
export default ActivityDesk;
