/* eslint-disable prefer-destructuring */
import React, { PureComponent } from 'react';

import {Button,Row,Col,Input,Upload,Form,Radio,Table} from 'antd';

import activityConst from '../../cardConst';

const FormItem = Form.Item;
const { TextArea } = Input;
const RadioGroup = Radio.Group;


const activityTypes = activityConst.activityTypes;

class ActivityMoment extends PureComponent{


  render(){
    const {
      titleFun,
      title,
      formItemLayout,
      form,
      rules,
      showModelTextNews,
      activityGetInfo,
    } = this.props;
    return (
      <div>
        <FormItem {...formItemLayout} label="文章标题">
          {form.getFieldDecorator('title', {
            initialValue:title,
            rules: [{ required: true, message: '请输入文章标题' }],
          })(
            <div style={{ display: 'flex' }}>
              <Input
                disabled
                placeholder="请输入文章标题"
                maxLength="64"
                value={title}
                addonAfter={title ? `${title.length  }/64` : '0/64'}
                onChange={titleFun}
              />
              <Button
                type='primary'
                disabled
                style={{ marginLeft: '20px' }}
                onClick={showModelTextNews}
              >选择图文
              </Button>

            </div>)}
        </FormItem>
        <FormItem {...formItemLayout} label="规则">
          {form.getFieldDecorator('rules',{
            initialValue:activityGetInfo ?activityGetInfo.extraInfo.replyTxt : ' ',
          })(<TextArea
            placeholder="请输入规则"
            rows="4"
            onChange={rules}
          />)}
        </FormItem>
      </div>
    )
  }

}
export default ActivityMoment;
