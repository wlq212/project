/* eslint-disable prefer-destructuring */
import React, { PureComponent } from 'react';

import {Button,Row,Col,Input,Upload,Form,Radio,Icon} from 'antd';
const FormItem = Form.Item;
const { TextArea } = Input;
const RadioGroup = Radio.Group;

import activityConst from '../../cardConst';
import styles from '../../../../routes/newActivity/newActivity.less';


const activityTypes = activityConst.activityTypes;

class ActivityQuestion extends PureComponent{


  render(){
    const {
      form,
      prizeCondition,
      imageUrlAbstr,
      formItemLayout,
      styles,
      action,
      uploadButton2,
      imageUrlAbstrCoverUrl,
      handleChangeAbstractCoverUrl,
      uploadButton1,
      handleChangeAbstractEsMoment,
      uploadButtones,
      rules,
      colorChange,
      colorInput,
      backgroupColor,
      activityGetInfo,
      isOpen,
      photoUrlsArr,
      deletePhotoUrl,
      handleChangeAbstract,
    } = this.props;
    return (
      <div>
        <FormItem {...formItemLayout} label="发奖条件">
          {form.getFieldDecorator('prizeCondition', {
            initialValue:activityGetInfo?activityGetInfo.extraInfo.prizeCondition : ' ',
            rules: [{ required: true, message: '请输入发奖条件' }],
          })(<Input
            placeholder="请输入发奖条件"
            addonAfter="分"
            type="number"
            disabled={Number(isOpen)=== 1}
            onChange={prizeCondition}
          />)}
        </FormItem>
        <FormItem {...formItemLayout} label="背景图片">
          {form.getFieldDecorator('coverUrl', {
            initialValue:imageUrlAbstr,
            rules: [{ required: true, message: '请上传背景图片' }],
          })(<Upload
            name="file"
            listType="picture-card"
            className={styles.antUpload}
            showUploadList={false}
            action={action}
            onChange={handleChangeAbstract}
          >
            {imageUrlAbstr ? (
              <img
                src={imageUrlAbstr}
                alt="avatar"
                style={{ width: '100px', height: '100px' }}
              />
            ) : uploadButton2}
          </Upload>)}

        </FormItem>
        <FormItem {...formItemLayout} label="封面图片">
          {form.getFieldDecorator('coverUrlOne', {
            initialValue:imageUrlAbstrCoverUrl,
            rules: [{ required: true, message: '请上传封面图片' }],
          })(<Upload
            name="file"
            listType="picture-card"
            className={styles.antUpload}
            showUploadList={false}
            action={action}
            onChange={handleChangeAbstractCoverUrl}
          >
            {imageUrlAbstrCoverUrl ? (
              <img
                src={imageUrlAbstrCoverUrl}
                alt="avatar"
                style={{ width: '100px', height: '100px' }}
              />
            ) : uploadButton1}
          </Upload>)}
        </FormItem>
        <FormItem {...formItemLayout} label="分享图片">
          {form.getFieldDecorator('photoUrls', {
            initialValue:photoUrlsArr,
            rules: [{ required: true, message: '请上传活动图片' }],
          })(
            <div>
              <ul style={{listStyle:"none",marginLeft:"-40px",float:"left",marginRight:"10px"}}>
                {
                  photoUrlsArr?photoUrlsArr.map((item,index) => {
                    return(
                      <li key={index} style={{position:"relative",float:"left",marginRight:"10px",marginBottom:"10px"}}><img alt="" src={item} style={{width:100,height:100}} />
                        <span
                          onClick={() => deletePhotoUrl(index,item)}
                          style={{position: "absolute",
                            right: "15px"}}
                        ><Icon
                          type="close-circle"
                          style={{
                            float: 'right',
                            marginRight: '20px',
                            cursor: 'pointer',
                            position:"absolute",
                          }}
                        />
                                  </span>
                      </li>
                    )
                  }):""
                }
                <li><Upload
                  name="file"
                  listType="picture-card"
                  className={styles.antUpload}
                  showUploadList={false}
                  action={action}
                  onChange={handleChangeAbstractEsMoment}
                >
                  {uploadButtones}
                </Upload>
                </li>
              </ul>

            </div>)}

        </FormItem>
        <FormItem {...formItemLayout} label="背景颜色">
          {form.getFieldDecorator('backgroupColor', {
            initialValue:backgroupColor,
            rules: [{ required: true, message: '请上传活动图片' }],
          })(<div>
            <Input type="color" style={{width:"100px"}} onChange={colorChange} value={backgroupColor} />
            <Input type="text" style={{width:"200px",marginLeft:"10px"}} onChange={colorInput} value={backgroupColor}/>
          </div>)}
        </FormItem>
        <FormItem {...formItemLayout} label="规则">
          {form.getFieldDecorator('rules', {
            initialValue:activityGetInfo ? activityGetInfo.extraInfo.rules : ' '
          })(<TextArea
            placeholder="请输入规则"
            disabled={Number(isOpen)=== 1}
            rows="4"
            onChange={rules}
          />)}
        </FormItem>
      </div>
    )
  }

}
export default ActivityQuestion;
