/* eslint-disable prefer-destructuring */
import React, { PureComponent } from 'react';

import {Button,Row,Col,Input,Upload,Form,Radio} from 'antd';
const FormItem = Form.Item;
const { TextArea } = Input;
const RadioGroup = Radio.Group;

import activityConst from '../../cardConst';
import styles from '../../../../routes/newActivity/newActivity.less';


const activityTypes = activityConst.activityTypes;

class ActivityPoster extends PureComponent{


  render(){
    const {
      brandName,
      brandNameFun,
      imageUrlAbstr,
      styles,
      action,
      handleChangeAbstract,
      formItemLayout,
      uploadButton1,
      form,
      isDefaultPoster,
      isDefaultPosterFun,
      handleChangeAbstractEs,
      photoUrls,
      uploadButtones,
      isOpen,
      helpNumFun,
      activityGetInfo,
      rules,
    } = this.props;
    return (
      <div>

        <FormItem {...formItemLayout} label="品牌名称">
          {form.getFieldDecorator('brandName', {
            initialValue:activityGetInfo.extraInfo?activityGetInfo.extraInfo.brandName:"",
            rules: [{ required: true, message: '请输入所属品牌' }],
          })(<Input
            placeholder="请输入所属品牌"
            maxLength="32"
            addonAfter={brandName ? `${brandName.length  }/32` : '0/32'}
            onChange={brandNameFun}
            value={brandName}
          />)}
        </FormItem>
        <FormItem {...formItemLayout} label="封面图片">
          {form.getFieldDecorator('coverUrl', {
            initialValue:imageUrlAbstr,
            rules: [{ required: true, message: '请上传封面图片' }],
          })(<Upload
            name="file"
            listType="picture-card"
            className={styles.antUpload}
            showUploadList={false}
            action={action}
            onChange={handleChangeAbstract}
          >
            {imageUrlAbstr ? (
              <img
                src={imageUrlAbstr}
                alt="avatar"
                style={{ width: '100px', height: '100px' }}
              />
            ) : uploadButton1}
          </Upload>)}

        </FormItem>
        <FormItem {...formItemLayout} label="海报图片">
          {form.getFieldDecorator('isDefaultPoster', {
            initialValue:activityGetInfo.extraInfo ? Number(activityGetInfo.extraInfo.isDefaultPoster): ' ',
            rules: [{ required: true, message: '请选择海报图片方式' }],
          })(<RadioGroup onChange={isDefaultPosterFun}>
              <Radio value={1}>自定义生成</Radio>
              <Radio value={0}>系统自动生成</Radio>
            </RadioGroup>,
          )}
        </FormItem>
        {
          isDefaultPoster === 1 ? (
            <FormItem {...formItemLayout} label="" style={{ marginLeft: '30%' }}>
              {form.getFieldDecorator('photoUrls', {
                initialValue:photoUrls,
                rules: [{ required: true, message: '请上传海报图片' }],
              })(<Upload

                name="file"
                listType="picture-card"
                className={styles.antUpload}
                showUploadList={false}
                action={action}
                onChange={handleChangeAbstractEs}
              >
                {photoUrls ? (
                  <img
                    src={photoUrls}
                    alt="avatar"
                    style={{ width: '100px', height: '100px' }}
                  />
                ) : uploadButtones}
              </Upload>)}
            </FormItem>
          ) : ''
        }
        <FormItem {...formItemLayout} label="助攻好友数">
          {form.getFieldDecorator('helpNum', {
            initialValue:activityGetInfo ? Number(activityGetInfo.extraInfo.helpNum): ' ',
            rules: [{ required: true, message: '请输入助攻好友数' }],
          })(<Input
            addonAfter="人"
            disabled={Number(isOpen) === 1}
            type="number"
            onChange={helpNumFun}
          />)}
        </FormItem>
        <FormItem {...formItemLayout} label="规则">
          {form.getFieldDecorator('rules',{
            initialValue:activityGetInfo ?activityGetInfo.extraInfo.rules: ' ',
          })(<TextArea
            placeholder="请输入规则"
            rows="4"
            onChange={rules}
          />)}
        </FormItem>
      </div>
    )
  }

}
export default ActivityPoster;
