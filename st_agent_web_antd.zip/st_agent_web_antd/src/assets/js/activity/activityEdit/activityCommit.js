/* eslint-disable prefer-destructuring */
import React, { PureComponent } from 'react';

import {Button,Row,Col,Input,Upload,Form,Radio,Table,Icon} from 'antd';
const FormItem = Form.Item;
const { TextArea } = Input;
const RadioGroup = Radio.Group;

import activityConst from '../../cardConst';
import styles from '../../../../routes/newActivity/newActivity.less';


const activityTypes = activityConst.activityTypes;

class ActivityCommit extends PureComponent{


  render(){
    const {
      brandName,
      brandNameFriend,
      imageUrlAbstr,
      styles,
      action,
      handleChangeAbstract,
      formItemLayout,
      uploadButton1,
      form,
      linkUrl,
      linkUrlFun,
      handleChangeAbstractEsMoment,
      partakeNotesFun,
      partakeNotes,
      dataSource,
      columns,
      handleAdd,
      photoUrlsArr,
      activityGetInfo,
      uploadButtones,
      deletePhotoUrl,
    } = this.props;
    return (
      <div>
        <FormItem {...formItemLayout} label="所属品牌">
          {form.getFieldDecorator('brandName',{
            initialValue:brandName,
          })(<Input
            placeholder="请输入所属品牌"
            maxLength="32"
            addonAfter={brandName ? `${brandName.length  }/32` : '0/32'}
            onChange={brandNameFriend}
          />)}
        </FormItem>
        <FormItem {...formItemLayout} label="文章链接">
          {form.getFieldDecorator('linkUrl',{
            initialValue: linkUrl,
          })(<Input
            maxLength="128"
            placeholder="请输入文章链接"
            addonAfter={linkUrl ? `${linkUrl.length  }/128` : '0/128'}
            onChange={linkUrlFun}
          />)}
        </FormItem>
        <FormItem {...formItemLayout} label="原价">
          {form.getFieldDecorator('originPrice', {
            initialValue:activityGetInfo ?activityGetInfo.extraInfo.originPrice : ' ',
            rules: [{ required: true, message: '请输入原价' }],
          })(<Input addonAfter="元/位" type="number"/>)}
        </FormItem>
        <FormItem {...formItemLayout} label="封面图片">
          {form.getFieldDecorator('coverUrl', {
            initialValue:imageUrlAbstr,
            rules: [{ required: true, message: '请上传封面图片' }],
          })(<Upload
              name="file"
              listType="picture-card"
              className={styles.antUpload}
              showUploadList={false}
              action={action}
              onChange={handleChangeAbstract}
            >
              {
                imageUrlAbstr ? (
                  <img
                    src={imageUrlAbstr}
                    alt="avatar"
                    style={{ width: '100px', height: '100px' }}
                  />) : uploadButton1}
            </Upload>,
          )}

        </FormItem>
        <FormItem {...formItemLayout} label="轮播图片">
          {form.getFieldDecorator('photoUrls', {
            initialValue:photoUrlsArr,
            rules: [{ required: true, message: '请上传封面图片' }],
          })(
            <div>
              <ul style={{listStyle:"none",marginLeft:"-40px",float:"left",marginRight:"10px"}}>
                {
                  photoUrlsArr?photoUrlsArr.map((item,index) => {
                    return(
                      <li style={{position:"relative",float:"left",marginRight:"10px"}}><img alt="" src={item} style={{width:100,height:100}} />
                        <span
                          onClick={() => deletePhotoUrl(index,item)}
                          style={{position: "absolute",
                            right: "15px"}}
                        ><Icon
                          type="close-circle"
                          style={{
                            float: 'right',
                            marginRight: '20px',
                            cursor: 'pointer',
                            position:"absolute",
                          }}
                        />
                                  </span>
                      </li>
                    )
                  }):""
                }
              </ul>
              <Upload
                name="file"
                listType="picture-card"
                className={styles.antUpload}
                showUploadList={false}
                action={action}
                onChange={handleChangeAbstractEsMoment}
              >
                {uploadButtones}
              </Upload>
            </div>)}

        </FormItem>
        <FormItem {...formItemLayout} label="参与方式">
          {form.getFieldDecorator('partakeNotes',{
            initialValue:activityGetInfo ? activityGetInfo.extraInfo.partakeNotes : ' ',
          })(<TextArea
            rows={4}
            onChange={partakeNotesFun}
            value={partakeNotes}
          />)}
        </FormItem>
        <FormItem {...formItemLayout} label="图文介绍">
          <Button onClick={handleAdd} type="primary" style={{ marginBottom: 16 }}>
            新增图文
          </Button>
          <Table
            bordered
            pagination={false}
            dataSource={dataSource}
            columns={columns}
          />
        </FormItem>
      </div>
    )
  }

}
export default ActivityCommit;
