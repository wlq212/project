/* eslint-disable prefer-destructuring */
import React, { PureComponent } from 'react';

import {Button,Row,Col,Input,Upload,Form,Radio,Table} from 'antd';

import activityConst from '../../cardConst';
import styles from '../../../../routes/newActivity/newActivity.less';

const FormItem = Form.Item;
const { TextArea } = Input;
const RadioGroup = Radio.Group;


const activityTypes = activityConst.activityTypes;

class ActivityGuess extends PureComponent{


  render(){
    const {
      imageUrlAbstr,
      styles,
      action,
      handleChangeAbstract,
      formItemLayout,
      uploadButton1,
      form,
      addSubjectList,
      beginTime,
      nowDate,
      CompareDate,
      subjectList,
      columnsSelect,
      dataSource,
      columns,
      handleAdd,
      isOpen,
      moment,
      activityGetInfo,
      rules,
    } = this.props;
    return (
      <div>
        <FormItem {...formItemLayout} label="封面图片">
          {form.getFieldDecorator('roleType', {
            initialValue:imageUrlAbstr,
            rules: [{ required: true, message: '请上传封面图片' }],
          })(<Upload
            name="file"
            listType="picture-card"
            className={styles.antUpload}
            showUploadList={false}
            action={action}
            disabled={Number(isOpen)=== 1}
            onChange={handleChangeAbstract}
          >
            {imageUrlAbstr ? (
              <img
                src={imageUrlAbstr}
                alt="avatar"
                style={{ width: '100px', height: '100px' }}
              />
            ) : uploadButton1}
          </Upload>)}
        </FormItem>
        <FormItem {...formItemLayout} label="竞猜选项">
          {form.getFieldDecorator('subjectList', {
            initialValue:subjectList,
            rules: [{ required: true, message: '请添加竞猜选项' }],
          })(
            <div>
              <Button onClick={addSubjectList} disabled={beginTime?CompareDate(nowDate,moment(beginTime).format('YYYY-MM-DD')):false}>
              添加选项
              </Button>
              <Table
                bordered
                disabled
                pagination={false}
                dataSource={subjectList}
                columns={columnsSelect}
              />
            </div>)}
        </FormItem>
        <FormItem {...formItemLayout} label="规则">
          {form.getFieldDecorator('rules',{
            initialValue:activityGetInfo ?activityGetInfo.extraInfo.rules : ' ',
          })(<TextArea
            placeholder="请输入规则"
            rows="4"
            onChange={rules}
          />)}
        </FormItem>
        <FormItem {...formItemLayout} label="图文介绍">
          {form.getFieldDecorator('dataSource',{
            initialValue:dataSource,
            rules: [{ required: true, message: '请添加竞猜选项' }],
          })(
            <div>
              <Button onClick={handleAdd} type="primary" style={{ marginBottom: 16 }} disabled={Number(isOpen)=== 1}>
                新增图文
              </Button>
              <Table
                bordered
                pagination={false}
                disabled={Number(isOpen)=== 1}
                dataSource={dataSource}
                columns={columns}
              />
            </div>)}
        </FormItem>
      </div>
    )
  }

}
export default ActivityGuess;
