/* eslint-disable prefer-destructuring */
import React, { PureComponent } from 'react';

import {Button,Row,Col,Input,Upload,Form,Radio} from 'antd';
const FormItem = Form.Item;
const { TextArea } = Input;
const RadioGroup = Radio.Group;

import activityConst from '../../cardConst';

const activityTypes = activityConst.activityTypes;

class ActivityDesk extends PureComponent{


  render(){
    const {
      imageUrlAbstr,
      action,
      handleChangeAbstractDesk,
      uploadButton2,
      imageUrlAbstrCoverUrl,
      handleChangeAbstractCoverUrl,
      uploadButton1,
      uploadButtones,
      handleChangeAbstractEsMoment,
      styles,
      form,
      formItemLayout,
      rules,
    } = this.props;
    return (
      <div>
        {/*<FormItem {...formItemLayout} label="海报图片">*/}
          {/*{form.getFieldDecorator('coverUrl', {*/}
            {/*initialValue:imageUrlAbstr,*/}
            {/*rules: [{ required: true, message: '请上传封面图片' }],*/}
          {/*})(<Upload*/}
            {/*name="file"*/}
            {/*listType="picture-card"*/}
            {/*className={styles.antUpload}*/}
            {/*showUploadList={false}*/}
            {/*action={action}*/}
            {/*onChange={handleChangeAbstractDesk}*/}
          {/*>*/}
            {/*{imageUrlAbstr ? (*/}
              {/*<img*/}
                {/*src={imageUrlAbstr}*/}
                {/*alt="avatar"*/}
                {/*style={{ width: '100px', height: '100px' }}*/}
              {/*/>*/}
            {/*) : uploadButton2}*/}
          {/*</Upload>)}*/}

        {/*</FormItem>*/}
        {/*<FormItem {...formItemLayout} label="封面图片">*/}
          {/*{form.getFieldDecorator('coverUrlOne', {*/}
            {/*initialValue: imageUrlAbstrCoverUrl,*/}
            {/*rules: [{ required: true, message: '请上传封面图片' }],*/}
          {/*})(<Upload*/}
            {/*name="file"*/}
            {/*listType="picture-card"*/}
            {/*className={styles.antUpload}*/}
            {/*showUploadList={false}*/}
            {/*action={action}*/}
            {/*onChange={handleChangeAbstractCoverUrl}*/}
          {/*>*/}
            {/*{imageUrlAbstrCoverUrl ? (*/}
              {/*<img*/}
                {/*src={imageUrlAbstrCoverUrl}*/}
                {/*alt="avatar"*/}
                {/*style={{ width: '100px', height: '100px' }}*/}
              {/*/>*/}
            {/*) : uploadButton1}*/}
          {/*</Upload>)}*/}
        {/*</FormItem>*/}
        <FormItem {...formItemLayout} label="活动图片">
          {form.getFieldDecorator('photoUrls', {
            rules: [{ required: true, message: '请上传活动图片' }],
          })(<Upload
            name="file"
            listType="picture-card"
            className={styles.antUpload}
            showUploadList
            action={action}
            multiple={true}
            onChange={handleChangeAbstractEsMoment}
          >
            {uploadButtones}
          </Upload>)}

        </FormItem>
        <FormItem {...formItemLayout} label="规则">
          {form.getFieldDecorator('rules')(<TextArea
            placeholder="请输入规则"
            rows="4"
            onChange={rules}
          />)}
        </FormItem>
      </div>
    )
  }

}
export default ActivityDesk;
