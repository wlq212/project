/* eslint-disable prefer-destructuring */
import React, { PureComponent } from 'react';

import {Button,Row,Col,Input,Upload,Form,Radio,Table} from 'antd';
const FormItem = Form.Item;
const { TextArea } = Input;
const RadioGroup = Radio.Group;

import activityConst from '../../cardConst';


const activityTypes = activityConst.activityTypes;

class ActivityMoment extends PureComponent{


  render(){
    const {
      titleFun,
      title,
      formItemLayout,
      form,
      rules,
      showModelTextNews,
    } = this.props;
    return (
      <div>
        <FormItem {...formItemLayout} label="文章标题">
          {form.getFieldDecorator('title', {
            initialValue:title,
            rules: [{ required: true, message: '请输入文章标题' }],
          })(
            <div style={{display:"flex"}}>
              <Input
                disabled
                placeholder="请输入文章标题"
                maxLength="64"
                addonAfter={title ? `${title.length  }/64` : '0/64'}
                onChange={titleFun}
                value={title}
              />
              <Button type='primary' style={{marginLeft:"20px"}} onClick={showModelTextNews}>选择图文</Button>

            </div>)}
        </FormItem>
        <FormItem {...formItemLayout} label="规则">
          {form.getFieldDecorator('rules')(<TextArea
            placeholder="请输入规则"
            rows="4"
            onChange={rules}
          />)}
        </FormItem>
      </div>
    )
  }

}
export default ActivityMoment;
