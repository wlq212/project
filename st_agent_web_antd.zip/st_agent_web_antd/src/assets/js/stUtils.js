import {keysIn,valuesIn,zipObject} from 'lodash';


// 递归参数
const recursiveParams = (params) => {
  const key = keysIn(params);
  const values = valuesIn(params);
  const value = [];
  for(let i=0;i<values.length;i++){
    if(values[i]==null || values[i]==='' || (Array === values[i].constructor && values[i].length===0)){
      key.splice(i,1);
      values.splice(i,1);
      if(i !== values.length){
        i--;
      }
    }else if(typeof(values[i]) === 'object' && Array === values[i].constructor){
        value.push(values[i]);
      }else if(typeof(values[i]) === 'object'){
        value.push(recursiveParams(values[i]));
      }else{
        const s = values[i].toString().replace(new RegExp("\"","gm"),"“");
        // let s = values[i];
        value.push(encodeURIComponent(s));
      }
  }
  return zipObject(key,value);
};

export default function stUtils(){
    const su = {};
    // 获取带参数的请求连接
    su.getReqStr = (params) => {
      const tmpParams = recursiveParams(params);
      const reqStr = `?reqStr=${ encodeURI(JSON.stringify(tmpParams))}`;
      return reqStr;
    };

    su.getReqJsonStr = (params) =>{
      const tmpParams = recursiveParams(params);
      const reqStr = `reqStr=${ encodeURI(JSON.stringify(tmpParams))}`;
      return reqStr;
    };

    // 是否为空判断
    su.dataIsNotEmpty = (a) => {
      if (a == null || a === '') {
        return false;
      } else {
        return true;
      }
    };

    return su;
  };


