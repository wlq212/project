/* eslint-disable prefer-destructuring */
import React, { PureComponent } from 'react';
import {Button,Row,Col,Input} from 'antd';
import StandardTable from '../../components/StandardTable';

class channelList extends PureComponent{


  render(){
    const {keywordList,selectedRows,loading,onSelectKeyWord,keyWordChange,getKeywordList,keywordFun} = this.props;
    const columns = [
      {
        title: '渠道名称',
        key: 'channelName',
        dataIndex: 'channelName',
      },
      {
        title: '类型',
        key: 'channelType',
        dataIndex: 'channelType',
        render: (text, record) => <span>{ types.map(item => {return record.channelType === item.value ? item.name : ''})}</span>,
      },
      {
        title: '所属活动',
        width: 200,
        key:"activityName",
        dataIndex:'activityName',
        render: (text, record) => <span>{record.activityName !== ""&&record.activityName != null ? record.activityName : '--'}</span>,
      },
      {
        title: '所属门店',
        key: 'shopName',
        dataIndex: 'shopName',
        render: (text, record) => <span>{record.shopName !== ""&&record.shopName != null ? record.shopName : '--'}</span>,
      },
      {
        title: '所属桌台',
        key: 'deskName',
        dataIndex: 'deskName',
        render: (text, record) => <span>{record.deskName !== ""&&record.deskName != null ? record.deskName : '--'}</span>,
      },
      {
        title: '关键词',
        key: 'keyword',
        dataIndex: 'keyword',
      },
      {
        title: '创建时间',
        key: 'createTime',
        dataIndex: 'createTime',
      },
      {
        title: '操作',
        width: 180,
        align:"right",
        fixed: 'right',
        render: (text, record) => (
          <Button type="primary" onClick={() => onSelectKeyWord(record)}>
            选中
          </Button>
        ),
      },
    ];
    return (
      <div>
        <Row>
          <Col xl={4} lg={4} md={4} sm={24} xs={24}>
            <Input placeholder="请输入关键词" style={{marginBottom:"10px"}} onChange={keywordFun} />
          </Col>
          <Col xl={2} lg={2} md={2} sm={24} xs={24}>
            <Button type={'primary'} style={{marginLeft:"10px"}} onClick={getKeywordList}>查询</Button>
          </Col>
        </Row>
        <StandardTable
          selectedRows={selectedRows}
          loading={loading}
          data={keywordList}
          columns={columns}
          onChange={keyWordChange}
        />
      </div>
    )
  }

}
export default channelList;
