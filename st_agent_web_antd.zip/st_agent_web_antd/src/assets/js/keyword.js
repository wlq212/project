/* eslint-disable prefer-destructuring */
import React, { PureComponent } from 'react';
import {Button,Row,Col,Input} from 'antd';
import StandardTable from '../../components/StandardTable';
import activityConst from './cardConst';

const activityTypes = activityConst.activityTypes;

class KeywordList extends PureComponent{


  render(){
    const { keywordList,selectedRows,loading,onSelectKeyWord,keyWordChange,getKeywordList,keywordFun} = this.props;
    const columns = [
      {
        title: '关键词',
        key: 'keyword',
        dataIndex: 'keyword',
      },
      {
        title: '类型',
        key: 'msgType',
        dataIndex: 'msgType',
        render: (text, record) => (
          <span>
            {record.msgType === 'text' ? '文本' : record.msgType === 'image' ? '图片' : '图文'}
          </span>
        ),
      },
      {
        title: '内容',
        width: `${40  }%`,
        key: 'content',
        dataIndex: 'content',
        render: (text, record) => (
          <div>
            {record.msgType === 'text' ? (
              <span style={{overflow:"hidden",
                display:"block",
                width:"300px",
                textOverflow:"ellipsis",
                whiteSpace:"nowrap",
              }}>{record.content}</span>
            ) : record.msgType === 'image' ? (
              <a href={record.picUrl} target="_blank" rel="noopener noreferrer">
                查看图片
              </a>
            ) : (
              <a href={record.url} target="_blank" rel="noopener noreferrer">
                查看图文
              </a>
            )}
          </div>
        ),
      },
      {
        title: '操作',
        width: 180,
        align:"right",
        fixed: 'right',
        render: (text, record) => (
          <Button type="primary" onClick={() => onSelectKeyWord(record)}>
            选中
          </Button>
        ),
      },
    ];
    return (
      <div>
        <Row>
          <Col xl={4} lg={4} md={4} sm={24} xs={24}>
            <Input placeholder="请输入关键词" style={{marginBottom:"10px"}} onChange={keywordFun} />
          </Col>
          <Col xl={2} lg={2} md={2} sm={24} xs={24}>
            <Button type={'primary'} style={{marginLeft:"10px"}} onClick={getKeywordList}>查询</Button>
          </Col>
        </Row>
        <StandardTable
          selectedRows={selectedRows}
          loading={loading}
          data={keywordList}
          columns={columns}
          onChange={keyWordChange}
        />
      </div>
    )
  }

}
export default KeywordList;
