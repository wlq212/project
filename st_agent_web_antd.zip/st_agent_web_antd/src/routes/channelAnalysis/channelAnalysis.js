/* eslint-disable no-unused-vars,react/destructuring-assignment,react/no-unused-state,class-methods-use-this,no-undef,no-shadow,react/sort-comp,prefer-destructuring,react/no-access-state-in-setstate */
import React, { Component, Fragment } from 'react';
import { connect } from 'dva';
import moment from "moment";
import {
  Row,
  Col,
  Icon,
  Card,
  Table,
  Radio,
  DatePicker,
  Tooltip,
  Modal,
  Input,
  Select,
  Checkbox,
  List,
  Button,
  Pagination,
  Form,
  } from 'antd';
import {
  ChartCard,
  yuan,
  MiniArea,
  MiniBar,
  MiniProgress,
  Field,
  Bar,
  Pie,
  TimelineChart,
} from 'components/Charts';
import StandardTable from 'components/StandardTable';
import { getTimeDistance } from '../../utils/utils';
import styles from './channelAnalysis.less';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import { dataCountChannelAnalysis } from '../../services/api';
import { getStore } from '../../assets/js/mUtils';

const { RangePicker } = DatePicker;
const Option = Select.Option;
const rankingListData = [];
for (let i = 0; i < 7; i += 1) {
  rankingListData.push({
    title: `工专路 ${i} 号店`,
    total: 323234,
  });
}
@connect(({ channelAnalysis, loading }) => ({
  channelAnalysis,
  loading: loading.models.channelAnalysis,
}))
export default class Analysis extends Component {
  constructor(props) {
    super(props);
    this.state = {
      salesType: '0',
      downModel: false,
      activityModel: false,
      channelModel: false,
      channel: '',
      activity:"",
      selectedRows: [],
      currentTabKey: '',
      numberName:"净关注人数",
      rateName:"净关注率",
      positionName:"netIncreaseNumber",
      position0:"date*netIncreaseNumber",
      positionName1:"netIncreaseRate",
      position1:"date*netIncreaseRate",
      formValues: {
        pageNo: 1,
        pageSize: 10,
      },
      formValuesActivity: {
        pageNo: 1,
        pageSize: 10,
      },
      initMap:[{
        cancelNumber:0,
        cancelRate: 0,
        date: "2018-08-24",
        goShopNumber: 0,
        netIncreaseNumber: 0,
        netIncreaseRate: 0,
        newNumber: 0,
        newRate: 0,
        oldNumber: 0,
        oldRate: 0,
        scanNumber: 0,
        scanRate: 0,
      }],
      search:{
        beginTime:getTimeDistance('month')[0].format('YYYY-MM-DD'),
        endTime:getTimeDistance('month')[1].format('YYYY-MM-DD'),
        channelType:"",
        sId:"",
        qrCodeId:"",
        pageNo:1,
        pageSize:10,
        dId:"",
        activityId:"",
      },
      rangePickerValue: getTimeDistance('month'),
    };
    this.handleDownCancel = this.handleDownCancel.bind(this);
    this.handleActivityCancel = this.handleActivityCancel.bind(this);
    this.handleChannelCancel = this.handleChannelCancel.bind(this);
    this.hanndleDownModelActivity=this.hanndleDownModelActivity.bind(this);
    this.hanndleDownModelChannel=this.hanndleDownModelChannel.bind(this);
    this.resetForm=this.resetForm.bind(this);
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'channelAnalysis/qrcodeListFetch',
      payload: this.state.formValues,
    });
    dispatch({
      type: 'channelAnalysis/fetchActivity',
      payload: this.state.formValuesActivity,
    });
    dispatch({
      type: 'channelAnalysis/shopList',
      payload: '',
    });
    dispatch({
      type: 'channelAnalysis/dataCountChannelAnalysisList',
      payload:this.state.search,
    })
  }

  pageOnChange=(pagination, filtersArg, sorter) =>{
    const {dispatch}=this.props;
    this.state.search.pageNo=pagination;
    this.state.search.pageSize=filtersArg;
    this.setState({
      search: this.state.search,
    });
    dispatch({
      type: 'channelAnalysis/dataCountChannelAnalysisList',
      payload:this.state.search,
    })
  };

  handleStandardTableChangeChannel = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    params.pageNo = pagination.current;
    params.pageSize = pagination.pageSize;
    this.setState({
      formValues: params,
    });
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'channelAnalysis/qrcodeListFetch',
      payload: params,
    });
  };

  showTooltip(tooltip,x,y){

  };

  handleChannelCancelActivity = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValuesActivity } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValuesActivity,
      ...filters,
    };
    params.pageNo = pagination.current;
    params.pageSize = pagination.pageSize;
    this.setState({
      formValuesActivity: params,
    });
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'channelAnalysis/fetchActivity',
      payload: params,
    });
  };

  // 下载模太框关闭
  handleDownCancel() {
    this.setState({
      downModel: false,
    });
  }

  handleActivityCancel() {
    this.setState({
      activityModel: false,
    });
  }

  hanndleDownModelActivity(){
    this.setState({
      activityModel: true,
    });
  }

  handleChannelCancel() {
    this.setState({
      channelModel: false,
    });
  }

  handleChannelSubmit() {

  }

  handleActivitySubmit() {

  }

  // 下载提交
  handleDownSubmit() {

  }

  showDownModel = () => {
    const {dispatch}=this.props;
    dispatch({
      type:"channelAnalysis/dataExportExcel",
      payload:this.state.search,
    })
  };

  showActivityModel = () => {
    this.setState({
      activityModel: true,
    });
  };

  hanndleDownModelChannel=()=>{
    this.setState({
      channelModel: true,
    });
  };

  showChannelModel = () => {
    this.setState({
      channelModel: true,
    });
  };


  handleChangeSalesType = e => {
    const that=this;
    switch (e.target.value) {
      case "0":
        that.setState({
          numberName:"净关注人数",
          rateName:"净关注率",
          positionName:"netIncreaseNumber",
          position0:"date*netIncreaseNumber",
          positionName1:"netIncreaseRate",
          position1:"date*netIncreaseRate",
        });
        break;
      case "1":
        that.setState({
          numberName:"到店关注人数",
          rateName:"净关注率",
          positionName:"goShopNumber",
          position0:"date*goShopNumber",
          positionName1:"netIncreaseRate",
          position1:"date*netIncreaseRate",
        });
        break;
      case "2":
        that.setState({
          numberName:"老关注人数",
          rateName:"老关注率",
          positionName:"oldNumber",
          position0:"date*oldNumber",
          positionName1:"oldRate",
          position1:"date*oldRate",
        });
        break;
      case "3":
        that.setState({
          numberName:"扫码关注人数",
          rateName:"扫码关注率",
          positionName:"scanNumber",
          position0:"date*scanNumber",
          positionName1:"scanRate",
          position1:"date*scanRate",
        });
        break;
      case "4":
        that.setState({
          numberName:"新增关注人数",
          rateName:"新增关注率",
          positionName:"newNumber",
          position0:"date*newNumber",
          positionName1:"newRate",
          position1:"date*newRate",
        });
        break;
      case "5":
        that.setState({
          numberName:"关注取消人数",
          rateName:"取消关注率",
          positionName:"cancelNumber",
          position0:"date*cancelNumber",
          positionName1:"cancelRate",
          position1:"date*cancelRate",
        });
        break;

    }
    this.setState({
      salesType: e.target.value,
    });
  };

  handleTabChange = key => {
    this.setState({
      currentTabKey: key,
    });
  };

  handleRangePickerChange = rangePickerValue => {
    this.setState({
      rangePickerValue,
    });
    const { dispatch } = this.props;
    if(rangePickerValue.length>0){
      this.state.search.beginTime=rangePickerValue[0].format('YYYY-MM-DD');
      this.state.search.endTime=rangePickerValue[1].format('YYYY-MM-DD');
      this.setState({
        search:this.state.search,
      });
      dispatch({
        type: 'channelAnalysis/dataCountChannelAnalysisList',
        payload:this.state.search,
      })
    }
  };



  selectActivity=(data)=> {
    const  {dispatch}=this.props;
    if(this.state.downModel){
      this.setState({
        modelActivity: data.activityName,
        activityModel:false,
      });
    }else{

      this.state.search.activityId=data.activityId
      this.setState({
        activity: data.activityName,
        search: this.state.search,
        activityModel:false,
      });
      dispatch({
        type: 'channelAnalysis/dataCountChannelAnalysisList',
        payload:this.state.search,
      })
    }
  };

  typeChange=(e)=>{
    const  {dispatch}=this.props;
    this.state.search.channelType=e;
    this.setState({
      type: e,
      search: this.state.search,
    });
    dispatch({
      type: 'channelAnalysis/dataCountChannelAnalysisList',
      payload:this.state.search,
    })
  };

  typeChangeModel=(e)=>{
    this.setState({
      typeModel: e,
    });
  };

  shopChangeModel=(e)=>{
    this.setState({
      shopModel: e,
    });
  };



  shopChange=(e)=>{
    const  {dispatch}=this.props;
    this.state.search.sId=e;
    this.setState({
      shop: e,
      search:this.state.search,
    });
    dispatch({
      type: 'channelAnalysis/dataCountChannelAnalysisList',
      payload:this.state.search,
    })
  };

  selectDate = type => {
    this.setState({
      rangePickerValue: getTimeDistance(type),
    });
    this.state.search.beginTime=getTimeDistance(type)[0].format('YYYY-MM-DD');
    this.state.search.endTime=getTimeDistance(type)[1].format('YYYY-MM-DD');
    const { dispatch } = this.props;
    this.setState({
      search:this.state.search,
    });
    dispatch({
      type: 'channelAnalysis/dataCountChannelAnalysisList',
      payload:this.state.search,
    });
  };

  isActive(type) {
    const { rangePickerValue } = this.state;
    const value = getTimeDistance(type);
    if (!rangePickerValue[0] || !rangePickerValue[1]) {
      return;
    }
    if (
      rangePickerValue[0].isSame(value[0], 'day') &&
      rangePickerValue[1].isSame(value[1], 'day')
    ) {
      return styles.currentDate;
    }
  }

  // 重置
  resetForm(){
    const {dispatch}=this.props;
    this.setState({
      activity:"",
      channel:"",
      search:{
        beginTime:getTimeDistance('week')[0].format('YYYY-MM-DD HH:mm:ss'),
        endTime:getTimeDistance('week')[1].format('YYYY-MM-DD HH:mm:ss'),
        channelType:"",
        sId:"",
        qrCodeId:"",
        pageNo:1,
        pageSize:10,
        dId:"",
        activityId:"",
      },
    })
    dispatch({
      type: 'channelAnalysis/dataCountChannelAnalysisList',
      payload:{
        beginTime:getTimeDistance('week')[0].format('YYYY-MM-DD HH:mm:ss'),
        endTime:getTimeDistance('week')[1].format('YYYY-MM-DD HH:mm:ss'),
        channelType:"",
        sId:"",
        qrCodeId:"",
        pageNo:1,
        pageSize:10,
        dId:"",
        activityId:"",
      },
    })
  }

  render() {
    const {dispatch}=this.props;
    const { rangePickerValue, salesType, selectedRows,initMap} = this.state;
    const { channelAnalysis, loading } = this.props;
    const salesExtra = (
      <div />
    );
    const selectChannel = (data) => {
      if(this.state.downModel){
        this.setState({
          modelChannel: data.channelName,
          channelModel:false,
        });
      }else{
        this.state.search.dId=data.dId;
        this.state.search.qrCodeId=data.qrCodeId;
        this.setState({
          channel: data.channelName,
          search:this.state.search,
          channelModel:false,
        });
        dispatch({
          type: 'channelAnalysis/dataCountChannelAnalysisList',
          payload:this.state.search,
        })
      }
    };
    const columnsChannel = [
      {
        title: '渠道名称',
        key: 'channelName',
        dataIndex: 'channelName',
      },
      {
        title: '所属活动',
        width: 200,
        key:"activityName",
        dataIndex:'activityName',
        render: (text, record) => <span>{record.activityName !== ""&&record.activityName != null ? record.activityName : '--'}</span>,
      },
      {
        title: '所属门店',
        key: 'shopName',
        dataIndex: 'shopName',
        render: (text, record) => <span>{record.shopName !== ""&&record.shopName != null ? record.shopName : '--'}</span>,
      },
      {
        title: '所属桌台',
        key: 'deskName',
        dataIndex: 'deskName',
        render: (text, record) => <span>{record.deskName !== ""&&record.deskName != null ? record.deskName : '--'}</span>,
      },
      {
        title: '操作',
        render(text, item) {
          return (<a onClick={() =>{selectChannel(item)}}>选择</a>);
        },
      },
    ];
    const columnsActivity = [
      {
        title: '活动名称',
        key: 'activityName',
        dataIndex: 'activityName',
      },
      {
        title: '活动类型',
        key: 'type',
        render: (text, record) => (
          <span>{record.type === 4 ? '答题' : record.type === 3 ? '竞猜' : record.type === 2 ? '朋友圈转发抽奖' : record.type === 1 ? '文章评论抽奖' : record.type === 0 ? '积分海报' : ''}</span>
        ),
      },
      {
        title: '创建时间',
        key: 'createTime',
        dataIndex: 'createTime',
      },
      {
        title: '中奖/参与人数',
        key: 'prizeCount',
        render: (text, record) => (
          <span>{`${record.prizeSize}/${record.userSize}人`}</span>
        ),
      },
      {
        title: '状态',
        key: 'state',
        dataIndex: 'state',
        render: (text, record) => (
          <span>{record.state === 1 ? '有效' : '无效'}</span>
        ),
      },
      {
        title: '操作',
        key: 'id',
        align: 'right',
        fixed: 'right',
        render: (text, record) => (
          <a onClick={()=>{this.selectActivity(record)}}>选择</a>
        ),
      },
    ];

    const columns = [{
      title: '日期',
      width: '10%',
      key:"date",
      dataIndex: 'date',

    }, {
      width: '7%',
      title: '到店人数',
      key:"goShopNumber",
      dataIndex: 'goShopNumber',
    }, {
      title: '扫码',
      width: '20%',
      key:"i",
      children: [
        {
          title: '扫码人数',
          key:"scanNumber",
          dataIndex: 'scanNumber',
        },
        {
          title: '扫码率',
          key:"scanRate",
          dataIndex: 'scanRate',
          render: (text) =>text?`${text}%`:"--",
        },
      ],
    }, {
      title: '老关注',
      key:"c",
      children: [
        {
          title: '老关注人数',
          key:"oldNumber",
          dataIndex: 'oldNumber',
        },
        {
          title: '老关注率',
          key:"oldRate",
          dataIndex: 'oldRate',
          render: (text) =>text?`${text}%`:"--",
        },
      ],
    },
      {
        title: '新增关注',
        key:"b",
        children: [
          {
            title: '新增关注人数',
            key:"newNumber",
            dataIndex: 'newNumber',
          },
          {
            title: '新增关注率',
            key:"newRate",
            dataIndex: 'newRate',
            render: (text)=>text?`${text}%`:"--",
          },
        ],
      }, {
        title: '关注后取消',
        key:"a",
        children: [
          {
            title: '取消关注人数',
            key:"cancelNumber",
            dataIndex: 'cancelNumber',
          },
          {
            title: '取消关注率',
            key:"cancelRate",
            dataIndex: 'cancelRate',
            render: (text) =>text?`${text}%`:"--",
          },
        ],
      },
      {
        title: '净增关注',
        key:"o",
        children: [
          {
            title: '净增关注人数',
            key:"netIncreaseNumber",
            dataIndex: 'netIncreaseNumber',
          },
          {
            title: '净增关注率',
            key:"netIncreaseRate",
            dataIndex: 'netIncreaseRate',
            render: (text) =>text?`${text}%`:"--",
          },
        ],
      }];
    const { Chart, Geom, Axis, Tooltip, Coord, Label, Legend, View, Guide, Shape } = window.BizCharts;
    const second = 1000;
    const minute = 1000 * 60;
    const hour = 60 * minute;
    const day = 24 * hour;

    function pick(data, field) {
      return data.map((item) => {
        const result = {};
        for (const key in item) {
          if (item.hasOwnProperty(key) && field.indexOf(key) !== -1) {
            result[key] = item[key];
          }
        }
        return result;
      });
    }
    const scale = {
        date: {
        alias: '日期',
        type: 'time',
        mask: 'YYYY-MM-DD',
       },
        netIncreaseNumber: {
          min: 0,
          alias: "净增关注人数",
        },
        cancelNumber:{
          min: 0,
          alias: "取消关注人数",
        },
        netIncreaseRate:{
          min:0,
          alias:"净增关注率",
          formatter(value) {
            return `${value}%`;
          },
        },
        cancelRate:{
          min:0,
          alias:"取消关注率",
          formatter(value) {
            return `${value}%`;
          },
        },
        newNumber:{
          min: 0,
          alias:"新增关注人数",
        },
        oldNumber:{
          min: 0,
          alias:"老关注人数",
        },
        oldRate:{
          min:0,
          alias:"老关注率",
          formatter(value) {
            return `${value}%`;
          },
        },
        scanNumber:{
          min: 0,
          alias:"扫码人数",
        },
        goShopNumber:{
          min: 0,
          alias:"到店人数",
        },
        scanRate:{
          min:0,
          alias:"扫码关注率",
          formatter(value) {
            return `${value}%`;
          },
        },
        newRate:{
          min:0,
          alias:"新增关注率",
          formatter(value) {
            return `${value}%`;
          },
        },
    };

    const data=channelAnalysis.channelAnalysisList.list;
    const reqStr = {

    }
    if(this.state.search.activityId){
      reqStr.activityId = this.state.search.activityId;
    }
    if(this.state.search.dId){
      reqStr.dId = this.state.search.dId;
    }
      reqStr.beginTime = moment(this.state.search.beginTime).format("YYYY-MM-DD");
      reqStr.endTime = moment(this.state.search.endTime).format("YYYY-MM-DD");
    if(this.state.search.qrCodeId){
      reqStr.qrCodeId = this.state.search.qrCodeId;
    }
    if(this.state.search.sId){
      reqStr.sId = this.state.search.sId;
    }
    if(this.state.search.channelType){
      reqStr.channelType = this.state.search.channelType;
    }
    const url={};
    if(JSON.parse(getStore("userInfo"))) {
      url.url = `/api/admin/dataCount/exportExcel?reqStr=${JSON.stringify(reqStr)}&token=${JSON.parse(getStore("userInfo")).token}`;
    }
    return (
      <PageHeaderLayout title="">
        <Fragment>
          <List loading={loading}>
            <Card
              title={
                <div>
                  <div style={{overflow:"hidden"}}>
                    <div style={{ float: 'left', position: 'relative',marginRight:"10px" }}>
                      <Input placeholder="选择活动" defaultValue={this.state.activity} style={{ width: '200px',paddingRight:"30px",marginBottom:"10px"}} onClick={this.showActivityModel} />
                      <Icon type="down" style={{ position: 'absolute', right: '10px', marginTop: '10px' }} onClick={this.showActivityModel} />
                    </div>
                    <div style={{ float: 'left', position: 'relative',marginRight:"10px",marginBottom:"10px"}}>
                      <Input
                        placeholder="选择渠道"
                        defaultValue={this.state.channel}
                        style={{ width: '200px',paddingRight:"30px"}}
                        onClick={this.showChannelModel}
                      />
                      <Icon onClick={this.showChannelModel} type="down" style={{ position: 'absolute', right: '10px', marginTop: '10px' }} />
                    </div>
                    <Select placeholder="请选择门店" style={{ marginRight:"10px", width: '200px',float:"left",marginBottom:"10px" }} onChange={this.shopChange}>
                      <Option value="">请选择所属门店</Option>
                      {
                      channelAnalysis.shopList?channelAnalysis.shopList.map((item,index) => {
                        return(<Option key={index} value={item.sId}>{item.businessName}</Option>)
                      }):""
                    }
                    </Select>
                    <Select placeholder="请选择类型" defaultValue={this.state.type} style={{ marginRight:"10px", width: '200px',float:"left",marginBottom:"10px" }} onChange={this.typeChange}>
                      <Option value="">请选择类型</Option>
                      <Option value="0">普通</Option>
                      <Option value="1">WIFI</Option>
                      <Option value="2">发票</Option>
                      <Option value="3">支付</Option>
                      <Option value="4">点单</Option>
                      <Option value="5">排队</Option>
                      <Option value="6">活动-线上</Option>
                      <Option value="7">活动-线下</Option>
                      <Option value="8">活动动态</Option>
                      <Option value="9">其他</Option>
                    </Select>

                    <Button type="primary" style={{marginRight:"10px",float:"left"}} onClick={this.resetForm}>重置</Button>
                  </div>
                  <div className={styles.salesExtraWrap}>
                    <div className={styles.salesExtra} style={{display:"block",marginTop:"10px"}}>
                      <RangePicker
                        style={{float:"left",marginBottom:"10px"}}
                        value={rangePickerValue}
                        onChange={this.handleRangePickerChange}

                        disabledDate={current => {
                          return current.isAfter();
                        }}
                      />
                      <div style={{float:"left",marginBottom:"10px"}}>
                      <a className={this.isActive('week')} onClick={() => this.selectDate('week')}>
                        最近7天
                      </a>
                      <a className={this.isActive('selfMonth')} onClick={() => this.selectDate('selfMonth')}>
                        最近15天
                      </a>
                      <a className={this.isActive('month')} onClick={() => this.selectDate('month')}>
                        最近30天
                      </a>
                      </div>
                    </div>
                  </div>
                </div>
            }
              loading={loading}
              bordered={false}
              bodyStyle={{ padding: 0 }}
              extra={salesExtra}
            >
              <div className={styles.salesCard}>
                <Radio.Group
                  value={salesType}
                  onChange={this.handleChangeSalesType}
                  style={{ marginTop: '20px', marginLeft: '30px' }}
                >
                  <Radio.Button value="0">净增关注人数</Radio.Button>
                  <Radio.Button value="1">到店人数</Radio.Button>
                  <Radio.Button value="2">老关注人数</Radio.Button>
                  <Radio.Button value="3">扫码关注人数</Radio.Button>
                  <Radio.Button value="4">新增关注人数</Radio.Button>
                  <Radio.Button value="5">关注取消人数</Radio.Button>
                </Radio.Group>

                <Row>
                  <Col xl={24} lg={24} md={24} sm={24} xs={24}>
                    <div className={styles.salesBar} style={{ marginTop: '20px' ,width:"97%"}}>
                      {
                        <Chart
                          height={400}
                          padding={[20, 40, 80, 40]}
                          forceFit
                          scale={{ time: { sync: true } }}
                        >
                          <Tooltip />
                          <Legend />
                          <View
                            data={pick(data.length>0?data:initMap, ['date', this.state.positionName, this.state.positionName1])}
                            scale={scale}
                          >
                            <Axis name="time" grid={null} />
                            <Geom type="line" position={this.state.position0} color="#4FAAEB" size={3} shape="genre" />
                            <Geom
                              type="point"
                              shape="circle"
                              position={this.state.position0}
                              style={{
                            stroke: "#fff",
                            lineWidth: 1,
                          }}
                              size={4}
                            />
                            {
                            this.state.position1 ? (
                              <div>
                                <Geom
                                  type="line"
                                  position={this.state.position1}
                                  color="#9AD681"
                                  size={2}
                                  shape="genre"
                                />
                                <Geom
                                  type="point"
                                  position={this.state.position1}
                                  size={4}
                                  shape="circle"
                                  color="#9AD681"
                                  style={{
                                    stroke: "#fff",
                                    lineWidth: 1,
                                  }}
                                />
                              </div>

): ""
                          }
                          </View>
                        </Chart>
                    }
                      <div style={{width:"400px",marginLeft:"40%",marginTop:"-40px"}}>
                        <span><span style={{display:"inline-block",height:"10px",width:"40px",background:"#4FAAEB",marginRight:"10px"}} />{this.state.numberName}</span>
                        {
                        this.state.rateName?<span><span style={{display:"inline-block",height:"10px",width:"40px",background:"#9AD681",marginLeft:"40px",marginRight:"10px"}} />{this.state.rateName}</span>:""
                      }
                      </div>
                    </div>
                  </Col>
                </Row>
                <Row style={{ position: 'relative'}}>
                  <div style={{float:"right",marginRight:"30px"}}>
                    <a href={url.url} style={{display:"block",height:"40px",width:"70px",background:"#4FAAEB",textAlign:"center",lineHeight:"40px",color:"#fff",marginBottom:"10px",borderRadius:"5px"}}>导出excel</a>
                  </div>
                  <div style={{padding:"30px"}}>
                    <Table pagination={{defaultCurrent:this.state.search.pageNo,pageSize:10,pageNo:this.state.search.pageNo,showSizeChanger:true,showQuickJumper:true}} columns={columns} dataSource={channelAnalysis.channelAnalysisList.list?channelAnalysis.channelAnalysisList.list:[]} size="middle" bordered  />
                  </div>
                </Row>
              </div>
            </Card>
          </List>
        </Fragment>
        <Modal
          visible={this.state.downModel}
          title="数据下载"
          onOk={this.handleDownSubmit}
          onCancel={this.handleDownCancel}
        >
          <Form style={{ height: '250px' }}>
            <Form.Item style={{ position: 'relative' }}>
              <Checkbox>导出活动：</Checkbox>
              <Input defaultValue={this.state.modelActivity} style={{ width: '300px' }} onClick={this.hanndleDownModelActivity} />
              <Icon type="down" style={{ marginLeft: '-20px', marginTop: '15px', position: 'absolute' }} />
            </Form.Item>
            <Form.Item>
              <Checkbox>导出门店：</Checkbox>
              <Select style={{ width: '300px' }} placeholder="请选择门店" onChange={this.shopChangeModel}>
                <Option value="">请选择所属门店</Option>
                {
                  channelAnalysis.shopList?channelAnalysis.shopList.map((item,index) => {
                    return(<Option key={index} value={item.sId}>{item.businessName}</Option>)
                  }):""
                }
              </Select>
            </Form.Item>
            <Form.Item>
              <Checkbox>导出类型：</Checkbox>
              <Select style={{ width: '300px' }} placeholder="请选择类型" onChange={this.typeChangeModel}>
                <Option value="">请选择类型</Option>
                <Option value="">请选择类型</Option>
                <Option value="0">普通</Option>
                <Option value="1">WIFI</Option>
                <Option value="2">发票</Option>
                <Option value="3">支付</Option>
                <Option value="4">点单</Option>
                <Option value="5">排队</Option>
                <Option value="6">活动-线上</Option>
                <Option value="7">活动-线下</Option>
                <Option value="8">活动动态</Option>
                <Option value="9">其他</Option>
              </Select>
            </Form.Item>
            <Form.Item style={{ position: 'relative' }}>
              <Checkbox>导出渠道：</Checkbox>
              <Input defaultValue={this.state.modelChannel} style={{ width: '300px' }} onClick={this.hanndleDownModelChannel} />
              <Icon type="down" style={{ marginLeft: '-20px', marginTop: '15px', position: 'absolute' }} />
            </Form.Item>
          </Form>
        </Modal>

        <Modal
          visible={this.state.activityModel}
          title="活动列表"
          width="80%"
          onOk={this.handleActivitySubmit}
          onCancel={this.handleActivityCancel}
          footer={null}
        >
          <StandardTable
            loading={loading}
            selectedRows={selectedRows}
            data={channelAnalysis.activityList}
            columns={columnsActivity}
            onChange={this.handleChannelCancelActivity}
          />
        </Modal>

        <Modal
          visible={this.state.channelModel}
          title="渠道列表"
          width="80%"
          onOk={this.handleChannelSubmit}
          footer={null}
          onCancel={this.handleChannelCancel}
        >
          <StandardTable
            loading={loading}
            selectedRows={selectedRows}
            data={channelAnalysis.channelList}
            columns={columnsChannel}
            onChange={this.handleStandardTableChangeChannel}
          />
        </Modal>
      </PageHeaderLayout>
    );
  }


}
