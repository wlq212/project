/* eslint-disable no-param-reassign */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import {
  Form,
  Input,
  Select,
  Button,
  Card,
  Row,
  Col,
  message,
} from 'antd';
import {isUndefined,isArray} from 'lodash';
import styles from './tplSetting.less';
import PageHeaderLayout from '../../../layouts/PageHeaderLayout';

const FormItem = Form.Item;
const {Option} = Select;


@connect(({ tplSetting,pageManage, loading }) => ({
  tplSetting,pageManage,
  loading: loading.models.tplSetting,
}))
@Form.create()
export default class TemplateList extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      tplList:{
        tabs:[],
      },
    };
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  componentDidMount() {
    const { dispatch} = this.props;
    const that = this;
    const params = {
      pageNo: 1,
      pageSize: 99999,
    };
    dispatch({
      type: 'pageManage/pageList',
      payload: params,
    });
    dispatch({
      type: 'tplSetting/shopListFetch',
      payload: {pageNo:1,pageSize:1},
    });
    dispatch({
      type: 'tplSetting/miniTplList',
      payload:{},
    }).then(() => {
      const {tplSetting:{templateList}} = that.props;
      if(!isUndefined(templateList)&&templateList != null){
        that.setState({tplList:templateList})
      }else {
        that.setState({tplList:{
            backgroundColor:"#000000",
            navigationBarBackgroundColor:"#000000",
            tabs:[]}})
      }

    });
  }

  /**
   * 设置颜色
   * @param e
   * @param flag，为0是导航栏背景颜色navigationBarBackgroundColor，为1是背景颜色backgroundColor
   */
  setColor = (e,flag) => {
    const {tplList} = this.state;
    if(flag === 0){
      tplList.navigationBarBackgroundColor = e.target.value;
    }else {
      tplList.backgroundColor = e.target.value;
    }
    this.setState({tplList});
  };

  /**
   * 输入名称
   * @param e
   * @param index
   */
  setTabName = (e,index) => {
    const {tplList} = this.state;
    const that = this;
    tplList.tabs[index].tabName = e.target.value;
    that.setState({tabs:[...tplList.tabs]});
  };

  /**
   * 选择页面
   * @param e
   * @param index
   */
  selectPage = (e,index) => {
    const {pageManage:{data:{list}}} = this.props;
    const {tplList} = this.state;
    const that = this;
    list.forEach(i => {
      if(i.pageId === e){
        tplList.tabs[index].tabName = i.name.substring(0,4);
      }
    });
    tplList.tabs[index].pageId = e;
    that.setState({tabs:[...tplList.tabs]});
  };

  /**
   * 保存
   * @param e
   */
  handleSubmit = e => {
    e.preventDefault();
    const { form, dispatch} = this.props;
    const {tplList} = this.state;
    form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        values.tabs = [...tplList.tabs];
        if(!isUndefined(tplList.id)){
          values.id = tplList.id;
        }

        dispatch({
          type: 'tplSetting/miniTplSave',
          payload: values,
        }).then((result) => {
          if(result.code === "200") {
            message.success('提交成功！');
          }else{
            message.error(result.msg);
          }
        }).catch(error => {
          message.error(error.msg);
        })
      }
    });

  };


  /**
   * 新增tab
   */
  tabAdd = () => {
    const {tplList} = this.state;
    const that = this;
    tplList.tabs.push({id:tplList.tabs.length});
    tplList.tabs.forEach((item,i) => {
      item.id = i;
    });
    that.setState({tabs:[...tplList.tabs]});
  };

  /**
   * 删除tab
   * @param index
   */
  tabDelete = (index) => {
    const {tplList} = this.state;
    const that = this;
    tplList.tabs.splice(index,1);
    tplList.tabs.forEach((item,i) => {
      item.id = i;
    });
    that.setState({tabs:[...tplList.tabs]});
  };

  /**
   * 是否打开排队
   * @param e
   */
  deskChange = (e) => {
    const {tplList} = this.state;
    const that = this;
    tplList.isOpenDesk = e;
    that.setState({isOpenDesk:{...tplList.isOpenDesk}});
  };

  /**
   * 是否打开预约
   * @param e
   */
  appointmentChange = (e) => {
    const {tplList} = this.state;
    const that = this;
    tplList.isOpenAppointment = e;
    that.setState({isOpenAppointment:{...tplList.isOpenAppointment}});
  };

 // ;
  render() {
    const { submitting, form,pageManage,tplSetting:{shopList}} = this.props;
    const { getFieldDecorator} = form;
    const {tplList} = this.state;

    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 17 },
      },
    };
    const submitFormLayout = {
      wrapperCol: {
        xs: { span: 24, offset: 0 },
        sm: { span: 17, offset: 7 },
      },
    };

    return (
      <PageHeaderLayout>
        <Card bordered={false}>
          <Row className={styles.tplBd}>
            <Col className={styles.tplLeft}>
              <Form onSubmit={this.handleSubmit} hideRequiredMark style={{ marginTop: 8 }}>
                <FormItem {...formItemLayout} label="导航栏背景色">
                  {getFieldDecorator('navigationBarBackgroundColor')(
                    <span>
                      <Input type="color" style={{width:"35%",marginRight:20}} value={tplList.navigationBarBackgroundColor} onChange={e => this.setColor(e,0)} />
                      <Input placeholder="#000000" style={{width:"35%"}} value={tplList.navigationBarBackgroundColor} onChange={e => this.setColor(e,0)} />
                    </span>
                  )}
                </FormItem>

                <FormItem {...formItemLayout} label="导航栏标题色">
                  {getFieldDecorator('navigationBarTextStyle', {
                    initialValue:tplList.navigationBarTextStyle,
                    rules: [{ required: true, message: '请选择导航栏标题色' }] })(
                      <Select style={{ width: "35%" }}>
                        <Option value="white">白色</Option>
                        <Option value="black">黑色</Option>
                      </Select>
                  )}
                </FormItem>
                <FormItem {...formItemLayout} label="导航栏标题">
                  {getFieldDecorator('navigationBarTitleText', {
                    initialValue:tplList.navigationBarTitleText,
                    rules: [{ required: true, message: '导航栏标题' }],
                  })(<Input placeholder="导航栏标题" style={{ width:"35%" }} />)}
                </FormItem>
                <FormItem {...formItemLayout} label="窗口背景色">
                  {getFieldDecorator('backgroundColor')(
                    <span>
                      <Input type="color" value={tplList.backgroundColor} style={{width:"35%",marginRight: 20}} onChange={e => this.setColor(e,1)} />
                      <Input placeholder="#000000" value={tplList.backgroundColor} style={{width:"35%"}} onChange={e => this.setColor(e,1)} />
                    </span>
                  )}
                </FormItem>
                <FormItem {...formItemLayout} label="底部导航TAB">
                  {(<Button type="primary" onClick={() => this.tabAdd()} disabled={tplList.tabs.length > 3}>新增</Button>)}
                </FormItem>
                {isArray(tplList.tabs) && tplList.tabs.length > 0 ?
                  tplList.tabs.map((obj,index) => (
                    <FormItem {...submitFormLayout} key={obj.id}>
                      {(
                        <div>
                          <Select style={{width:"35%",marginRight:20}} onChange={(e) => this.selectPage(e,index)} value={obj.pageId}>
                            {(isArray(pageManage.data.list) && pageManage.data.list.length > 0)? pageManage.data.list.map((item) => <Option value={item.pageId} key={item.id}>{item.name}</Option>):""}
                          </Select>
                          <Input placeholder={`组${index+1}`} addonAfter={`${(obj.tabName != null && obj.tabName !== "")?obj.tabName.length:0}/4`} maxLength={4} style={{width:"35%",marginRight:20}} value={obj.tabName} onChange={e => this.setTabName(e,index)} />
                          <Button type="danger" onClick={() => this.tabDelete(index)}>删除</Button>
                        </div>
                      )}
                    </FormItem>
                  ))
                  :(<div />)
                }

                <FormItem {...formItemLayout} label="是否开启排队按钮">
                  {getFieldDecorator('isOpenDesk',{
                    initialValue:tplList.isOpenDesk,
                    rules: [{ required: true, message: '请选择是否开启排队' }] })(
                      <Select style={{ width: "35%" }} onChange={this.deskChange}>
                        <Option value={1}>是</Option>
                        <Option value={0}>否</Option>
                      </Select>
                  )}
                </FormItem>
                <FormItem {...formItemLayout} label="是否开启预约按钮">
                  {getFieldDecorator('isOpenAppointment',{
                    initialValue:tplList.isOpenAppointment,
                    rules: [{ required: true, message: '请选择是否开启预约' }] })(
                      <Select style={{ width: "35%" }} onChange={this.appointmentChange}>
                        <Option value={1}>是</Option>
                        <Option value={0}>否</Option>
                      </Select>
                  )}
                </FormItem>

                <FormItem {...submitFormLayout} style={{ marginTop: 32 }}>
                  <Button type="primary" htmlType="submit" loading={submitting}>
                    保存
                  </Button>
                </FormItem>
              </Form>
            </Col>
            <Col className={styles.tplRight}>
              <div className={styles.tplRightHd}>
                <div>
                  {
                    shopList?isArray(shopList.photoList) && shopList.photoList.length > 0 ? <img src={shopList.photoList[0]} alt={shopList.businessName} />  : "":""
                  }
                </div>
                <div style={{textAlign:"left",flex:1,marginLeft:20}}>
                  <div style={{fontSize:20}}><b>{shopList?shopList.businessName:""}</b></div>
                  <div>{shopList?shopList.recommend:""}</div>
                </div>
              </div>
              <div className={styles.tplRightBd}>
                <div>
                  <span className="iconfont icon-adress" />
                  <span style={{marginLeft:5}}>{shopList?shopList.city+shopList.district+shopList.address:""}</span>
                </div>
                {shopList?shopList.telephone != null && shopList.telephone !== "" ? <div style={{marginTop:10}}><span className="iconfont icon-tel" /><span style={{marginLeft:5}}>{shopList.telephone}</span></div> :"":""}
                {shopList?shopList.openTime != null && shopList.openTime!==""?<div style={{marginTop:10}}><span className="iconfont icon-home" /><span style={{marginLeft:5}}>{shopList.openTime}</span></div> :"":""}
                <div style={{marginTop:10}}>
                  <span className="iconfont icon-home" />
                  <span style={{marginLeft:5}}>其它门店</span>
                </div>
              </div>
              <div className={styles.tplRightFoot}>
                <div style={{marginTop:10}}>
                  {tplList.isOpenDesk === 1 ? <Button style={{marginRight:30}} type="primary">排队</Button> : ""}
                  {tplList.isOpenAppointment === 1 ? <Button type="primary">预约</Button> : ""}
                </div>
              </div>
            </Col>
          </Row>

        </Card>
      </PageHeaderLayout>
    );
  }
}
