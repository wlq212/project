/* eslint-disable no-unused-vars,no-unused-vars,react/no-unused-state,no-param-reassign,default-case,lines-between-class-members,react/sort-comp,array-callback-return,prefer-destructuring,react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Form,
  Input,
  Button,
  Card,
  message,
  Upload,
  Checkbox,
  Radio,
  Icon,
  } from 'antd';
const RadioGroup = Radio.Group;
import PageHeaderLayout from '../../../layouts/PageHeaderLayout';
import styles from '../common.less';
import {getStore} from '../../../assets/js/mUtils'

const CheckboxGroup = Checkbox.Group;
const FormItem = Form.Item;
const { TextArea } = Input;
function beforeUpload(file) {
  const isJPG = file.type === 'image/jpeg';
  if (!isJPG) {
    message.error('You can only upload JPG file!');
  }
  const isLt2M = file.size / 1024 / 1024 < 2;
  if (!isLt2M) {
    message.error('Image must smaller than 2MB!');
  }
  return isJPG && isLt2M;
}
@connect(({ pageManage, loading }) => ({
  pageManage,
  loading: loading.models.pageManage,
}))
@Form.create()
export default class BasicFormsOne extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      previewVisible: false,
      iconPath:"",
      previewImage: '',
      fileList:[],
      updateCheckbox:[],
      imageUrl:"",
      pageRefList:[],
      headerImage:"",
      loading: false,
      action: `/api/admin/file/upload?type=3&token=${JSON.parse(getStore("userInfo")).token}`,
      data:{
        type:3,
        token:JSON.parse(getStore("userInfo")).token,
      },
      headers: {
        authorization: 'authorization-text',
      },
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.checkboxOnchange = this.checkboxOnchange.bind(this)
  }

  handleCancel = () => this.setState({ previewVisible: false });
  componentDidMount() {
    const { dispatch} = this.props;
    dispatch({
      type: 'pageManage/wxGetTemplateList',
      payload:"",
    });
  }

  cancel= e => {
    e.preventDefault();
    const { dispatch} = this.props;
    dispatch(routerRedux.push('/setting/pageManage'));
  };

  handleSubmit = e => {
    e.preventDefault();
    const { form, dispatch} = this.props;
    form.validateFieldsAndScroll((err, values) => {
      values.iconPath=this.state.imageUrl;
      values.pageRefList=this.state.pageRefList;
      if(values.isDefaultIndex){
        values.isDefaultIndex=1;
      }else{
        values.isDefaultIndex=0;
      }
      if (!err) {
        dispatch({
          type: 'pageManage/pageAdd',
          payload: values,
        }).then((result) => {
          if(result){
            switch(result.code){
              case "200":
                message.success('添加成功');
                dispatch(routerRedux.push('/setting/pageManage'));
                break;
              case "500":
                message.error(result.msg);
                break;
            }
          }
        },(result) => {

        })
      }
    });

  };

  handleChange(info){

    if (info.file.status === 'uploading') {
      this.setState({ loading: true });
      return;
    }
    // console.log(info)
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.setState({
        imageUrl:info.file.response.obj,
        loading: false,
      });
    }
  }
;
  checkboxOnchange(e){
    const {pageManage} = this.props;
    const arrCheck=[];
    e.map((item) => {
      pageManage.TemplateList.map((item2) => {
        if(item2.template_id===item){
          arrCheck.push(item2)
        }
      })
    });
    this.setState({
      pageRefList:arrCheck,
    })

  }
;
  render() {
    const { submitting, form,pageManage,loading} = this.props;
    const uploadButton = (
      <div>
        <Icon type={this.state.loading ? 'loading' : 'plus'} />
        <div className="ant-upload-text">本地上传</div>
      </div>
    );
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 15 },
        md: { span: 10 },
      },
    };
    const submitFormLayout = {
      wrapperCol: {
        xs: { span: 24, offset: 0 },
        sm: { span: 10, offset: 7 },
      },
    };
    return (
      <PageHeaderLayout showReturn={true} url="/setting/pageManage">
        <Card bordered={false}>
          <Form onSubmit={this.handleSubmit} hideRequiredMark style={{ marginTop: 8 }}>
            <FormItem {...formItemLayout} label="名称">
              {form.getFieldDecorator('name', {
                rules: [{ required: true, message: '请输入名称' }],
              })(<Input placeholder="请输入名称" />)}
            </FormItem>
            <FormItem {...formItemLayout} label="类型">
              {form.getFieldDecorator('type', {
                rules: [{ required: true, message: '请输入类型' }],
              })(<RadioGroup>
                <Radio value={0}>基础页面</Radio>
                <Radio value={1}>入口页面</Radio>
                <Radio value={2}>普通页面</Radio>
              </RadioGroup>)}
            </FormItem>
            <FormItem {...formItemLayout} label="小程序路径">
              {form.getFieldDecorator('path', {
                rules: [{ required: true, message: '小程序路径' }],
              })(<Input placeholder="小程序路径" />)}
            </FormItem>
            <FormItem {...formItemLayout} label="图标">
              <div className="clearfix">
                <Upload
                  name="file"
                  listType="picture-card"
                  className={styles.antUpload}
                  showUploadList={false}
                  action={this.state.action}
                  beforeUpload={beforeUpload}
                  onChange={this.handleChange}
                >
                  {this.state.imageUrl ? <img src={this.state.imageUrl} alt="avatar" className={styles.antUpload} /> : uploadButton}
                </Upload>
              </div>
            </FormItem>
            <FormItem {...formItemLayout} label="是否首页">
              {form.getFieldDecorator('isDefaultIndex')(
                <Checkbox></Checkbox>
              )}
            </FormItem>
            <FormItem {...formItemLayout} label="功能描述">
              {form.getFieldDecorator('func')(<TextArea rows={4} />)}
            </FormItem>
            <FormItem {...submitFormLayout} style={{ marginTop: 32 }}>
              <Button type="primary" htmlType="submit" loading={loading}>
                提交
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.cancel}>取消</Button>
            </FormItem>
          </Form>
        </Card>
      </PageHeaderLayout>
    );
  }
}
