/* eslint-disable no-unused-vars,react/destructuring-assignment,react/no-unused-state,react/sort-comp,prefer-destructuring,no-shadow,no-case-declarations,default-case,no-underscore-dangle */
import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Select,
  Icon,
  Button,
  Alert,
  Modal,
  message,
  Divider,
} from 'antd';
import StandardTable from 'components/StandardTable';
import PageHeaderLayout from '../../../layouts/PageHeaderLayout';
import styles from '../common.less';
import { setStore,getStore} from '../../../assets/js/mUtils';

const FormItem = Form.Item;
const { Option } = Select;
const getValue = obj =>
  Object.keys(obj)
    .map(key => obj[key])
    .join(',');
const CreateForm = Form.create()(props => {
  const { modalVisible, form, handleAdd, handleModalVisible, handleChange } = props;
  const okHandle = () => {
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      handleAdd(fieldsValue);
    });
  };
  return (
    <Modal
      title="账号添加"
      visible={modalVisible}
      onOk={okHandle}
      onCancel={() => handleModalVisible()}
    >
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号类型" validateStatus="success">
        {form.getFieldDecorator('roleType', {
          rules: [{ required: true, message: '请选择账号类型' }],
        })(<Select
          style={{ width: 290 }}
          placeholder="请选择账号类型"
          optionFilterProp="children"
          onChange={handleChange}
        >
          <Option value="200">管理员</Option>
          <Option value="300">普通成员</Option>
        </Select>)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="品牌名称" validateStatus="success">
        {form.getFieldDecorator('brandName', {
          rules: [{ required: true, message: '请输入品牌名称' }],
        })(<Input placeholder="请输入品牌名称" id="brandNameOne" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号" validateStatus="success">
        {form.getFieldDecorator('userName', {
          rules: [{ required: true, message: '请输入账号' }],
        })(<Input placeholder="请输入账号" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="密码">
        {form.getFieldDecorator('pwd', {
          rules: [{ required: true, message: '请输入密码' }],
        })(<Input placeholder="请输入密码" type="password" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="微信号">
        {form.getFieldDecorator('city')(<Button type="primary">关联微信</Button>)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="手机号">
        {form.getFieldDecorator('city')(<Input placeholder="请输入手机号" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="城市">
        {form.getFieldDecorator('mobile')(<Input placeholder="请输入" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="状态">
        {form.getFieldDecorator('state', {
          rules: [{ required: true, message: '请选择状态' }],
        })(<Select
          style={{ width: 290 }}
          placeholder="请选择状态"
          optionFilterProp="children"
          onChange={handleChange}
        >
          <Option value="0">停用</Option>
          <Option value="1">正常</Option>
        </Select>)}
      </FormItem>
    </Modal>
  );
});

const CollectionCreateForm = Form.create({
  mapPropsToFields(props) {
    return {
      roleType: Form.createFormField(props.selectRowData.roleType),
      brandName: Form.createFormField(props.selectRowData.brandName),
      userName: Form.createFormField(props.selectRowData.userName),
      pwd: Form.createFormField(props.selectRowData.pwd),
      city: Form.createFormField(props.selectRowData.city),
      mobile: Form.createFormField(props.selectRowData.mobile),
      state: Form.createFormField(props.selectRowData.state),
    };
  },
})(
  class extends React.Component {
    render() {
      const { visible, onCancel, onCreate, form } = this.props;
      return (
        <Modal
          visible={visible}
          title="更新"
          okText="更新"
          onCancel={onCancel}
          onOk={onCreate}
        >
          <Form layout="vertical">
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号类型" validateStatus="success">
              {form.getFieldDecorator('roleType', {
                rules: [{ required: true, message: '请选择账号类型' }],
              })(<Select
                style={{ width: 290 }}
                placeholder="请选择账号类型"
                optionFilterProp="children"
              >
                <Option value="200">管理员</Option>
                <Option value="300">普通成员</Option>
              </Select>)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="品牌名称" validateStatus="success">
              {form.getFieldDecorator('brandName', {
                rules: [{ required: true, message: '请输入品牌名称' }],
              })(<Input placeholder="请输入品牌名称" id="brandNameOne" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号" validateStatus="success">
              {form.getFieldDecorator('userName', {
                rules: [{ required: true, message: '请输入账号' }],
              })(<Input placeholder="请输入账号" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="密码">
              {form.getFieldDecorator('pwd', {
                rules: [{ required: true, message: '请输入密码' }],
              })(<Input placeholder="请输入密码" type="password" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="微信号">
              {form.getFieldDecorator('city')(<Button type="primary">关联微信</Button>)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="手机号">
              {form.getFieldDecorator('city')(<Input placeholder="请输入手机号" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="城市">
              {form.getFieldDecorator('mobile')(<Input placeholder="请输入" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="状态">
              {form.getFieldDecorator('state', {
                rules: [{ required: true, message: '请选择状态' }],
              })(<Select
                style={{ width: 290 }}
                placeholder="请选择状态"
                optionFilterProp="children"
              >
                <Option value="0">停用</Option>
                <Option value="1">正常</Option>
              </Select>)}
            </FormItem>
          </Form>
        </Modal>
      );
    }
  },
);

@connect(({ pageManage, loading }) => ({
  pageManage,
  loading: loading.models.pageManage,
}))

@Form.create()
export default class TableList extends PureComponent {
  state = {
    visible: false,
    modalVisible: false,
    selectRowData: {},
    message: '',
    type: '',
    pageNo:1,
    modelTitle: '添加管理员',
    alertVisible: false,
    expandForm: false,
    selectedRows: [],
    formValues: {
      pageNo:1,
      pageSize:10,
    },
  };

  handleCancel = () => {
    this.setState({ visible: false });
  };

  handleCreate = () => {
    const form = this.formRef.props.form;
    form.validateFields((err) => {
      if (err) {
        return;
      }

      // console.log('Received values of form: ', values);
      form.resetFields();
      this.setState({ visible: false });
    });
  };

  saveFormRef = (formRef) => {
    this.formRef = formRef;
  };

  componentDidMount() {
    const { dispatch } = this.props;
    if(getStore("formValues")){
      dispatch({
        type: 'pageManage/pageList',
        payload: {
          ...getStore("formValues"),
        },
      });
    }else{
      const params = {
        pageNo: 1,
        pageSize: 10,
      };
      dispatch({
        type: 'pageManage/pageList',
        payload: params,
      });
    }
  }

  handleChange = flag => {

  };

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});
    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    params.pageNo=pagination.current;
    this.setState({
      formValues:params,
    })
    params.pageSize=pagination.pageSize;
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'pageManage/pageList',
      payload: params,
    });
  };

  handleFormReset = () => {
    const { form,dispatch} = this.props;
    form.resetFields();
    const params = {
      pageNo: 1,
      pageSize: 10,
    };
    dispatch({
      type: 'pageManage/pageList',
      payload: params,
    });
    this.setState({
      formValues:params,
    });
  };

  toggleForm = () => {
    const { expandForm } = this.state;
    this.setState({
      expandForm: !expandForm,
    });
  };

  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (!selectedRows) return;

    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'rule/remove',
          payload: {
            no: selectedRows.map(row => row.no).join(','),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
  };

  handleSearch = e => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      if(fieldsValue.name){
        fieldsValue.name=fieldsValue.name.replace(/\s/gi,'');
      }
      const values = {
        ...fieldsValue,
        pageNo: 1,
        pageSize: 10,
      };
      this.setState({
        formValues:values,
      });
      dispatch({
        type: 'pageManage/pageList',
        payload: values,
      });

    });
  };

  delete = rows => {
    const { dispatch } = this.props;
    const {formValues}=this.state;
    const confirm = Modal.confirm;
    confirm({
      title: '提示?',
      content: '确定要删除小程序页面吗？',
      onOk() {
        const params = {
          pageId: rows.pageId,
        };
        dispatch({
          type: 'pageManage/pageDelete',
          payload: params,
        }).then((result) => {
          if (result) {
            switch (result.code) {
              case '200':
                message.success('删除成功');
                const params = {
                  pageNo: formValues.pageNo,
                  pageSize: formValues.pageSize,
                };
                dispatch({
                  type: 'pageManage/pageList',
                  payload: params,
                });
                break;
              case '500':
                message.error(result.msg || '删除失败');
                break;
            }
          }
        }, (result) => {

        });

      },
      onCancel() {
      },
    });
  };

  add = () => {
    const { dispatch } = this.props;
    dispatch(routerRedux.push('/setting/pageManage/pageManageAdd'));

  };

  update = data => {
    const { dispatch } = this.props;
    dispatch({
      type: 'pageManage/updateParams',
      payload: data,
    });
    dispatch(routerRedux.push('/setting/pageManage/pageManageEidt'));
    setStore("formValues",this.state.formValues)

  };

  handleModalVisible = flag => {
    this.setState({
      modalTitle: '管理员添加',
      modalVisible: !!flag,
    });
  };

  handleClose = () => {
    this.setState({ alertVisible: false });
  };

  /*
  类型查询
  */
  typeSearch=e=>{
    const { dispatch } = this.props;
    this.state.formValues.type=e;
    dispatch({
      type: 'pageManage/pageList',
      payload: this.state.formValues,
    });
    this.setState({
      formValues:this.state.formValues,
    })
  };

  renderSimpleForm(data) {
    this._data = data;
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col  md={8} sm={24}>
            <FormItem label="页面类型">
              {getFieldDecorator('type')(
                <Select placeholder="请选择页面类型" onChange={this.typeSearch}>
                  <Option value="">请选择页面类型</Option>
                  <Option value="0">基础页面</Option>
                  <Option value="1">入口页面</Option>
                  <Option value="2">普通页面</Option>
                </Select>)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>

            <FormItem>
              {getFieldDecorator('name')(<Input placeholder="请输入页面名称" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <span className={styles.submitButtons}>
              <Button type="primary" htmlType="submit">
              查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
            重置
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }
  ;

  renderAdvancedForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="查询参数">
              {getFieldDecorator('name')(<Input placeholder="请输入页面名称" />)}
            </FormItem>
          </Col>
        </Row>
        <div style={{ overflow: 'hidden' }}>
          <span style={{ float: 'right', marginBottom: 24 }}>
            <Button type="primary" htmlType="submit">
                查询
            </Button>
            <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
              重置
            </Button>
            <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
              收起 <Icon type="up" />
            </a>
          </span>
        </div>
      </Form>
    );
  }
  ;

  renderForm(data) {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm(data);
  }
  ;

  render() {
    const { pageManage, loading } = this.props;
    const { selectedRows, modalVisible, alertVisible, message, type, modalTitle, selectRowData } = this.state;
    pageManage.data.pagination.current=this.state.formValues.pageNo;
    const data = pageManage.data;
    const columns = [
      {
        title: '页面名称',
        key: 'name',
        dataIndex: 'name',
      },
      {
        title: '页面类型',
        key: 'type',
        render: (text, record) => (
          <Fragment>
            <span>{record.type==0?"基础页面":record.type==1?"入口页面":"普通页面"}</span>
          </Fragment>
        ),
      },
      {
        title: '小程序路径',
        key: 'path',
        dataIndex: 'path',
      },
      {
        title: '功能描述',
        dataIndex: 'func',
        key: 'func',
      },
      {
        title: '操作',
        fixed:"right",
        align:"right",
        render: (text, record) => (
          <Fragment>
            <a onClick={() => this.update(record)}>编辑</a>
            <Divider type="vertical" />
            <a onClick={() => this.delete(record)}>删除</a>
          </Fragment>
        ),
      },
    ];
    const parentMethods = {
      handleAdd: this.handleAdd,
      handleModalVisible: this.handleModalVisible,
    };
    return (
      <PageHeaderLayout title="">
        {
          alertVisible ? (
            <Alert
              message={message}
              showIcon
              type={type}
              closable
              afterClose={this.handleClose
                }
            />
            ) :
            null
        }
        <Card bordered={false}>
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>
              {this.renderForm(pageManage)}
              <Button className={styles.buttonAddClass} type="primary" onClick={() => this.add()}>
                新建小程序页面
              </Button>
            </div>
            <div className={styles.tableListOperator}>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={data}
              columns={columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
            />
          </div>
        </Card>
        <CollectionCreateForm
          wrappedComponentRef={this.saveFormRef}
          visible={this.state.visible}
          onCancel={this.handleCancel}
          onCreate={this.handleCreate}
          selectRowData={selectRowData}
        />
        <CreateForm {...parentMethods} modalVisible={modalVisible} modalTitle={modalTitle} />
      </PageHeaderLayout>
    );
  }
}
