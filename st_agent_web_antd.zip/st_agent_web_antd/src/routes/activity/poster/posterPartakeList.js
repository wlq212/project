/* eslint-disable no-unused-vars,react/no-unused-state,no-undef,react/jsx-boolean-value */
import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Select,
  Icon,
  Button,
  Dropdown,
  Menu,
  InputNumber,
  DatePicker,
  message,
  } from 'antd';
import StandardTable from 'components/StandardTable';
import PageHeaderLayout from '../../../layouts/PageHeaderLayout';
import styles from '../TableList.less';

const FormItem = Form.Item;
const { Option } = Select;

/**
 * @return {null}
 */
function GetQueryString(name) {
  const reg = new RegExp(`(^|&)${  name  }=([^&]*)(&|$)`);
  const num = window.location.href.indexOf('?');
  const r = window.location.href.substr(num + 1).match(reg);
  if (r != null) return unescape(r[2]);
  return null;
};

@connect(({ poster, loading }) => ({
  poster,
  loading: loading.models.poster,
}))
@Form.create()
export default class TableList extends PureComponent {
  state = {
    modalVisible: false,
    expandForm: false,
    selectedRows: [],
    formValues: {},
  };

  componentDidMount() {
    const { dispatch } = this.props;
    const params = {
      posterId: GetQueryString('posterId'),
      pageNo: 1,
      pageSize: 10,
    };
    dispatch({
      type: 'poster/posterParticipationButton',
      payload: params,
    });
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      posterId: GetQueryString('posterId'),
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    this.setState({
      formValues:params,
    })
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }

    dispatch({
      type: 'poster/posterParticipationButton',
      payload: params,
    });
  };

  handleFormReset = () => {
    const { form,dispatch} = this.props;
    form.resetFields();
    const params = {
      posterId: GetQueryString('posterId'),
      pageNo: 1,
      pageSize: 10,
    };
    dispatch({
      type: 'poster/posterParticipationButton',
      payload: params,
    });
    this.setState({
      formValues:params,
    });

  };


  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (!selectedRows) return;

    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'rule/remove',
          payload: {
            no: selectedRows.map(row => row.no).join(','),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
  };

  handleSearch = e => {
    e.preventDefault();

    const { dispatch, form } = this.props;

    form.validateFields((err, fieldsValue) => {
      if (err) return;

      const values = {
        posterId: GetQueryString('posterId'),
        ...fieldsValue,
        pageSize: 10,
        pageNo: 1,
      };
     this.setState({
       formValues:values,
     })
      dispatch({
        type: 'poster/posterParticipationButton',
        payload: values,
      });
    });
  };

  handleModalVisible = flag => {
    this.setState({
      modalVisible: !!flag,
    });
  };

  // 助力明细
  posterDetaillist = rows => {
    const { dispatch } = this.props;
    dispatch(routerRedux.push(`/marketingManage/activity/poster/posterDetailList?referId=${  rows.pUserId}`));
  };

  handleAdd = fields => {
    const { dispatch } = this.props;
    dispatch({
      type: 'rule/add',
      payload: {
        description: fields.desc,
      },
    });

    message.success('添加成功');
    this.setState({
      modalVisible: false,
    });
  };

  renderSimpleForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={2} sm={24}>
            <FormItem>
              {getFieldDecorator('isPrize')(
                <Select style={{ width: 120 }} placeholder="请选择中奖状态">
                  <Option value="1">中奖</Option>
                  <Option value="0">未中奖</Option>
                </Select>)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="查询参数">
              {getFieldDecorator('nickName')(<Input placeholder="请输入要搜索的微信昵称" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <span className={styles.submitButtons}>
              <Button type="primary" htmlType="submit">
                查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                重置
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }

  renderAdvancedForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="规则编号">
              {getFieldDecorator('no')(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>,
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="调用次数">
              {getFieldDecorator('number')(<InputNumber style={{ width: '100%' }} />)}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="更新日期">
              {getFieldDecorator('date')(
                <DatePicker style={{ width: '100%' }} placeholder="请输入更新日期" />,
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status3')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>,
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status4')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>,
              )}
            </FormItem>
          </Col>
        </Row>
        <div style={{ overflow: 'hidden' }}>
          <span style={{ float: 'right', marginBottom: 24 }}>
            <Button type="primary" htmlType="submit">
              查询
            </Button>
            <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
              重置
            </Button>
            <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
              收起 <Icon type="up" />
            </a>
          </span>
        </div>
      </Form>
    );
  }

  renderForm() {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm();
  }

  render() {
    const {
      poster: { posterParticipation },
      loading,
    } = this.props;
    posterParticipation.pagination.current=this.state.formValues.pageNo;
    const { selectedRows} = this.state;
    const columns = [
      {
        title: '排名',
        dataIndex: 'id',
      },
      {
        title: '头像',
        dataIndex: 'subtitle',
        render: (text, record) => (
          <img alt="" src={record.headUrl} style={{ width: 40, height: 40 }} />
        ),
      },
      {
        title: '昵称',
        dataIndex: 'nickName',

      },
      {
        title: '主攻好友数',
        dataIndex: 'assistsFriendNum',
        render: (text, record) => (
          <span>{record.assistsFriendNum}次</span>
        ),
      },
      {
        title: '积分',
        dataIndex: 'voucherNumber',
        render: (text, record) => (
          <span>{record.integral}分</span>
        ),
      },
      {
        title: '中奖状态',
        render: (text, record) => (
          <span>{Number(record.isPrize)=== 0 ? '未中奖' : '中奖'}</span>
        ),
      },
      {
        title: '通知状态',
        render: (text, record) => (
          <span>{Number(record.isPrize) === 1 ? Number(record.isPrize) === 1 ? '通知成功' : '' : '--'}</span>
        ),
      },
      {
        title: '参与时间',
        dataIndex: 'createTime',
      },
      {
        title: '操作',
        align:"right",
        fixed:"right",
        render: (text, record) => (
          <Fragment>
            <a onClick={() => this.posterDetaillist(record)}>助力明细</a>
          </Fragment>
        ),
      },

    ];

    const menu = (
      <Menu onClick={this.handleMenuClick} selectedKeys={[]}>
        <Menu.Item key="remove">删除</Menu.Item>
        <Menu.Item key="approval">批量审批</Menu.Item>
      </Menu>
    );

    return (
      <PageHeaderLayout title="" showReturn={true} url="/marketingManage/activity/poster">
        <Card bordered={false}>
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>{this.renderForm()}</div>
            <div className={styles.tableListOperator}>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                  <Dropdown overlay={menu}>
                    <Button>
                      更多操作 <Icon type="down" />
                    </Button>
                  </Dropdown>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={posterParticipation}
              columns={columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
            />
          </div>
        </Card>
      </PageHeaderLayout>
    );
  }
}
