/* eslint-disable prefer-destructuring,no-unused-vars,react/destructuring-assignment,no-case-declarations,default-case,react/sort-comp,react/jsx-props-no-multi-spaces,react/jsx-indent,react/jsx-closing-tag-location,react/jsx-boolean-value */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import {
  List,
  Card,
  Radio,
  Input,
  Modal,
  message,
  Icon,
  Button,
  DatePicker,
  Select,
  Dropdown,
  Menu,
  Avatar,
} from 'antd';

import PageHeaderLayout from '../../../layouts/PageHeaderLayout';
import styles from './commentUserList.less';
import { getStore, setStore } from '../../../assets/js/mUtils';

const {RangePicker} = DatePicker;

const { TextArea } = Input;
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;

function GetQueryString(name) {
  const reg = new RegExp(`(^|&)${  name  }=([^&]*)(&|$)`);
  const num = window.location.href.indexOf('?');
  const r = window.location.href.substr(num + 1).match(reg);
  if (r != null)
    return unescape(r[2]);
  return null;
};
@connect(({ comment, loading }) => ({
  comment,
  loading: loading.models.comment,
}))
export default class BasicList extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      modalVisible: false,
      content: '',
      sendCardState:"发送卡券",
      replayObj: {},
      searchParams: {
        pageNo: 1,
        pageSize: 10,
        aId: '',
        rowsSlectParams: {},
        startDate: '',
        endDate: '',
        commentType: '',
        isPrize: '',
      },
    };
    this.onChangeTime = this.onChangeTime.bind(this);
    this.radioChange = this.radioChange.bind(this);
    this.prizeSelelct = this.prizeSelelct.bind(this);
    this.handleOk = this.handleOk.bind(this);
  }

  componentDidMount() {
    const { dispatch } = this.props;
    const { searchParams } = this.state;
    dispatch({
      type: 'comment/commentUserListButton',
      payload: Object.assign(searchParams, { aId: GetQueryString('aId') }),
    });
  }

  onChangeTime(e, dateString) {
    const { dispatch } = this.props;
    const { searchParams } = this.state;
    dispatch({
      type: 'comment/commentUserListButton',
      payload: Object.assign(searchParams,
        {
          startDate: dateString[0],
          endDate: dateString[1],
        }),
    });
    this.setState({
      searchParams: Object.assign(searchParams,
        {
          startDate: dateString[0],
          endDate: dateString[1],
        }),
    });
  }

  prizeSelelct(e) {
    const { dispatch } = this.props;
    const { searchParams } = this.state;
    dispatch({
      type: 'comment/commentUserListButton',
      payload: Object.assign(searchParams, { isPrize: e }),
    });
    this.setState({
      searchParams: Object.assign(searchParams, { isPrize: e }),
    });
  }
  //分页


  radioChange(e) {
    const { dispatch } = this.props;
    const { searchParams } = this.state;
    searchParams.pageNo=1;
    dispatch({
      type: 'comment/commentUserListButton',
      payload: Object.assign(searchParams, { commentType: e.target.value }),
    });
    this.setState({
      searchParams: Object.assign(searchParams, { commentType: e.target.value }),
    });
  }

  handleOk = () => {
    const { dispatch } = this.props;
    const { searchParams } = this.state;
    this.setState({
      modalVisible: false,
    });
    const replyParams = {
      replyTxt: this.state.content,
      aUserId: this.state.replayObj.aUserId,
      msgDataId: GetQueryString('msgDataId'),
      userCommentId: this.state.replayObj.userCommentId,
    };
    dispatch({
      type: 'comment/replyCommentButton',
      payload: replyParams,
    }).then((result) => {
      if (result) {
        switch (result.code) {
          case '200':
            message.success('回复成功');
            dispatch({
              type: 'comment/commentUserListButton',
              payload: Object.assign(searchParams, { aId: GetQueryString('aId') }),
            });
            break;
          case '500':
            message.error(result.msg || '回复失败');
            break;
        }
      }
    });
  };

  handleCancel = () => {
    this.setState({
      modalVisible: false,
    });
  };

  replayComment = rows => {
    this.setState({
      content: rows.replyContent,
      replayObj: rows,
      modalVisible: true,
    });
  };

  handleContent(e) {
    const value = e.target.value;
    this.setState({
      content: value,
    });
  };

  setselect = (data) => {
    const confirm = Modal.confirm;
    const { searchParams } = this.state;
    const { dispatch } = this.props;
    confirm({
      title: '提示?',
      content: '确定要设置为精选吗？',
      onOk() {
        const response = dispatch({
          type: 'comment/commentUnmarkelectOrMarkelectButton',
          payload: {
            commentType: data.commentType===2?1:2,
            aUserId: data.aUserId,
            msgDataId: GetQueryString('msgDataId'),
            userCommentId: data.userCommentId,
          },
        });
        response.then((result) => {
          if (result) {
            switch (result.code) {
              case '200':
                message.success('设置成功');
                const params = {
                  pageNo: 1,
                  pageSize: 10,
                };
                dispatch({
                  type: 'comment/commentUserListButton',
                  payload: Object.assign(searchParams, { aId: GetQueryString('aId') }),
                });
                break;
              case '500':
                message.error(result.msg || '设置失败');
                break;
            }
          }
        }, (result) => {
          // console.log(result);
        });


      },
      onCancel() {
      },
    });
  };
  //一键发送中奖通知
  commentAwardPrizesButton=data=>{
    const { dispatch } = this.props;
    const { searchParams } = this.state;
    this.setState({
      sendCardState:"重新发送卡券",
    })
    dispatch({
      type: 'comment/commentAwardPrizesButton',
      payload:{
        aId:GetQueryString('aId'),
      },
    }).then(function(result) {
      switch(result.code){
        case "200":
          message.success("通知成功")
          dispatch({
            type: 'comment/commentUserListButton',
            payload: Object.assign(searchParams, { aId: GetQueryString('aId') }),
          });
          break;
        case "500":
          this.setState({
            sendCardState:0,
          })
          message.error("通知失败")
          break;
      }
    })
  }
  //发送中奖通知
  sendCard=data=>{
    const { dispatch } = this.props;
    const { searchParams } = this.state;
    this.setState({
      sendCardState:"重新发送卡券",
    })
    dispatch({
      type: 'comment/commentAgainNoticeButton',
      payload:{
        aId:GetQueryString('aId'),
        aUserId:data.aUserId,
        openId:data.openId,
      },
    }).then(function(result) {
      switch(result.code){
        case "200":
          message.success("通知成功")
          dispatch({
            type: 'comment/commentUserListButton',
            payload: Object.assign(searchParams, { aId: GetQueryString('aId') }),
          });
          break;
        case "500":
          message.error("通知失败")
          break;
      }
    })
  }
  syncComment=data=>{
    const { dispatch } = this.props;
    const { searchParams } = this.state;
    dispatch({
      type: 'comment/commentSyncCommentButton',
      payload:{
        aId:GetQueryString('aId'),
        msgDataId:GetQueryString('msgDataId'),
        begin:0,
      },
    }).then(function(result) {
      switch(result.code){
        case "200":
          message.success("同步成功")
          dispatch({
            type: 'comment/commentUserListButton',
            payload: Object.assign(searchParams, { aId: GetQueryString('aId') }),
          });
          break;
        case "500":
          message.error("同步失败")
          break;
      }

    })
  };
  setLuckDraw = data => {
    const confirm = Modal.confirm;
    const { searchParams } = this.state;
    const { dispatch } = this.props;
    // console.log(rowsSlectParams);
    confirm({
      title: '提示?',
      content: '确定要设置该用户中奖吗？',
      onOk() {
        const response = dispatch({
          type: 'comment/commentPrizeSetUpButton',
          payload: {
            isPrize: data.isPrize===0?1:0,
            isNotice: data.isNotice,
            aUserId: data.aUserId,
            msgDataId:GetQueryString("msgDataId"),
            userCommentId: data.userCommentId,
            replyTxt: "hhhh",
            openId: data.openId,
            prizeCount: GetQueryString("prizeCount"),
            aId: data.aId,
          },
        });
        response.then((result) => {
          if (result) {
            switch (result.code) {
              case '200':
                message.success('设置成功');
                dispatch({
                  type: 'comment/commentUserListButton',
                  payload: Object.assign(searchParams, { aId: GetQueryString('aId') }),
                });
                break;
              case '500':
                message.error(result.msg || '设置失败');
                break;
            }
          }
        }, (result) => {

        });


      },
      onCancel() {
      },
    });
  };

  rowsSlect = data => {
    this.setState({
      rowsSlectParams: data,
    });
  };

  render() {
    const {
      comment: { commentUserList },
      loading,
      dispatch,
    } = this.props;
    const {searchParams}=this.state;
    const changePage=(current,size)=>{
      searchParams.pageNo=current;
      searchParams.pageSize=size;
      this.setState({
        searchParams:searchParams,
      })
      dispatch({
        type: 'comment/commentUserListButton',
        payload: Object.assign(searchParams, { aId: GetQueryString('aId') }),
      });
      setStore("pageNo",current)
    }
    const extraContent = (
      <div className={styles.extraContent}>

        <RadioGroup defaultValue="" onChange={this.radioChange} >
          <RadioButton value="">全部</RadioButton>
          <RadioButton value="1">普通评论</RadioButton>
          <RadioButton value="2">精选评论</RadioButton>
        </RadioGroup>
        <Select defaultValue="" style={{ width: 120, margin: '0 5px' }} onChange={this.prizeSelelct}>
          <Option value="">中奖状态</Option>
          <Option value="1">中奖</Option>
          <Option value="0">未中奖</Option>
        </Select>
        <RangePicker onChange={this.onChangeTime} allowClear format="YYYY-MM-DD" />
        <Button type="primary" style={{marginLeft:"10px"}} onClick={this.commentAwardPrizesButton}>一键发送中奖通知</Button>
        <Button type="primary" style={{marginLeft:"10px"}} onClick={this.syncComment}>同步留言</Button>
      </div>
    );

    const paginationProps = {
      showSizeChanger: true,
      showQuickJumper: true,
      pageSize: 10,
      current:searchParams.pageNo,
      onChange:function(current,size){
        changePage(current,size)
      },
      onShowSizeChange:function(current, size){
        searchParams.pageNo=current;
        searchParams.pageSize=size;
        changePage(current,size)
      },
      total: commentUserList.pagination ? commentUserList.pagination.total : '',
    };

    return (
      <PageHeaderLayout showReturn={true} url="/marketingManage/activity/comment">
        <div className={styles.standardList}>
          <Card
            className={styles.listCard}
            bordered={false}
            title="评论列表"
            style={{ marginTop: 24 }}
            bodyStyle={{ padding: '0 32px 40px 32px' }}
            extra={extraContent}
          >
            <List
              size="large"
              rowKey="id"
              loading={loading}
              pagination={paginationProps}
              dataSource={commentUserList.list}
              renderItem={item => (
                <List.Item>
                  <List.Item.Meta
                    style={{marginTop:"-40px",float:"left"}}
                    avatar={<Avatar src={item.headImg} shape="square" size="large" />}
                    title={<a><h4>{item.nickName?item.nickName:"匿名网友"}{item.commentType===1?"":item.commentType===2?<span><Icon type="star" style={{color:"red",marginLeft:"10px"}} />精选</span>:""}{item.isPrize===1?<span><Icon type="star" style={{color:"red",marginLeft:"10px"}} />中奖</span>:""}</h4><a href={item.href} style={{color:"rgba(0, 0, 0, 0.45)"}}>{item.content}</a></a>}
                    description={item.replyContent?`回复内容:${item.replyContent?item.replyContent:"---"}`:""}
                  />
                  <div style={{marginTop:"80px",marginRight:"-200px"}}>
                    <a onClick={() => this.replayComment(item)} style={{marginTop:"20px",marginRight:"10px",display:"inline-block"}}>回复评论</a>
                    <a onClick={()=>this.setselect(item)} style={{marginRight:"10px"}}>{item.commentType!==2?'设置精选':'取消精选'}</a>
                    {item.isPrize===0&&item.isNotice!==1?<a onClick={()=>this.setLuckDraw(item)} style={{marginRight:"10px"}}>{item.isPrize===0&&item.isNotice!==1?'设置中奖':''}</a>:""}
                    {item.isPrize!==0&&item.isNotice!==1?<a onClick={()=>this.setLuckDraw(item)} style={{marginRight:"10px"}}>{item.isPrize!==0&&item.isNotice!==1?'取消中奖':''}</a>:""}
                    {item.isNotice===1&&item.isPrize!==0?<span style={{marginRight:"10px"}}>{item.isNotice===1&&item.isPrize!==0?'取消中奖':''}</span>:""}

                    {item.isPrize===1&&item.isNotice===0?<a  style={{marginRight:"10px"}}onClick={()=>this.sendCard(item)}>{item.isNotice===0?this.state.sendCardState:''}</a>:""}
                    {item.isNotice===1?<span style={{marginRight:"10px"}}>{item.isNotice===1?'已发送卡券':''}</span>:""}
                  </div>
                  <div><span>评论时间:</span><span>{item.createTime}</span></div>
                </List.Item>
              )}
            />
          </Card>
        </div>
        <Modal
          title="回复评论"
          visible={this.state.modalVisible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
          <TextArea rows={6} value={this.state.content} onChange={this.handleContent.bind(this)} />
        </Modal>
      </PageHeaderLayout>
    );
  }
}
