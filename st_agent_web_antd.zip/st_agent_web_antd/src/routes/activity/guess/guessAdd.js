/* eslint-disable no-unused-vars,react/no-unused-state,react/sort-comp,no-undef,react/destructuring-assignment,array-callback-return,react/no-access-state-in-setstate,no-empty,lines-between-class-members,no-plusplus,no-shadow,default-case,react/jsx-no-undef,react/jsx-boolean-value */
import React, { Fragment } from 'react';
import { connect } from 'dva';
import {
  Form,
  Input,
  Button,
  Modal,
  message,
  Row,
  Col,
  Card,
  DatePicker,
  Radio,
  Table,
  Upload,
  Icon,
  Popconfirm,
} from 'antd';
import { routerRedux } from 'dva/router';
import StandardTable from 'components/StandardTable';
import moment from 'moment';
import PageHeaderLayout from '../../../layouts/PageHeaderLayout';
import styles from '../style.less';
import { getStore } from '../../../assets/js/mUtils';

const FormItem = Form.Item;

const { TextArea } = Input;
const RadioGroup = Radio.Group;
const {RangePicker } = DatePicker;
@Form.create()
class Step2 extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      loading1: false,
      loading2: false,
      validTime: [],
      title: '',
      action: `/api/admin/file/upload?type=3&token=${getStore('userInfo')?JSON.parse(getStore('userInfo')).token:""}`,
      data: {
        type: 3,
        token:`${getStore('userInfo')?JSON.parse(getStore('userInfo')).token:""}`,
      },
      isDisplay: 1,
      selectedRows: [],
      subjectList: [],
      cardRefList: [],
      dataSourceSelect: [],
      dataSource: [],
    };
    this.handleAdd = this.handleAdd.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.showModel = this.showModel.bind(this);
    this.title = this.title.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
    this.onChangeTime = this.onChangeTime.bind(this);
    this.cancelRest = this.cancelRest.bind(this);
    this.addSubjectList = this.addSubjectList.bind(this);
    this.handleChangeAbstract = this.handleChangeAbstract.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  componentDidMount() {
    const myDate = new Date();
    const now = myDate.toLocaleDateString();
    this.setState({
      validTime: [moment(now).format('YYYY-MM-DD'), moment(now).format('YYYY-MM-DD')],
    });
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      title: this.state.title,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'guess/cardListButton',
      payload: params,
    });
  };

  title(e) {

    this.setState({
      title: e.target.value,
    });
  }

  handleAdd() {
    const { dataSource } = this.state;
    const newData = {
      imgUrl: '',
      content: '',
    };
    this.setState({
      dataSource: [...dataSource, newData],
    });
  }

  handleDelete = (key) => {
    const dataSource = [...this.state.dataSource];
    this.setState({ dataSource: dataSource.filter((item, index) => index !== key) });
  };

  handleCancel() {
    this.setState({
      visible: false,
    });
  }

  deletSelectedRows = rows => {
    const cardRefList = [...this.state.cardRefList];
    this.setState({ deletSelectedRows: cardRefList.filter(item => item.cardId !== rows.cardId) });

  };
  deleteColumnsSelect = key => {
    const dataSourceSelect = [...this.state.subjectList];
    this.setState({ subjectList: dataSourceSelect.filter((item, index) => index !== key) });
  };

  handleSearch() {
    const { dispatch } = this.props;
    const params = {
      title: this.state.title,
      pageSize: 10,
      pageNo: 1,
    };
    dispatch({
      type: 'guess/cardListButton',
      payload: params,
    });
  }

  renderForm() {
    return (
      <Form  layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={7} sm={24} style={{ margin: '-10px 0 10px 0' }}>
            <FormItem label="查询参数">
              <Input placeholder="请输入卡券标题" onChange={this.title} />
            </FormItem>
          </Col>
          <Col md={1} sm={24} style={{ margin: '-5px 0 10px 0' }}>
            <span className={styles.submitButtons}>
              <Button type="primary" onClick={this.handleSearch}>
              查询
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }

  selectCardList = rows => {
    const dataSource = [...this.state.cardRefList];
    if (dataSource.length === 0) {
      dataSource.push(rows);
      this.setState({
        cardRefList: dataSource,
        visible: false,
      });
    } else {
      dataSource.map((item) => {
        if (item.cardId !== rows.cardId) {
          dataSource.push(rows);
        } else {

        }
      });
    }
    this.setState({
      cardRefList:dataSource.distinct('cardId'),
      visible: false,
    });
  };

  handleTextKey = rows => {
    this.setState({
      key: rows,
    });
  };

  handleText = e => {
    this.state.dataSource[this.state.key].content = e.target.value;
    this.setState({
      dataSource: this.state.dataSource,
    });
  };

  showModel() {
    const { dispatch } = this.props;
    const params = {
      pageSize: 10,
      pageNo: 1,
    };
    dispatch({
      type: 'guess/cardListButton',
      payload: params,
    });
    this.setState({
      visible: true,
    });

  }

  handleChangeTab = info => {
    if (info.file.status === 'uploading') {
      this.setState({ loading2: true });
      return;
    }
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.state.dataSource[this.state.key].imgUrl = info.file.response.obj;
      this.setState({
        dataSource: this.state.dataSource,
        loading2: false,
      });
    }
  };

  handleChangeAbstract(info) {
    if (info.file.status === 'uploading') {
      this.setState({ loading1: true });
      return;
    }
    // console.log(info);
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.setState({
        imageUrlAbstr: info.file.response.obj,
        loading1: false,
      });
    }
  };

  onChangeTime(date, dateString) {
    this.setState({
      validTime: dateString,
    });
  };

  cancelRest() {
    const { dispatch } = this.props;
    dispatch(routerRedux.push('/marketingManage/activity/guess'));
  }

  addSubjectList() {
    const obj = {
      sNo: '',
      question: '',
    };
    this.state.subjectList.push(obj);
    this.setState({
      subjectList: [...this.state.subjectList],
    });
  }

  keyIndex(key) {
    this.setState({
      key,
    });
  }


  handleSubmit() {
    const { form, dispatch } = this.props;
    form.validateFieldsAndScroll((err, values) => {

      if (!err) {
        const cardList = this.state.cardRefList;
        const data = {
          title: values.title,
          cardList: [],
          endTime: moment(this.state.validTime[1], 'YYYY-MM-DD').valueOf() / 1000,
          beginTime: moment(this.state.validTime[0], 'YYYY-MM-DD').valueOf() / 1000,
          coverUrl: this.state.imageUrlAbstr,
          subjectList: this.state.subjectList,
          prizeCount: values.prizeCount,
          newsList: this.state.dataSource,
        };

        if (this.state.subjectList.length <= 0) {
          message.error('请添加竞选选项');
        }
        for (let i = 0; i < cardList.length; i++) {
          if ((values.prizeCount * cardList[i].getLimit) > cardList[i].skuQuantity) {
            message.error('中奖人数乘以限领数不能大于库存数？');
            return;
          }
        }
        const cards = [];
        cardList.forEach(i => {
          const cardOne = {
            cardId: i.cardId,
          };
          cards.push(cardOne);
        });
        data.cardRefList = cards;
        dispatch({
          type: 'guess/guessAddButton',
          payload: data,
        }).then((result) => {
          if (result) {
            switch (result.code) {
              case '200':
                message.success('添加成功');
                dispatch(routerRedux.push('/marketingManage/activity/guess'));
                break;
              case '500':
                message.error(result.msg);
                break;
            }
          }
        }, (result) => {

        });
      }
    });
  }

  sNo = (e) => {
    this.state.subjectList[+this.state.key].sNo = e.target.value;
    this.setState({
      subjectList: this.state.subjectList,
    });
  };

  question = (e) => {

    this.state.subjectList[+this.state.key].question = e.target.value;
    this.setState({
      subjectList: this.state.subjectList,
    });
  };

  render() {

    const { form, loading, guess: { saveCardList } } = this.props;
    const { dataSource, subjectList } = this.state;

    const columnsSelect = [
      {
        title: '选号',
        dataIndex: 'sNo',
        render: (text, record, index) => {
          return (
            <Input
              onChange={this.sNo}
              onFocus={() => {
              this.keyIndex(index);
            }}
            />
          );
        },
      },
      {
        title: '选题',
        dataIndex: 'question',
        render: (text, record, index) => {
          return (
            <Input
              onChange={this.question}
              onFocus={() => {
              this.keyIndex(index);
            }}
            />
          );
        },
      },
      {
        title: '答案',
        render: () => {
          return (
            <span>--</span>
          );
        },
      },
      {
        title: '操作',
        align:"right",
        fixed:"right",
        render: (text, record, index) => (
          <Fragment>
            <a onClick={() => this.deleteColumnsSelect(index)}>删除</a>
          </Fragment>
        ),
      },
    ];
    const columnsTab = [
      {
        title: '优惠券名称',
        key: 'title',
        dataIndex: 'title',
      },
      {
        title: '优惠券副标题',
        dataIndex: 'subtitle',
        key: 'subtitle',
      },
      {
        title: '操作',
        align:"right",
        fixed:"right",
        render: (text, record) => (
          <Fragment>
            <a onClick={() => this.selectCardList(record)}>选择</a>
          </Fragment>
        ),
      },
    ];
    const { selectedRows} = this.state;
    const uploadButton1 = (
      <div>
        <Icon type={this.state.loading1 ? 'loading' : 'plus'} />
        <div className="ant-upload-text">本地上传</div>
      </div>
    );
    const uploadButton2 = (
      <div>
        <Icon type={this.state.loading2 ? 'loading' : 'plus'} />
        <div className="ant-upload-text">本地上传</div>
      </div>
    );
    const columns = [{
      title: '图片',
      dataIndex: 'image_url',
      width: '30%',
      render: (text, record, index) => {
        return (
          <Upload
            name="file"
            listType="picture-card"
            className={styles.antUpload}
            showUploadList={false}
            action={this.state.action}
            beforeUpload={() => this.handleTextKey(index)}
            onChange={this.handleChangeTab}
          >
            {dataSource ? dataSource[index].imgUrl ? (
              <img
                src={dataSource[index].imgUrl}
                alt="avatar"
                style={{
              width: '100px',
              height: '100px',
            }}
              />
) : uploadButton2 : ''}
          </Upload>
        );
      },
    }, {
      title: '文字',
      dataIndex: 'text',
      render: (text, record, index) => {
        return (
          <TextArea
            rows={4}
            onChange={this.handleText}
            placeholder="请输入图片描述，最多输入512个中文"
            onFocus={() => this.handleTextKey(index)}
            maxLength="512"
          />
        );
      },
    }, {
      title: '操作',
      width: 50,
      dataIndex: '操作',
      align:"right",
      fixed:"right",
      render: (text, record, index) => {
        return (
          this.state.dataSource.length >= 1
            ? (
              <Popconfirm title="确定是否删除？" onConfirm={() => this.handleDelete(index)}>
                <a>删除</a>
              </Popconfirm>
            ) : null
        );
      },
    }];
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 },
        md: { span: 10 },
      },
    };
    const title = (e) => {
      this.setState({
        title: e.target.value,
      });
    };
    const rules = (e) => {
      this.setState({
        rules: e.target.value,
      });
    };
    const deleteCard = data => {
      const deletSelectedRows = [...this.state.cardRefList];
      this.setState({ cardRefList: deletSelectedRows.filter(item => item.cardId !== data.cardId) });

    };
    return (
      <PageHeaderLayout showReturn={true} url="/marketingManage/activity/guess">
        <Card bordered={false}>
          <Form layout="horizontal" className={styles.stepForm}>
            <FormItem {...formItemLayout} label="竞猜标题">
              {form.getFieldDecorator('title', {
                rules: [{ required: true, message: '请输入竞猜标题' }],
              })(<Input
                addonAfter={this.state.title ? `${this.state.title.length  }/64` : '0/64'}
                onChange={title}
                value={this.state.title}
              />)}
            </FormItem>
            <FormItem {...formItemLayout} label="封面图片">
              {form.getFieldDecorator('roleType', {
                rules: [{ required: true, message: '请上传封面图片' }],
              })(<Upload
                name="file"
                listType="picture-card"
                className={styles.antUpload}
                showUploadList={false}
                action={this.state.action}

                onChange={this.handleChangeAbstract}
              >
                {this.state.imageUrlAbstr ? (
                  <img
                    src={this.state.imageUrlAbstr}
                    alt="avatar"
                    style={{ width: '100px', height: '100px' }}
                  />
) : uploadButton1}
              </Upload>)}

            </FormItem>
            <FormItem {...formItemLayout} label="竞猜时间">
              {form.getFieldDecorator('times', {
                rules: [{ required: true, message: '请选择竞猜时间' }],
              })(<RangePicker
                onChange={this.onChangeTime}
                value={[moment(this.state.validTime[0], 'YYYY-MM-DD'), moment(this.state.validTime[1], 'YYYY-MM-DD')]}
              />)}
            </FormItem>
            <FormItem {...formItemLayout} label="中奖人数">
              {form.getFieldDecorator('prizeCount', {
                rules: [{ required: true, message: '请输入中奖人数' }],
              })(<Input addonAfter="人" type="number" />)}
            </FormItem>
            <FormItem {...formItemLayout} label="竞猜选项">
              {form.getFieldDecorator('subjectList', {
                rules: [{ required: true, message: '请添加竞猜选项' }],
              })(<div>
                <Button onClick={this.addSubjectList}>
                  添加选项
                </Button>
                <Table
                  bordered
                  pagination={false}
                  dataSource={subjectList}
                  columns={columnsSelect}
                />
              </div>)}
            </FormItem>
            <FormItem {...formItemLayout} label="优惠券">
              <Button onClick={this.showModel} style={{ marginBottom: 16 }}>
                关联卡券
              </Button>
              <ul>
                {
                  this.state.cardRefList ? this.state.cardRefList.map((item) => {
                    return (
                      <li style={{
                        overflow: 'hidden',
                        border: '1px solid #ddd',
                        padding: '10px',
                        display: 'flex',
                        fontSize: '12px',
                        marginLeft: '-40px',
                        position:"relative",
                        background: '#f2f2f0',
                      }}
                      >
                        <img
                          alt=""
                          src={item.logoUrl}
                          style={{
                          float: 'left',
                          width: 50,
                          height: 50,
                          borderRadius: '50%',
                          marginRight: '10px',
                        }}
                        />
                        <div style={{ float: 'left', marginTop: '-15px' }}>
                          <div style={{ height: 20 }}><span
                            style={{ fontWeight: 'bold' }}
                          >{item.title}
                                                      </span>({item.subtitle})
                          </div>
                          <div style={{ height: 20 }}>库存共{item.skuQuantity} 每人限领{item.getLimit}张</div>
                          <div
                            style={{ height: 20 }}
                          >使用时间:{moment(item.dateInfo.begin_timestamp * 1000).format('YYYY-MM-DD')} 至 {moment(item.dateInfo.end_timestamp * 1000).format('YYYY-MM-DD')}
                          </div>
                        </div>
                        <span onClick={() => deleteCard(item)}><Icon
                          type="close-circle"
                          style={{
                            position: 'absolute',
                            right:"10px",
                          cursor: 'pointer',
                        }}
                        />
                        </span>
                      </li>
                    );
                  }) : ''
                }

              </ul>
            </FormItem>
            <FormItem {...formItemLayout} label="活动规则">
              {form.getFieldDecorator('rules')(<TextArea rows={4} onChange={rules} value={this.state.rules} />)}
            </FormItem>
            <FormItem {...formItemLayout} label="图文介绍">
              <Button onClick={this.handleAdd} type="primary" style={{ marginBottom: 16 }}>
                新增图文
              </Button>
              <Table
                bordered
                dataSource={dataSource}
                pagination={false}
                columns={columns}
              />
            </FormItem>
            <FormItem {...formItemLayout} label="显示状态">
              {form.getFieldDecorator('isDisplay',
                {
                  initialValue: this.state.isDisplay,
                })(<RadioGroup value={this.state.isDisplay}>
                  <Radio value={1}>显示</Radio>
                  <Radio value={0}>隐藏</Radio>
                   </RadioGroup>)}
            </FormItem>
            <FormItem {...formItemLayout} label="">
              <div style={{ marginLeft: '70%', width: '400px' }}>
                <Button loading={loading} type="primary" style={{ marginBottom: 16, marginRight: 20 }} onClick={this.handleSubmit}>
                  提交
                </Button>
                <Button onClick={this.cancelRest}> 取消</Button>
              </div>
            </FormItem>
          </Form>
        </Card>
        <Modal
          title="卡券列表"

          visible={this.state.visible}
          footer={null}
          width="80%"
          onCancel={this.handleCancel}
        >
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>
              {this.renderForm()}
            </div>
            <div className={styles.tableListOperator}>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              data={saveCardList}
              loading={loading}
              columns={columnsTab}
              onChange={this.handleStandardTableChange}
            />
          </div>
        </Modal>
      </PageHeaderLayout>
    );
  }
}

export default connect(({ guess, loading }) => ({
  guess,
  loading: loading.models.guess,
}))(Step2);
