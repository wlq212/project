/* eslint-disable no-unused-vars,react/no-unused-state,react/destructuring-assignment,react/no-access-state-in-setstate,react/no-access-state-in-setstate,react/no-access-state-in-setstate,react/sort-comp,array-callback-return,no-empty,no-undef,no-plusplus,default-case,lines-between-class-members,react/jsx-boolean-value */
import React, { Fragment } from 'react';
import { connect } from 'dva';
import {
  Form,
  Input,
  Button,
  message,
  Modal,
  Row,
  Col,
  Card,
  Select,
  DatePicker,
  Radio,
  Table,
  Upload,
  Icon,
  Popconfirm,
} from 'antd';
import { routerRedux } from 'dva/router';
import StandardTable from 'components/StandardTable';
import moment from 'moment';
import PageHeaderLayout from '../../../layouts/PageHeaderLayout';
import styles from '../style.less';
import { getStore } from '../../../assets/js/mUtils';

const FormItem = Form.Item;

const { TextArea } = Input;
const RadioGroup = Radio.Group;

/**
 * @return {string}
 */
function GetQueryString(name) {
  const reg = new RegExp(`(^|&)${  name  }=([^&]*)(&|$)`);
  const num = window.location.href.indexOf('?');
  const r = window.location.href.substr(num + 1).match(reg);
  if (r != null) return unescape(r[2]);
  return null;
}
@Form.create()
class Step2 extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      visibleKeyWord: false,
      loading1: false,
      loading2: false,
      loading3: false,
      validTime: '',
      title: '',
      action: `/api/admin/file/upload?type=3&token=${getStore('userInfo')?JSON.parse(getStore('userInfo')).token:""}`,
      data: {
        type: 3,
        token:`${getStore('userInfo')?JSON.parse(getStore('userInfo')).token:""}`,
      },
      isDisplay: 1,
      photoUrls: [],
      selectedRows: [],
      selectedRowsKeyWord: [],
      subjectList: [],
      cardRefList: [],
      keyword: '',
      dataSourceSelect: [],
      dataSource: [],
    };
    this.handleAdd = this.handleAdd.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.showModel = this.showModel.bind(this);
    this.title = this.title.bind(this);
    this.keyword = this.keyword.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
    this.onChangeTime = this.onChangeTime.bind(this);
    this.cancelRest = this.cancelRest.bind(this);
    this.addSubjectList = this.addSubjectList.bind(this);
    this.handleChangeAbstract = this.handleChangeAbstract.bind(this);
    this.handleChangeAbstractEs = this.handleChangeAbstractEs.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.showModelKeyWord = this.showModelKeyWord.bind(this);
    this.handleCancelKeyWord = this.handleCancelKeyWord.bind(this);
    this.selectKeyWord = this.selectKeyWord.bind(this);
  }

  componentDidMount() {
    const { dispatch } = this.props;
    const myDate = new Date();
    const now = myDate.toLocaleDateString();
    this.setState({
      validTime: moment(now).format('YYYY-MM-DD'),
    });
    const that=this;
    // 初始化数据
    dispatch({
      type: 'moments/circleGetButton',
      payload: { cId: GetQueryString('cId') },
    }).then((result) => {
      if (result.code === '200') {
        that.setState({
          imageUrlAbstr: result.obj.coverUrl,
          originPrice:result.obj.originPrice,
          prizeCount:result.obj.prizeCount,
          keyword:result.obj.keyword,
          validTime:result.obj.deadline,
          linkUrl:result.obj.linkUrl,
          acName:result.obj.acName,
          photoUrls:result.obj.photoUrls.split(","),
          brandName:result.obj.brandName,
          partakeNotes:result.obj.partakeNotes,
          dataSource: result.obj.newsList,
          cardRefList: result.obj.cardList,
          isDisplay: result.obj.isDisplay,
        });
        that.setState({
          guessSelectGuessOne: result.obj,
        });
      }
    });

  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      title: this.state.title,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'moments/cardListButton',
      payload: params,
    });
  };

  handleStandardTableChangeKeyWord = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      keyword: this.state.keyword,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'moments/autoReplyListButton',
      payload: params,
    });
  };

  title(e) {

    this.setState({
      title: e.target.value,
    });
  }

  handleAdd() {
    const { dataSource } = this.state;
    const newData = {
      imgUrl: '',
      content: '',
    };
    this.setState({
      dataSource: [...dataSource, newData],
    });
  }

  handleDelete = (key) => {
    const dataSource = [...this.state.dataSource];
    this.setState({ dataSource: dataSource.filter((item, index) => index !== key) });
  };

  handleCancel() {
    this.setState({
      visible: false,
    });
  }

  handleCancelKeyWord() {
    this.setState({
      visibleKeyWord: false,
    });
  }

  deletSelectedRows = rows => {
    const cardRefList = [...this.state.cardRefList];
    this.setState({ deletSelectedRows: cardRefList.filter(item => item.cardId !== rows.cardId) });

  };

  keyword = e => {
    this.setState({
      keyword: e.target.value,
    });
  };
  handleSearch() {
    const { dispatch } = this.props;
    const params = {
      title: this.state.title,
      pageSize: 10,
      pageNo: 1,
    };
    dispatch({
      type: 'moments/cardListButton',
      payload: params,
    });
  }

  handleSearchKeyWord() {
    const { dispatch } = this.props;
    const params = {
      keyword: this.state.keyword,
      pageSize: 10,
      pageNo: 1,
    };
    dispatch({
      type: 'moments/autoReplyListButton',
      payload: params,
    });
  }

  renderForm() {
    return (
      <Form layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={7} sm={24} style={{ margin: '-10px 0 10px 0' }}>
            <FormItem label="查询参数">
              <Input placeholder="请输入卡券标题" onChange={this.title} />
            </FormItem>
          </Col>
          <Col md={1} sm={24} style={{ margin: '-5px 0 10px 0' }}>
            <span className={styles.submitButtons}>
              <Button type="primary" onClick={this.handleSearch}>
              查询
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }

  renderFormKeyWord() {
    return (
      <Form layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={7} sm={24} style={{ margin: '-10px 0 10px 0' }}>
            <FormItem label="查询参数">
              <Input placeholder="请输入关键词" onChange={this.keyword} />
            </FormItem>
          </Col>
          <Col md={1} sm={24} style={{ margin: '-5px 0 10px 0' }}>
            <span className={styles.submitButtons}>
              <Button type="primary" onClick={this.handleSearchKeyWord}>
              查询
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }

  selectCardList = rows => {
    const dataSource = [...this.state.cardRefList];
    if (dataSource.length === 0) {
      dataSource.push(rows);
      this.setState({
        cardRefList: dataSource,
        visible: false,
      });
    } else {
      dataSource.map((item) => {
        if (item.cardId !== rows.cardId) {
          dataSource.push(rows);
        } else {

        }
      });
    }
    this.setState({
      cardRefList:dataSource.distinct("cardId"),
      visible: false,
    });
  };

  // 选择关键词
  selectKeyWord = rows => {
    this.setState({
      visibleKeyWord: false,
      autoReplyId:rows.autoReplyId,
      keyword: rows.keyword,
    });
  };

  handleTextKey = rows => {
    this.setState({
      key: rows,
    });
  };

  handleText = e => {
    this.state.dataSource[this.state.key].content = e.target.value;
    this.setState({
      dataSource: this.state.dataSource,
    });
  };

  showModel() {
    const { dispatch } = this.props;
    const params = {
      pageSize: 10,
      pageNo: 1,
    };
    dispatch({
      type: 'moments/cardListButton',
      payload: params,
    });
    this.setState({
      visible: true,
    });

  }

  showModelKeyWord() {
    const { dispatch } = this.props;
    const params = {
      pageSize: 10,
      pageNo: 1,
    };
    dispatch({
      type: 'moments/autoReplyListButton',
      payload: params,
    });
    this.setState({
      visibleKeyWord: true,
    });

  }

  handleChangeTab = info => {
    if (info.file.status === 'uploading') {
      this.setState({ loading2: true });
      return;
    }
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.state.dataSource[this.state.key].imgUrl = info.file.response.obj;
      this.setState({
        dataSource: this.state.dataSource,
        loading2: false,
      });
    }
  };

  handleChangeAbstract(info) {
    if (info.file.status === 'uploading') {
      this.setState({ loading1: true });
      return;
    }
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.setState({
        imageUrlAbstr: info.file.response.obj,
        loading1: false,
      });
    }
  };

  handleChangeAbstractEs(info) {
    if (info.file.status === 'uploading') {
      this.setState({ loading3: true });
      return;
    }
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.setState({
        photoUrls: [...this.state.photoUrls, info.file.response.obj],
        loading3: false,
      });
    }
  };

  onChangeTime(date, dateString) {
    this.setState({
      validTime: dateString,
    });
  };

  cancelRest() {
    const { dispatch } = this.props;
    dispatch(routerRedux.push('/marketingManage/activity/moments'));
  }

  addSubjectList() {
    const obj = {
      sNo: '',
      question: '',
    };
    this.state.subjectList.push(obj);
    this.setState({
      subjectList: [...this.state.subjectList],
    });
  }
  /*
    表单提交
     */
  handleSubmit() {
    const { form, dispatch } = this.props;
    form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        const cardList = this.state.cardRefList;
        const data = {
          cardList: [],
          acName: values.acName,
          brandName: values.brandName,
          prizeCount: values.prizeCount,
          linkUrl: values.linkUrl,
          originPrice: values.originPrice,
          keyword: this.state.keyword,
          autoReplyId:this.state.autoReplyId,
          partakeNotes: values.partakeNotes,
          newsList: this.state.dataSource,
          deadline: this.state.validTime,
          coverUrl: this.state.imageUrlAbstr,
          photoUrls: this.state.photoUrls.toString(),
          isDisplay: values.isDisplay,
        };
        for (let i = 0; i < cardList.length; i++) {
          if ((values.prizeCount * cardList[i].getLimit) > cardList[i].skuQuantity) {
            message.error('中奖人数乘以限领数不能大于库存数？');
            return;
          }
        }
        const cards = [];
        cardList.forEach(i => {
          const cardOne = {
            cardId: i.cardId,
          };
          cards.push(cardOne);
        });
        data.cardRefList = cards;
        dispatch({
          type: 'moments/circleUpdate',
          payload: Object.assign(this.state.guessSelectGuessOne,data),
        }).then((result) => {
          if (result) {
            switch (result.code) {
              case '200':
                message.success('更新成功');
                dispatch(routerRedux.push('/marketingManage/activity/moments'));
                break;
              case '500':
                message.error(result.msg);
                break;
            }
          }
        }, (result) => {

        });
      }
    });
  }

  sNo = (e) => {
    this.state.subjectList[+this.state.key].sNo = e.target.value;
    this.setState({
      subjectList: this.state.subjectList,
    });
  };

  question = (e) => {

    this.state.subjectList[+this.state.key].question = e.target.value;
    this.setState({
      subjectList: this.state.subjectList,
    });
  };

  render() {

    const { form, loading, moments: { saveCardList, autoReplyList } } = this.props;
    const { dataSource} = this.state;
    const columnsTab = [
      {
        title: '优惠券名称',
        key: 'title',
        dataIndex: 'title',
      },
      {
        title: '优惠券副标题',
        dataIndex: 'subtitle',
        key: 'subtitle',
      },
      {
        title: '操作',
        align:"right",
        fixed:"right",
        render: (text, record) => (
          <Fragment>
            <a onClick={() => this.selectCardList(record)}>选择</a>
          </Fragment>
        ),
      },
    ];
    const columnsKeyWordTab = [
      {
        title: '关键词',
        key: 'keyword',
        dataIndex: 'keyword',
      },
      {
        title: '类型',
        key: 'msgType',
        render: (text, record) => (
          <span>
            {record.msgType === 'image'
              ? '图片'
              : record.msgType === 'news'
                ? '图文'
                : record.msgType === 'text'
                  ? '文本'
                  : ''}
          </span>
        ),
      },
      {
        title: '回复内容',
        width: 200,
        render: (text, record) => (
          <a
            className={styles.tdClass}
            href={
              record.msgType === 'image'
                ? record.picUrl
                : record.msgType === 'news'
                ? record.url
                : '#'
            }
          >
            {record.msgType === 'image'
              ? '查看图片'
              : record.msgType === 'news'
                ? '查看图文'
                : record.msgType === 'text'
                  ? record.content
                  : ''}
          </a>
        ),
      },
      {
        title: '状态',
        key: 'state',
        render: (text, record) => <span>{record.state === 0 ? '无效' : '有效'}</span>,
      },
      {
        title: '创建时间',
        dataIndex: 'createTime',
        key: 'createTime',
      },
      {
        title: '操作',
        width: 180,
        fixed: 'right',
        align:"right",
        render: (text, record) => (
          <Fragment>
            <a onClick={() => this.selectKeyWord(record)}>
              选择
            </a>
          </Fragment>
        ),
      },
    ];
    const { selectedRows, selectedRowsKeyWord } = this.state;
    const uploadButton1 = (
      <div>
        <Icon type={this.state.loading1 ? 'loading' : 'plus'} />
        <div className="ant-upload-text">本地上传</div>
      </div>
    );
    const uploadButton2 = (
      <div>
        <Icon type={this.state.loading2 ? 'loading' : 'plus'} />
        <div className="ant-upload-text">本地上传</div>
      </div>
    );
    const uploadButtones = (
      <div>
        <Icon type={this.state.loading3 ? 'loading' : 'plus'} />
        <div className="ant-upload-text">本地上传</div>
      </div>
    );
    const columns = [{
      title: '图片',
      dataIndex: 'image_url',
      width: '30%',
      render: (text, record, index) => {
        return (
          <Upload
            name="file"
            listType="picture-card"
            className={styles.antUpload}
            showUploadList={false}
            action={this.state.action}
            beforeUpload={() => this.handleTextKey(index)}
            onChange={this.handleChangeTab}
          >
            {dataSource ? dataSource[index].imgUrl ? (
              <img
                src={dataSource[index].imgUrl}
                alt="avatar"
                style={{
              width: '100px',
              height: '100px',
            }}
              />
) : uploadButton2 : ''}
          </Upload>
        );
      },
    }, {
      title: '文字',
      dataIndex: 'text',
      render: (text, record, index) => {
        return (

          <div>
            {form.getFieldDecorator('title', {
              initialValue: dataSource[index].content,
              rules: [{ required: true, message: '请输入图片描述，最多输入512个中文' }],
            })(
              <TextArea
                rows={4}
                onChange={this.handleText}
                placeholder="请输入图片描述，最多输入512个中文"
                onFocus={() => this.handleTextKey(index)}
                maxLength="512"
                value={dataSource[index].content}
              />
            )}
          </div>
        );
      },
    }, {
      title: '操作',
      width: 50,
      dataIndex: '操作',
      align:"center",
      fixed:"right",
      render: (text, record, index) => {
        return (
          this.state.dataSource.length >= 1
            ? (
              <Popconfirm title="确定是否删除？" onConfirm={() => this.handleDelete(index)}>
                <a>删除</a>
              </Popconfirm>
            ) : null
        );
      },
    }];
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 },
        md: { span: 10 },
      },
    };
    const acName = (e) => {
      this.setState({
        acName: e.target.value,
      });
    };
    const brandName = (e) => {
      this.setState({
        brandName: e.target.value,
      });
    };
    const linkUrl = (e) => {
      this.setState({
        linkUrl: e.target.value,
      });
    };
    const partakeNotes = (e) => {
      this.setState({
        partakeNotes: e.target.value,
      });
    };
    const deleteCard = data => {
      const deletSelectedRows = [...this.state.cardRefList];
      this.setState({ cardRefList: deletSelectedRows.filter(item => item.cardId !== data.cardId) });

    };
    const deletePhotoUrl=(index)=>{
      const arr=[...this.state.photoUrls];
      arr.splice(index,1)
      this.setState({
        photoUrls:arr,
      })
    }
    return (
      <PageHeaderLayout showReturn={true} url="/marketingManage/activity/moments">
        <Card bordered={false}>
          <Form layout="horizontal" className={styles.stepForm}>
            <FormItem {...formItemLayout} label="活动名称">
              {form.getFieldDecorator('acName', {
                initialValue:this.state.acName,
                rules: [{ required: true, message: '请输入活动名称' }],
              })(<Input
                placeholder="请输入活动名称"
                maxLength="64"
                addonAfter={this.state.acName ? `${this.state.acName.length  }/64` : '0/64'}
                onChange={acName}
                value={this.state.acName}
              />)}
            </FormItem>
            <FormItem {...formItemLayout} label="所属品牌">
              {form.getFieldDecorator('brandName', {
                initialValue:this.state.brandName,
                rules: [{ required: true, message: '请输入所属品牌' }],
              })(<Input
                placeholder="请输入所属品牌"
                maxLength="32"
                addonAfter={this.state.brandName ? `${this.state.brandName.length  }/32` : '0/32'}
                onChange={brandName}
                value={this.state.brandName}
              />)}
            </FormItem>
            <FormItem {...formItemLayout} label="封面图片">
              {form.getFieldDecorator('coverUrl', {
                initialValue: this.state.imageUrlAbstr,
                rules: [{ required: true, message: '请上传封面图片' }],
              })(<Upload
                name="file"
                listType="picture-card"
                className={styles.antUpload}
                showUploadList={false}
                action={this.state.action}
                onChange={this.handleChangeAbstract}
              >
                {this.state.imageUrlAbstr ? (
                  <img
                    src={this.state.imageUrlAbstr}
                    alt="avatar"
                    style={{ width: '100px', height: '100px' }}
                  />
) : uploadButton1}
              </Upload>)}

            </FormItem>
            <FormItem {...formItemLayout} label="轮播图片">
              {form.getFieldDecorator('photoUrls', {
                initialValue: this.state.photoUrls,
                rules: [{ required: true, message: '请上传封面图片' }],
              })(
                <div>
                  <ul style={{listStyle:"none",marginLeft:"-40px",float:"left",marginRight:"10px"}}>
                    {
                      this.state.photoUrls.map((item,index) => {
                         return(
                           <li style={{position:"relative",float:"left",marginRight:"10px"}}><img alt="" src={item} style={{width:100,height:100}} />
                             <span
                               onClick={() => deletePhotoUrl(index,item)}
                               style={{position: "absolute",
                               right: "15px"}}
                             ><Icon
                               type="close-circle"
                               style={{
                               float: 'right',
                               marginRight: '20px',
                               cursor: 'pointer',
                               position:"absolute",
                             }}
                             />
                             </span>
                           </li>
                         )
                      })
                    }
                  </ul>
                  <Upload
                    name="file"
                    listType="picture-card"
                    className={styles.antUpload}
                    showUploadList
                    action={this.state.action}
                    onChange={this.handleChangeAbstractEs}
                  >
                    {uploadButtones}
                  </Upload>
                </div>)}

            </FormItem>
            <FormItem {...formItemLayout} label="文章链接">
              {form.getFieldDecorator('linkUrl',{
                initialValue:this.state.linkUrl,
              })(<Input
                maxLength="128"
                placeholder="请输入文章链接"
                addonAfter={this.state.linkUrl ? `${this.state.linkUrl.length  }/128` : '0/128'}
                onChange={linkUrl}
                value={this.state.linkUrl}
              />)}
            </FormItem>
            <FormItem {...formItemLayout} label="报名截止时间">
              {form.getFieldDecorator('deadline', {
                initialValue:moment(this.state.validTime, 'YYYY-MM-DD'),
                rules: [{ required: true, message: '请选择报名截止时间' }],
              })(
                <DatePicker
                  showTime
                  format="YYYY-MM-DD HH:mm:ss"
                  placeholder="请选择时间"
                  onChange={this.onChangeTime}
                />
                )}
            </FormItem>
            <FormItem {...formItemLayout} label="中奖人数">
              {form.getFieldDecorator('prizeCount', {
                initialValue:this.state.prizeCount,
                rules: [{ required: true, message: '请输入中奖人数' }],
              })(<Input addonAfter="人" type="number" disabled />)}
            </FormItem>
            <FormItem {...formItemLayout} label="原价">
              {form.getFieldDecorator('originPrice', {
                initialValue:this.state.originPrice,
                rules: [{ required: true, message: '请输入原价' }],
              })(<Input addonAfter="元/位" type="number" />)}
            </FormItem>
            <FormItem {...formItemLayout} label="关键词">
              {form.getFieldDecorator('keyword',{
                initialValue:this.state.keyword,
              })(<div onClick={this.showModelKeyWord}><Select
                placeholder="请选择关键词"
                value={this.state.keyword}
              />
              </div>)}
            </FormItem>
            <FormItem {...formItemLayout} label="优惠券">
              {form.getFieldDecorator('prizeCount', {
                rules: [{ required: true, message: '请选择优惠券' }],
              })(
                <div>
                  <Button disabled onClick={this.showModel} style={{ marginBottom: 16 }}>
                    关联卡券
                  </Button>
                  <ul>
                    {
                      this.state.cardRefList ? this.state.cardRefList.map((item) => {
                        return (
                          <li style={{
                            overflow: 'hidden',
                            border: '1px solid #ddd',
                            padding: '10px',
                            display: 'flex',
                            fontSize: '12px',
                            marginLeft: '-40px',
                            position:"relative",
                            background: '#f2f2f0',
                          }}
                          >
                            <img
                              alt=""
                              src={item.logoUrl}
                              style={{
                              float: 'left',
                              width: 50,
                              height: 50,
                              borderRadius: '50%',
                              marginRight: '10px',
                            }}
                            />
                            <div style={{ float: 'left', marginTop: '-15px' }}>
                              <div style={{ height: 20 }}><span
                                style={{ fontWeight: 'bold' }}
                              >{item.title}
                                                          </span>({item.subtitle})
                              </div>
                              <div style={{ height: 20 }}>库存共{item.skuQuantity} 每人限领{item.getLimit}张</div>
                              <div
                                style={{ height: 20 }}
                              >使用时间:{moment(item.dateInfo.begin_timestamp * 1000).format('YYYY-MM-DD')} 至 {moment(item.dateInfo.end_timestamp * 1000).format('YYYY-MM-DD')}
                              </div>
                            </div>
                            <span onClick={() => deleteCard(item)}><Icon
                              type="close-circle"
                              style={{
                                position: 'absolute',
                                right:"10px",
                              cursor: 'pointer',
                            }}
                            />
                            </span>
                          </li>
                        );
                      }) : ''
                    }

                  </ul>
                </div>,
              )}
            </FormItem>
            <FormItem {...formItemLayout} label="参与方式">
              {form.getFieldDecorator('partakeNotes',{
                initialValue:this.state.partakeNotes,
              })(<TextArea
                rows={4}
                onChange={partakeNotes}
                value={this.state.partakeNotes}
              />)}
            </FormItem>
            <FormItem {...formItemLayout} label="图文介绍">
              <Button onClick={this.handleAdd} type="primary" style={{ marginBottom: 16 }}>
                新增图文
              </Button>
              <Table
                bordered
                pagination={false}
                dataSource={dataSource}
                columns={columns}
              />
            </FormItem>
            <FormItem {...formItemLayout} label="显示状态">
              {form.getFieldDecorator('isDisplay',
                {
                  initialValue: this.state.isDisplay,
                })(<RadioGroup value={this.state.isDisplay}>
                  <Radio value={1}>显示</Radio>
                  <Radio value={0}>隐藏</Radio>
                   </RadioGroup>)}
            </FormItem>
            <FormItem {...formItemLayout} label="">
              <div style={{ marginLeft: '70%', width: '400px' }}>
                <Button loading={loading} type="primary" style={{ marginBottom: 16, marginRight: 20 }} onClick={this.handleSubmit}>
                  提交
                </Button>
                <Button onClick={this.cancelRest}> 取消</Button>
              </div>
            </FormItem>
          </Form>
        </Card>
        <Modal
          title="卡券列表"

          visible={this.state.visible}
          footer={null}
          width="80%"
          onCancel={this.handleCancel}
        >
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>
              {this.renderForm()}
            </div>
            <div className={styles.tableListOperator}>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              data={saveCardList}
              loading={loading}
              columns={columnsTab}
              onChange={this.handleStandardTableChange}
            />
          </div>
        </Modal>
        <Modal
          title="关键词列表"

          visible={this.state.visibleKeyWord}
          footer={null}
          width="80%"
          onCancel={this.handleCancelKeyWord}
        >
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>
              {this.renderFormKeyWord()}
            </div>
            <div className={styles.tableListOperator}>
              {selectedRowsKeyWord.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRowsKeyWord}
              data={autoReplyList}
              loading={loading}
              columns={columnsKeyWordTab}
              onChange={this.handleStandardTableChangeKeyWord}
            />
          </div>
        </Modal>
      </PageHeaderLayout>
    );
  }
}

export default connect(({ moments, loading }) => ({
  moments,
  loading: loading.models.moments,
}))(Step2);
