/* eslint-disable no-unused-vars,react/sort-comp,no-undef,default-case,no-shadow,no-case-declarations,prefer-destructuring,react/no-unused-state,class-methods-use-this,react/jsx-boolean-value */
import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Select,
  Icon,
  Button,
  Dropdown,
  Menu,
  InputNumber,
  DatePicker,
  Modal,
  message,
  Divider,
} from 'antd';
import StandardTable from 'components/StandardTable';
import PageHeaderLayout from '../../../layouts/PageHeaderLayout';
import styles from '../TableList.less';

const FormItem = Form.Item;
const { Option } = Select;

/**
 * @return {string}
 */
function GetQueryString(name)
{
  const reg = new RegExp(`(^|&)${ name }=([^&]*)(&|$)`);
  const num= window.location.href.indexOf("?")
  const r = window.location.href.substr(num+1).match(reg);
  if(r!=null)return  unescape(r[2]); return null;
};
@connect(({moments , loading }) => ({
  moments,
  loading: loading.models.moments,
}))
@Form.create()
export default class TableList extends PureComponent {
  constructor(props) {
    super(props);
    this.state= {
      modalVisible: false,
      isOpen:"",
      expandForm: false,
      selectedRows: [],
      formValues: {},
    };
    this.cancelPrice = this.cancelPrice.bind(this);
    this.setPrice = this.setPrice.bind(this);
  }

  componentDidMount() {
    const { dispatch } = this.props;
    const params={
      cId:this.GetQueryString("cId"),
      pageNo:1,
      pageSize:10,
    };
    dispatch({
      type: 'moments/circleSelectParticipationButton',
      payload:params,
    });
  }

  GetQueryString(name)
  {
    const reg = new RegExp(`(^|&)${ name }=([^&]*)(&|$)`);
    const num= window.location.href.indexOf("?")
    const r = window.location.href.substr(num+1).match(reg);
    if(r!=null)return  unescape(r[2]); return null;
  }
;
  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      cId:this.GetQueryString("cId"),
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    params.pageNo= pagination.current;
    params.pageSize=pagination.pageSize;
    this.setState({
      formValues:params,
    })
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }

    dispatch({
      type: 'moments/circleSelectParticipationButton',
      payload:params,
    });
  };

  handleFormReset = () => {
    const { form,dispatch} = this.props;
    form.resetFields();
    const params={
      cId:this.GetQueryString("cId"),
      pageNo:1,
      pageSize:10,
    };
    dispatch({
      type: 'moments/circleSelectParticipationButton',
      payload:params,
    });
    this.setState({
      formValues:params,
    });

  };


  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (!selectedRows) return;

    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'rule/remove',
          payload: {
            no: selectedRows.map(row => row.no).join(','),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
  };

  handleSearch = e => {
    e.preventDefault();

    const { dispatch, form } = this.props;

    form.validateFields((err, fieldsValue) => {
      if (err) return;

      const values = {
        cId:this.GetQueryString("cId"),
        ...fieldsValue,
        pageSize:10,
        pageNo:1,
      };

      this.setState({
        cId:this.GetQueryString("cId"),
        formValues: values,
      });
      dispatch({
        type: 'moments/circleSelectParticipationButton',
        payload:values,
      });
    });
  };

  handleModalVisible = flag => {
    this.setState({
      modalVisible: !!flag,
    });
  };

  handleAdd = fields => {
    const { dispatch } = this.props;
    dispatch({
      type: 'rule/add',
      payload: {
        description: fields.desc,
      },
    });

    message.success('添加成功');
    this.setState({
      modalVisible: false,
    });
  };

  renderSimpleForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={4} sm={24}>
            <FormItem>
              {getFieldDecorator('isPrize')(
                <Select style={{ width: 120 }} placeholder="请选择中奖状态">
                  <Option value="1">中奖</Option>
                  <Option value="0">未中奖</Option>
                </Select>)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="查询参数">
              {getFieldDecorator('nickName')(<Input placeholder="请输入微信昵称" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <span className={styles.submitButtons}>
              <Button type="primary" htmlType="submit">
                查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                重置
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }

  renderAdvancedForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="规则编号">
              {getFieldDecorator('no')(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="调用次数">
              {getFieldDecorator('number')(<InputNumber style={{ width: '100%' }} />)}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="更新日期">
              {getFieldDecorator('date')(
                <DatePicker style={{ width: '100%' }} placeholder="请输入更新日期" />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status3')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status4')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <div style={{ overflow: 'hidden' }}>
          <span style={{ float: 'right', marginBottom: 24 }}>
            <Button type="primary" htmlType="submit">
              查询
            </Button>
            <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
              重置
            </Button>
            <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
              收起 <Icon type="up" />
            </a>
          </span>
        </div>
      </Form>
    );
  }

  renderForm() {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm();
  }

  isNoticeButton = row =>{
    const { dispatch } = this.props;
    const confirm = Modal.confirm;
    confirm({
      title: '提示?',
      content: '确定要重新通知吗？',
      onOk() {
          const params = {
            cId:GetQueryString("cId"),
            formId:row.formId,
            openId:row.openId,
            cUserId:row.cUserId,
          };
          dispatch({
            type: 'moments/circleAgainNoticeBtton',
            payload:params,
          }).then((result) => {
            if(result){
              switch(result.code){
                case "200":
                  message.success('重新通知成功');
                  const params={
                    cId:GetQueryString("cId"),
                    pageNo:1,
                    pageSize:10,
                  };
                  dispatch({
                    type: 'moments/circleSelectParticipationButton',
                    payload:params,
                  });
                  break;
                case "500":
                  message.error(result.msg||'重新通知失败');
                  break;
              }
            }
          })
      },
      onCancel() {},
    });
  };

  cancelPrice = row =>{

    const { dispatch } = this.props;
    const confirm = Modal.confirm;
    confirm({
      title: '提示?',
      content: '确定要取消中奖吗？',
      onOk() {
          const params = {
            isPrize:0,
            cUserId:row.cUserId,
            cId:GetQueryString("cId"),
          };
          dispatch({
            type: 'moments/circleIsPrizeButton',
            payload:params,
          }).then((result) => {
            if(result){
              switch(result.code){
                case "200":
                  message.success('取消中奖成功');
                  const params={
                    cId:GetQueryString("cId"),
                    pageNo:1,
                    pageSize:10,
                  };
                  dispatch({
                    type: 'moments/circleSelectParticipationButton',
                    payload:params,
                  });
                  dispatch({
                    type: 'moments/circleParticipationCountButton',
                    payload:params,
                  });
                  break;
                case "500":
                  message.error(result.msg||'取消中奖失败');
                  break;
              }
            }
          })
      },
      onCancel() {},
});

  };

  setPrice = row =>{
    const { dispatch } = this.props;
    const confirm = Modal.confirm;
    confirm({
      title: '提示?',
      content: '确定要设置中奖吗？',
      onOk() {
        const params = {
          isPrize:1,
          cUserId:row.cUserId,
          cId:GetQueryString("cId"),
        };
        dispatch({
          type: 'moments/circleIsPrizeButton',
          payload:params,
        }).then((result) => {
          if(result){
            switch(result.code){
              case "200":
                message.success('设置中奖成功');
                const params={
                  cId:GetQueryString("cId"),
                  pageNo:1,
                  pageSize:10,
                };
                dispatch({
                  type: 'moments/circleSelectParticipationButton',
                  payload:params,
                });
                dispatch({
                  type: 'moments/circleParticipationCountButton',
                  payload:params,
                });
                break;
              case "500":
                message.error(result.msg||'设置中奖失败');
                break;
            }
          }
        })
      },
      onCancel() {},
    });
  };

  /*
  系统随机抽奖
   */
  circlemoments(){
    const { dispatch} = this.props;
    const confirm = Modal.confirm;
    confirm({
      title: '提示?',
      content: '确定要系统随机抽奖吗？',
      onOk() {
        const params = {
          cId:GetQueryString("cId"),
        }
        dispatch({
          type: 'moments/circleLuckDrawButton',
          payload:params,
        }).then((result) => {
          if(result){
            switch(result.code){
              case "200":
                message.success('随机啊抽奖成功');
                const params={
                  cId:GetQueryString("cId"),
                  pageNo:1,
                  pageSize:10,
                };
                dispatch({
                  type: 'moments/circleSelectParticipationButton',
                  payload:params,
                });
                dispatch({
                  type: 'moments/circleParticipationCountButton',
                  payload:params,
                });
                break;
              case "500":
                message.error(result.msg||'随机抽奖失败');
                break;
            }
          }
        })
      },
      onCancel() {},
    });
  }

  // 发送中奖通知
  circleSendNotice(){
    const { dispatch } = this.props;
    const confirm = Modal.confirm;
    confirm({
      title: '提示?',
      content: '确定要发送中奖通知吗？',
      onOk() {
        const params = {
          cId:GetQueryString("cId"),
        };
        dispatch({
          type: 'moments/circleSendNoticeButton',
          payload:params,
        }).then((result) => {
          if(result){
            switch(result.code){
              case "200":
                message.success('发送中奖通知成功');
                const params={
                  cId:GetQueryString("cId"),
                  pageNo:1,
                  pageSize:10,
                };
                dispatch({
                  type: 'moments/circleSelectParticipationButton',
                  payload:params,
                });
                dispatch({
                  type: 'moments/circleParticipationCountButton',
                  payload:params,
                });
                break;
              case "500":
                message.error(result.msg||'发送中奖通知失败');
                break;
            }
          }
        })
      },
      onCancel() {},
    });
  }

  render() {
    const {
      moments: { circleSelectParticipation },
      loading,
    } = this.props;
    circleSelectParticipation.pagination.current=this.state.formValues.pageNo;
    const { selectedRows} = this.state;
    const columns = [
      {
        title: '序号',
        dataIndex: 'id',
        width:100,
      },
      {
        title: '头像',
        dataIndex: 'brandName',
        render: (text, record) => (
          <img alt="" src={record.headImg} style={{width:40,height:40}} />
        ),
      },
      {
        title: '昵称',
        dataIndex: 'nickName',
      },
      {
        title: '手机号',
        dataIndex: 'mobile',
      },
      {
        title: '上传图片',
        render: (text, record) => (
          <a href={record.uploadImgUrl}><img alt="" src={record.uploadImgUrl} style={{width:40,height:40}} /></a>
        ),
      },
      {
        title: '中奖状态',
        render: (text, record) => (
          <span>{Number(record.isPrize) === 0 ? '未中奖' : '中奖'}</span>
        ),
      },
      {
        title: '通知状态',
        render: (text, record) => (
          <span>{Number(record.isNotice)===1?'通知成功':'未通知'}</span>
        ),
      },
      {
        title: '参与时间',
        dataIndex: 'createTime',
      },
      {
        title: '操作',
        align:"right",
        fixed:"right",
        render: (text,record) => (
          <Fragment>
            {
              this.GetQueryString("isOpen")===1&& record.isPrize ===1 && record.isNotice ===0?<span><a  onClick={() => this.cancelPrice(record)}>取消中奖</a><Divider type="vertical" /><a href="javaScrpt:void(0)" onClick={() => this.isNoticeButton(record)}>重新通知</a></span>:<a href="javaScrpt:void(0)" onClick={() => this.setPrice(record)}>设置中奖</a>
            }
          </Fragment>
        ),
      },
    ];

    const menu = (
      <Menu onClick={this.handleMenuClick} selectedKeys={[]}>
        <Menu.Item key="remove">删除</Menu.Item>
        <Menu.Item key="approval">批量审批</Menu.Item>
      </Menu>
    );

    return (
      <PageHeaderLayout title="" showReturn={true} url="/marketingManage/activity/moments">
        <Card bordered={false}>
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>{this.renderForm()}</div>
            <div className={styles.tableListOperator}>
              <Button disabled={Number(this.GetQueryString("isOpen"))===1} type="primary" onClick={() => this.circlemoments()} style={{float:"right",marginTop:"-57px",marginRight:"140px"}}>
                系统随机抽奖
              </Button>
              <Button disabled={Number(this.GetQueryString("isOpen"))===1} type="primary" onClick={() => this.circleSendNotice()} className={styles.buttonAddClass}>
                发送中奖通知
              </Button>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                  <Dropdown overlay={menu}>
                    <Button>
                      更多操作 <Icon type="down" />
                    </Button>
                  </Dropdown>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={circleSelectParticipation}
              columns={columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
            />
          </div>
        </Card>
      </PageHeaderLayout>
    );
  }
}
