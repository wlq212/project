/* eslint-disable react/no-unused-state,no-unused-vars,prefer-destructuring,react/sort-comp,default-case,react/destructuring-assignment,react/no-access-state-in-setstate,no-shadow */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Row,
  Col,
  Card,
  Pagination,
  Form,
  Input,
  Icon,
  Button,
  Upload,
  List,
  Alert,
  Radio,
  Modal,
  message,
} from 'antd';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from './autoReply.less';
import { getStore } from '../../assets/js/mUtils';
import moment from "moment";
const FormItem = Form.Item;
const RadioButton = Radio.Button;
const { TextArea } = Input;
const RadioGroup = Radio.Group;
@connect(({ autoReply, loading }) => ({
  autoReply,
  loading: loading.models.autoReply,
}))
@Form.create()
export  default class autoReplyTable extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      action: `/api/admin/file/upload?type=3&token=${getStore('userInfo') ? JSON.parse(getStore('userInfo')).token : ''}`,
      data: {
        type: 3,
        token: `${getStore('userInfo') ? JSON.parse(getStore('userInfo')).token : ''}`,
      },
      loading1: false,
      loading: false,
      modalVisible: false,
      selectRowData: {},
      selectState1: {},
      switchType: 1,
      message: '',
      autoReply: {
        data: {
          list2: [],
        },
      },
      confirmDirty: false,
      autoCompleteResult: [],
      type: '',
      modelTitle: '添加管理员',
      alertVisible: false,
      expandForm: false,
      selectState: 'text',
      selectedRows: [],
      formValues: {},
      visibleImage: false,
      visibleNews: false,
    };
    this.buttonClick2 = this.buttonClick2.bind(this);
    this.handleChangeImage = this.handleChangeImage.bind(this);
    this.handleChangeImage2 = this.handleChangeImage2.bind(this);
    this.changeState2 = this.changeState2.bind(this);
    this.handleShowNews = this.handleShowNews.bind(this);
    this.handleShowImage = this.handleShowImage.bind(this);
    this.handleCancelNews = this.handleCancelNews.bind(this);
    this.handleCancelImage = this.handleCancelImage.bind(this);
    this.deleteNewsUrl2 = this.deleteNewsUrl2.bind(this);
    this.isCommand2 = this.isCommand2.bind(this);
    this.changePage=this.changePage.bind(this);
  }

  handleSubmitOne = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'autoReply/updateAutoReplyButton',
      payload: this.state.autoReply.data.list2[0],
    }).then((result) => {
      if (result) {
        switch (result.code) {
          case '200':
            dispatch(routerRedux.push('/wxAccounts/autoReply'));
            message.success('更新成功');
            break;
          case '500':
            message.error(result.msg);
            break;
        }
      }
    });
  };

  // 图片素材库model显示与隐藏
  handleCancelImage() {
    this.setState({
      visibleImage: false,
    });
  }

  handleShowImage() {
    const { dispatch } = this.props;
    const paramsOne = {
      pageNo: 1,
      pageSize: 18,
      type: 'image',
    };
    dispatch({
      type: 'autoReply/fetch',
      payload: paramsOne,
    });
    this.setState({
      visibleImage: true,
    });
  }

  // 选择素材
  selectImage(data) {
    this.state.autoReply.data.list2[0].mediaId = data.mediaId;
    this.state.autoReply.data.list2[0].picUrl = data.url;
    this.setState({
      autoReply: this.state.autoReply,
      visibleImage: false,
    });
  }

  /*
  *选择图文素材
   */
  selectNews(data) {
    this.state.autoReply.data.list2[0].mediaId = data.mediaId;
    this.state.autoReply.data.list2[0].url = data.url;
    this.state.autoReply.data.list2[0].picUrl = data.localUrl;
    this.state.autoReply.data.list2[0].title = data.title;
    this.setState({
      autoReply: this.state.autoReply,
      visibleNews: false,
    });
  }

  // 图文库分页切换
  changePageNews(data) {
    this._data = data;
    const { dispatch } = this.props;
    const { pageNo } = this.state;
    const params = {
      pageNo,
      pageSize: 18,
      type: 'news',
    };
    dispatch({
      type: 'autoReply/fetchnews',
      payload: params,
    });
  }


  // 图片库分页切换
  changePage=e=> {
    const { dispatch } = this.props;
    const params = {
      pageNo:e,
      pageSize: 18,
      type: 'image',
    };
    dispatch({
      type: 'autoReply/fetch',
      payload: params,
    });
  }

  // 图文素材库model显示与隐藏
  handleCancelNews() {
    this.setState({
      visibleNews: false,
    });
  }

  handleShowNews() {
    const { dispatch } = this.props;
    const paramsOne = {
      pageNo: 1,
      pageSize: 18,
      type: 'news',
    };
    dispatch({
      type: 'autoReply/fetchnews',
      payload: paramsOne,
    });
    this.setState({
      visibleNews: true,
    });
  }

  componentWillMount() {
    const { autoReply } = this.props;
    this.state.autoReply.data.list2 = [autoReply.eidtData];
    this.setState({
      autoReply: this.state.autoReply,
    });
  }

  // 上传图片
  handleChangeImage(info) {
    if (info.file.status === 'uploading') {
      this.setState({ loading: true });
      return;
    }
    // console.log(info);
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.setState({
        imageUrl: info.file.response.obj,
        loading: false,
      });
    }
  };

  buttonClick2(e) {
    this.state.autoReply.data.list2[0].msgType = e.target.value;
    this.setState({
      msgType2: e.target.value,
      autoReply: this.state.autoReply,
    });
  };


  handleChangeImage2(info) {
    const { autoReply } = this.state;
    if (info.file.status === 'uploading') {
      this.setState({ loading1: true });
      return;
    }
    if (info.file.status === 'done') {
      message.success('上传成功');
      autoReply.data.list2[0].picUrl = info.file.response.obj;
      this.setState({
        autoReply,
        imageUrl2: info.file.response.obj,
        loading1: false,
      });
    }
  }


  // 删除图文
  deleteNewsUrl2 = () => {
    const { dispatch } = this.props;
    event.preventDefault();
    this.state.autoReply.data.list2[0].picUrl = '';
    this.state.autoReply.data.list2[0].title='';
    this.setState({
      autoReply: this.state.autoReply,
    });
    dispatch({
      type: 'autoReply/updateState',
      payload: '',
    });
  };


  changeState2(e) {
    const { autoReply } = this.state;
    autoReply.data.list2[0].state = e.target.value;
    this.setState({
      state2: e.target.value,
      autoReply,
    });
  }

  // 是否关联指令
  isCommand2 = e => {
    const { autoReply } = this.state;
    autoReply.data.list2[0].isCommand = e.target.value;
    this.setState({
      autoReply,
    });
  };


  render() {
    const { autoReply, loading,form} = this.props;
    const that=this;
    const {
      alertVisible,
      message,
      type,
    } = this.state;
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 8 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 },
      },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        xs: {
          span: 24,
          offset: 0,
        },
        sm: {
          span: 16,
          offset: 8,
        },
      },
    };
    const uploadButton2 = (
      <div>
        <Icon type={this.state.loading1 ? 'loading' : 'plus'} />
        <div className="ant-upload-text">本地上传</div>
      </div>
    );
    const TextArea2 = e => {
      this.state.autoReply.data.list2[0].content = e.target.value;
      this.setState({
        autoReply: this.state.autoReply,
      });
    };
    const keyword = e => {
      this.state.autoReply.data.list2[0].keyword = e.target.value;
      this.setState({
        autoReply: this.state.autoReply,
      });
    };
    const deleteImageUrl1 = () => {
      const { dispatch } = this.props;
      this.state.autoReply.data.list2[0].picUrl = '';
      this.setState({
        autoReply: this.state.autoReply,
      });
      dispatch({
        type: 'autoReply/updateState',
        payload: '',
      });
    };
    const mouseOverState=this.mouseOverState;
    const mouseLeaveState=this.mouseLeaveState;
    const IconVisiable=this.state.IconVisiable;
    const deleteImage=this.deleteImage;
    const dataImag=autoReply.Image.list ? autoReply.Image.list : '';
    const props = {
      name: 'file',
      action: `/api/admin/material/addImg?token=${getStore('userInfo') ? JSON.parse(getStore('userInfo')).token : ''}`,
      data: {
        type: 3,
        token: `${getStore('userInfo') ? JSON.parse(getStore('userInfo')).token : ''}`,
      },
      showUploadList: false,
      headers: {
        authorization: 'authorization-text',
      },
      onChange(info) {
        if (info.file.status !== 'uploading') {
          setData(true)
        }
        if (info.file.status === 'done') {
          setData(false)
          that.changePage();
          message.success(`${info.file.name} 上传成功`);
        } else if (info.file.status === 'error') {
          message.error(`${info.file.name} file upload failed.`);
        }
      },
    };
    const setData=data=>{
      this.setState({
        loadingUpload: data,
      });
    };
    const operations = (
      <div>
        <Upload {...props}>
          <Button>
            <Icon type={this.state.loadingUpload?"loading":"upload"} /> 点击上传
          </Button>
        </Upload>
      </div>
    );
    return (
      <PageHeaderLayout title="" showReturn={true} url="/wxAccounts/autoReply">
        {alertVisible ? (
          <Alert message={message} showIcon type={type} closable afterClose={this.handleClose} />
        ) : null}
        <Card bordered={false}>
          <Form>
            <div>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col md={20} sm={24}>

                  <FormItem {...formItemLayout} label="关键词" width="200">
                    {form.getFieldDecorator('msgType', {
                      initialValue: this.state.autoReply.data.list2[0]?this.state.autoReply.data.list2[0].keyword:"",
                     })(
                      <Input onChange={keyword} />
                    )}
                  </FormItem>
                </Col>
              </Row>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col md={20} sm={24}>
                  <FormItem {...formItemLayout} label="类型" width="200">
                    <RadioGroup
                      id="button2"
                      onChange={this.buttonClick2}
                      value={this.state.autoReply.data.list2[0]?this.state.autoReply.data.list2[0].msgType:""}
                    >
                      <RadioButton value="text">文本</RadioButton>
                      <RadioButton value="image">图片</RadioButton>
                      <RadioButton value="news">图文</RadioButton>
                    </RadioGroup>
                  </FormItem>
                </Col>
              </Row>
              {
                this.state.autoReply.data.list2[0].msgType === 'text' ? (
                  <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                    <Col md={20} sm={24}>
                      <FormItem {...formItemLayout} width="200" label="文本">
                          {form.getFieldDecorator('content', {
                            initialValue: this.state.autoReply.data.list2[0]?this.state.autoReply.data.list2[0].content:"",
                          })(
                            <TextArea onChange={TextArea2} rows={4} />
                          )}
                      </FormItem>
                    </Col>
                  </Row>
                ) : this.state.autoReply.data.list2[0].msgType === 'image' ? (
                  <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                    <Col md={20} sm={24}>
                      <FormItem {...formItemLayout} width="200" label="图文">
                        <div>
                          {this.state.autoReply.data.list2[0].picUrl ? '' : (
                            <div className={styles.cardClass}>
                              <Card
                                style={{ width: 200, height: 105, float: 'left', marginRight: 5,lineHeight:"55px",textAlign:'center' }}
                                onClick={this.handleShowImage}
                              >
                                <p>素材中选择</p>
                              </Card>
                            </div>
                          )}
                          <div>
                            {this.state.autoReply.data.list2[0].picUrl ? (
                              <div>
                                <img
                                  src={this.state.autoReply.data.list2[0].picUrl}
                                  alt="avatar"
                                  style={{border:'1px solid #ddd'}}
                                  className={styles.antUpload}
                                />
                                <span onClick={deleteImageUrl1}><Icon
                                  type="close-circle"
                                  style={{ position: 'absolute' }}
                                />
                                  </span>
                              </div>
                            ) : ""}

                          </div>
                        </div>
                      </FormItem>
                    </Col>
                  </Row>
                ) : this.state.autoReply.data.list2[0].msgType === 'news' ? (
                  <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                    <Col md={20} sm={24}>
                      <FormItem {...formItemLayout} width="200" label="图文">
                        {
                          this.state.autoReply.data.list2[0].title ? (
                            <div>
                              <img
                                alt=""
                                src={this.state.autoReply.data.list2[0].picUrl}
                                className={styles.antUpload}
                                style={{ border: '1px solid #ddd' }}
                              />
                              <div>{this.state.autoReply.data.list2[0].title}</div>
                              <span onClick={this.deleteNewsUrl2}><Icon
                                type="close-circle"
                                style={{
                                  position: 'absolute', top: '10px',
                                  right: '-120px',
                                }}
                              />
                              </span>
                            </div>
                          ) : (
                            <div>
                              <div className={styles.cardClass} onClick={this.handleShowNews}>
                                <Card style={{ width: 200, height: 105, float: 'left', marginRight: 5,lineHeight:"55px",textAlign:'center' }}>
                                  <p>素材中选择</p>
                                </Card>
                              </div>
                            </div>
                          )}
                      </FormItem>
                    </Col>
                  </Row>
                ) : ''
              }
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col md={20} sm={24}>
                  <FormItem {...formItemLayout} label="是否关联指令" width="200">
                    {form.getFieldDecorator('isCommand', {
                      initialValue: this.state.autoReply.data.list2[0].isCommand,
                    })(
                      <RadioGroup
                        name="isCommand"
                        onChange={this.isCommand2}
                      >
                        <Radio value={0}>否</Radio>
                        <Radio value={1}>是</Radio>
                      </RadioGroup>
                    )}

                  </FormItem>
                </Col>
              </Row>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col md={20} sm={24}>
                  <FormItem {...formItemLayout} label="状态" width="200">
                    <RadioGroup
                      onChange={this.changeState2}
                      name="state"
                      value={JSON.stringify(this.state.autoReply) !== '{}' ? (JSON.stringify(this.state.autoReply.data.list2) !== '{}' ? this.state.autoReply.data.list2[0].state : '') : ''}
                    >
                      <Radio value={1}>生效</Radio>
                      <Radio value={0}>失效</Radio>
                    </RadioGroup>
                  </FormItem>
                </Col>
              </Row>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col md={20} sm={24}>
                  <FormItem {...tailFormItemLayout} width="200">
                    <Button loading={loading} type="primary" onClick={this.handleSubmitOne}>
                      提交
                    </Button>
                  </FormItem>
                </Col>
              </Row>
            </div>
          </Form>
        </Card>
        <Modal
          title="图片素材库"
          visible={this.state.visibleImage}
          footer={null}
          width="77%"
          onCancel={this.handleCancelImage}
        >
          <div>
            {operations}
            <List loading={loading}>
              <div style={{overFlow:"hidden"}}>
                <ul style={{display:"flex",listStyle:"none",flexWrap:"wrap", justifyContent: 'space-around',padding:"0px"}}>
                  {
                    dataImag?dataImag.map((item) => {
                      return (
                        <li
                          onMouseOver={mouseOverState}
                          onMouseLeave={mouseLeaveState}
                          id={item.mediaId}
                          style={{margin:"10px",marginBottom:"40px"}}
                        >
                          <div style={{ position:"relative",width:"155px",height:"100px"}}>
                            <a href={item.localUrl} target="_blank" rel="noopener noreferrer" style={{color:"#000"}}>
                              <img src={item.localUrl} style={{width:"155px",height:"100px"}} id={item.mediaId} alt="" />
                              <div className={styles.imagedownOverflow}>{item.title}</div>
                            </a>
                            <span
                              style={{ cursor: 'pointer', color: '#1890ff' }}
                              onClick={() => {
                                this.selectImage(item);
                              }}
                            >选择
                            </span>
                          </div>
                        </li>
                      )
                    }):""
                  }
                </ul>
              </div>
              <div style={{marginTop:"30px",float:"right"}}>
                <Pagination defaultPageSize={24} defaultCurrent={this.state.pageNo} total={autoReply.Image.pagination.total} style={{float:"right"}} onChange={this.changePage} />
              </div>
            </List>
          </div>
        </Modal>
        <Modal
          title="图文素材库"
          visible={this.state.visibleNews}
          footer={null}
          width="80%"
          onCancel={this.handleCancelNews}
        >
          <List
            itemLayout="vertical"
            size="large"
            loading={loading}
            pagination={{
              onChange: page => {
                this.changePageNews(page);
              },
              pageSize: 18,
            }}
            dataSource={autoReply.news.list ? autoReply.news.list : ''}
            renderItem={(item,index)=> (
              item ? (
                <List.Item
                  style={{ overflow: 'hidden', paddingBottom: '10px' }}
                  actions={[
                    <span
                      onClick={() => {
                        this.selectNews(item);
                      }}
                      style={{ cursor: 'pointer', color: '#1890ff' }}
                    >选择
                    </span>,
                  ]}
                  extra={<img width={130} alt="logo"
                              src={item.localUrl}
                              style={{ border: '1px solid #ddd'}}/>}
                >
                  <List.Item.Meta
                    // avatar={<Avatar src={item.content.news_item[0].thumb_url} />}
                    title={
                      <a href={item.url} target="_blank">
                        {item.title}
                      </a>
                    }
                    description={item.digest}
                  />
                  <div style={{marginTop:"60px"}}>发表时间：{item.updateTime }&nbsp;&nbsp;&nbsp;&nbsp;</div>
                </List.Item>
              ) : ''


            )}
          />
        </Modal>
      </PageHeaderLayout>
    );
  }
}
