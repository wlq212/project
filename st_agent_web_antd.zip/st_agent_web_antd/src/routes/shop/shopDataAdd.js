import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Form,
  Select,
  Button,
  Card,
  message,
  DatePicker,
  InputNumber,
} from 'antd';
import {isArray} from "lodash";
import PageHeaderLayout from '../../layouts/PageHeaderLayout';

const FormItem = Form.Item;
const { Option } = Select;
@connect(({ shop, loading }) => ({
  shop,
  loading: loading.models.shop,
}))
@Form.create()
export default class AddShopData extends PureComponent {
  state = {
    currData:{},
  };

  componentDidMount(){
    const { dispatch } = this.props;
    dispatch({
      type: 'shop/shopListFetch',
      payload:{pageNo: 1,pageSize: 999999},
    });
  }

  /**
   * 点击取消
   * @param e
   */
  cancel = e => {
    e.preventDefault();
    const { dispatch } = this.props;
    dispatch(routerRedux.push('/Data/shopDataList'));
  };

  handleSubmit = e => {
    e.preventDefault();
    const { form, dispatch} = this.props;
    const {currData} = this.state;
    form.validateFields((err) => {
      if (err) return;
      if (!err) {
        dispatch({
          type: 'shop/addShopDataFetch',
          payload: currData,
        }).then(
          (res) => {
            if (res.code === "200") {
              message.success('添加成功');
              dispatch(routerRedux.push('/Data/shopDataList'));
            }else {
              message.success(res.msg);
            }
          },
        ).catch(error => {
          message.error(error.msg);
        });
      }
    });
  };

  /**
   * 选择门店
   * @param e
   */
  changeShop = (e) => {
    const {currData} = this.state;
    currData.sId = e;
    this.setState({currData});
  };

  /**
   * 选择日期
   * @param date
   * @param dateString 日期
   */
  changeTime = (date, dateString) => {
    const {currData} = this.state;
    currData.dTime = dateString;
    this.setState({currData});
  };

  /**
   * 输入到店人数
   * @param value
   */
  changeNum = (value) => {
    const {currData} = this.state;
    currData.num = value;
    this.setState({currData});
  };

  render() {
    const { submitting, form,shop:{shopList},loading} = this.props;
    const {currData} = this.state;
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 },
        md: { span: 10 },
      },
    };
    const submitFormLayout = {
      wrapperCol: {
        xs: { span: 24, offset: 0 },
        sm: { span: 10, offset: 7 },
      },
    };
    return (
      <PageHeaderLayout showReturn url="/Data/shopDataList">
        <Card bordered={false}>
          <Form onSubmit={this.handleSubmit} hideRequiredMark style={{ marginTop: 8 }}>
            <FormItem {...formItemLayout} label="选择门店">
              {form.getFieldDecorator('sId', {
                initialValue: currData.sId,
                rules: [{ required: true, message: '请选择门店' }],
              })(
                <Select placeholder="请选择门店" onChange={e => this.changeShop(e)}>
                  <Option value="">请选择门店</Option>
                  {
                    isArray(shopList) && shopList.length > 0 ? shopList.map(item => (
                      <Option key={item.id} value={item.sId}>{item.businessName}</Option>
                    )):""
                  }
                </Select>)}
            </FormItem>
            <FormItem {...formItemLayout} label="统计日期">
              {form.getFieldDecorator('dTime', {
                initialValue: currData.dTime,
                rules: [{ required: true, message: '请选择统计日期' }],
              })(<DatePicker style={{width:"100%"}} onChange={this.changeTime} />)}
            </FormItem>
            <FormItem {...formItemLayout} label="到店人数">
              {form.getFieldDecorator('num', {
                initialValue: currData.num,
                rules: [{ required: true, message: '请输入到店人数' }],
              })(
                <InputNumber style={{width:"100%"}} min={0} placeholder="请输入到店人数" onChange={this.changeNum} />
              )}
            </FormItem>
            <FormItem {...submitFormLayout} style={{ marginTop: 32 }}>
              <Button type="primary" htmlType="submit" loading={loading}>
                提交
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.cancel}>
                取消
              </Button>
            </FormItem>
          </Form>
        </Card>
      </PageHeaderLayout>
    );
  }
}
