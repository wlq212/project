/* eslint-disable no-unused-vars,react/no-unused-state,no-undef,react/sort-comp,react/no-access-state-in-setstate,react/destructuring-assignment,react/destructuring-assignment,react/destructuring-assignment,array-callback-return,lines-between-class-members,lines-between-class-members,default-case,no-plusplus,no-empty,react/jsx-tag-spacing,react/jsx-boolean-value,prefer-arrow-callback */
import React, { Fragment } from 'react';
import { connect } from 'dva';
import {
  Form,
  Input,
  Button,
  message,
  Modal,
  Row,
  Col,
  Checkbox,
  Card,
  DatePicker,
  Radio,
  Upload,
  Select,
  Icon,
} from 'antd';
import { routerRedux } from 'dva/router';
import StandardTable from 'components/StandardTable';
import moment from 'moment';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from './shop.less';
import { getStore } from '../../assets/js/mUtils';
import {division} from '../../assets/js/city';
function GetQueryString(name) {
  const reg = new RegExp(`(^|&)${  name  }=([^&]*)(&|$)`);
  const num = window.location.href.indexOf('?');
  const r = window.location.href.substr(num + 1).match(reg);
  if (r != null)
    return unescape(r[2]);
  return null;
};
const FormItem = Form.Item;

const { TextArea } = Input;
const RadioGroup = Radio.Group;

const categories=[
  {name:"江浙菜",value:'江浙菜'},
  {name:"粤菜",value:'粤菜'},
  {name:"川菜",value:'川菜'},
  {name:"湘菜",value:'湘菜'},
  {name:"东北菜",value:'东北菜'},
  {name:"徽菜",value:'徽菜'},
  {name:"闽菜",value:'闽菜'},
  {name:"鲁菜",value:'鲁菜'},
  {name:"台湾菜",value:'台湾菜'},
  {name:"西北菜",value:'西北菜'},
  {name:"东南亚菜",value:'东南亚菜'},
  {name:"西餐",value:'西餐'},
  {name:"日韩菜",value:'日韩菜'},
  {name:"火锅",value:'火锅'},
  {name:"清真菜",value:'清真菜'},
  {name:"小吃快餐",value:'小吃快餐'},
  {name:"海鲜",value:'海鲜'},
  {name:"烧烤",value:'烧烤'},
  {name:"自助餐",value:'自助餐'},
  {name:"面包甜点",value:'面包甜点'},
  {name:"茶餐厅",value:'茶餐厅'},
  {name:"其他美食",value:'其他美食'}
];
@Form.create()
class Step2 extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      syncWx:"",
      visibleKeyWord: false,
      loading1: false,
      loading2: false,
      loading3: false,
      validTime: '',
      shengShi:[],
      shengShiQu:[],
      shopInfo:"",
      title: '',
      action: `/api/admin/file/upload?type=3&token=${getStore('userInfo') ? JSON.parse(getStore('userInfo')).token : ''}`,
      data: {
        type: 3,
        token: `${getStore('userInfo') ? JSON.parse(getStore('userInfo')).token : ''}`,
      },
      states: 1,
      photoUrls:[],
      selectedRows: [],
      selectedRowsKeyWord: [],
      subjectList: [],
      cardRefList: [],
      keyword: '',
      dataSourceSelect: [],
      dataSource: [],

    };
    this.handleAdd = this.handleAdd.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.showModel = this.showModel.bind(this);
    this.title = this.title.bind(this);
    this.keyword = this.keyword.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
    this.onChangeTime = this.onChangeTime.bind(this);
    this.cancelRest = this.cancelRest.bind(this);
    this.addSubjectList = this.addSubjectList.bind(this);
    this.handleChangeAbstract = this.handleChangeAbstract.bind(this);
    this.handleChangeAbstractEs = this.handleChangeAbstractEs.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.addSubmit=this.addSubmit.bind(this);

  }

  componentDidMount() {
    const { dispatch } = this.props;
    const myDate = new Date();
    const now = myDate.toLocaleDateString();
    this.setState({
      validTime: moment(now).format('YYYY-MM-DD'),
    });
    dispatch({
      type: 'shop/getShopInfo',
      payload:{
        sId:GetQueryString('sId')?GetQueryString('sId'):""},
    });
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      title: this.state.title,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'poster/cardListButton',
      payload: params,
    });
  };

  title(e) {

    this.setState({
      title: e.target.value,
    });
  }

  handleAdd() {
    const { dataSource } = this.state;
    const newData = {
      image_url: '',
      text: '',
    };
    this.setState({
      dataSource: [...dataSource, newData],
    });
  }

  handleDelete = (key) => {
    const dataSource = [...this.state.dataSource];
    this.setState({ dataSource: dataSource.filter((item, index) => index !== key) });
  };

  handleCancel() {
    this.setState({
      visible: false,
    });
  }
  keyword = e => {
    this.setState({
      keyword: e.target.value,
    });
  };

  handleSearch() {
    const { dispatch } = this.props;
    const params = {
      title: this.state.title,
      pageSize: 10,
      pageNo: 1,
    };
    dispatch({
      type: 'poster/cardListButton',
      payload: params,
    });
  }

  renderForm() {
    return (
      <Form layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={7} sm={24} style={{ margin: '-10px 0 10px 0' }}>
            <FormItem label="查询参数">
              <Input placeholder="请输入卡券标题" onChange={this.title}/>
            </FormItem>
          </Col>
          <Col md={1} sm={24} style={{ margin: '-5px 0 10px 0' }}>
            <span className={styles.submitButtons}>
              <Button type="primary" onClick={this.handleSearch}>
              查询
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }

  selectCardList = rows => {
    const dataSource = [...this.state.cardRefList];
    if (dataSource.length === 0) {
      dataSource.push(rows);
      this.setState({
        cardRefList: dataSource,
        visible: false,
      });
    } else {
      dataSource.map((item) => {
        if (item.cardId !== rows.cardId) {
          dataSource.push(rows);
        } else {

        }
      });
    }
    this.setState({
      cardRefList:dataSource.distinct('cardId'),
      visible: false,
    });
  };

  showModel() {
    const { dispatch } = this.props;
    const params = {
      pageSize: 10,
      pageNo: 1,
    };
    dispatch({
      type: 'poster/cardListButton',
      payload: params,
    });
    this.setState({
      visible: true,
    });

  }

  handleChangeAbstract(info) {
    if (info.file.status === 'uploading') {
      this.setState({ loading1: true });
      return;
    }
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.state.photoUrls.push(info.file.response.obj)
      if( this.state.photoUrls.length>5){
        message.error("上传数量不能超过5张")
      }else{
        this.setState({
          photoUrls:this.state.photoUrls,
          loading1: false,
        });
      }

    }
  };

  handleChangeAbstractEs(info) {
    if (info.file.status === 'uploading') {
      this.setState({ loading3: true });
      return;
    }
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.state.photoUrls.push(info.file.response.obj)
      this.setState({
        photoUrls:this.state.photoUrls,
        loading3: false,
      });
    }
  };

  onChangeTime(date, dateString) {
    this.setState({
      validTime: dateString,
    });
  };

  cancelRest() {
    const { dispatch } = this.props;
    dispatch(routerRedux.push('/marketingManage/activity/poster'));
  }

  addSubjectList() {
    const obj = {
      sNo: '',
      question: '',
    };
    this.state.subjectList.push(obj);
    this.setState({
      subjectList: [...this.state.subjectList],
    });
  }

// 表单提交
  handleSubmit() {
    const { form, dispatch } = this.props;
    form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        const cardList = this.state.cardRefList;
        const data = {
          cardList: [],
          title: values.title,
          brandName: values.brandName,
          prizeCount: values.prizeCount,
          helpNum: values.helpNum,
          isDefaultPoster: values.isDefaultPoster,
          originPrice: values.originPrice,
          keyword: values.keyword,
          posterImg: this.state.photoUrls,
          coverUrl: this.state.imageUrlAbstr,
          rules: values.rules,

          state: values.state,
          deadline: this.state.validTime,
          isDisplay: values.isDisplay,
        };
        for (let i = 0; i < cardList.length; i++) {
          if ((values.prizeCount * cardList[i].getLimit) > cardList[i].skuQuantity) {
            message.error('中奖人数乘以限领数不能大于库存数？');
            return;
          }
        }
        const cards = [];
        cardList.forEach(i => {
          const cardOne = {
            cardId: i.cardId,
          };
          cards.push(cardOne);
        });
        data.cardRefList = cards;
        dispatch({
          type: 'poster/posterAddButton',
          payload: data,
        }).then((result) => {
          if (result) {
            switch (result.code) {
              case '200':
                message.success('添加成功');
                dispatch(routerRedux.push('/wxAccounts/shop'));
                break;
              case '500':
                message.error(result.msg);
                break;
            }
          }
        }, (result) => {

        });
      }
    });
  }

  sNo = (e) => {
    this.state.subjectList[+this.state.key].sNo = e.target.value;
    this.setState({
      subjectList: this.state.subjectList,
    });
  };

  question = (e) => {

    this.state.subjectList[+this.state.key].question = e.target.value;
    this.setState({
      subjectList: this.state.subjectList,
    });
  };
  // 选取省份
  selectOne=data=>{
    this.setState({
      sheng:data,
      shengShi:division[data],
    })
  };
  //市
  selectTwo=data=>{
    console.log(data)
    this.setState({
      shi:data,
      shengShiQu:this.state.shengShi[data],
    })
  };
  //区
  selectThree=data=>{
    this.setState({
      qu:data,
    })
  };

  //提交
  addSubmit(){
    const { form, dispatch } = this.props;
    const that=this;
        dispatch({
          type: "shop/updateShop",
          payload:that.state.shopInfo,
        }).then(function(result) {
          switch (result.code) {
            case "200":
              message.success("更新成功");
              dispatch(routerRedux.push('/wxAccounts/shop'));
              break;
            case "500":
              message.error(result.msg);
              break;
          }
        })
      }

  render(){
    const { form, loading,shop} = this.props;
    this.setState({
      shopInfo:shop.shopInfo.obj,
    });
    const columnsTab = [
      {
        title: '优惠券名称',
        key: 'title',
        dataIndex: 'title',
      },
      {
        title: '优惠券副标题',
        dataIndex: 'subtitle',
        key: 'subtitle',
      },
      {
        title: '操作',
        align:"right",
        fixed:"right",
        render: (text, record) => (
          <Fragment>
            <a onClick={() => this.selectCardList(record)}>选择</a>
          </Fragment>
        ),
      },
    ];
    const { selectedRows } = this.state;
    const uploadButton1 = (
      <div>
        <Icon type={this.state.loading1 ? 'loading' : 'plus'} />
        <div className="ant-upload-text">本地上传</div>
      </div>
    );
    const uploadButtones = (
      <div>
        <Icon type={this.state.loading3 ? 'loading' : 'plus'} />
        <div className="ant-upload-text">本地上传</div>
      </div>
    );
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 },
        md: { span: 10 },
      },
    };
    const businessName = (e) => {
      this.state.shopInfo.businessName=e.target.value;
      this.setState({
        shopInfo:this.state.shopInfo,
      });
    };
    const branchName = (e) => {
      this.state.shopInfo.branchName=e.target.value;
      this.setState({
        shopInfo:this.state.shopInfo,
      });
    };
    const address=(e) => {
      this.state.shopInfo.address=e.target.value;
      this.setState({
        shopInfo:this.state.shopInfo,
      });
    };
    const recommend=(e) => {
      this.state.shopInfo.recommend=e.target.value;
      this.setState({
        shopInfo:this.state.shopInfo,
      });
    };
    const introduction=(e) => {
      this.state.shopInfo.introduction=e.target.value;
      this.setState({
        shopInfo:this.state.shopInfo,
      });
    };
    const categoriesChange=(e) => {
      this.state.shopInfo.categories=e.target.value;
      this.setState({
        shopInfo:this.state.shopInfo,
      });
    };
    const special=(e) => {
      this.state.shopInfo.special=e.target.value;
      this.setState({
        shopInfo:this.state.shopInfo,
      });
    };
    const openTime=(e) => {
      this.state.shopInfo.openTime=e.target.value;
      this.setState({
        shopInfo:this.state.shopInfo,
      });
    };
    const avgPrice=(e) => {
      this.state.shopInfo.avgPrice=e.target.value;
      this.setState({
        shopInfo:this.state.shopInfo,
      });
    };
    const telephone=(e) => {
      this.state.shopInfo.telephone=e.target.value;
      this.setState({
        shopInfo:this.state.shopInfo,
      });
    };
    const location=(e)=>{
      this.state.shopInfo.location=e.target.value;
      this.setState({
        shopInfo:this.state.shopInfo,
      });
    };
    const syncWx=(e)=>{
      this.state.shopInfo.syncWx= !e.target.value?1:0;
      this.setState({
        shopInfo:this.state.shopInfo,
      });
    };
    const merchantId=(e)=>{
      this.state.shopInfo.merchantId= e.target.value;
      this.setState({
        shopInfo:this.state.shopInfo,
      });
    };
    return (
      <PageHeaderLayout showReturn={true} url="/wxAccounts/shop">
        <Card bordered={false}>
          <Form layout="horizontal" className={styles.stepForm}>
            <FormItem {...formItemLayout} label="门店名称">
              {form.getFieldDecorator('businessName', {
                rules: [{ required: true, message: '请输入门店名称，如奈雪' }],
                initialValue: shop.shopInfo?shop.shopInfo.obj.businessName:"",
              })(<Input
                disabled={true}
                placeholder="请输入门店名称，如奈雪"
                onChange={businessName}
              />)}
            </FormItem>
            <FormItem {...formItemLayout} label="分店名称">
              {form.getFieldDecorator('branchName', {
                rules: [{ required: true, message: '请输入分店名，如万象城店' }],
                initialValue: shop.shopInfo?shop.shopInfo.obj.branchName:"",
              })(<Input
                disabled={true}
                placeholder="请输入分店名，如万象城店"
                onChange={branchName}
              />)}
            </FormItem>
            <FormItem {...formItemLayout} label="地址">
              {form.getFieldDecorator('brandName', {
                rules: [{ required: true, message: '请输入地址' }],
              })(
                <div>
                  <Select
                    style={{ width: 140,marginRight:"10px"}}
                    placeholder="省份"
                    disabled={true}
                    value={shop.shopInfo?shop.shopInfo.obj.province:""}
                    onChange={this.selectOne}
                  >
                    {
                      Object.keys(division).map((item,index) => {
                        return(<Option value={item} key={index}>{item}</Option>)
                      })
                    }
                  </Select>
                  <Select
                    style={{ width: 140,marginRight:"10px"}}
                    placeholder="城市"
                    disabled={true}
                    value={shop.shopInfo?shop.shopInfo.obj.city:""}
                    onChange={this.selectTwo}
                  >
                    {
                      Object.keys(this.state.shengShi).map((item,index) => {
                        return(<Option value={item} key={index}>{item}</Option>)
                      })
                    }
                  </Select>
                  <Select
                    style={{ width: 140 }}
                    placeholder="区县"
                    disabled={true}
                    value={shop.shopInfo?shop.shopInfo.obj.district:""}
                    onChange={this.selectThree}
                  >
                    {
                      this.state.shengShiQu.map((item,index) => {
                        return(<Option value={item} key={index}>{item}</Option>)
                      })
                    }
                  </Select>
                  <Input
                    placeholder="输入详细地址，请勿重复省市区信息"
                    onChange={address}
                    disabled={true}
                    value={shop.shopInfo?shop.shopInfo.obj.address:""}
                  />
                </div>
              )}
            </FormItem>
            <FormItem {...formItemLayout} label="经纬度">
              {form.getFieldDecorator('location', {
                rules: [{ required: true, message: '如23.99,124.99' }],
              })(<div><Input
                placeholder="如23.99,124.99"
                onChange={location}
                style={{width:370}}
                disabled={true}
                value={shop.shopInfo?(shop.shopInfo.obj.longitude+","+shop.shopInfo.obj.latitude):""}
              /><a href="https://lbs.amap.com/console/show/picker" target="blank">手动选择</a>
              </div>)}
            </FormItem>
            <FormItem {...formItemLayout} label="类目">
              {form.getFieldDecorator('categories', {
                rules: [{ required: true, message: '请选择类目' }],
                initialValue:shop.shopInfo?shop.shopInfo.obj.categories:"",
              })(<Select
                showSearch
                placeholder="请选择类目"
                disabled={true}
                onChange={categoriesChange}
              >
                {
                  categories.map((item,index) => {
                    return(<Option value={item.value} key={index}>{item.value}</Option>)
                  })
                }
              </Select>)}
            </FormItem>
            <FormItem {...formItemLayout} label="门店电话">
              {form.getFieldDecorator('telephone', {
                rules: [{ required: true, message: '纯数字，区号、分机号均由“-”隔开' }],
                initialValue: shop.shopInfo?shop.shopInfo.obj.telephone:"",
              })(<Input
                onChange={telephone}
                disabled={true}
                placeholder="纯数字，区号、分机号均由“-”隔开"
              />)}
            </FormItem>
            <FormItem {...formItemLayout} label="媒体图片">
              {form.getFieldDecorator('coverUrl', {
                initialValue: this.state.imageUrlAbstr,
                rules: [{ required: true, message: '请上传封面图片' }],
              })(
                <div>
                  <ul style={{display:'flex',listStyle:"none",paddingLeft:"0px"}}>
                    {
                      shop.shopInfo.obj?shop.shopInfo.obj.photoLis?shop.shopInfo.obj.photoList.map(function(item,index) {
                        return (
                          <li style={{marginRight:"10px"}}>
                            <img
                              src={item}
                              alt="avatar"
                              style={{ width: '100px', height: '100px' }}
                            />
                          </li>
                        )
                      }):"":""
                    }
                    <li>
                      <Upload
                        name="file"
                        listType="picture-card"
                        disabled={true}
                        className={styles.antUpload}
                        showUploadList={true}
                        action={this.state.action}
                        onChange={this.handleChangeAbstract}
                      >
                        {this.state.imageUrlAbstr ? (
                          <img
                            src={this.state.imageUrlAbstr}
                            alt="avatar"
                            style={{ width: '100px', height: '100px' }}
                          />
                        ) : uploadButton1}
                      </Upload>
                    </li>
                  </ul>

                </div>
                  )}
            </FormItem>
            <FormItem {...formItemLayout} label="门店推荐">
              {form.getFieldDecorator('recommend', {
                initialValue:shop.shopInfo?shop.shopInfo.obj.recommend:"",
              })(<TextArea
                rows={4}
                placeholder="推荐品，餐厅可为推荐菜；200字以内"
                onChange={recommend}
                disabled={true}
                value={this.state.recommend}
              />)}
            </FormItem>
            <FormItem {...formItemLayout} label="人均价格">
              {form.getFieldDecorator('avgPrice', {
                initialValue:shop.shopInfo?shop.shopInfo.obj.avgPrice:"",
              })(<Input placeholder="大于0的整数" type="number" disabled={true} onChange={avgPrice}/>)}
            </FormItem>
            <FormItem {...formItemLayout} label="营业时间">
              {form.getFieldDecorator('openTime', {
                initialValue:shop.shopInfo?shop.shopInfo.obj.openTime:"",
              })(<Input onChange={openTime} disabled={true} placeholder="24 小时制表示，用“-”连接，如 8:00-20:00"/>)}
            </FormItem>
            <FormItem {...formItemLayout} label="特色服务">
              {form.getFieldDecorator('special', {
                initialValue:shop.shopInfo?shop.shopInfo.obj.special:"",
              })(<Input
                placeholder="如免费wifi，免费停车，送货上门等"
                disabled={true}
                onChange={special}
              />)}
            </FormItem>
            <FormItem {...formItemLayout} label="简介">
              {form.getFieldDecorator('introduction',{
                initialValue:shop.shopInfo?shop.shopInfo.obj.introduction:"",
              })(<TextArea
                rows={4}
                onChange={introduction}
                placeholder="输入简介….600字以内"
                disabled={true}
                value={this.state.introduction}
              />)}
            </FormItem>
            <FormItem {...formItemLayout} label="微信同步">
              {form.getFieldDecorator('syncWx',{
                initialValue:shop.shopInfo?shop.shopInfo.obj.syncWx:"",
              })(  <Checkbox onChange={syncWx} disabled={true}/>)}
            </FormItem>
            <FormItem {...formItemLayout} label="商户号Id">
              {form.getFieldDecorator('merchantId',{
                initialValue:shop.shopInfo?shop.shopInfo.obj.merchantId:"",
              })(<Input
                placeholder="请输入商户号Id"
                onChange={merchantId}
              />)}
            </FormItem>
            <FormItem {...formItemLayout} label="" style={{marginLeft:"28%"}}>
              <div>
                <Button type="primary" onClick={this.addSubmit} loading={loading}>
                  修改
                </Button>
              </div>
            </FormItem>
          </Form>
        </Card>
        <Modal
          title="卡券列表"

          visible={this.state.visible}
          footer={null}
          width="80%"
          onCancel={this.handleCancel}
        >
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>
              {this.renderForm()}
            </div>
            <div className={styles.tableListOperator}>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                </span>
              )}
            </div>

          </div>
        </Modal>
      </PageHeaderLayout>
    );
  }
}
export default connect(({ shop, loading }) => ({
  shop,
  loading: loading.models.shop,
}))(Step2);



