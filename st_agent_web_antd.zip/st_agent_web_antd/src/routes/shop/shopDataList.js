/* eslint-disable no-param-reassign */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import { Row, Col, Card, Form, Select, DatePicker,Button } from 'antd';
import StandardTable from 'components/StandardTable';
import { isUndefined,isArray } from 'lodash';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from '../../assets/css/common.less';

const FormItem = Form.Item;
const { Option } = Select;
const DatePickerRangePicker = DatePicker.RangePicker;
const getValue = obj =>
  Object.keys(obj)
    .map(key => obj[key])
    .join(',');

@connect(({shop, loading }) => ({
  shop,
  loading: loading.models.shop,
}))
@Form.create()
export default class ShopDataList extends PureComponent {
  state = {
    selectedRows: [],
    formValues: {},
  };

  componentDidMount() {
    const { dispatch} = this.props;
    const data = {
      pageNo: 1,
      pageSize: 10,
    };
    dispatch({
      type: 'shop/shopDataListFetch',
      payload: data,
    });
    dispatch({
      type: 'shop/shopListFetch',
      payload: {pageNo:1,pageSize:999999},
    });
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});
    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    formValues.pageNo=pagination.current;
    this.setState({
      formValues,
    })
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'shop/shopDataListFetch',
      payload: params,
    });
  };

  /**
   * 搜索门店
   * @param e
   */
  handleSearchShop = e => {
    const { dispatch, form } = this.props;
    let beginTime;
    let endTime;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const rangeValue = fieldsValue.time;
      if(!isUndefined(rangeValue) && rangeValue.length > 0){
        beginTime = rangeValue[0].format('YYYY-MM-DD');
        endTime = rangeValue[1].format('YYYY-MM-DD');
      }
      const values = {
        pageNo: 1,
        pageSize: 10,
        beginTime,
        endTime,
        sId:e,
      };
      this.setState({
        formValues: values,
      });
      dispatch({
        type: 'shop/shopDataListFetch',
        payload: values,
      });

    });
  };

  /**
   * 搜索时间
   * @param e
   * @param time
   */
  handleSearchTime =(e,time) => {
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      const values = {
        pageNo: 1,
        pageSize: 10,
        beginTime: time[0],
        endTime: time[1],
        sId:fieldsValue.sId,
      };
      this.setState({
        formValues:values,
      });
      dispatch({
        type: 'shop/shopDataListFetch',
        payload: values,
      });
    });
  };

  addShopData = () => {
    const {dispatch}=this.props;
    dispatch(routerRedux.push('/Data/shopDataList/addShopData'));
  };

  renderSimpleForm() {
    const { form,shop:{shopList} } = this.props;
    const { getFieldDecorator } = form;

    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={6} sm={24}>
            <FormItem>
              {getFieldDecorator('time')(<DatePickerRangePicker onChange={this.handleSearchTime} />)}
            </FormItem>
          </Col>
          <Col md={4} sm={24} style={{paddingRight:"10px",paddingLeft:"10px"}}>
            <FormItem>
              {getFieldDecorator('sId',{
                initialValue:"",
              })(
                <Select onChange={this.handleSearchShop}>
                  <Option value="">请选择门店</Option>
                  {isArray(shopList) && shopList.length > 0 ? shopList.map(item => (
                    <Option key={item.id} value={item.sId}>{item.businessName}</Option>
                  )) :""}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={4} sm={24} style={{float:"right",textAlign:"right"}}>
            <Button type="primary" onClick={this.addShopData}>
              导入
            </Button>
          </Col>
        </Row>
      </Form>
    );
  }

  render() {
    const columns = [
      {
        title: '时间',
        key: 'dTime',
        dataIndex: 'dTime',
        width:"15%",
        render:(text,record) => (
          record.dTime.substring(0,10)
        ),
      },
      {
        title: '门店',
        dataIndex: 'shopName',
        key: 'shopName',
        width:"50%",
      },
      {
        title: '到店人数',
        dataIndex: 'num',
        key: 'num',
      },
      {
        title: '导入时间',
        dataIndex: 'createTime',
        key: 'createTime',
        width:"15%",
      },
    ];
    const {
      shop: { shopDataList },
      loading,
    } = this.props;
    const { selectedRows,formValues:{pageNo}} = this.state;
    shopDataList.pagination.current = pageNo;
    return (
      <PageHeaderLayout>
        <Card>
          <div className={styles.tableListForm}>
            {this.renderSimpleForm()}
          </div>
        </Card>
        <Card>
          <StandardTable
            loading={loading}
            data={shopDataList}
            columns={columns}
            selectedRows={selectedRows}
            onChange={this.handleStandardTableChange}
          />
        </Card>
      </PageHeaderLayout>
    );
  }
}
