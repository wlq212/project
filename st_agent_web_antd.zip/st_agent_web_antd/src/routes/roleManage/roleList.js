import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { Row, Col, Card, Form, Select,Button,Divider} from 'antd';
import StandardTable from 'components/StandardTable';

import { routerRedux } from 'dva/router';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import { getStore } from '../../assets/js/mUtils';
import styles from '../channel/channel.less';

const FormItem = Form.Item;
const { Option } = Select;
const getValue = obj =>
  Object.keys(obj)
    .map(key => obj[key])
    .join(',');

@connect(({roleManage, loading }) => ({
  roleManage,
  loading: loading.models.roleManage,
}))
@Form.create()
export default class RoleList extends PureComponent {
  state = {
    selectedRows: [],
    formValues: {},
    state:"",
    roleType:"",
  };

  componentDidMount() {
    const { dispatch } = this.props;
    const params = {
      pageNo: 1,
      pageSize: 10,
    };
    dispatch({
      type: 'roleManage/roleListFetch',
      payload: params,
    });
  }

  stateSearch = (value) => {
    this.setState({state:value});
    const { dispatch} = this.props;
    const {roleType} = this.state;
    const values = {
      pageNo: 1,
      pageSize: 10,
      roleType,
      state:value,
    };
    dispatch({
      type: 'roleManage/roleListFetch',
      payload: values,
    });
  };

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});
    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    formValues.pageNo=pagination.current;
    this.setState({
      formValues,
    })
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'roleManage/roleListFetch',
      payload: params,
    });
  };

  roleTypeSearch = (value) => {
    this.setState({roleType:value});
    const { dispatch } = this.props;
    const {state} = this.state;
    const values = {
      pageNo: 1,
      pageSize: 10,
      roleType:value,
      state,
    };
    dispatch({
      type: 'roleManage/roleListFetch',
      payload: values,
    });
  };

  roleSetting = data => {
    const { dispatch } = this.props;
    dispatch({
      type: 'roleManage/roleEditData',
      payload:data,
    });
    dispatch(routerRedux.push('/setting/roleList/roleManage'));
  };

  roleEdit = data => {
    const { dispatch } = this.props;
    let params = {
      name:"",
      roleType:"",
      state:1,
    };
    if(data !== -1){
      params = data;
    }
    dispatch({
      type: 'roleManage/roleEditData',
      payload:params,
    });
    dispatch(routerRedux.push('/setting/roleList/roleAdd'));
  };

  renderSimpleForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    const {roleType} = JSON.parse(getStore("userInfo"));
    return (
      <Form layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={4} sm={24}>
            <FormItem>
              {getFieldDecorator('state')(
                <Select
                  onSelect={this.stateSearch}
                  placeholder="请选择状态"
                >
                  <Option value="">请选择状态</Option>
                  <Option value={1}>有效</Option>
                  <Option value={0}>无效</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={4} sm={24}>
            {roleType === 100 ? (
              <FormItem>
                {getFieldDecorator('roleType')(
                  <Select
                    onSelect={this.roleTypeSearch}
                    placeholder="请选择角色类型"
                  >
                    <Option value="">请选择角色类型</Option>
                    <Option value={100}>系统管理员</Option>
                    <Option value={200}>管理员</Option>
                    <Option value={300}>普通用户</Option>
                  </Select>
                )}
              </FormItem>
            ):(roleType === 200 ? (
              <FormItem>{getFieldDecorator('roleType')(
                <Select
                  onSelect={this.roleTypeSearch}
                  placeholder="请选择角色类型"
                >
                  <Option value="">请选择角色类型</Option>
                  <Option value={200}>管理员</Option>
                  <Option value={300}>普通用户</Option>
                </Select>
              )}
              </FormItem>
            ):"")}
          </Col>
          <Button type="primary" style={{float:"right",marginRight:20}} onClick={() => this.roleEdit(-1)}>
            新增角色
          </Button>
        </Row>
      </Form>
    );
  }

  render() {
    // noinspection JSAnnotator
    const columns = [
      {
        title: '角色名称',
        key: 'name',
        dataIndex:'name',
      },
      {
        title: '角色类型',
        dataIndex: 'roleType',
        key: 'roleType',
        render: (text, record) => (
          <span>
            {record.roleType === 100 ? '系统管理员' : (record.roleType === 200 ? '管理员' :'普通用户')}
          </span>
        ),
      }
      ,
      {
        title: '状态',
        dataIndex: 'state',
        key: 'state',
        render: (text, record) => (
          <span>
            {record.state === 1 ? '有效' : '无效'}
          </span>
        ),
      },
      {
        title: '创建时间',
        dataIndex: 'createTime',
        key: 'createTime',
        width:"17%",
      },
      {
        title: '操作',
        align:"right",
        width:"20%",
        render: (text,record) => <div><a onClick={() => this.roleEdit(record)}>编辑</a>  <Divider type="vertical" /> <a onClick={() => this.roleSetting(record)}>配置菜单</a></div>,
      },
    ];
    const {
      roleManage: { roleList },
      loading,
    } = this.props;
    const { selectedRows,formValues:{pageNo} } = this.state;
    roleList.pagination.current = pageNo;
    return (
      <PageHeaderLayout>
        <Card>
          <div className={styles.tableListForm}>{this.renderSimpleForm()}</div>
          <StandardTable
            loading={loading}
            data={roleList}
            columns={columns}
            selectedRows={selectedRows}
            onChange={this.handleStandardTableChange}
          />
        </Card>
      </PageHeaderLayout>
    );
  }
}
