/* eslint-disable no-param-reassign */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import { Tree ,
  Card,
  Form,
  message} from 'antd';
import { isUndefined } from 'lodash';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';


const {TreeNode} = Tree;

@connect(({ menuManage,roleManage, loading }) => ({
  menuManage,roleManage,
  loading: loading.models.roleManage,
}))
@Form.create()
export default class RoleManage extends PureComponent{
  constructor(props) {
    super(props);
    this.state = {
      treeData:[],
      expandedKeys: [],
      checkedKeys: [],
    };
  }

  componentDidMount(){
    const { dispatch,roleManage:{editData} } = this.props;
    if(isUndefined(editData.roleId)){
      dispatch(routerRedux.push('/setting/roleList'));
      return;
    }
    dispatch({
      type:'menuManage/fetchMenuList',
      payload:{},
    }).then(() => {
      const {menuManage:{menuList} } = this.props;
      const expandedKeys = [];
      for(let i=0; i<menuList.length; i+=1){
        expandedKeys.push(menuList[i].menuId);
      }
      this.setState({treeData:menuList,expandedKeys});
    }).then(() => {
      dispatch({
        type:'roleManage/roleMenuListFetch',
        payload:{roleId:editData.roleId},
      }).then(() => {
        const {roleManage:{roleMenuList} } = this.props;
        this.setState({checkedKeys:roleMenuList});
      })
    })
  };

  /**
   * 勾选某个菜单
   * @param checkedKeys
   */
  onCheck = (checkedKeys,{node}) => {
    const {checked} = node.props;
    if(!checked){
      const parentMenu = this.getParentMenuItem(node);
      if(parentMenu != null){
        const unionSet = new Set([...checkedKeys.checked, ...[parentMenu.menuId]]);
        checkedKeys.checked = [...unionSet];
      }
    }
    this.setState({checkedKeys});
  };

  /**
   * 获取点击树形菜单的父节点数据
   * @param node
   * @returns {*}
   */
  getParentMenuItem(node){
    const posArr = node.props.pos.split("-");
    if(posArr.length <= 2){
      return null;
    }
    const {treeData} =  this.state;
    const menuItem = treeData[posArr[posArr.length - 2]];
    return menuItem;
  };

  /**
   * 保存
   */
  save = () => {
    const { dispatch,roleManage:{editData}} = this.props;
    const {checkedKeys:{checked}} = this.state;
    const params = {roleId:editData.roleId,menuIdList:checked};
    dispatch({
      type:"roleManage/saveRoleMenuFetch",
      payload:params,
    }).then(res => {
      if(res.code === "200"){
        message.success("保存成功");
        dispatch(routerRedux.push('/setting/roleList'));
      }else {
        message.error(res.msg);
      }
    }).catch(error => {
      message.error(error.msg);
    })
  };


  render() {
    const {expandedKeys,checkedKeys,treeData} = this.state;
    const loop = data => data.map((item) => {
      if (item.children && item.children.length) {
        return <TreeNode key={item.menuId} title={item.name}>{loop(item.children)}</TreeNode>;
      }
      return <TreeNode key={item.menuId} title={item.name} />;
    });
    return (
      <PageHeaderLayout showReturn url="/setting/roleList">
        <div style={{display:"flex"}}>
          <div style={{width:400}}>
            <div style={{display:"flex",height:50,border:"1px solid #ddd",justifyContent: "space-between",lineHeight:"50px",padding:"0 10px"}}>
              <div>管理系统左侧菜单</div>
              <div><a onClick={this.save}>保存</a></div>
            </div>
            <Card style={{height:500,overflow:"auto"}}>
              <Tree
                checkable
                className="draggable-tree"
                draggable
                expandedKeys={expandedKeys}
                checkStrictly
                checkedKeys={checkedKeys}
                onCheck={this.onCheck}
              >
                {loop(treeData)}
              </Tree>
            </Card>
          </div>
          <div style={{flex:1,padding:"100px 0 0 100px"}}>
            <h4>使用说明</h4>
            <div>1、勾选要为该角色配置的菜单项</div>
            <div>2、勾选后，点击右上角保存按钮生效</div>
          </div>
        </div>

      </PageHeaderLayout>

    );
  }
}
