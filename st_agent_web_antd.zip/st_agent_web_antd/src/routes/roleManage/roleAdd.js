/* eslint-disable no-unused-vars,react/jsx-boolean-value */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import { isUndefined } from 'lodash';
import {
  Form,
  Input,
  Card,
  Select,
  Radio,
  Button,
  message,
} from 'antd';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import { getStore } from '../../assets/js/mUtils';
import { division } from '../../assets/js/city';

const FormItem = Form.Item;
const {Option} = Select;
const RadioGroup = Radio.Group;
@connect(({ roleManage, loading }) => ({
  roleManage,
  loading: loading.models.roleManage,
}))
@Form.create()
export  default class RoleAdd extends PureComponent {
  state = {
    roleList:{},
  };

  componentDidMount(){
    const {roleManage:{editData}} = this.props;
    this.setState({roleList:editData});
  };

  onSubmit = () => {
    const {dispatch,form:{validateFieldsAndScroll}} = this.props;
    const {roleList} = this.state;
    validateFieldsAndScroll((err,values) => {
      if(!err){
        roleList.name = values.name;
        roleList.roleType = values.roleType;
        roleList.state = values.state;
        dispatch({
          type:"roleManage/roleAddFetch",
          payload: roleList,
        }).then(res => {
          if(res.code === "200"){
            message.success("保存成功！！！");
            dispatch(routerRedux.push('/setting/roleList'));
          }else {
            message.error(res.msg);
          }
        }).catch(error => {
          message.error(error.msg);
        })
      }
    })
  };

  nameChange = (e) => {
    const {roleList} = this.state;
    roleList.name = e.target.value;
    this.setState({roleList});
  };

  cancel = () => {
    const {dispatch} = this.props;
    dispatch(routerRedux.push('/setting/roleList'));
  };

  render() {
    const { form:{getFieldDecorator}} = this.props;
    const {roleList} = this.state;
    const {roleType} = JSON.parse(getStore("userInfo"));
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 5 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 },
        md: { span: 10 },
      },
    };
    const submitFormLayout = {
      wrapperCol: {
        xs: { span: 24, offset: 0 },
        sm: { span: 17, offset: 5 },
      },
    };
    return (
      <PageHeaderLayout showReturn url="/setting/roleList">
        <Card bordered={false}>
          <Form hideRequiredMark style={{ marginTop: 8 }}>
            <FormItem {...formItemLayout} label="名称">
              {getFieldDecorator('name',{
                initialValue:roleList.name,
                rules: [
                  {
                    required: true,
                    message: '请输入名称',
                  },
                ],
              })(
                <Input addonAfter={`${roleList.name == null || roleList.name === "" ? 0 : roleList.name.length}/64`} maxLength={64} onChange={e => this.nameChange(e)} />
              )}
            </FormItem>
            {roleType === 100 && (roleList.roleType > 100 || roleList.roleType === "") ? (
              <FormItem {...formItemLayout} label="角色类型">
                {getFieldDecorator('roleType', {
                  initialValue: roleList.roleType,
                  rules: [
                    {
                      required: true,
                      message: '请选择角色类型',
                    },
                  ],
                })(
                  <Select
                    placeholder="请选择角色类型"
                    style={{ width: 160 }}
                  >
                    <Option value="">请选择角色类型</Option>
                    <Option value={200}>管理员</Option>
                    <Option value={300}>普通用户</Option>
                  </Select>
                )}
              </FormItem>
                ):(roleType === 200 && (roleList.roleType > 200 || roleList.roleType === "") ? (
                  <FormItem {...formItemLayout} label="角色类型">{getFieldDecorator('roleType', {
                    initialValue: roleList.roleType,
                    rules: [
                      {
                        required: true,
                        message: '请选择角色类型',
                      },
                    ],
                  })(
                    <Select
                      placeholder="请选择角色类型"
                      style={{ width: 160 }}
                    >
                      <Option value="">请选择角色类型</Option>
                      <Option value={300}>普通用户</Option>
                    </Select>
                  )}
                  </FormItem>
                ):"")}

            <FormItem {...formItemLayout} label="状态">
              {getFieldDecorator('state', {
                initialValue: roleList.state,
              })(
                <RadioGroup>
                  <Radio value={1}>有效</Radio>
                  <Radio value={0}>无效</Radio>
                </RadioGroup>
              )}
            </FormItem>
            <FormItem {...submitFormLayout}>
              <Button type="primary" onClick={this.onSubmit}>
                保存
              </Button>
              <Button style={{marginLeft:20}} onClick={this.cancel}>
                取消
              </Button>
            </FormItem>
          </Form>
        </Card>
      </PageHeaderLayout>
    );
  }
}
