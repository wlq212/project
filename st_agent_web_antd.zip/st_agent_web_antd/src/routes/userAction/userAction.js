/* eslint-disable no-param-reassign */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { Row, Col, Card, Form, Select, DatePicker } from 'antd';
import StandardTable from 'components/StandardTable';
import { isUndefined } from 'lodash';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from '../../assets/css/common.less';
import userActionConst from '../../assets/js/cardConst';


const userActionTypes = userActionConst.userActionTypes;
const FormItem = Form.Item;
const { Option } = Select;
const DatePickerRangePicker = DatePicker.RangePicker;
const getValue = obj =>
  Object.keys(obj)
    .map(key => obj[key])
    .join(',');

@connect(({userAction, loading }) => ({
  userAction,
  loading: loading.models.userAction,
}))
@Form.create()
export default class UserAction extends PureComponent {
  state = {
    selectedRows: [],
    formValues: {},
  };

  componentDidMount() {
    const { dispatch} = this.props;
    const data = {
      pageNo: 1,
      pageSize: 10,
    };
    dispatch({
      type: 'userAction/userActionListFetch',
      payload: data,
    });
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});
    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    formValues.pageNo=pagination.current;
    this.setState({
      formValues,
    })
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'userAction/userActionListFetch',
      payload: params,
    });
  };

  /**
   * 搜索类型
   * @param e
   */
  handleSearchType = e => {
    const { dispatch, form } = this.props;
    let beginTime;
    let endTime;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const rangeValue = fieldsValue.time;
      if(!isUndefined(rangeValue) && rangeValue.length > 0){
        beginTime = rangeValue[0].format('YYYY-MM-DD');
        endTime = rangeValue[1].format('YYYY-MM-DD');
      }
      const values = {
        pageNo: 1,
        pageSize: 10,
        beginTime,
        endTime,
        type:e,
      };
      this.setState({
        formValues: values,
      });
      dispatch({
        type: 'userAction/userActionListFetch',
        payload: values,
      });

    });
  };

  /**
   * 搜索行为类型
   * @param e
   */
  handleActionType = e => {
    const { dispatch, form } = this.props;
    let beginTime;
    let endTime;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const rangeValue = fieldsValue.time;
      if(!isUndefined(rangeValue) && rangeValue.length > 0){
        beginTime = rangeValue[0].format('YYYY-MM-DD');
        endTime = rangeValue[1].format('YYYY-MM-DD');
      }
      const values = {
        pageNo: 1,
        pageSize: 10,
        beginTime,
        endTime,
        actionType:e,
      };
      this.setState({
        formValues: values,
      });
      dispatch({
        type: 'userAction/userActionListFetch',
        payload: values,
      });

    });
  };

  /**
   * 搜索时间
   * @param e
   * @param time
   */
  handleSearchTime =(e,time) => {
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      const values = {
        pageNo: 1,
        pageSize: 10,
        beginTime: time[0],
        endTime: time[1],
        actionType:fieldsValue.actionType,
      };
      this.setState({
        formValues:values,
      });
      dispatch({
        type: 'userAction/userActionListFetch',
        payload: values,
      });
    });
  };

  /**
   * 查询
   * @param e
   */
  handleSearch = e => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    let beginTime;
    let endTime;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const rangeValue = fieldsValue.time;
      if(!isUndefined(rangeValue) && rangeValue.length > 0){
        beginTime = rangeValue[0].format('YYYY-MM-DD');
        endTime = rangeValue[1].format('YYYY-MM-DD');
      }
      const values = {
        pageNo: 1,
        pageSize: 10,
        beginTime,
        endTime,
        ...fieldsValue,
      };
      this.setState({
        formValues:values,
      });
      dispatch({
        type: 'userAction/userActionListFetch',
        payload: values,
      });
    });
  };

  renderSimpleForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;

    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 24 }}>
          <Col md={6} sm={24}>
            <FormItem>
              {getFieldDecorator('time')(<DatePickerRangePicker onChange={this.handleSearchTime} />)}
            </FormItem>
          </Col>
          {/* <Col md={4} sm={24} style={{paddingRight:"10px",paddingLeft:"10px"}}> */}
          {/* <FormItem> */}
          {/* {getFieldDecorator('type',{ */}
          {/* initialValue:"", */}
          {/* })( */}
          {/* <Select onChange={this.handleSearchType}> */}
          {/* <Option value="">请选择数据类型</Option> */}
          {/* <Option value={1}>操作数据</Option> */}
          {/* <Option value={2}>行为数据</Option> */}
          {/* <Option value={3}>消费数据</Option> */}
          {/* </Select> */}
          {/* )} */}
          {/* </FormItem> */}
          {/* </Col> */}
          <Col md={4} sm={24} style={{paddingRight:"10px",paddingLeft:"10px"}}>
            <FormItem>
              {getFieldDecorator('actionType',{
                initialValue:"",
              })(
                <Select onChange={this.handleActionType}>
                  <Option value="">请选择数据类型</Option>
                  {
                    userActionTypes.map(item => (
                      <Option key={item.value} value={item.value}>{item.name}</Option>
                    ))
                  }
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }

  render() {
    const columns = [
      {
        title: '头像',
        dataIndex: 'headImgUrl',
        key: 'headImgUrl',
        width:"5%",
        render: (text, record) => (
          record.headImgUrl !== "" && record.headImgUrl != null ? <img src={record.headImgUrl} alt={record.nickName} className={styles.awart} style={{border:"1px solid #ddd"}} /> : <div className={styles.awart} style={{border:"1px solid #ddd"}} />
        ),
      },
      {
        title: '昵称',
        dataIndex: 'nickName',
        key: 'nickName',
        width:"10%",
        render:(text,record) => (
          record.nickName !== "" && record.nickName != null ?<div style={{width:140,display: "block",whiteSpace: "nowrap", textOverflow: "ellipsis", overflow: "hidden"}}>{record.nickName}</div> : <div>未知</div>
        ),
      },
      {
        title: '互动',
        dataIndex: 'action',
        key: 'action',
      },
      {
        title: '类型',
        dataIndex: 'type',
        key: 'type',
        width:"10%",
        render: (text, record) => (
          <span>
            {record.type === 1 ? '操作数据' : record.type === 2 ? '行为数据' : record.type === 3 ?'消费数据':'--'}
          </span>
        ),
      },
      {
        title: '时间',
        dataIndex: 'createTime',
        key: 'createTime',
        width:"15%",
        overflow:"hidden",
      },
    ];
    const {
      userAction: { userList },
      loading,
    } = this.props;
    const { selectedRows,formValues:{pageNo}} = this.state;
    userList.pagination.current = pageNo;
    return (
      <PageHeaderLayout>
        <Card>
          <div className={styles.tableListForm}>
            {this.renderSimpleForm()}
          </div>
          <StandardTable
            loading={loading}
            data={userList}
            columns={columns}
            selectedRows={selectedRows}
            onChange={this.handleStandardTableChange}
          />
        </Card>
      </PageHeaderLayout>
    );
  }
}
