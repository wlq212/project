/* eslint-disable react/no-unused-state,no-unused-vars,no-shadow,no-case-declarations,default-case,prefer-destructuring,no-lone-blocks,no-undef,react/destructuring-assignment */
import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import moment from 'moment';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Select,
  Icon,
  Button,
  Dropdown,
  Menu,
  InputNumber,
  DatePicker,
  Modal,
  message,
  Divider,
} from 'antd';
import StandardTable from 'components/StandardTable';
import { removeStore, getStore, setStore } from '../../assets/js/mUtils';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from '../../assets/css/TableList.less';

const FormItem = Form.Item;
const { Option } = Select;

function timestampToTime(timestamp) {
  const date = new Date(timestamp * 1000);// 时间戳为10位需*1000，时间戳为13位的话不需乘1000
  const Y = `${date.getFullYear()  }-`;
  const M = `${date.getMonth() + 1 < 10 ? `0${  date.getMonth() + 1}` : date.getMonth() + 1  }-`;
  const D = `${date.getDate()  } `;
  const h = `${date.getHours()  }:`;
  const m = `${date.getMinutes()  }:`;
  const s = date.getSeconds();
  return Y + M + D + h + m + s;
}

@connect(({ card, loading }) => ({
  card,
  loading: loading.models.card,
}))
@Form.create()
export default class TableList extends PureComponent {
  state = {
    modalVisible: false,
    expandForm: false,
    imageUrlAbstr: '',
    action: `/api/admin/file/upload?type=3&token=${getStore('userInfo')?JSON.parse(getStore('userInfo')).token:""}`,
    data: {
      type: 3,
      token:`${getStore('userInfo')?JSON.parse(getStore('userInfo')).token:""}`,
    },
    selectedRows: [],
    formValues: {
      pageNo: 1,
      pageSize: 10,
    },
  };

  componentDidMount() {
    const { dispatch } = this.props;
    if (getStore('cardInfo')) {
      removeStore('cardInfo');
    }
    if (getStore('cardInfoDetail')) {
      removeStore('cardInfoDetail');
    }
    if (getStore('submit')) {
      removeStore('submit');
    }
   if( getStore("formValues")){
     dispatch({
       type: 'card/cardListButton',
       payload: {
         ...JSON.parse(getStore("formValues")),
       },
     });
     this.setState({
       formValues:{
        ...JSON.parse(getStore("formValues")),
      },
     })
   }else{
     const params = {
       pageNo: 1,
       pageSize: 10,
     };
     dispatch({
       type: 'card/cardListButton',
       payload: params,
     });
   }
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});
    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    this.setState({
      formValues:params,
    })
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }

    dispatch({
      type: 'card/cardListButton',
      payload: params,
    });
  };

  handleFormReset = () => {
    const { form,dispatch} = this.props;
    form.resetFields();
    const params = {
      pageNo: 1,
      pageSize: 10,
    };
    dispatch({
      type: 'card/cardListButton',
      payload: params,
    });
    this.setState({
      formValues:params,
    });

  };


  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (!selectedRows) return;

    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'rule/remove',
          payload: {
            no: selectedRows.map(row => row.no).join(','),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
  };

  handleSearch = e => {
    e.preventDefault();

    const { dispatch, form } = this.props;

    form.validateFields((err, fieldsValue) => {
      if (err) return;
      if(fieldsValue.title){
        fieldsValue.title=fieldsValue.title.replace(/\s/gi,'');
      }
      const values = {
        ...fieldsValue,
        pageSize: 10,
        pageNo: 1,
      };

      this.setState({
        formValues: values,
      });
      dispatch({
        type: 'card/cardListButton',
        payload: values,
      });
    });
  };

  handleModalVisible = flag => {
    this.setState({
      modalVisible: !!flag,
    });
  };

  handleAdd = () => {
    const { dispatch } = this.props;
    dispatch(routerRedux.push('/marketingManage/card/cardEdit/'));

  };

  cardUpdate = fields => {
    const { dispatch } = this.props;
    dispatch(routerRedux.push('/marketingManage/card/cardUpdate/'));
    setStore('updateCardId', fields.cardId);
    setStore("formValues",this.state.formValues)
  };

  delete = rows => {
    const { dispatch } = this.props;
    const {formValues}=this.state;
    const confirm = Modal.confirm;
    confirm({
      title: '提示?',
      content: '确定要删除吗',
      onOk() {
        const params = {
          cardId: rows.cardId,
          syncWx: rows.syncWx,
        };
        const response = dispatch({
          type: 'card/cardDeleteButton',
          payload: params,
        });
        response.then((result) => {
          if (result) {
            switch (result.code) {
              case '200':
                message.success('删除成功');
                const params = {
                  pageNo: formValues.pageNo,
                  pageSize: formValues.pageSize,
                };
                dispatch({
                  type: 'card/cardListButton',
                  payload: params,
                });
                break;
              case '500':
                message.error(result.msg || '删除失败');
                break;
            }
          }
        }, (result) => {
          // console.log(result);
        });


      },
      onCancel() {
      },
    });
  };

  cardUsage = rows => {
    const { dispatch } = this.props;
    dispatch(routerRedux.push(`/marketingManage/card/cardUsage?cardId=${  rows.cardId}`));
    setStore("formValues",this.state.formValues)
  };

  // 统计
  cardCount= rows => {
    const { dispatch } = this.props;
    dispatch(routerRedux.push(`/marketingManage/card/cardCount?cardId=${  rows.cardId}`));
    setStore("formValues",this.state.formValues)
  };

  renderSimpleForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem>
              {getFieldDecorator('title')(<Input placeholder="请输入优惠券名称" />)}
            </FormItem>
          </Col>
          <Col md={16} sm={24}>
            <span className={styles.submitButtons}>
              <Button type="primary" htmlType="submit">
                查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                重置
              </Button>
              <Button icon="plus" type="primary" onClick={() => this.handleAdd(true)} style={{float:"right"}}>
                新建
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }

  renderAdvancedForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="规则编号">
              {getFieldDecorator('no')(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>,
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="调用次数">
              {getFieldDecorator('number')(<InputNumber style={{ width: '100%' }} />)}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="更新日期">
              {getFieldDecorator('date')(
                <DatePicker style={{ width: '100%' }} placeholder="请输入更新日期" />,
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status3')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>,
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status4')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>,
              )}
            </FormItem>
          </Col>
        </Row>
        <div style={{ overflow: 'hidden' }}>
          <span style={{ float: 'right', marginBottom: 24 }}>
            <Button type="primary" htmlType="submit">
              查询
            </Button>
            <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
              重置
            </Button>
            <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
              收起 <Icon type="up" />
            </a>
          </span>
        </div>
      </Form>
    );
  }

  renderForm() {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm();
  }

  render() {
    const {
      card: { cardList },
      loading,
    } = this.props;
    cardList.pagination.current=this.state.formValues.pageNo;
    const { selectedRows} = this.state;
    const columns = [
      {
        title: '优惠券名称',
        dataIndex: 'title',
      },
      {
        title: '优惠券副标题',
        dataIndex: 'subtitle',
      },
      {
        title: '优惠券类型',
        width:"200",
        dataIndex: 'cardType',
        render: (text, record) => (
          <span>{record.cardType === 'CASH' ? '代金券' : record.cardType === 'DISCOUNT' ? '折扣券' : '兑换券'}</span>
        ),
      },
      {
        title: '有效时间',
        render(text, record) {
          {
            if (record.dateInfo.type === 'DATE_TYPE_FIX_TIME_RANGE') {
              return (
                <div>{moment(record.dateInfo.begin_timestamp*1000).format('YYYY-MM-DD HH:mm:ss')}至{moment(record.dateInfo.end_timestamp*1000).format('YYYY-MM-DD HH:mm:ss')}</div>
              );
            }
            if (record.dateInfo.type === 'DATE_TYPE_FIX_TERM') {
              return (
                <div>{record.dateInfo.fixed_term}</div>
              );
            }
          }
        },
      },
      {
        title: '状态',
        dataIndex: 'status',
      },
      {
        title: '库存',
        dataIndex: 'skuQuantity',
      },
      {
        title: '操作',
        fixed: 'right',
        align:"right",
        render: (text, record) => (
          <Fragment>
            <a onClick={() => this.cardUpdate(record)}>编辑</a>
            <Divider type="vertical" />
            <a onClick={() => this.delete(record)}>删除</a>
            <Divider type="vertical" />
            <a onClick={() => this.cardUsage(record)}>使用情况</a>
            <Divider type="vertical" />
            <a onClick={() => this.cardCount(record)}>统计</a>
          </Fragment>
        ),
      },
    ];

    const menu = (
      <Menu onClick={this.handleMenuClick} selectedKeys={[]}>
        <Menu.Item key="remove">删除</Menu.Item>
        <Menu.Item key="approval">批量审批</Menu.Item>
      </Menu>
    );

    return (
      <PageHeaderLayout title="">
        <Card bordered={false}>
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>{this.renderForm()}</div>
            <div className={styles.tableListOperator}>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                  <Dropdown overlay={menu}>
                    <Button>
                      更多操作 <Icon type="down" />
                    </Button>
                  </Dropdown>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={cardList}
              columns={columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
            />
          </div>
        </Card>
      </PageHeaderLayout>
    );
  }
}
