/* eslint-disable no-unused-vars,react/jsx-boolean-value */
import React, { PureComponent, Fragment } from 'react';
import { Route, Redirect, Switch } from 'dva/router';
import { Card, Steps ,List} from 'antd';
import PageHeaderLayout from '../../../layouts/PageHeaderLayout';
import NotFound from '../../Exception/404';
import { getRoutes } from '../../../utils/utils';
import styles from './style.less';

const { Step } = Steps;
export default class StepForm extends PureComponent {
  getCurrentStep() {
    const { location } = this.props;
    const { pathname } = location;
    const pathList = pathname.split('/');
    switch (pathList[pathList.length - 1]) {
      case 'baseinfo':
        return 0;
      case 'carinfo':
        return 1;
      case 'result':
        return 2;
      default:
        return 0;
    }
  }

  render() {
    const { match, routerData, location,loading } = this.props;
    return (
      <PageHeaderLayout tabActiveKey={location.pathname} showReturn={true} url="/marketingManage/card">
        <Steps current={this.getCurrentStep()} className={styles.steps} style={{marginTop:"10px"}}>
          <Step title="基本属性" />
          <Step title="券面信息" />
        </Steps>
        <List loading={loading}>
        <Card bordered={false} style={{paddingBottom:"0px",background:this.getCurrentStep()===1?"#f0f2f5":"#fff"}}>
          <Fragment>
            <Switch>
              {getRoutes(match.path, routerData).map(item => (
                <Route
                  key={item.key}
                  path={item.path}
                  component={item.component}
                  exact={item.exact}
                />
              ))}
              <Redirect
                exact
                from="/marketingManage/card/cardUpdate"
                to="/marketingManage/card/cardUpdate/baseinfo"
              />
              <Route render={NotFound} />
            </Switch>
          </Fragment>
        </Card>
        </List>
      </PageHeaderLayout>
    );
  }
}
