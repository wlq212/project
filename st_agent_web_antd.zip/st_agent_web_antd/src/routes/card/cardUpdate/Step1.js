/* eslint-disable react/no-unused-state,no-unused-vars,camelcase,camelcase,react/destructuring-assignment,no-undef,radix,react/sort-comp,array-callback-return,no-shadow,lines-between-class-members,no-empty,react/no-access-state-in-setstate,no-const-assign */
import React, { Fragment } from 'react';
import { connect } from 'dva';
import {
  Form,
  Input,
  Button,
  Radio,
  DatePicker,
  Table,
  Modal,
  Row,
  Col,
} from 'antd';
import { routerRedux } from 'dva/router';
import moment from 'moment';
import StandardTable from 'components/StandardTable';
import styles from './style.less';
import { setStore, getStore } from '../../../assets/js/mUtils';

const RadioGroup = Radio.Group;
const FormItem = Form.Item;
const { RangePicker} = DatePicker;
const formItemLayout = {
  labelCol: {
    span: 5,
  },
  wrapperCol: {
    span: 19,
  },
};


@Form.create()
class Step1 extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      shop: [],
      cardInfoAddSave: {},
      selectedRows: [],
      validTime1: '0',
      validTime: [],
      fitForShop: 0,
      visible: false,
      cardType: 0,
    };
    this.showModel = this.showModel.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
    this.branchName = this.branchName.bind(this);
    this.selectshop = this.selectshop.bind(this);
    this.onChangeTime = this.onChangeTime.bind(this);
  }

  onChangeTime(date, dateString) {
    this.setState({
      validTime: dateString,
    });
  }

  componentDidMount() {
    const { dispatch } = this.props;
    const that=this;
    dispatch({
      type: 'card/cardGetButton',
      payload: { CardId: getStore('updateCardId') },
    }).then((result) => {
      if (result.code === '200') {
        setStore('cardInfo', { data: result.obj });
      }
      let dataInfo = {};
      const myDate = new Date();
      const now = myDate.toLocaleDateString();
      that.setState({
        validTime: [moment(now).format('YYYY-MM-DD'), moment(now).format('YYYY-MM-DD')],
      });
      if (getStore('cardInfo')) {
        dataInfo = JSON.parse(getStore('cardInfo')).data;
        that.setState({
          title: JSON.parse(getStore('cardInfo')).data.title,
          center_sub_title: JSON.parse(getStore('cardInfo')).data.baseInfo.center_sub_title,
        });
        // console.log(JSON.parse(getStore('cardInfo')).data.baseInfo.date_info.type);
        if (
          JSON.parse(getStore('cardInfo')).data.baseInfo.date_info.type === 'DATE_TYPE_FIX_TIME_RANGE'
        ) {
          that.setState({
            validTime1: 0,
          });
          dataInfo.begin_timestamp =
            JSON.parse(getStore('cardInfo')).data.baseInfo.date_info.begin_timestamp * 1000;
          dataInfo.end_timestamp =
            JSON.parse(getStore('cardInfo')).data.baseInfo.date_info.end_timestamp * 1000;
          that.setState({
            begin_timestamp: moment(dataInfo.begin_timestamp).format('YYYY-MM-DD'),
            end_timestamp: moment(dataInfo.end_timestamp).format('YYYY-MM-DD'),
            validTime: [
              moment(dataInfo.begin_timestamp).format('YYYY-MM-DD'),
              moment(dataInfo.end_timestamp).format('YYYY-MM-DD'),
            ],
          });
        } else if (
          JSON.parse(getStore('cardInfo')).data.baseInfo.date_info.type === 'DATE_TYPE_FIX_TERM'
        ) {
          that.setState({
            validTime1: 1,
            fixed_term: parseInt(JSON.parse(getStore('cardInfo')).data.baseInfo.date_info.fixed_term),
            fixed_begin_term: parseInt(
              JSON.parse(getStore('cardInfo')).data.baseInfo.date_info.fixed_begin_term
            ),
          });
        }
        if (JSON.parse(getStore('cardInfo')).data.baseInfo.code_type === 'CODE_TYPE_NONE') {
          that.setState({
            verification: 0,
          });
        } else if (JSON.parse(getStore('cardInfo')).data.baseInfo.code_type === 'CODE_TYPE_QRCODE') {
          that.setState({
            verification: 1,
          });
        }
        if (
          JSON.parse(getStore('cardInfo')).data.baseInfo.use_all_locations==="true"
        ) {
          // console.log(Boolean(JSON.parse(getStore('cardInfo')).data.baseInfo.use_all_locations) == true);
          that.setState({
            fitForShop: 0,
            shop: [],
          });
        } else if (
          JSON.parse(getStore('cardInfo')).data.baseInfo.use_all_locations==="false"
        ) {
          that.setState({
            fitForShop: 1,
            shop: JSON.parse(getStore('cardInfo')).data.shopList,
          });
        }
        that.setState({
          quantity: parseInt(JSON.parse(getStore('cardInfo')).data.baseInfo.sku.quantity),
          get_limit: parseInt(JSON.parse(getStore('cardInfo')).data.baseInfo.get_limit),
        });
        if (JSON.parse(getStore('cardInfo')).data.baseInfo.service_phone != null) {
          that.setState({
            service_phone: parseInt(JSON.parse(getStore('cardInfo')).data.baseInfo.service_phone),
          });
        }

        if (JSON.stringify(JSON.parse(getStore('cardInfo')).data.advancedInfo.abstract) !== '{}') {
          // 判断是否为空，从而选中
          that.setState({
            abstract: true,
          });
          if (JSON.parse(getStore('cardInfo')).data.advancedInfo.abstract.icon_url_list) {
            if (
              JSON.parse(getStore('cardInfo')).data.advancedInfo.abstract.icon_url_list.length > 0
            ) {
              // 判断是否空数组
              that.setState({
                icon_url_list: JSON.parse(
                  getStore('cardInfo')
                ).data.advancedInfo.abstract.icon_url_list.join(''),
              });
            }
          }
        }
        if (!JSON.parse(getStore('cardInfo')).data.advancedInfo.text_image_list) {
          that.setState({
            text_image_list: [],
            items: [],
          });
        } else {
          that.setState({
            text_image_list: [],
            items: JSON.parse(getStore('cardInfo')).data.advancedInfo.text_image_list,
          });
        }
        console.log(JSON.parse(getStore('cardInfo')))
        if (JSON.parse(getStore('cardInfo')).data.cardType === 'CASH') {
          that.setState({
            cardType: 0,
            leastCost: JSON.parse(getStore('cardInfo')).data.leastCost / 100,
            reduceCost: JSON.parse(getStore('cardInfo')).data.reduceCost / 100,
          });
        } else if (JSON.parse(getStore('cardInfo')).data.cardType === 'DISCOUNT') {
          that.setState({
            cardType: 1,
            discount: (100 - JSON.parse(getStore('cardInfo')).data.discount) / 10,
          });
        } else {
          that.setState({
            cardType: 2,
          });
        }
      }
      that.setState({
        cardInfoAddSave: dataInfo,
      });
    })

  }

  showModel() {
    const { dispatch } = this.props;
    const params = {
      pageSize: 10,
      pageNo: 1,
    };
    dispatch({
      type: 'card/fetch',
      payload: params,
    });
    this.setState({
      visible: true,
    });
  }

  handleCancel() {
    this.setState({
      visible: false,
    });
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }

    dispatch({
      type: 'card/fetch',
      payload: params,
    });
  };

  selectshop = rows => {
    const dataSource = [...this.state.shop];
    if (dataSource.length === 0) {
      dataSource.push(rows);
      this.setState({
        shop: dataSource,
        visible: false,
      });
    } else {
      dataSource.map((item) => {
        if (item.sId ===rows.sId) {

        } else {
          dataSource.push(rows);
        }
      });
      this.setState({
        shop: dataSource.distinct('sId'),
        visible: false,
      });
    }
  };

  handleSearch() {
    const { dispatch } = this.props;
    const params = {
      branchName: this.state.branchName,
      pageSize: 10,
      pageNo: 1,
    };
    dispatch({
      type: 'card/fetch',
      payload: params,
    });
  }
  branchName(e) {
    this.setState({
      branchName: e.target.value.replace(/\s/gi,''),
    });
  }

  deletshop = sId => {
    const dataSource = [...this.state.shop];
    this.setState({ shop: dataSource.filter(item => item.sId !== sId) });
  };

  renderForm() {
    return (
      <Form layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={7} sm={24} style={{ margin: '-10px 0 10px 0' }}>
            <FormItem label="查询参数">
              <Input placeholder="请输入门店分店名" onChange={this.branchName} />
            </FormItem>
          </Col>
          <Col md={1} sm={24} style={{ margin: '-5px 0 10px 0' }}>
            <span className={styles.submitButtons}>
              <Button type="primary" onClick={this.handleSearch}>
                查询
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }

  render() {
    const { form, dispatch, saveshop, loading } = this.props;
    const { selectedRows, shop } = this.state;
    const { getFieldDecorator, validateFields } = form;
    const onValidateForm = () => {
      validateFields((err, values) => {
        const dataOne = JSON.parse(
          JSON.stringify(JSON.parse(getStore('cardInfo')).data).replace(/baseInfo/g, 'base_info')
        );
        const data = {
          data: JSON.parse(JSON.stringify(dataOne).replace(/advancedInfo/g, 'advanced_info')),
        };
        if (Number(values.cardType)=== 0) {
          data.data.cardType = 'CASH';
          data.data.leastCost = values.leastCost * 100;
          data.data.reduceCost = values.reduceCost * 100;
        } else if (Number(values.cardType)=== 1) {
          data.data.cardType = 'DISCOUNT';
          if (values.discount > 0 > 10) {
            message.error('请填写正确的折扣方式');
            return;
          } else {
            data.data.discount = 100 - values.discount * 10;
          }
        } else {
          data.data.cardType = 'GIFT';
        }

        if (String(values.verification)=== '0') {
          data.data.base_info.code_type = 'CODE_TYPE_NONE';
        } else if (String(values.verification)==='1') {
          data.data.base_info.code_type = 'CODE_TYPE_QRCODE';
        }
        if (Number(values.fitForShop)=== 0) {
          data.data.base_info.use_all_locations = true;
          data.data.base_info.location_id_list = [];
        } else if (Number(values.fitForShop)=== 1) {
          data.data.base_info.use_all_locations = false;
          const arr=[];
          if(shop){
            shop.map((item) => {
              arr.push(item.poiId)
            });
          }
          data.data.base_info.location_id_list = arr;
        }
        if (Number(values.validTime1)=== '0') {
          data.data.base_info.date_info.type = 'DATE_TYPE_FIX_TIME_RANGE';
          data.data.base_info.date_info.begin_timestamp =
            moment(this.state.validTime[0], 'YYYY-MM-DD').valueOf() / 1000;
          data.data.base_info.date_info.end_timestamp =
            moment(`${this.state.validTime[1]} 23:59:59`, 'YYYY-MM-DD HH:mm:ss').valueOf() / 1000;
          // console.log(data.data.base_info.date_info.begin_timestamp);
        } else if (Number(values.validTime1)=== '1') {
          data.data.base_info.date_info.type = 'DATE_TYPE_FIX_TERM';
        }
        if (!err) {
          setStore('cardInfo', data);
          dispatch({
            type: 'card/saveStepFormData',
            payload: data,
          });
          dispatch(routerRedux.push('/marketingManage/card/cardUpdate/carinfo'));
        }
      });
    };
    const cancelValidateForm = () => {
      dispatch(routerRedux.push('/marketingManage/card'));
    };
    const title = e => {
      this.setState({
        title: e.target.value,
      });
    };
    const center_sub_title = e => {
      this.setState({
        center_sub_title: e.target.value,
      });
    };
    const cardType = e => {
      this.setState({
        cardType: e.target.value,
      });
    };
    const reduceCost = e => {
      this.setState({
        reduceCost: e.target.value,
      });
    };
    const leastCost = e => {
      this.setState({
        leastCost: e.target.value,
      });
    };
    const discount = e => {
      this.setState({
        discount: e.target.value,
      });
    };
    const validTime = e => {
      this.setState({
        validTime1: e.target.value,
      });
    };
    const quantity = e => {
      this.setState({
        quantity: e.target.value,
      });
    };
    const get_limit = e => {
      this.setState({
        get_limit: e.target.value,
      });
    };
    const verification = e => {
      this.setState({
        verification: e.target.value,
      });
    };
    const fitForShop = e => {
      this.setState({
        fitForShop: e.target.value,
      });
    };
    const fixed_begin_term = e => {
      this.setState({
        fixed_begin_term: e.target.value,
      });
    };
    const fixed_term = e => {
      this.setState({
        fixed_term: e.target.value,
      });
    };

    const fitForShopColuns = [
      {
        title: '门店名',
        key: 'businessName',
        dataIndex: 'businessName',
      },
      {
        title: '门店地址',
        key: 'address',
        render: (text, record) => (
          <span>{record.address}</span>
        ),
      },
      {
        title: '操作',
        render: (text, record) => {
         return(
           <a onClick={() => this.deletshop(record.sId)}>
            删除
           </a>
         )
        },
      },
    ];
    const columns = [
      {
        title: '门店名',
        key: 'businessName',
        dataIndex: 'businessName',
      },
      {
        title: '门店地址',
        key: 'province',
        render: (text, record) => (
          <span>{record.province + record.city + record.district + record.address}</span>
        ),
      },
      {
        title: '审核状态',
        dataIndex: 'availableState',
        key: 'availableState',
        render: (text, record) => (
          <span>
            {Number(record.availableState)=== 4
              ? '审核失败'
              :Number(record.availableState)=== 3
                ? '审核通过'
                : Number(record.availableState)=== 2
                  ? '审核中'
                  : '系统错误'}
          </span>
        ),
      },
      {
        title: '记录状态',
        dataIndex: 'state',
        key: 'state',
        render: (text, record) => <span>{Number(record.state) === 1 ? '通过' : '不通过'}</span>,
      },
      {
        title: '操作',
        align:"right",
        fixed:"right",
        render: (text, record) => (
          <Fragment>
            <a onClick={() => this.selectshop(record)}>
              选择
            </a>
          </Fragment>
        ),
      },
    ];
    console.log(this.state.cardType)
    return (
      <Fragment>
        <Form layout="horizontal" className={styles.stepForm} hideRequiredMark style={{margin: "0px auto",maxWidth:"900px"}}>
          <Form.Item {...formItemLayout} label="优惠券标题">
            {getFieldDecorator('title', {
              initialValue: this.state.title,
              rules: [{ required: true, message: '请输入优惠券标题' }],
            })(
              <div>
                <Input
                  style={{width:"350px"}}
                  disabled
                  placeholder="请输入优惠券标题"
                  addonAfter={this.state.title ? `${this.state.title.length  }/9` : '0/9'}
                  value={this.state.title}
                  onChange={title}
                  maxLength="9"
                />
                <span style={{marginLeft:"20px",color:"rgba(0, 0, 0, 0.25)"}}>建议描述优惠券提供的具体优惠、例如：满100元减5元</span>
              </div>
            )}
          </Form.Item>
          <Form.Item {...formItemLayout} label="优惠券副标题">
            {getFieldDecorator('center_sub_title', {
              initialValue: this.state.center_sub_title,
            })(
              <Input
                placeholder="请输入优惠券副标题"
                disabled
                style={{width:"350px"}}
                addonAfter={
                  this.state.center_sub_title ? `${this.state.center_sub_title.length  }/18` : '0/18'
                }
                onChange={center_sub_title}
                maxLength="18"
              />
            )}
          </Form.Item>
          <Form.Item {...formItemLayout} label="优惠券类型">
            {getFieldDecorator('cardType', {
              initialValue: this.state.cardType,
              rules: [{ required: true, message: '请输入优惠券类型' }],
            })(
              <RadioGroup onChange={cardType} disabled>
                <Radio value={0}>代金券</Radio>
                <Radio value={1}>折扣券</Radio>
                <Radio value={2}>兑换券</Radio>
              </RadioGroup>
            )}
          </Form.Item>
          {Number(this.state.cardType)=== 0 ? (
            <div>
              <Form.Item {...formItemLayout} label="减免金额">
                {getFieldDecorator('reduceCost', {
                  initialValue: this.state.reduceCost,
                  rules: [{ required: true, message: '请输入优惠券减免金额' }],
                })(
                  <div>
                    <Input
                      style={{width:"350px"}}
                      placeholder="请输入优惠券减免金额"
                      addonAfter="元"
                      disabled
                      type="number"
                      onChange={reduceCost}
                      value={this.state.reduceCost}
                    />
                  </div>
                )}
              </Form.Item>
              <Form.Item {...formItemLayout} label="使用条件">
                {getFieldDecorator('leastCost', {
                  initialValue: this.state.leastCost,
                  rules: [{ required: true, message: '请输入优惠券使用条件' }],
                })(
                  <Input
                    style={{width:"350px"}}
                    addonBefore="消费金额满"
                    placeholder="请输入优惠券使用条件"
                    addonAfter="元"
                    disabled
                    type="number"
                    onChange={leastCost}
                  />
                )}
              </Form.Item>
            </div>
          ) : Number(this.state.cardType)=== 1 ? (
            <Form.Item {...formItemLayout} label="折扣额度">
              {getFieldDecorator('discount', {
                initialValue: this.state.discount,
                rules: [{ required: true, message: '请输入优惠券折扣额度' }],
              })(
                <Input
                  disabled
                  style={{width:"350px"}}
                  placeholder="请输入优惠券折扣额度"
                  addonAfter="折"
                  type="number"
                  onChange={discount}
                />
              )}
            </Form.Item>
          ) : (
            ''
          )}

          <Form.Item {...formItemLayout} label="生效时间">
            {getFieldDecorator('validTime1', {
              initialValue: this.state.validTime1,
            })(
              <div>
                <RadioGroup onChange={validTime} value={this.state.validTime1} disabled>
                  <Radio value={0}>固定时间</Radio>
                  <Radio value={1}>领取后生效</Radio>
                </RadioGroup>
              </div>
            )}
          </Form.Item>
          {Number(this.state.validTime1) === 1 ? (
            <div style={{ margin: '0 190px' }}>
              <Form.Item {...formItemLayout} label="">
                {getFieldDecorator('fixed_begin_term', {
                  initialValue: this.state.fixed_begin_term,
                })(
                  <Input
                    disabled
                    style={{width:"350px"}}
                    addonAfter="天"
                    addonBefore="领券以后"
                    type="number"
                    onChange={fixed_begin_term}
                  />
                )}
              </Form.Item>
              <Form.Item {...formItemLayout} label="">
                {getFieldDecorator('fixed_term', {
                  initialValue: this.state.fixed_term,
                })(
                  <Input
                    disabled
                    style={{width:"350px"}}
                    placeholder="有效天数"
                    addonAfter="天"
                    addonBefore="有效天数"
                    type="number"
                    onChange={fixed_term}
                  />
                )}
              </Form.Item>
            </div>
          ) : (
            <Form.Item style={{ margin: '-20px 0px 10px 190px' }} {...formItemLayout} label="">
              <RangePicker
                disabled
                onChange={this.onChangeTime}
                style={{width:"350px"}}
                value={[
                  moment(this.state.validTime[0], 'YYYY-MM-DD'),
                  moment(this.state.validTime[1], 'YYYY-MM-DD'),
                ]}
              />
            </Form.Item>
          )}
          <Form.Item {...formItemLayout} label="库存">
            {getFieldDecorator('quantity', {
              initialValue: this.state.quantity,
              rules: [{ required: true, message: '请输入优惠券库存' }],
            })(
              <Input
                placeholder="请输入优惠券副标题"
                addonAfter="张"
                style={{width:"350px"}}
                disabled
                type="number"
                onChange={quantity}
              />
            )}
          </Form.Item>
          <Form.Item {...formItemLayout} label="每人限额">
            {getFieldDecorator('get_limit', {
              initialValue: this.state.get_limit,
              rules: [{ required: true, message: '请输入优惠券额度' }],
            })(
              <Input
                placeholder="请输入优惠券副标题"
                addonAfter="张"
                disabled
                style={{width:"350px"}}
                type="number"
                onChange={get_limit}
              />
            )}
          </Form.Item>
          <Form.Item {...formItemLayout} label="核销方式">
            {getFieldDecorator('verification', {
              initialValue: this.state.verification,
              rules: [{ required: true, message: '请选择核销方式' }],
            })(
              <div>
                <RadioGroup onChange={verification} value={this.state.verification}>
                  <Radio value={0}>自动核销</Radio>
                  <Radio value={1}>扫码核销</Radio>
                </RadioGroup>
              </div>
            )}
          </Form.Item>
          <Form.Item {...formItemLayout} label="适合门店" style={{marginBottom:"0px"}}>
            {getFieldDecorator('fitForShop', {
              initialValue: this.state.fitForShop,
              rules: [{ required: true, message: '请添加适合门店' }],
            })(
              <div>
                <RadioGroup onChange={fitForShop} value={this.state.fitForShop} disabled>
                  <Radio value={0}>适用全部门店</Radio>
                  <Radio value={1}>指定门店</Radio>
                </RadioGroup>
              </div>
            )}
          </Form.Item>
          {Number(this.state.fitForShop)=== 1 ? (
            <Form.Item {...formItemLayout} label="">
              {getFieldDecorator('fitForShop')(
                <div>

                  <Table
                    style={{ margin: '0 180px', width: '500px' }}
                    bordered
                    dataSource={this.state.shop?this.state.shop:[]}
                    pagination={false}
                    columns={fitForShopColuns}
                  />
                  <Button
                    type="dashed"
                    style={{ width: '500px', marginBottom: 8, margin: '0 180px' }}
                    icon="plus"
                    onClick={this.showModel}
                  >
                    添加
                  </Button>
                </div>
              )}
            </Form.Item>
          ) : (
            ''
          )}

        </Form>
        <Modal
          title="门店列表"
          visible={this.state.visible}
          footer={null}
          width="80%"
          onCancel={this.handleCancel}
        >
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>{this.renderForm()}</div>
            <div className={styles.tableListOperator}>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={saveshop || []}
              columns={columns}
              onChange={this.handleStandardTableChange}
            />
          </div>
        </Modal>
        <Form.Item
          wrapperCol={{
            xs: { span: 24, offset: 0 },
            sm: {
              span: formItemLayout.wrapperCol.span,
              offset: formItemLayout.labelCol.span,
            },
          }}
          label=""
          style={{position:"absolute",width:"100%",left:"13%",marginTop:"30px",marginBottom:"0px"}}
        >
          <Button onClick={cancelValidateForm} style={{ margin: '0 0px',marginRight:"40px"}}>
            取消
          </Button>
          <Button type="primary" onClick={onValidateForm}>
            下一步
          </Button>
        </Form.Item>
      </Fragment>
    );
  }
}

export default connect(({ card, loading }) => ({
  data: card.step,
  loading: loading.models.shop,
  saveshop: card.saveshop,
}))(Step1);
