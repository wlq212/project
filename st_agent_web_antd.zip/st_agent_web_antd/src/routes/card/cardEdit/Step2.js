/* eslint-disable react/destructuring-assignment,camelcase,camelcase,camelcase,camelcase,camelcase,react/jsx-closing-tag-location,no-unused-vars,react/no-access-state-in-setstate,react/no-access-state-in-setstate,react/no-unused-state,eqeqeq,react/sort-comp,default-case,no-return-assign */
import React from 'react';
import { connect } from 'dva';
import {
  Form,
  Input,
  Button,
  Icon,
  Upload,
  Checkbox,
  Card,
  Table,
  Popconfirm,
  message,
} from 'antd';
import { routerRedux } from 'dva/router';
import moment from 'moment';
import styles from './style.less';
import { setStore, getStore } from '../../../assets/js/mUtils';
import bgColor from '../../../assets/js/cardConst';

const { TextArea } = Input;

const FormItem = Form.Item;
const EditableContext = React.createContext();
const EditableRow = ({ form, index, ...props }) => (
  <EditableContext.Provider value={form}>
    <tr {...props} />
  </EditableContext.Provider>
);

const EditableFormRow = Form.create()(EditableRow);

class EditableCell extends React.Component {
  state = {
    editing: false,
  };

  componentDidMount() {
    if (this.props.editable) {
      document.addEventListener('click', this.handleClickOutside, true);
    }
  }

  componentWillUnmount() {
    if (this.props.editable) {
      document.removeEventListener('click', this.handleClickOutside, true);
    }
  }

  toggleEdit = () => {
    const editing = !this.state.editing;
    this.setState({ editing }, () => {
      if (editing) {
        this.input.focus();
      }
    });
  };

  handleClickOutside = e => {
    const { editing } = this.state;
    if (editing && this.cell !== e.target && !this.cell.contains(e.target)) {
      this.save();
    }
  };

  save = () => {
    const { record, handleSave } = this.props;
    this.form.validateFields((error, values) => {
      if (error) {
        return;
      }
      this.toggleEdit();
      handleSave({ ...record, ...values });
    });
  };

  render() {
    const { editing } = this.state;
    const { editable, dataIndex, title, record, ...restProps } = this.props;
    return (
      <td ref={node => (this.cell = node)} {...restProps}>
        {editable ? (
          <EditableContext.Consumer>
            {form => {
              this.form = form;
              return editing ? (
                <FormItem style={{ margin: 0 }}>
                  /* eslint-disable no-return-assign */
                  {form.getFieldDecorator(dataIndex, {
                    rules: [
                      {
                        required: true,
                        message: `${title} is required.`,
                      },
                    ],
                    initialValue: record[dataIndex],
                  })(<Input ref={node => (this.input = node)} onPressEnter={this.save} />)}
                </FormItem>
              ) : (
                <div
                  className="editable-cell-value-wrap"
                  style={{ paddingRight: 24 }}
                  onClick={this.toggleEdit}
                >
                  {restProps.children}
                </div>
              );
            }}
          </EditableContext.Consumer>
        ) : (
          restProps.children
        )}
      </td>
    );
  }
}

const formItemLayout = {
  labelCol: {
    span: 5,
  },
  wrapperCol: {
    span: 19,
  },
};

function beforeUpload(file) {
  const isJPG = file.type === 'image/jpeg';
  if (!isJPG) {
    message.error('You can only upload JPG file!');
  }
  const isLt2M = file.size / 1024 / 1024 < 2;
  if (!isLt2M) {
    message.error('Image must smaller than 2MB!');
  }
  return isJPG && isLt2M;
}

@Form.create()
class Step2 extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      color: '#63b359',
      value: 'Color010',
      loading: false,
      editing: false,
      checked: false,
      imageUrl: '',
      syncWx:true,
      imageUrlAbstr: '',
      action: `/api/admin/file/upload?type=3&token=${getStore('userInfo') ? JSON.parse(getStore('userInfo')).token : ''}`,
      data: {
        type: 3,
        token: `${getStore('userInfo') ? JSON.parse(getStore('userInfo')).token : ''}`,
      },
      dataSource: [],
      count: 0,
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleChangeAbstract = this.handleChangeAbstract.bind(this);
  }

  componentDidMount() {
    if (getStore('submit')) {
      this.setState({
        imageUrl: JSON.parse(getStore('cardInfoDetail')).data.base_info.logo_url,
        brand_name: JSON.parse(getStore('cardInfoDetail')).data.base_info.brand_name,
        color: JSON.parse(getStore('cardInfoDetail')).data.base_info.color,
        notice: JSON.parse(getStore('cardInfoDetail')).data.base_info.notice,
        abstract: JSON.parse(getStore('cardInfoDetail')).data.advanced_info.abstract,
        abstractinfo: JSON.parse(getStore('cardInfoDetail')).data.advanced_info.abstract.abstract,
        custom_url_name: JSON.parse(getStore('cardInfoDetail')).data.base_info.custom_url_name,
        custom_url_sub_title: JSON.parse(getStore('cardInfoDetail')).data.base_info
          .custom_url_sub_title,
        custom_url: JSON.parse(getStore('cardInfoDetail')).data.base_info.custom_url,
        gift: JSON.parse(getStore('cardInfoDetail')).data.gift,
        description: JSON.parse(getStore('cardInfoDetail')).data.base_info.description,
        service_phone: JSON.parse(getStore('cardInfoDetail')).data.base_info.service_phone,
        dataSource: JSON.parse(getStore('cardInfoDetail')).data.advanced_info.text_image_list,
      });
      if (JSON.parse(getStore('cardInfoDetail')).data.advanced_info.abstract === '{}') {
        this.setState({
          abstract: false,
        });
      } else if (JSON.parse(getStore('cardInfoDetail')).data.advanced_info.abstract.icon_url_list) {
        this.setState({
          abstract: true,
          imageUrlAbstr: JSON.parse(getStore('cardInfoDetail')).data.advanced_info.abstract
            .icon_url_list[0],
        });
      }
      if (Number(JSON.parse(getStore('cardInfoDetail')).data.syncWx) === 1) {
        this.setState({
          syncWx: true,
        });
      } else {
        this.setState({
          syncWx: false,
        });
      }
    }
  }

  handleDelete = key => {
    const dataSource = [...this.state.dataSource];
    this.setState({ dataSource: dataSource.filter((item, index) => index !== key) });
  };

  handleAdd = () => {
    const { dataSource } = this.state;
    const newData = {
      image_url: '',
      text: '',
    };
    this.setState({
      dataSource: [...dataSource, newData],
    });
  };

  handleSave = row => {
    const newData = [...this.state.dataSource];
    const index = newData.findIndex(item => row.key === item.key);
    const item = newData[index];
    newData.splice(index, 1, {
      ...item,
      ...row,
    });
    this.setState({ dataSource: newData });
  };

  handleChange(info) {
    if (info.file.status === 'uploading') {
      this.setState({ loading: true });
      return;
    }
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.setState({
        imageUrl: info.file.response.obj,
        loading: false,
      });
    }
  }

  handleChangeAbstract(info) {
    if (info.file.status === 'uploading') {
      this.setState({ loading1: true });
      return;
    }
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.setState({
        imageUrlAbstr: info.file.response.obj,
        loading1: false,
      });
    }
  }

  handleTextKey = rows => {
    this.setState({
      key: rows,
    });
  };

  handleText = e => {
    this.state.dataSource[this.state.key].text = e.target.value;
    this.setState({
      dataSource: this.state.dataSource,
    });
  };

  handleChangeTab = info => {
    if (info.file.status === 'uploading') {
      this.setState({ loading2: true });
      return;
    }
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.state.dataSource[this.state.key].image_url = info.file.response.obj;
      this.setState({
        dataSource: this.state.dataSource,
        loading2: false,
      });
    }
  };

  render() {
    const { form, dispatch, submitting,loading } = this.props;
    const { getFieldDecorator, validateFields } = form;
    const { value } = this.state;
    const uploadButton = (
      <div>
        <Icon type={this.state.loading ? 'loading' : 'plus'} />
        <div className="ant-upload-text">本地上传</div>
      </div>
    );
    const uploadButton1 = (
      <div>
        <Icon type={this.state.loading1 ? 'loading' : 'plus'} />
        <div className="ant-upload-text">本地上传</div>
      </div>
    );
    const uploadButton2 = (
      <div>
        <Icon type={this.state.loading2 ? 'loading' : 'plus'} />
        <div className="ant-upload-text">本地上传</div>
      </div>
    );
    const columnsone = [
      {
        title: '图片',
        dataIndex: 'image_url',
        width: '20%',
        render: (text, record, index) => {
          return (
            <Upload
              name="file"
              listType="picture-card"
              className={styles.antUpload}
              showUploadList={false}
              action={this.state.action}
              beforeUpload={() => this.handleTextKey(index)}
              onChange={this.handleChangeTab}
            >
              {dataSource ? (
                dataSource[index].image_url ? (
                  <img
                    src={dataSource[index].image_url}
                    alt="avatar"
                    style={{
                      width: '100px',
                      height: '100px',
                    }}
                  />
                ) : (
                  uploadButton2
                )
              ) : (
                ''
              )}
            </Upload>
          );
        },
      },
      {
        title: '文字',
        dataIndex: 'text',
        render: (text, record, index) => {
          return (
            <TextArea
              rows={4}
              onChange={this.handleText}
              placeholder="请输入图片描述，最多输入512个中文"
              onFocus={() => this.handleTextKey(index)}
              maxLength="512"
            />
          );
        },
      },
      {
        title: '操作',
        width: 80,
        dataIndex: '操作',
        align: 'right',
        fixed: 'right',
        render: (text, record, index) => {
          return this.state.dataSource.length >= 1 ? (
            <Popconfirm title="确定是否删除？" onConfirm={() => this.handleDelete(index)}>
              <a>删除</a>
            </Popconfirm>
          ) : null;
        },
      },
    ];
    const { dataSource } = this.state;
    const components = {
      body: {
        row: EditableFormRow,
        cell: EditableCell,
      },
    };
    const columns = columnsone.map(col => {
      if (!col.editable) {
        return col;
      }
      return {
        ...col,
        onCell: record => ({
          record,
          editable: col.editable,
          dataIndex: col.dataIndex,
          title: col.title,
          handleSave: this.handleSave,
        }),
      };
    });
    const onPrev = () => {
      dispatch(routerRedux.push('/marketingManage/card/cardEdit/baseinfo'));
    };
    const onValidateForm = e => {
      e.preventDefault();
      validateFields((err, values) => {
        const cardInfo = JSON.parse(getStore('cardInfo'));
        cardInfo.data.base_info.logo_url = this.state.imageUrl;
        cardInfo.data.base_info.brand_name = values.brand_name;
        cardInfo.data.base_info.color = this.state.value;
        cardInfo.data.base_info.notice = values.notice;
        if (!values.abstract) {
          cardInfo.data.advanced_info.abstract = {};
        }
        if (this.state.imageUrlAbstr != null && this.state.imageUrlAbstr !== '') {
          cardInfo.data.advanced_info.abstract.icon_url_list = [this.state.imageUrlAbstr];
        }
        cardInfo.data.advanced_info.abstract.abstract = values.abstractinfo;
        cardInfo.data.base_info.custom_url_name = values.custom_url_name;
        cardInfo.data.base_info.custom_url_sub_title = values.custom_url_sub_title;
        cardInfo.data.base_info.custom_url = values.custom_url;
        cardInfo.data.gift = values.gift;
        cardInfo.data.base_info.description = values.description;
        cardInfo.data.base_info.service_phone = values.service_phone;
        if (this.state.syncWx) {
          cardInfo.data.syncWx = 1;
        } else {
          cardInfo.data.syncWx = 0;
        }
        cardInfo.data.advanced_info.text_image_list = this.state.dataSource;
        if (!err) {
          setStore('cardInfoDetail', cardInfo);
          setStore('submit', true);
          dispatch({
            type: 'card/cardAdd',
            payload: cardInfo.data,
          }).then((result) => {
            switch (result.code) {
              case '200':
                dispatch(routerRedux.push('/marketingManage/card'));
                message.success('添加成功');
                break;
              case '500':
                message.error(result.msg);
                break;
            }
          });
        }
      });
    };
    const selectColor = e => {
      // console.log(e.target.attributes['value'].value);
      this.setState({
        color: e.target.id,
        value: e.target.attributes.value.value,
      });
    };
    const brand_name = e => {
      this.setState({
        brand_name: e.target.value,
      });
    };
    const notice = e => {
      this.setState({
        notice: e.target.value,
      });
    };
    const abstractinfo = e => {
      this.setState({
        abstractinfo: e.target.value,
      });
    };
    const custom_url_name = e => {
      this.setState({
        custom_url_name: e.target.value,
      });
    };
    const custom_url_sub_title = e => {
      this.setState({
        custom_url_sub_title: e.target.value,
      });
    };
    const custom_url = e => {
      this.setState({
        custom_url: e.target.value,
      });
    };
    const checkboxselelct = e => {
      if (e.target.checked) {
        this.setState({
          abstract: true,
        });
      } else {
        this.setState({
          abstract: false,
        });
      }
    };
    const gift = e => {
      this.setState({
        gift: e.target.value,
      });
    };
    const description = e => {
      this.setState({
        description: e.target.value,
      });
    };
    const service_phone = e => {
      this.setState({
        service_phone: e.target.value,
      });
    };
    const syncWx = e => {
      this.setState({
        syncWx: e.target.checked,
      });
    };
    const end_timestamp = moment(
      JSON.parse(getStore('cardInfo')).data.base_info.date_info.end_timestamp * 1000,
    ).format('YYYY-MM-DD');
    // console.log(end_timestamp);
    const begin_timestamp = moment(
      JSON.parse(getStore('cardInfo')).data.base_info.date_info.begin_timestamp * 1000,
    ).format('YYYY-MM-DD');
    const validTime1 = JSON.parse(getStore('cardInfo')).data.base_info.date_info.type;
    return (
      <div style={{ overflow: 'hidden',marginTop:"-30px"}}>
        <Card title="券面详情" >
          <div>
            <div style={{ float: 'left' }}>
              <Form layout="horizontal" className={styles.stepForm} style={{ margin: '0px 30px' }}>
                <Form.Item {...formItemLayout} className={styles.stepFormText} label="小程序logo">
                  {getFieldDecorator('logo_url', {
                    initialValue: this.state.imageUrl,
                    rules: [
                      {
                        required: true,
                        message: '请上传小程序头像',
                      },
                    ],
                  })(
                    <div className="clearfix">
                      <Upload
                        name="file"
                        listType="picture-card"
                        className={styles.antUpload}
                        showUploadList={false}
                        action={this.state.action}
                        beforeUpload={beforeUpload}
                        onChange={this.handleChange}
                      >
                        {this.state.imageUrl ? (
                          <img
                            src={this.state.imageUrl}
                            alt="avatar"
                            style={{ width: '100px', height: '100px' }}
                          />
                        ) : (
                          uploadButton
                        )}
                      </Upload>
                    </div>,
                  )}
                </Form.Item>
                <Form.Item {...formItemLayout} className={styles.stepFormText} label="商户名称">
                  {getFieldDecorator('brand_name', {
                    initialValue: this.state.brand_name,
                    rules: [
                      {
                        required: true,
                        message: '请输入商户名称',
                      },
                    ],
                  })(
                    <Input
                      maxLength="12"
                      onChange={brand_name}
                      addonAfter={
                        this.state.brand_name ? `${this.state.brand_name.length  }/12` : '0/12'
                      }
                      value={this.state.brand_name}
                    />,
                  )}
                </Form.Item>
                <Form.Item {...formItemLayout} className={styles.stepFormText} label="卡券颜色">
                  {getFieldDecorator('color', {
                    initialValue: this.state.color,
                    rules: [
                      {
                        required: true,
                        message: '请选择颜色',
                      },
                    ],
                  })(
                    <ul style={{ listStyle: 'none', margin: '20px 0px 0 -30px' }}>
                      {bgColor.bgColor.map((item) => {
                        return (
                          <li
                            style={{
                              background: item.color,
                              width: '30px',
                              height: '30px',
                              float: 'left',
                              margin: '-20px 15px 0 -10px',
                              cursor: 'pointer',
                              border: item.value === value ? '2px solid #000' : '',
                            }}
                            id={item.color}
                            value={item.value}
                            onClick={selectColor}
                          />
                        );
                      })}
                    </ul>,
                  )}
                </Form.Item>
                <Form.Item {...formItemLayout} className={styles.stepFormText} label="操作说明">
                  {getFieldDecorator('notice', {
                    initialValue: this.state.notice,
                    rules: [
                      {
                        required: true,
                        message: '请输入操作说明',
                      },
                    ],
                  })(
                    <Input
                      maxLength="16"
                      onChange={notice}
                      addonAfter={this.state.notice ? `${this.state.notice.length  }/16` : '0/16'}
                      value={this.state.notice}
                    />,
                  )}
                </Form.Item>
                <Form.Item {...formItemLayout} className={styles.stepFormText} label="券面设置">
                  {getFieldDecorator('abstract')(
                    <Checkbox onChange={checkboxselelct} checked={this.state.abstract}>
                      设置封面
                    </Checkbox>,
                  )}
                </Form.Item>
                {this.state.abstract ? (
                  <div>
                    <Form.Item {...formItemLayout} className={styles.stepFormText} label="封面图片">
                      <Upload
                        name="file"
                        listType="picture-card"
                        className={styles.antUpload}
                        showUploadList={false}
                        action={this.state.action}
                        beforeUpload={beforeUpload}
                        onChange={this.handleChangeAbstract}
                      >
                        {this.state.imageUrlAbstr ? (
                          <img
                            src={this.state.imageUrlAbstr}
                            alt="avatar"
                            style={{ width: '100px', height: '100px' }}
                          />
                        ) : (
                          uploadButton1
                        )}
                      </Upload>
                    </Form.Item>
                    <Form.Item {...formItemLayout} className={styles.stepFormText} label="封面介绍">
                      {getFieldDecorator('abstractinfo', {
                        initialValue: this.state.abstractinfo,
                      })(
                        <Input
                          maxLength="12"
                          onChange={abstractinfo}
                          addonAfter={
                            this.state.abstractinfo
                              ? `${this.state.abstractinfo.length  }/12`
                              : '0/12'
                          }
                          value={this.state.abstractinfo}
                        />,
                      )}
                    </Form.Item>
                  </div>
                ) : (
                  ''
                )}
                <Form.Item {...formItemLayout} className={styles.stepFormText} label="场景入口">
                  {getFieldDecorator('custom_url_name', {
                    initialValue: this.state.custom_url_name,
                  })(
                    <Input
                      maxLength="15"
                      addonBefore="场景名称"
                      onChange={custom_url_name}
                      addonAfter={
                        this.state.custom_url_name
                          ? `${this.state.custom_url_name.length  }/15`
                          : '0/15'
                      }
                    />,
                  )}
                  {getFieldDecorator('custom_url_sub_title', {
                    initialValue: this.state.custom_url_sub_title,
                  })(
                    <Input
                      maxLength="18"
                      addonBefore="引导语"
                      style={{ margin: '10px 0px' }}
                      onChange={custom_url_sub_title}
                      addonAfter={
                        this.state.custom_url_sub_title
                          ? `${this.state.custom_url_sub_title.length  }/18`
                          : '0/18'
                      }
                    />,
                  )}
                  {getFieldDecorator('custom_url', {
                    initialValue: this.state.custom_url,
                  })(
                    <Input
                      maxLength="128"
                      addonBefore="跳转链接"
                      onChange={custom_url}
                      addonAfter={
                        this.state.custom_url ? `${this.state.custom_url.length  }/128` : '0/128'
                      }
                      value={this.state.custom_url}
                    />,
                  )}
                </Form.Item>
              </Form>
            </div>
            <div style={{ float: 'right', position: 'relative',marginRight:"50px"}}>
              <div
                style={{
                  width: '350px',
                  height: '600px',
                  marginLeft: '0%',
                  border: '1px solid #ddd',
                  background: this.state.color,
                }}
              >
                <div
                  style={{
                    width: '330px',
                    height: '530px',
                    background: '#fff',
                    margin: '50px auto 10px auto',
                    textAlign: 'center',
                  }}
                >
                  {this.state.imageUrl ? (
                    <img
                      alt=""
                      src={this.state.imageUrl ? this.state.imageUrl : ''}
                      style={{
                        width: '100px',
                        height: '100px',
                        borderRadius: '50%',
                        border: '1px solid #ddd',
                        left: '130px',
                        position: 'absolute',
                        top: '10px',
                      }}
                    />
                  ) : (
                    <img
                      alt=""
                      style={{
                        width: '100px',
                        height: '100px',
                        borderRadius: '50%',
                        border: '1px solid #ddd',
                        left: '130px',
                        position: 'absolute',
                        top: '10px',
                      }}
                    />
                  )}
                  <div style={{ paddingTop: '80px' }}>
                    <div style={{color:"#000",fontSize:"20px"}}>{JSON.parse(getStore('cardInfo')).data.base_info.title}</div>
                    <span>{JSON.parse(getStore('cardInfo')).data.base_info.center_sub_title}</span>
                    <div style={{fontSize:"18px"}}>{this.state.brand_name}</div>
                    <p style={{ marginTop: '10px' }}>
                      可用时间：<br/>起始日期 {
                      validTime1 === 'DATE_TYPE_FIX_TERM' ? (
                        <span>
                          <span>{`领券后${  JSON.parse(getStore('cardInfo')).data.base_info.date_info.fixed_begin_term  }天生效`}</span>
                          <span>{`有效天数${  JSON.parse(getStore('cardInfo')).data.base_info.date_info.fixed_term  }天`}</span>
                        </span>
): (
  <span>
    <span>{getStore('cardInfo') ? begin_timestamp : ''}</span><br/>结束日期<span>
      {getStore('cardInfo') ? end_timestamp : ''}</span>
  </span>
)}
                    </p>
                    <div style={{ position: 'relative' }}>
                      <img
                        alt=""
                        src={this.state.imageUrlAbstr}
                        style={{
                          width: '300px',
                          height: '120px',
                          marginLeft: '0px',
                          border: '1px solid #ddd',
                          marginTop: '20px',
                        }}
                      />
                      <div
                        style={{
                          width: '300px',
                          height: '20px',
                          position: 'absolute',
                          background: 'rgba(0,0,0,0.5)',
                          left: '15px',
                          color: '#fff',
                          textAlign: 'left',
                        }}
                      >
                        {this.state.abstractinfo}
                      </div>
                    </div>
                    <div style={{ marginTop: '30px' }}>
                      <a href={this.state.custom_url}>
                        <span style={{ float: 'left', marginLeft: '15px', color: '#000' }}>
                          {this.state.custom_url_name}
                        </span>
                        <span
                          style={{
                            float: 'right',
                            color: '#000',
                            marginRight: '15px',
                          }}
                        >
                          {this.state.custom_url_sub_title}
                        </span>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>
        <Card title="详细信息" style={{ marginTop: '7px' }}>
          <div>
            <div style={{ float: 'left' }}>
              <Form layout="horizontal" className={styles.stepForm} style={{ margin: '0px 30px' }}>
                <Form.Item {...formItemLayout} className={styles.stepFormText} label="优惠说明">
                  {getFieldDecorator('gift', {
                    initialValue: this.state.gift,
                    rules: [
                      {
                        required: true,
                        message: '请输入优惠说明',
                      },
                    ],
                  })(<TextArea rows={4} onChange={gift} style={{ width: '420px' }} />)}
                </Form.Item>
                <Form.Item {...formItemLayout} className={styles.stepFormText} label="使用须知">
                  {getFieldDecorator('description', {
                    initialValue: this.state.description,
                    rules: [
                      {
                        required: true,
                        message: '请输入使用须知',
                      },
                    ],
                  })(<TextArea rows={4} onChange={description} />)}
                </Form.Item>

                <Form.Item {...formItemLayout} className={styles.stepFormText} label="客服电话">
                  {getFieldDecorator('service_phone', {
                    initialValue: this.state.service_phone,
                  })(<Input onChange={service_phone} />)}
                </Form.Item>
                <Form.Item {...formItemLayout} className={styles.stepFormText} label="图文介绍">
                  <div>
                    <Button onClick={this.handleAdd} type="primary" style={{ marginBottom: 16 }}>
                      新增图文
                    </Button>
                    <span style={{marginLeft:"10px",color:"rgba(0, 0, 0, 0.25)"}}>显示于优惠券详情页下方，最多20组</span>
                    <Table
                      components={components}
                      rowClassName={() => 'editable-row'}
                      bordered
                      pagination={false}
                      dataSource={dataSource}
                      columns={columns}
                    />
                  </div>
                </Form.Item>
                <Form.Item {...formItemLayout} className={styles.stepFormText} label="微信同步">
                  {getFieldDecorator('syncWx', {
                    initialValue: this.state.syncWx,
                    rules: [
                      {
                        required: true,
                        message: '请选择微信同步',
                      },
                    ],
                  })(<Checkbox onChange={syncWx} checked={this.state.syncWx} />)}
                </Form.Item>
              </Form>
            </div>
            <div style={{ float: 'right', position: 'relative' ,marginRight:"50px"}}>
              <div
                style={{
                  width: '350px',
                  height: '600px',
                  border: '1px solid #ddd',
                  marginLeft: '30px',
                  background: this.state.color,
                }}
              >
                <div
                  style={{
                    width: '330px',
                    height: '530px',
                    background: '#fff',
                    margin: '50px auto 10px auto',
                    textAlign: 'left',
                  }}
                >
                  <div style={{ paddingTop: '10px' }}>
                    <div style={{ paddingLeft: '20px' }}>
                      <h3>卡券详情</h3>
                      <p style={{ marginTop: '10px' }}>使用说明：{this.state.gift}</p>
                      <p style={{ marginTop: '10px' }}>
                        可用时间：<br/>起始日期 {
                        validTime1 === 'DATE_TYPE_FIX_TERM' ? (
                          <span>
                            <span>{`领券后${  JSON.parse(getStore('cardInfo')).data.base_info.date_info.fixed_begin_term  }天生效`}</span>
                            <span>{`有效天数${  JSON.parse(getStore('cardInfo')).data.base_info.date_info.fixed_term  }天`}</span>
                          </span>
): (
  <span>
    <span>{getStore('cardInfo') ? begin_timestamp : ''}</span><br/>结束日期<span>
      {getStore('cardInfo') ? end_timestamp : ''}</span>
  </span>
)}
                      </p>
                      <p style={{ marginTop: '10px' }}>使用须知：{this.state.description}</p>
                      <h3>图文介绍</h3>
                    </div>
                    {dataSource.map((item) => {
                      return (
                        <div style={{ position: 'relative', marginBottom: '10px' }}>
                          {item.image_url ? (
                            <img
                              alt=""
                              src={item.image_url}
                              style={{
                                width: '300px',
                                height: '120px',
                                border: '1px solid #ddd',
                                marginTop: '20px',
                                marginLeft: '15px',
                              }}
                            />
                          ) : (
                            <img
                              alt=""
                              style={{
                                width: '300px',
                                height: '120px',
                                border: '1px solid #ddd',
                                marginTop: '20px',
                                marginLeft: '15px',
                              }}
                            />
                          )}
                          <div
                            style={{
                              width: '300px',
                              height: '20px',
                              position: 'absolute',
                              background: 'rgba(0,0,0,0.5)',
                              left: '15px',
                              color: '#fff',
                            }}
                          >
                            {item.text}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>
        <Form.Item
          style={{position:"absolute",width:"100%",margin:"0 auto",marginTop:"5px",left:"24%"}}
          wrapperCol={{
            xs: { span: 24, offset: 0 },
            sm: {
              span: formItemLayout.wrapperCol.span,
              offset: formItemLayout.labelCol.span,
            },
          }}
          label=""

        >
          <Button onClick={onPrev} style={{ margin: '0 0px',marginRight:"40px"}}>
            上一步
          </Button>
          <Button type="primary" onClick={onValidateForm} loading={loading}>
            提交
          </Button>

        </Form.Item>
      </div>
    );
  }
}

export default connect(({ card, loading }) => ({
  submitting: loading.effects['card/submitStepForm'],
  data: card.step,
}))(Step2);
