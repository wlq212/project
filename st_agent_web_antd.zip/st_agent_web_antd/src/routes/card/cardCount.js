/* eslint-disable no-unused-vars,no-undef,react/destructuring-assignment,default-case,no-case-declarations,no-shadow,prefer-destructuring,func-names,react/sort-comp,class-methods-use-this,react/jsx-boolean-value */
import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Select,
  Icon,
  Button,
  Dropdown,
  Menu,
  InputNumber,
  DatePicker,
  Modal,
  message,
} from 'antd';
import StandardTable from 'components/StandardTable';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from '../../assets/css/TableList.less';
import moments from '../../models/moments';

const { RangePicker } = DatePicker;
const FormItem = Form.Item;
const { Option } = Select;

/**
 * @return {string}
 */
function GetQueryString(name) {
  const reg = new RegExp(`(^|&)${  name  }=([^&]*)(&|$)`);
  const num = window.location.href.indexOf('?');
  const r = window.location.href.substr(num + 1).match(reg);
  if (r != null) return unescape(r[2]);
  return null;
};
@connect(({ card, loading }) => ({
  card,
  loading: loading.models.card,
}))
@Form.create()
export default class TableList extends PureComponent {
  constructor(props){
    super(props)
    this.state={
      modalVisible: false,
      expandForm: false,
      selectedRows: [],
      formValues: {
        pageNo:1,
        pageSize:10,
        beginRefDateTime:"",
        endRefDateTime:"",
      },
    };
    this.onChange=this.onChange.bind(this);
  }

  componentDidMount() {
    const {dispatch}=this.props;
    const day1 = new Date();
    day1.setTime(day1.getTime()-24*60*60*1000);
    const s1 = `${day1.getFullYear()}-${  day1.getMonth()+1>=10?day1.getMonth()+1:`0${day1.getMonth()+1}`}-${  day1.getDate()<10? `0${day1.getDate()}`:day1.getDate()}`;
    const day2 = new Date();
    day2.setTime(day2.getTime());
    const s2 = `${day2.getFullYear()}-${ day1.getMonth()+1>=10?day1.getMonth()+1:`0${day1.getMonth()+1}` }-${  day1.getDate()<10? `0${day1.getDate()}`:day1.getDate()}`;
    this.state.formValues.beginRefDateTime=s1;
    this.state.formValues.endRefDateTime=s2;
    this.setState({
      formValues:this.state.formValues,
    });
    dispatch({
      type: 'card/cardStatListButton',
      payload: {
        pageNo:"1",
        pageSize:"10",
        cardId:this.GetQueryString("cardId"),
        beginRefDateTime:s1,
        endRefDateTime:s2,
      },
    });
  }

  GetQueryString(name) {
    const reg = new RegExp(`(^|&)${  name  }=([^&]*)(&|$)`);
    const num = window.location.href.indexOf('?');
    const r = window.location.href.substr(num + 1).match(reg);
    if (r != null) return unescape(r[2]);
    return null;
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});
    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      cardId:this.GetQueryString("cardId"),
      ...formValues,
      ...filters,
    };
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }

    dispatch({
      type: 'card/cardStatListButton',
      payload: params,
    });
  };

  handleFormReset = () => {
    const { form} = this.props;
    form.resetFields();
    this.setState({
      formValues: {},
    });

  };


  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (!selectedRows) return;

    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'rule/remove',
          payload: {
            no: selectedRows.map(row => row.no).join(','),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
  };

  handleSearch = e => {
    e.preventDefault();

    const { dispatch} = this.props;

    dispatch({
      type: 'card/cardStatListButton',
      payload:{
        beginRefDateTime:this.state.beginRefDateTime,
        endRefDateTime:this.state.endRefDateTime,
        cardId:this.state.cardId,
      },
    });
  };

  handleModalVisible = flag => {
    this.setState({
      modalVisible: !!flag,
    });
  };

  // 日期选择
  onChange(a,b){
    const {dispatch}=this.props;
     this.setState({
       beginRefDateTime:b[0],
       endRefDateTime:b[1],
       cardId:GetQueryString("cardId"),
     });
    this.state.formValues.beginRefDateTime=b[0];
    this.state.formValues.endRefDateTime=b[1];
    this.setState({
      formValues:this.state.formValues,
    })
    dispatch({
      type: 'card/cardStatListButton',
      payload: this.state.formValues,
    });
  }

  handleAdd = fields => {
    const { dispatch } = this.props;
    dispatch({
      type: 'rule/add',
      payload: {
        description: fields.desc,
      },
    });

    message.success('添加成功');
    this.setState({
      modalVisible: false,
    });
  };

  delete = rows => {
    const { dispatch } = this.props;
    const confirm = Modal.confirm;
    confirm({
      title: '提示?',
      content: '确定要删除吗',
      onOk() {
        const params = {
          cardId: rows.cardId,
          syncWx: rows.syncWx,
        };
        const response = dispatch({
          type: 'card/cardDeleteButton',
          payload: params,
        });
        response.then(function(result) {
          if (result) {
            switch (result.code) {
              case '200':
                message.success('删除成功');
                const params = {
                  cardId: this.GetQueryString('cardId'),
                  pageNo: 1,
                  pageSize: 10,
                };
                dispatch({
                  type: 'card/cardListButton',
                  payload: params,
                });
                break;
              case '500':
                message.error(result.msg || '删除失败');
                break;
            }
          }
        }, (result) => {
          // console.log(result);
        });


      },
      onCancel() {
      },
    });
  };

  renderSimpleForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem>
              {getFieldDecorator('beginTime')(  <RangePicker onChange={this.onChange} />)}
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }

  renderAdvancedForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="规则编号">
              {getFieldDecorator('no')(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>,
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="调用次数">
              {getFieldDecorator('number')(<InputNumber style={{ width: '100%' }} />)}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="更新日期">
              {getFieldDecorator('date')(
                <DatePicker style={{ width: '100%' }} placeholder="请输入更新日期" />,
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status3')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>,
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status4')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>,
              )}
            </FormItem>
          </Col>
        </Row>
        <div style={{ overflow: 'hidden' }}>
          <span style={{ float: 'right', marginBottom: 24 }}>
            <Button type="primary" htmlType="submit">
              查询
            </Button>
            <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
              重置
            </Button>
            <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
              收起 <Icon type="up" />
            </a>
          </span>
        </div>
      </Form>
    );
  }

  renderForm() {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm();
  }

  render() {
    const {
      card: { saveCardStatList },
      loading,
    } = this.props;
    const { selectedRows, modalVisible } = this.state;
    const columns = [
      {
        title: '日期',
        key:"id",
        dataIndex: 'refDate',
      },
      {
        title: '浏览',
        key:"id",
        children:[
          {
            title: '次数',
            dataIndex: 'viewCnt',
          },
          {
            title: '人数',
            dataIndex: 'viewUser',
          },
        ],
      },
      {
        title: '领取',
        key:"id",
        children:[
          {
            title: '次数',
            dataIndex: 'receiveCnt',
          },
          {
            title: '人数',
            dataIndex: 'receiveUser',
          },
        ],
      },
      {
        title: '核销',
        key:"id",
        children:[
          {
            title: '次数',
            dataIndex: 'verifyCnt',
          },
          {
            title: '人数',
            dataIndex: 'verifyUser',
          },
        ],
      },
      {
        title: '转赠',
        key:"id",
        children:[
          {
            title: '次数',
            dataIndex: 'givenCnt',
          },
          {
            title: '人数',
            dataIndex: 'givenUser',
          },
        ],
      },
      {
        title: '过期',
        key:"id",
        children:[
          {
            title: '次数',
            dataIndex: 'expireCnt',
          },
          {
            title: '人数',
            dataIndex: 'expireUser',
          },
        ],
      },

    ];

    const menu = (
      <Menu onClick={this.handleMenuClick} selectedKeys={[]}>
        <Menu.Item key="remove">删除</Menu.Item>
        <Menu.Item key="approval">批量审批</Menu.Item>
      </Menu>
    );

    return (
      <PageHeaderLayout title="" showReturn={true} url="/marketingManage/card">
        <Card bordered={false}>
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>{this.renderForm()}</div>
            <div className={styles.tableListOperator}>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                  <Dropdown overlay={menu}>
                    <Button>
                      更多操作 <Icon type="down" />
                    </Button>
                  </Dropdown>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={saveCardStatList}
              columns={columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
            />
          </div>
        </Card>
      </PageHeaderLayout>
    );
  }
}
