/* eslint-disable prefer-destructuring,no-unused-vars,react/destructuring-assignment,no-case-declarations,default-case,react/sort-comp,react/jsx-props-no-multi-spaces,react/jsx-indent,react/jsx-closing-tag-location,react/jsx-boolean-value */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import {
  List,
  Card,
  Radio,
  Input,
  Modal,
  message,
  Icon,
  Button,
  DatePicker,
  Select,
  Dropdown,
  Menu,
  Avatar,
} from 'antd';

import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from './commentUserList.less';
import { getStore, setStore } from '../../assets/js/mUtils';

const {RangePicker} = DatePicker;

const { TextArea } = Input;
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;

function GetQueryString(name) {
  const reg = new RegExp(`(^|&)${  name  }=([^&]*)(&|$)`);
  const num = window.location.href.indexOf('?');
  const r = window.location.href.substr(num + 1).match(reg);
  if (r != null)
    return unescape(r[2]);
  return null;
};
@connect(({ newActivity, loading }) => ({
  newActivity,
  loading: loading.models.newActivity,
}))
export default class BasicList extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      modalVisible: false,
      content: '',
      sendCardState:"发送卡券",
      replayObj: {},
      searchParams: {
        pageNo: 1,
        pageSize: 10,
        activityId: GetQueryString("aId"),
        type:GetQueryString("type"),
        beginTime: '',
        endTime: '',
        commentType: '',
        isPrize: '',
      },
    };
    this.onChangeTime = this.onChangeTime.bind(this);
    this.radioChange = this.radioChange.bind(this);
    this.prizeSelelct = this.prizeSelelct.bind(this);
    this.handleOk = this.handleOk.bind(this);
  }

  componentDidMount() {
    const { dispatch } = this.props;
    const { searchParams } = this.state;
    dispatch({
      type: 'newActivity/commentUserListButton',
      payload: Object.assign(searchParams),
    });
  }

  onChangeTime(e, dateString) {
    const { dispatch } = this.props;
    const { searchParams } = this.state;
    searchParams.pageNo=1;
    dispatch({
      type: 'newActivity/commentUserListButton',
      payload: Object.assign(searchParams,
        {
          beginTime: dateString[0],
          endTime: dateString[1],
        }),
    });
    this.setState({
      searchParams: Object.assign(searchParams,
        {
          beginTime: dateString[0],
          endTime: dateString[1],
        }),
    });
  }

  prizeSelelct(e) {
    const { dispatch } = this.props;
    const { searchParams } = this.state;
    searchParams.pageNo=1;
    dispatch({
      type: 'newActivity/commentUserListButton',
      payload: Object.assign(searchParams, { isPrize: e }),
    });
    this.setState({
      searchParams: Object.assign(searchParams, { isPrize: e }),
    });
  }
  // 分页


  radioChange(e) {
    const { dispatch } = this.props;
    const { searchParams } = this.state;
    searchParams.pageNo=1;
    dispatch({
      type: 'newActivity/commentUserListButton',
      payload: Object.assign(searchParams, { commentType: e.target.value }),
    });
    this.setState({
      searchParams: Object.assign(searchParams, { commentType: e.target.value }),
    });
  }

  handleOk = () => {
    const { dispatch } = this.props;
    const { searchParams } = this.state;
    this.setState({
      modalVisible: false,
    });
    const replyParams = {
      replyTxt: this.state.content,
      msgDataId: GetQueryString('msgDataId'),
      activityId: GetQueryString('aId'),
      activityUserId:this.state.replayObj.activityUserId,
      type: GetQueryString('type'),
      userCommentId:JSON.parse(this.state.replayObj.extraInfo).userCommentId,
    };
    dispatch({
      type: 'newActivity/replyCommentButton',
      payload: replyParams,
    }).then((result) => {
      if (result) {
        switch (result.code) {
          case '200':
            message.success('回复成功');
            dispatch({
              type: 'newActivity/commentUserListButton',
              payload: Object.assign(searchParams),
            });
            break;
          case '500':
            message.error(result.msg || '回复失败');
            break;
        }
      }
    });
  };

  handleCancel = () => {
    this.setState({
      modalVisible: false,
    });
  };

  replayComment = rows => {
    this.setState({
      content: JSON.parse(rows.extraInfo).replyContent,
      replayObj: rows,
      modalVisible: true,
    });
  };

  handleContent(e) {
    const value = e.target.value;
    this.setState({
      content: value,
    });
  };

  setselect = (data) => {
    const confirm = Modal.confirm;
    const { searchParams } = this.state;
    const { dispatch } = this.props;
    confirm({
      title: '提示?',
      content: '确定要设置为精选吗？',
      onOk() {
        const response = dispatch({
          type: 'newActivity/commentUnmarkelectOrMarkelectButton',
          payload: {
            activityUserId:data.activityUserId,
            commentType: Number(JSON.parse(data.extraInfo).commentType)===2?1:2,
            msgDataId: GetQueryString('msgDataId'),
            userCommentId:JSON.parse(data.extraInfo).userCommentId,
          },
        });
        response.then((result) => {
          if (result) {
            switch (result.code) {
              case '200':
                message.success('设置成功');
                const params = {
                  pageNo: 1,
                  pageSize: 10,
                };
                dispatch({
                  type: 'newActivity/commentUserListButton',
                  payload: Object.assign(searchParams),
                });
                break;
              case '500':
                message.error(result.msg || '设置失败');
                break;
            }
          }
        }, (result) => {
          // console.log(result);
        });


      },
      onCancel() {
      },
    });
  };

  // 一键发送中奖通知
  commentAwardPrizesButton=data=>{
    const { dispatch } = this.props;
    const { searchParams } = this.state;
    this.setState({
      sendCardState:"重新发送卡券",
    })
    dispatch({
      type: 'newActivity/posterOpenAPrizeButton',
      payload:{
        activityId: GetQueryString('aId'),
        type:GetQueryString('type'),
      },
    }).then(function(result) {
      switch(result.code){
        case "200":
          message.success("通知成功")
          dispatch({
            type: 'newActivity/commentUserListButton',
            payload: Object.assign(searchParams),
          });
          break;
        case "500":
          this.setState({
            sendCardState:0,
          })
          message.error("通知失败")
          break;
      }
    })
  }

  // 发送中奖通知
  sendCard=data=>{
    const { dispatch } = this.props;
    const { searchParams } = this.state;
    this.setState({
      sendCardState:"重新发送卡券",
    })
    dispatch({
      type: 'newActivity/commentAgainNoticeButton',
      payload:{
        activityId:GetQueryString('aId'),
        type:GetQueryString("type"),
        activityUserId:data.activityUserId,
      },
    }).then((result) => {
      switch(result.code){
        case "200":
          message.success("通知成功")
          dispatch({
            type: 'newActivity/commentUserListButton',
            payload: Object.assign(searchParams),
          });
          break;
        case "500":
          message.error("通知失败")
          break;
      }
    })
  }

  syncComment=data=>{
    const { dispatch } = this.props;
    const { searchParams } = this.state;
    dispatch({
      type: 'newActivity/commentSyncCommentButton',
      payload:{
        activityId: GetQueryString('aId'),
        msgDataId:GetQueryString('msgDataId'),
      },
    }).then((result) => {
      switch(result.code){
        case "200":
          message.success("同步成功")
          dispatch({
            type: 'newActivity/commentUserListButton',
            payload: Object.assign(searchParams),
          });
          break;
        case "500":
          message.error("同步失败")
          break;
      }

    })
  };

  setLuckDraw = (data,text) => {
    const confirm = Modal.confirm;
    const { searchParams } = this.state;
    const { dispatch } = this.props;
    confirm({
      title: '提示?',
      content: `确定要${text}吗？`,
      onOk() {
        const response = dispatch({
          type: 'newActivity/commentPrizeSetUpButton',
          payload: {
            isPrize: data.isPrize===0?1:0,
            isNotice: data.isNotice,
            openId: data.openId,
            prizeCount: GetQueryString("prizeCount"),
            activityUserId:data.activityUserId,
            activityId: data.activityId,
          },
        });
        response.then((result) => {
          if (result) {
            switch (result.code) {
              case '200':
                message.success('设置成功');
                dispatch({
                  type: 'newActivity/commentUserListButton',
                  payload: Object.assign(searchParams),
                });
                break;
              case '500':
                message.error(result.msg || '设置失败');
                break;
            }
          }
        }, (result) => {

        });


      },
      onCancel() {
      },
    });
  };

  rowsSlect = data => {
    this.setState({
      rowsSlectParams: data,
    });
  };

  render() {
    const {
      newActivity: { commentUserList },
      loading,
      dispatch,
    } = this.props;
    const {searchParams}=this.state;
    const changePage=(current,size)=>{
      searchParams.pageNo=current;
      searchParams.pageSize=size;
      this.setState({
        searchParams,
      })
      dispatch({
        type: 'newActivity/commentUserListButton',
        payload: Object.assign(searchParams),
      });
      setStore("pageNo",current)
    }
    const extraContent = (
      <div className={styles.extraContent}>
        <Select defaultValue="" style={{ width: 120, margin: '0 5px' }} onChange={this.prizeSelelct}>
          <Option value="">中奖状态</Option>
          <Option value="1">中奖</Option>
          <Option value="0">未中奖</Option>
        </Select>
        <RangePicker onChange={this.onChangeTime} allowClear format="YYYY-MM-DD" />
        <Button type="primary" style={{marginLeft:"10px"}} onClick={this.commentAwardPrizesButton}>一键发送中奖通知</Button>
        <Button type="primary" style={{marginLeft:"10px"}} onClick={this.syncComment}>同步留言</Button>
      </div>
    );

    const paginationProps = {
      showSizeChanger: true,
      showQuickJumper: true,
      pageSize: 10,
      current:searchParams.pageNo,
      onChange(current,size){
        changePage(current,size)
      },
      onShowSizeChange(current, size){
        searchParams.pageNo=current;
        searchParams.pageSize=size;
        changePage(current,size)
      },
      total: commentUserList.pagination ? commentUserList.pagination.total : '',
    };

    return (
      <PageHeaderLayout showReturn={true} url="/marketingManage/newActivity">
        <div className={styles.standardList}>
          <Card
            className={styles.listCard}
            bordered={false}
            title="评论列表"
            style={{ marginTop: 24 }}
            bodyStyle={{ padding: '0 32px 40px 32px' }}
            extra={extraContent}
          >
            <List
              size="large"
              rowKey="id"
              loading={loading}
              pagination={paginationProps}
              dataSource={commentUserList.list}
              renderItem={item => (
                <List.Item>
                  <List.Item.Meta
                    style={{marginTop:"-40px",float:"left"}}
                    avatar={<Avatar src={item.headImg} shape="square" size="large" />}
                    title={<a><h4>{item.nickName?item.nickName:"匿名网友"}
                    {Number(JSON.parse(item.extraInfo).commentType)!==2?"":Number(JSON.parse(item.extraInfo).commentType)===2?<span><Icon type="star" style={{color:"red",marginLeft:"10px"}} />精选</span>:""}
                    {item.isPrize===1?<span><Icon type="star" style={{color:"red",marginLeft:"10px"}} />中奖</span>:""}</h4><a href={item.href} style={{color:"rgba(0, 0, 0, 0.6)"}}>{JSON.parse(item.extraInfo).content}</a></a>}
                    description={<a>回复内容:<span style={{color:"rgba(0, 0, 0, 0.45)"}}>{JSON.parse(item.extraInfo).replyContent?`${JSON.parse(item.extraInfo).replyContent?JSON.parse(item.extraInfo).replyContent:"---"}`:""}</span></a>}
                  />
                  <div style={{marginTop:"80px",marginRight:"-200px"}}>
                    <a onClick={() => this.replayComment(item)} style={{marginTop:"20px",marginRight:"10px",display:"inline-block"}}>回复评论</a>
                    <a onClick={()=>this.setselect(item)} style={{marginRight:"10px"}}>{Number(JSON.parse(item.extraInfo).commentType)!==2?'设置精选':'取消精选'}</a>
                    {item.isPrize===0&&item.isNotice!==1?<a onClick={()=>this.setLuckDraw(item,'设置该用户中奖')} style={{marginRight:"10px"}}>{item.isPrize===0&&item.isNotice!==1?'设置中奖':''}</a>:""}
                    {item.isPrize!==0&&item.isNotice!==1?<a onClick={()=>this.setLuckDraw(item,'取消该用户中奖')} style={{marginRight:"10px"}}>{item.isPrize!==0&&item.isNotice!==1?'取消中奖':''}</a>:""}
                    {item.isNotice===1&&item.isPrize!==0?<span style={{marginRight:"10px"}}>{item.isNotice===1&&item.isPrize!==0?'已中奖':''}</span>:""}
                    {item.isPrize===1&&item.isNotice===0?<a  style={{marginRight:"10px"}}onClick={()=>this.sendCard(item)}>{item.isNotice===0?this.state.sendCardState:''}</a>:""}
                    {item.isNotice===1?<span style={{marginRight:"10px"}}>{item.isNotice===1?'已发送卡券':''}</span>:""}
                  </div>
                  <div style={{color:"rgba(0, 0, 0, 0.45)"}}><span>评论时间:</span><span>{item.createTime}</span></div>
                </List.Item>
              )}
            />
          </Card>
        </div>
        <Modal
          title="回复评论"
          visible={this.state.modalVisible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
          <TextArea rows={6} value={this.state.content} onChange={this.handleContent.bind(this)} />
        </Modal>
      </PageHeaderLayout>
    );
  }
}
