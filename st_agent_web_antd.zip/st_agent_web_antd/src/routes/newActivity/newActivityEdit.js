/* eslint-disable no-unused-vars,react/no-unused-state,no-undef,react/sort-comp,react/no-access-state-in-setstate,react/destructuring-assignment,react/destructuring-assignment,react/destructuring-assignment,array-callback-return,lines-between-class-members,lines-between-class-members,default-case,no-plusplus,no-empty,react/jsx-tag-spacing,react/jsx-boolean-value,object-shorthand,no-useless-escape */
import React, { Fragment } from 'react';
import { connect } from 'dva';
import {
  Form,
  Input,
  Button,
  message,
  Select,
  Modal,
  Row,
  Col,
  Table,
  Card,
  Popconfirm,
  DatePicker,
  Radio,
  Upload,
  List,
  Icon,
} from 'antd';
import { routerRedux } from 'dva/router';
import StandardTable from 'components/StandardTable';
import moment from 'moment';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from './newActivity.less';
import { getStore } from '../../assets/js/mUtils';
import ActivityCommit from '../../assets/js/activity/activityEdit/activityCommit';
import ActivityDesk from '../../assets/js/activity/activityEdit/activityDesk';
import ActivityPoster from '../../assets/js/activity/activityEdit/activityPoster';
import ActivityGuess from '../../assets/js/activity/activityEdit/activityGuess';
import ActivityQuestion from '../../assets/js/activity/activityEdit/activityQuestion';
import ActivityMoment from '../../assets/js/activity/activityEdit/activityMoments';

const { RangePicker } = DatePicker;
const FormItem = Form.Item;
const { TextArea } = Input;
const RadioGroup = Radio.Group;

function GetQueryString(name) {
  const reg = new RegExp(`(^|&)${  name  }=([^&]*)(&|$)`);
  const num = window.location.href.indexOf('?');
  const r = window.location.href.substr(num + 1).match(reg);
  if (r != null)
    return unescape(r[2]);
  return null;
};

@Form.create()
class Step2 extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      visibleKeyWord: false,
      loading1: false,
      loading2: false,
      loading3: false,
      validTime: '',
      imageUrlAbstrCoverUrl:"",
      title: '',
      action: `/api/admin/file/upload?type=3&token=${getStore('userInfo') ? JSON.parse(getStore('userInfo')).token : ''}`,
      data: {
        type: 3,
        token: `${getStore('userInfo') ? JSON.parse(getStore('userInfo')).token : ''}`,
      },
      states: 1,
      photoUrls:[],
      photoUrlsArr:[],
      selectedRows: [],
      selectedRowsKeyWord: [],
      subjectList:[],
      cardRefList:[],
      keyword: '',
      dataSourceSelect: [],
      dataSource: [],
      activityId:GetQueryString('activityId'),
      type:GetQueryString('type'),
    };
    this.handleAdd = this.handleAdd.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.showModel = this.showModel.bind(this);
    this.title = this.title.bind(this);
    this.keyword = this.keyword.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
    this.onChangeTime = this.onChangeTime.bind(this);
    this.cancelRest = this.cancelRest.bind(this);
    this.addSubjectList = this.addSubjectList.bind(this);
    this.handleChangeAbstract = this.handleChangeAbstract.bind(this);
    this.handleChangeAbstractEs = this.handleChangeAbstractEs.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.addProm = this.addProm.bind(this);
    this.time = this.time.bind(this);
    this.handleCancelKeyWord = this.handleCancelKeyWord.bind(this);
    this.handleChangeAbstractEsMoment=this.handleChangeAbstractEsMoment.bind(this);
    this.showModelTextNews=this.showModelTextNews.bind(this);
    this.beginDate=this.beginDate.bind(this);
    this.handleSearchTextDate=this.handleSearchTextDate.bind(this);
    this.handleCancelTextNews=this.handleCancelTextNews.bind(this);
    this.handleChangeAbstractCoverUrl=this.handleChangeAbstractCoverUrl.bind(this);
  }

  componentDidMount() {
    const { dispatch } = this.props;
    const myDate = new Date();
    const that = this;
    const now = myDate.toLocaleDateString();
    this.setState({
      validTime: moment(now).format('YYYY-MM-DD'),
    });
    const params = {
      activityId:this.state.activityId,
      type: this.state.type,
    };
    dispatch({
      type: 'newActivity/activityGetButton',
      payload: params,
    }).then((result) => {
      if (result.code === '200') {
          switch (GetQueryString('type')) {
            case "0":
              that.setState({
                activityGetInfo: result.obj,
                cardRefList: result.obj.cardList,
                keyword: result.obj.keyword,
                beginTime: result.obj.beginTime,
                endTime: result.obj.endTime,
                imageUrlAbstr:result.obj.extraInfo?result.obj.extraInfo.coverUrl:"",
                photoUrls:result.obj.extraInfo?result.obj.extraInfo.posterImg:"",
                isDefaultPoster:result.obj.extraInfo?Number(result.obj.extraInfo.isDefaultPoster):"",
                qrCodeId:result.obj.extraInfo?result.obj.extraInfo.qrCodeId:"",

              });
              break;
            case "1":
              that.setState({
                activityGetInfo: result.obj,
                cardRefList: result.obj.cardList,
                keyword: result.obj.keyword,
                beginTime: result.obj.beginTime,
                endTime: result.obj.endTime,
                title:result.obj.extraInfo?result.obj.extraInfo.title:"",
              });
              break;
            case "2":
              that.setState({
                activityGetInfo: result.obj,
                cardRefList: result.obj.cardList,
                keyword: result.obj.keyword,
                beginTime: result.obj.beginTime,
                endTime: result.obj.endTime,
                brandName:result.obj.extraInfo?result.obj.extraInfo.brandName:"",
                linkUrl:result.obj.extraInfo?result.obj.extraInfo.linkUrl:"",
                imageUrlAbstr:result.obj.extraInfo?result.obj.extraInfo.coverUrl:"",
                photoUrlsArr:result.obj.extraInfo?result.obj.extraInfo.photoUrls:[],
                dataSource:result.obj.newsList,
              });
              break;
            case "3":
              that.setState({
                activityGetInfo: result.obj,
                cardRefList: result.obj.cardList,
                keyword: result.obj.keyword,
                beginTime: result.obj.beginTime,
                endTime: result.obj.endTime,
                subjectList:result.obj.subjectList?result.obj.subjectList:[],
                imageUrlAbstr:result.obj.extraInfo?result.obj.extraInfo.coverUrl:"",
                dataSource:result.obj.newsList,
              });
              break;
            case "4":
              that.setState({
                activityGetInfo: result.obj,
                cardRefList: result.obj.cardList,
                keyword: result.obj.keyword,
                beginTime: result.obj.beginTime,
                endTime: result.obj.endTime,
                imageUrlAbstr:result.obj.extraInfo?result.obj.extraInfo.backgroundUrl :"",
                imageUrlAbstrCoverUrl:result.obj.extraInfo?result.obj.extraInfo.coverUrl:"",
                photoUrlsArr:result.obj.extraInfo?result.obj.extraInfo.shareUrl?result.obj.extraInfo.shareUrl:[]:[],
                backgroupColor:result.obj.extraInfo?result.obj.extraInfo.backgroupColor:"",
                qrCodeId:result.obj.extraInfo?result.obj.extraInfo.qrCodeId:"",
              });
              break;
            case "5":
              that.setState({
                activityGetInfo: result.obj,
                cardRefList: result.obj.cardList,
                keyword: result.obj.keyword,
                beginTime: result.obj.beginTime,
                endTime: result.obj.endTime,
                imageUrlAbstr:result.obj.extraInfo?result.obj.extraInfo.posterImg:"",
                imageUrlAbstrCoverUrl:result.obj.extraInfo?result.obj.extraInfo.coverImg:"",
                photoUrlsArr:result.obj.extraInfo?result.obj.extraInfo.photoUrls?result.obj.extraInfo.photoUrls:[]:[],

              });
              break;
          }
        }
    });

  }

  handleStandardTableChangeKeyWord = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      keyword: this.state.keyword,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'newActivity/autoReplyListButton',
      payload: params,
    });
  };
  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      title: this.state.title,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'newActivity/cardListButton',
      payload: params,
    });
  };

  title(e) {
    this.setState({
      title: e.target.value.replace(/\s/gi,''),
    });
  }

  handleAdd() {
    const { dataSource } = this.state;
    const newData = {
      image_url: '',
      text: '',
    };
    this.setState({
      dataSource: [...dataSource, newData],
    });
  }

  handleDelete = (key) => {
    const dataSource = [...this.state.dataSource];
    this.setState({ dataSource: dataSource.filter((item, index) => index !== key) });
  };

  handleCancel() {
    this.setState({
      visible: false,
    });
  }

  keyword = e => {
    this.setState({
      keyword: e.target.value.replace(/\s/gi,''),
    });
  };

  handleSearch() {
    const { dispatch } = this.props;
    const params = {
      title: this.state.title,
      pageSize: 10,
      pageNo: 1,
    };
    dispatch({
      type: 'newActivity/cardListButton',
      payload: params,
    });
  }

  renderForm() {
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={7} sm={24} style={{ margin: '-10px 0 10px 0' }}>
            <FormItem>
              <Input placeholder="请输入卡券标题" onChange={this.title}/>
            </FormItem>
          </Col>
          <Col md={1} sm={24} style={{ margin: '-5px 0 10px 0' }}>
            <span className={styles.submitButtons}>
              <Button type="primary" htmlType="submit">
              查询
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }

  handleCancelKeyWord() {
    this.setState({
      visibleKeyWord: false,
    });
  };

  showModelKeyWord = data => {
    const { dispatch } = this.props;
    const params = {
      pageSize: 10,
      pageNo: 1,
    };
    dispatch({
      type: 'newActivity/autoReplyListButton',
      payload: params,
    });

    this.setState({
      visibleKeyWord: true,
    });
  };
  selectCardList = rows => {
    if(!this.state.cardRefList){
      this.state.cardRefList=[];
    }
    if (this.state.cardRefList.length === 0) {
      this.state.cardRefList.push(rows);
      this.setState({
        cardRefList: [...this.state.cardRefList],
        visible: false,
      });
    } else {
      this.state.cardRefList.map((item) => {
        if (item.cardId !== rows.cardId) {
          this.state.cardRefList.push(rows);
        } else {

        }
      });
    }
    this.setState({
      cardRefList:Array.from(new Set([...this.state.cardRefList])).distinct("cardId"),
      visible: false,
    });
  };

  handleSearchKeyWord() {
    const { dispatch } = this.props;
    const params = {
      keyword: this.state.keyword,
      pageSize: 10,
      pageNo: 1,
    };
    dispatch({
      type: 'newActivity/autoReplyListButton',
      payload: params,
    });
  };

  showModel() {
    const { dispatch } = this.props;
    const params = {
      pageSize: 10,
      pageNo: 1,
    };
    dispatch({
      type: 'newActivity/cardListButton',
      payload: params,
    });
    this.setState({
      visible: true,
    });

  }

  handleChangeAbstract(info) {
    if (info.file.status === 'uploading') {
      this.setState({ loading1: true });
      return;
    }
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.setState({
        imageUrlAbstr: info.file.response.obj,
        loading1: false,
      });
    }
  };

  handleChangeAbstractEs(info) {
    if (info.file.status === 'uploading') {
      this.setState({ loading3: true });
      return;
    }
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.setState({
        photoUrls: info.file.response.obj,
        loading3: false,
      });
    }
  };

  onChangeTime(date, dateString) {
    this.setState({
      validTime: dateString,
    });
  };

  cancelRest() {
    const { dispatch } = this.props;
    dispatch(routerRedux.push('/marketingManage/newActivity'));
  }



// 表单提交
  handleSubmit() {
    const { form, dispatch } = this.props;
    const that=this;
    form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        const cardList = this.state.cardRefList;
        const data = {
          cardList: [],
          activityName: values.activityName,
          beginTime: this.state.beginTime,
          endTime: this.state.endTime,
          keyword: this.state.keyword,
          autoReplyId:this.state.autoReplyId,
          state: values.state,
          prizeCount: values.prizeCount,
          type: GetQueryString('type'),
          extraInfo: "",
          isOpen: 0,
        };
        switch (GetQueryString('type')) {
          case "0":
            /*
            *积分海报
            */

            data.extraInfo={
              isDefaultPoster:that.state.isDefaultPoster,
              posterImg:that.state.photoUrls,
              helpNum:values.helpNum,
              brandName:values.brandName,
              coverUrl:that.state.imageUrlAbstr,
              rules:values.rules,
              qrCodeId:that.state.qrCodeId,
            };
            break;
          case "1":
            /*
            *文章评论抽奖
            */

            data.extraInfo={
              title:that.state.title,
              msgDataId:that.state.msgDataId?that.state.msgDataId.split("_")[0]:"",
              replyTxt:values.rules,
            }
            break;
          case "2":
            /*
            *朋友圈转发抽奖
            */
            data.newsList=that.state.dataSource;
            data.extraInfo={
              linkUrl:values.linkUrl,
              originPrice:values.originPrice,
              photoUrls:that.state.photoUrlsArr,
              brandName:values.brandName,
              coverUrl:that.state.imageUrlAbstr,
              partakeNotes:values.partakeNotes,
            }
            break;
          case "3":
            /*
            *竞猜
            */
            data.subjectList=that.state.subjectList;
            data.newsList=that.state.dataSource;
            data.extraInfo={
              coverUrl:that.state.imageUrlAbstr,
              rules:values.rules,
            };
            break;
          case "4":
            /*
            *答题
            */
            data.extraInfo={
              coverUrl:that.state.imageUrlAbstrCoverUrl,
              shareUrl:that.state.photoUrlsArr,
              backgroundUrl:that.state.imageUrlAbstr,
              prizeCondition: values.prizeCondition,
              rules:values.rules,
              backgroupColor:that.state.backgroupColor,
              qrCodeId:that.state.qrCodeId,
            };
            break;
          case "5":
            /*
            *桌台拼手气
            */
            data.extraInfo={
              coverImg:that.state.imageUrlAbstrCoverUrl,
              photoUrls:that.state.photoUrlsArr,
              posterImg:that.state.imageUrlAbstr,
              rules:values.rules,
            }
            break;
        }
        if (cardList) {
          for (let i = 0; i < cardList.length; i++) {
            if ((values.prizeCount * cardList[i].getLimit) > cardList[i].skuQuantity) {
              message.error('中奖人数乘以限领数不能大于库存数？');
              return;
            }
          }
          const cards = [];
          cardList.forEach(i => {
            const cardOne = {
              cardId: i.cardId,
            };
            cards.push(cardOne);
          });
          data.cardRefList = cards;
        }
        dispatch({
          type: 'newActivity/addNewActivityButton',
          payload: Object.assign(this.state.activityGetInfo, data),
        }).then((result) => {
          if (result) {
            switch (result.code) {
              case '200':
                message.success('更新成功');
                dispatch(routerRedux.push('/marketingManage/newActivity'));
                break;
              case '500':
                message.error(result.msg);
                break;
            }
          }
        }, (result) => {

        });
      }
    });
  }

  sNo = (e) => {
    this.state.subjectList[+this.state.key].sNo = e.target.value;
    this.setState({
      subjectList: this.state.subjectList,
    });
  };

  question = (e) => {

    this.state.subjectList[+this.state.key].question = e.target.value;
    this.setState({
      subjectList: this.state.subjectList,
    });
  };

  // 添加问题
  addProm() {
    const { dispatch } = this.props;
    const obj = {
      question: '',
      score: '',
      sNo: '',
      sex: '',
      subjectOptionList: [],
    };
    this.state.subjectList.push(obj);
    this.setState({
      subjectList: this.state.subjectList,
    });
    dispatch({
      type: 'newActivity/addKon',
    });

  }

  // 添加选项
  addSelect(index) {

  }

  time(a, b) {
    this.setState({
      beginTime: b[0],
      endTime: b[1],
    });
  }

  renderFormKeyWord() {
    return (
      <Form layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={7} sm={24} style={{ margin: '-10px 0 10px 0' }}>
            <FormItem label="查询参数">
              <Input placeholder="请输入关键词" onChange={this.keyword}/>
            </FormItem>
          </Col>
          <Col md={1} sm={24} style={{ margin: '-5px 0 10px 0' }}>
            <span className={styles.submitButtons}>
              <Button type="primary" onClick={this.handleSearchKeyWord}>
              查询
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  };

  selectKeyWord = rows => {
    this.setState({
      visibleKeyWord: false,
      autoReplyId: rows.autoReplyId,
      keyword: rows.keyword,
    });
  };

  /*
   * 积分海报
   * */
  handleChangeAbstract(info) {
    if (info.file.status === 'uploading') {
      this.setState({ loading1: true });
      return;
    }
    // console.log(info);
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.setState({
        imageUrlAbstr: info.file.response.obj,
        loading1: false,
      });
    }
  };
  handleChangeAbstractCoverUrl(info) {
    if (info.file.status === 'uploading') {
      this.setState({ loading1: true });
      return;
    }
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.setState({
        imageUrlAbstrCoverUrl: info.file.response.obj,
        loading1: false,
      });
    }
  };

  handleChangeAbstractEs(info) {
    if (info.file.status === 'uploading') {
      this.setState({ loading3: true });
      return;
    }
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.setState({
        photoUrls: info.file.response.obj,
        loading3: false,
      });
    }
  };

  /*
  文章评论抽奖
   */
  showModelTextNews() {
    this.setState({
      visibleTextNews: true,
    });
  }

  beginDate(a, b) {
    this.setState({
      beginDate: b,
      endDate: b,
    });
  }

  selectImageTextList = rows => {
    this.setState({
      title: rows.title,
      msgDataId: rows.msgid,
      visibleTextNews: false,
    });

  };

  handleCancelTextNews() {
    this.setState({
      visibleTextNews: false,
    });
  }

  renderFormDateText() {
    return (
      <Form layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={7} sm={24} style={{ margin: '-10px 0 10px 0' }}>
            <FormItem label="查询参数">
              <DatePicker placeholder="请选择日期" onChange={this.beginDate}/>
            </FormItem>
          </Col>
          <Col md={1} sm={24} style={{ margin: '-5px 0 10px 0' }}>
            <span className={styles.submitButtons}>
              <Button type="primary" onClick={this.handleSearchTextDate}>
              查询
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }

  handleSearchTextDate() {
    const { dispatch } = this.props;
    const params = {
      beginTime: this.state.beginDate,
      endTime: this.state.endDate,
    };
    dispatch({
      type: 'newActivity/commentGetarticlesummaryButton',
      payload: params,
    });
  }

  /*
  朋友圈转发抽奖
   */
  handleAdd() {
    const { dataSource } = this.state;
    const newData = {
      imgUrl: '',
      content: '',
    };
    this.setState({
      dataSource: [...dataSource, newData],
    });
  }

  handleDelete = (key) => {
    const dataSource = [...this.state.dataSource];
    this.setState({ dataSource: dataSource.filter((item, index) => index !== key) });
  };

  handleChangeAbstractEsMoment(info) {
    if (info.file.status === 'uploading') {
      this.setState({ loading3: true });
      return;
    }
    if (info.file.status === 'done') {
      message.success('上传成功');
      console.log(this.state.photoUrlsArr)
      this.setState({
        photoUrlsArr: [...this.state.photoUrlsArr, info.file.response.obj],
        loading3: false,
      });
    }
  };

  /*
  *竞猜
   */
  deleteColumnsSelect = key => {
    const dataSourceSelect = [...this.state.subjectList];
    this.setState({ subjectList: dataSourceSelect.filter((item, index) => index !== key) });
  };

  addSubjectList() {
    const obj = {
      sNo: '',
      question: '',
    };
    console.log( this.state.subjectList)
    this.state.subjectList.push(obj);
    this.setState({
      subjectList: [...this.state.subjectList],
    });
  }

  keyIndex(key) {
    this.setState({
      key,
    });
  };

  sNo = (e) => {
    this.state.subjectList[+this.state.key].sNo = e.target.value;
    this.setState({
      subjectList: this.state.subjectList,
    });
  };

  question = (e) => {

    this.state.subjectList[+this.state.key].question = e.target.value;
    this.setState({
      subjectList: this.state.subjectList,
    });
  };

  handleTextKey = rows => {
    this.setState({
      key: rows,
    });
  };
  handleText = e => {
    const {dispatch}=this.props;
    this.state.dataSource[+this.state.key].content = e.target.value;
    this.setState({
      dataSource: this.state.dataSource,
    });
    dispatch({
      type: 'newActivity/addKon',
    });
  };
  handleChangeTab = info => {
    if (info.file.status === 'uploading') {
      this.setState({ loading2: true });
      return;
    }
    if (info.file.status === 'done') {
      message.success('上传成功');
      this.state.dataSource[this.state.key].imgUrl = info.file.response.obj;
      this.setState({
        dataSource: this.state.dataSource,
        loading2: false,
      });
    }
  };

  render() {
    const { selectedRowsKeyWord, selectedRows } = this.state;
    const { form, loading, newActivity: { saveCardList, autoReplyList, activityGetInfo, commentGetarticlesummary } } = this.props;
    const { subjectList } = this.state;
    const { dataSource,photoUrlsArr} = this.state;
    const columnsTab = [
      {
        title: '优惠券名称',
        key: 'title',
        dataIndex: 'title',
      },
      {
        title: '优惠券副标题',
        dataIndex: 'subtitle',
        key: 'subtitle',
      },
      {
        title: '操作',
        align: 'right',
        fixed: 'right',
        render: (text, record) => (
          <Fragment>
            <a onClick={() => this.selectCardList(record)}>选择</a>
          </Fragment>
        ),
      },
    ];
    const uploadButton1 = (
      <div>
        <Icon type={this.state.loading1 ? 'loading' : 'plus'}/>
        <div className="ant-upload-text">本地上传</div>
      </div>
    );
    const uploadButtones = (
      <div>
        <Icon type={this.state.loading3 ? 'loading' : 'plus'}/>
        <div className="ant-upload-text">本地上传</div>
      </div>
    );
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 },
        md: { span: 10 },
      },
    };
    const activityName = (e) => {
      this.setState({
        activityName: e.target.value,
      });
    };
    const rules = (e) => {
      this.setState({
        rules: e.target.value,
      });
    };
    const deleteCard = data => {
      const deletSelectedRows = [...this.state.cardRefList];
      this.setState({ cardRefList: deletSelectedRows.filter(item => item.cardId !== data.cardId) });

    };
    const keyword = e => {
      this.setState({
        keyword: e.target.value,
      });
    };
    const question = e => {
      subjectList[this.state.key].question = e.target.value;
      this.setState({
        subjectList: subjectList,
      });
    };
    const key = index => {
      this.setState({
        key: index,
      });
    };
    const sex = e => {
      if (this.state.key) {
        subjectList[this.state.key].sex = e.target.value;
        this.setState({
          subjectList: subjectList,
        });
      } else {
        message.error('请先填写题目或者选项');
      }
    };
   // 选项名字
    const optName = e => {
      const { dispatch } = this.props;
      subjectList[this.state.index].subjectOptionList[this.state.index1].optName = e.target.value;
      this.setState({
        subjectList: this.state.subjectList,
      });
      dispatch({
        type: 'newActivity/addKon',
      });

    };
    const grade = e => {
      const { dispatch } = this.props;
      subjectList[this.state.index].subjectOptionList[this.state.index1].grade = e.target.value;
      this.setState({
        subjectList: this.state.subjectList,
      });
      dispatch({
        type: 'newActivity/addKon',
      });

    };
    const keyValue = (index, index1) => {
      this.setState({
        index: index,
        index1: index1,
      });
    };

    const columnsKeyWordTab = [
      {
        title: '关键词',
        key: 'keyword',
        dataIndex: 'keyword',
      },
      {
        title: '类型',
        key: 'msgType',
        render: (text, record) => (
          <span>
            {record.msgType === 'image'
              ? '图片'
              : record.msgType === 'news'
                ? '图文'
                : record.msgType === 'text'
                  ? '文本'
                  : ''}
          </span>
        ),
      },
      {
        title: '回复内容',
        width: 200,
        render: (text, record) => (
          <a
            className={styles.tdClass}
            href={
              record.msgType === 'image'
                ? record.picUrl
                : record.msgType === 'news'
                ? record.url
                : '#'
            }
          >
            {record.msgType === 'image'
              ? '查看图片'
              : record.msgType === 'news'
                ? '查看图文'
                : record.msgType === 'text'
                  ? record.content
                  : ''}
          </a>
        ),
      },
      {
        title: '状态',
        key: 'state',
        render: (text, record) => <span>{record.state === 0 ? '无效' : '有效'}</span>,
      },
      {
        title: '创建时间',
        dataIndex: 'createTime',
        key: 'createTime',
      },
      {
        title: '操作',
        width: 180,
        fixed: 'right',
        align: 'right',
        render: (text, record) => (
          <Fragment>
            <a onClick={() => this.selectKeyWord(record)}>
              选择
            </a>
          </Fragment>
        ),
      },
    ];
    this.setState({
      activityName: activityGetInfo ? activityGetInfo.activityName : '',
    });

    /*
   *积分海报
   */
    const brandName = (e) => {
      this.setState({
        brandName: e.target.value,
      });
    };
    const isDefaultPoster = e => {
      this.setState({
        isDefaultPoster: e.target.value,
      });
    };
    const helpNum = e => {
      this.setState({
        helpNum: e.target.value,
      });
    };
    /*
    文章评论抽奖
    */
    const title = (e) => {
      this.setState({
        title: e.target.value,
      });
    };
    const columnsTabTextNews = [
      {
        title: '标题',
        dataIndex: 'title',
      },
      {
        title: '操作',
        align: 'right',
        fixed: 'right',
        render: (text, record) => (
          <Fragment>
            <a onClick={() => this.selectImageTextList(record)}>选择</a>
          </Fragment>
        ),
      },
    ];
    /*
    朋友圈转发抽奖
    */
    const deletePhotoUrl=(index)=>{
      const arr=[...this.state.photoUrlsArr];
      arr.splice(index,1)
      this.setState({
        photoUrlsArr:arr,
      })
    }
    const brandNameFriend = e => {
      this.setState({
        brandName: e.target.value,
      });
    };
    const linkUrl = (e) => {
      this.setState({
        linkUrl: e.target.value,
      });
    };
    const partakeNotes = (e) => {
      this.setState({
        partakeNotes: e.target.value,
      });
    };
    const uploadButton2 = (
      <div>
        <Icon type={this.state.loading2 ? 'loading' : 'plus'}/>
        <div className="ant-upload-text">本地上传</div>
      </div>
    );
    const columns = [{
      title: '图片',
      dataIndex: 'image_url',
      key:"image_url",
      width: '30%',
      render: (text, record, index) => {
        return (
          <Upload
            name="file"
            listType="picture-card"
            className={styles.antUpload}
            showUploadList={false}
            action={this.state.action}
            beforeUpload={() => this.handleTextKey(index)}
            onChange={this.handleChangeTab}
          >
            {dataSource ? dataSource[index].imgUrl ? (
              <img
                src={dataSource[index].imgUrl}
                alt="avatar"
                style={{
                  width: '100px',
                  height: '100px',
                }}
              />
            ) : uploadButton2 : ''}
          </Upload>
        );
      },
    }, {
      title: '文字',
      key:"content",
      dataIndex: 'content',
      render: (text, record, index) => {
        return (
          <textarea
            rows={4}
            value={dataSource[index].content}
            onChange={this.handleText}
            key={index}
            disabled={Number(GetQueryString("isOpen")) === 1}
            placeholder="请输入图片描述，最多输入512个中文"
            onFocus={() => {
              this.keyIndex(index);
            }}
            maxLength="512"
          />
        );
      },
    }, {
      title: '操作',
      width: 50,
      dataIndex: '操作',
      align: 'right',
      fixed: 'right',
      render: (text, record, index) => {
        return (
          this.state.dataSource.length >= 1
            ? (
              <Popconfirm title="确定是否删除？" onConfirm={() => this.handleDelete(index)}>
                <a>删除</a>
              </Popconfirm>
            ) : null
        );
      },
    }];
    /* 竞猜 */
    const columnsSelect = [
      {
        title: '选号',
        dataIndex: 'sNo',
        width:"20%",
        render: (text, record, index) => {
          return (
            <Input
              onChange={this.sNo}
              value={record.sNo}
              type="number"
              disabled={Number(GetQueryString("isOpen"))=== 1}
              onFocus={() => {
                this.keyIndex(index);
              }}
            />
          );
        },
      },
      {
        title: '选题',
        width:"50%",
        dataIndex: 'question',
        render: (text, record, index) => {
          return (
            <Input
              disabled={Number(GetQueryString("isOpen"))=== 1}
              value={record.question}
              onChange={this.question}
              onFocus={() => {
                this.keyIndex(index);
              }}
            />
          );
        },
      },
      {
        title: '答案',
        width:"20%",
        render: () => {
          return (
            <span>--</span>
          );
        },
      },
      {
        title: '操作',
        align: 'right',
        fixed: 'right',
        render: (text, record, index) => (
          <Fragment>
            <a onClick={() => this.deleteColumnsSelect(index)}>删除</a>
          </Fragment>
        ),
      },
    ];
    const nowDate=`${new Date().getFullYear()}-${new Date().getMonth()+1}-${new Date().getDate()}`;
    const {beginTime}=this.state;
    const CompareDate=(d1,d2)=>{
      if((new Date(d1.replace(/-/g,"\/"))) > (new Date(d2.replace(/-/g,"\/")))){
        message.error("活动时间不能小于现在时间")
      }
      return ((new Date(d1.replace(/-/g,"\/"))) > (new Date(d2.replace(/-/g,"\/"))));
    };
    //  答题
    const colorChange=e=>{
      this.setState({
        backgroupColor:e.target.value,
      })
    };
    const colorInput=e=>{
      this.setState({
        backgroupColor:e.target.value,
      })
    };
    function disabledDate(current) {
      const now=new Date(moment(current).format("YYYY-MM-DD"))
      return moment(new Date(now.getTime()+24*60*60*1000)) && moment(new Date(now.getTime()+24*60*60*1000)) < moment().endOf('day');
    }
    return (
      <PageHeaderLayout showReturn={true} url="/marketingManage/newActivity">
        <List loading={loading}>
        <Card title="基本信息" style={{ marginBottom: '10px' }}>
          <Form layout="horizontal" className={styles.stepForm}>
            <FormItem {...formItemLayout} label="活动名称">
              {form.getFieldDecorator('activityName', {
                initialValue: activityGetInfo ? activityGetInfo.activityName : '',
                rules: [{ required: true, message: '请输入活动名称' }],
              })(<Input
                placeholder="请输入活动名称"
                disabled={Number(GetQueryString("isOpen"))=== 1}
                maxLength="64"
                addonAfter={this.state.activityName ? `${this.state.activityName.length  }/64` : '0/64'}
                onChange={activityName}
              />)}
            </FormItem>
            <FormItem {...formItemLayout} label="活动时间">
              {form.getFieldDecorator('time', {
                initialValue: [moment(this.state.beginTime), moment(this.state.endTime)],
                rules: [{ required: true, message: '请选择活动时间' }],
              })(<RangePicker onChange={this.time} disabled={Number(GetQueryString("isOpen"))=== 1} showTime={{ format: 'HH:mm:ss' }}
                              format="YYYY-MM-DD HH:mm:ss" disabledDate={disabledDate} />)}
            </FormItem>
            {
              this.state.type==="0"? (
                <FormItem {...formItemLayout} label="关键词">
                  {form.getFieldDecorator('keyword', {
                  initialValue: this.state.keyword,
                })(
                  <div style={{position:"relative"}}>
                    <Input onClick={this.showModelKeyWord} placeholder="请选择关键词" value={this.state.keyword} disabled={Number(GetQueryString("isOpen"))=== 1}/>
                    <Icon type="down" style={{position:"absolute",right:"10px",top:"15px"}} />
                  </div>
                )}
                </FormItem>
):""
            }
            <FormItem {...formItemLayout} label="中奖人数设定">
              {form.getFieldDecorator('prizeCount', {
                initialValue: activityGetInfo ? activityGetInfo.prizeCount : '',
                rules: [{ required: true, message: '请输入中奖人数' }],
              })(<Input addonAfter="人" type="number" disabled={Number(GetQueryString("isOpen"))=== 1}/>)}
            </FormItem>
            <FormItem {...formItemLayout} label="优惠券">
              {form.getFieldDecorator('cardRelation')(
                <div>
                  <Button onClick={this.showModel} style={{ marginBottom: 16 }} disabled={Number(GetQueryString("isOpen"))=== 1}>
                    关联卡券
                  </Button>
                  <ul>

                    {
                      this.state.cardRefList ? this.state.cardRefList.map((item) => {
                        return (
                          <li style={{
                            overflow: 'hidden',
                            border: '1px solid #ddd',
                            padding: '10px',
                            display: 'flex',
                            position: 'relative',
                            fontSize: '12px',
                            marginLeft: '-40px',
                            marginBottom:"5px",
                            background: '#f2f2f0',
                          }}
                          >
                            <img
                              alt=""
                              src={item.logoUrl}
                              style={{
                                float: 'left',
                                width: 50,
                                height: 50,
                                borderRadius: '50%',
                                marginRight: '10px',
                              }}
                            />
                            <div style={{ float: 'left', marginTop: '-15px' }}>
                              <div style={{ height: 20 }}><span
                                style={{ fontWeight: 'bold' }}
                              >{item.title}
                                                          </span>({item.subtitle})
                              </div>
                              <div style={{ height: 20 }}>库存共{item.skuQuantity} 每人限领{item.getLimit}张</div>
                              <div
                                style={{ height: 20 }}
                              >使用时间:<span>{item.dateInfo.begin_timestamp?<span>{moment(item.dateInfo.begin_timestamp * 1000).format('YYYY-MM-DD')} 至 {moment(item.dateInfo.end_timestamp * 1000).format('YYYY-MM-DD')}</span>:`领券后${item.dateInfo.fixed_begin_term}天生效有效天数${item.dateInfo.fixed_term}`}</span>
                              </div>
                            </div>
                            {
                              Number(GetQueryString("isOpen"))!== 1 ? (
                                <span onClick={() => deleteCard(item)}><Icon
                                  type="close-circle"
                                  style={{
                                    position: 'absolute',
                                    right: '10px',
                                    cursor: 'pointer',
                                  }}
                                />
                                </span>
                              ) : ''
                            }
                          </li>
                        );
                      }) : ''
                    }

                  </ul>
                </div>,
              )}
            </FormItem>
            <FormItem {...formItemLayout} label="状态">
              {form.getFieldDecorator('state', {
                initialValue: activityGetInfo ? activityGetInfo.state : '',
              })(
                <RadioGroup disabled={Number(GetQueryString("isOpen"))=== 1}>
                  <Radio value={1}>展示</Radio>
                  <Radio value={0}>隐藏</Radio>
                </RadioGroup>)}
            </FormItem>
          </Form>
        </Card>
        </List>
        <Card title="其他信息">
          <Form layout="horizontal" className={styles.stepForm}>
            {
              Number(GetQueryString('type')) === 4? (
                <div>
                  <ActivityQuestion

                    formItemLayout={formItemLayout}
                    form={form}
                    styles={styles}
                    prizeCondition={this.prizeCondition}
                    imageUrlAbstr={this.state.imageUrlAbstr}
                    action={this.state.action}
                    handleChangeAbstractDesk={this.handleChangeAbstractDesk}
                    uploadButton2={uploadButton2}
                    imageUrlAbstrCoverUrl={this.state.imageUrlAbstrCoverUrl}
                    uploadButton1={uploadButton1}
                    handleChangeAbstractCoverUrl={this.handleChangeAbstractCoverUrl}
                    handleChangeAbstractEsMoment={this.handleChangeAbstractEsMoment}
                    uploadButtones={uploadButtones}
                    rules={rules}
                    colorChange={colorChange}
                    colorInput={colorInput}
                    backgroupColor={this.state.backgroupColor}
                    activityGetInfo={this.state.activityGetInfo}
                    isOpen={Number(GetQueryString("isOpen"))}
                    photoUrlsArr={this.state.photoUrlsArr}
                    deletePhotoUrl={deletePhotoUrl}
                    handleChangeAbstract={this.handleChangeAbstract}
                  />
                </div>
              ) : ''
            }
            {
              /*
              *竞猜
            */
              Number(GetQueryString('type')) === 3 ? (
                <div>
                  <ActivityGuess
                    imageUrlAbstr={this.state.imageUrlAbstr}
                    styles={styles}
                    action={this.state.action}
                    handleChangeAbstract={this.handleChangeAbstract}
                    formItemLayout={formItemLayout}
                    uploadButton1={uploadButton1}
                    form={form}
                    addSubjectList={this.addSubjectList}
                    beginTime={beginTime}
                    nowDate={nowDate}
                    CompareDate={CompareDate}
                    activityGetInfo={this.state.activityGetInfo}
                    subjectList={subjectList}
                    columnsSelect={columnsSelect}
                    dataSource={dataSource}
                    columns={columns}
                    handleAdd={this.handleAdd}
                    isOpen={Number(GetQueryString("isOpen"))}
                    moment={moment}
                    rules={rules}

                  />
                </div>
              ) : ''
            }
            {
              /*
              *朋友圈转发抽奖
            */
              Number(GetQueryString('type')) === 2 ? (
                <div>
                  <ActivityCommit
                    styles={styles}
                    activityGetInfo={this.state.activityGetInfo}
                    action={this.state.action}
                    form={form}
                    formItemLayout={formItemLayout}
                    brandName={this.state.brandName}
                    brandNameFriend={brandNameFriend}
                    linkUrlFun={linkUrl}
                    photoUrlsArr={this.state.photoUrlsArr}
                    imageUrlAbstr={this.state.imageUrlAbstr}
                    handleChangeAbstract={this.handleChangeAbstract}
                    linkUrl={this.state.linkUrl}
                    deletePhotoUrl={deletePhotoUrl}
                    handleChangeAbstractEsMoment={this.handleChangeAbstractEsMoment}
                    partakeNotesFun={partakeNotes}
                    uploadButton1={uploadButton1}
                    partakeNotes={this.state.partakeNotes}
                    handleAdd={this.handleAdd}
                    dataSource={dataSource}
                    columns={columns}
                    uploadButtones={uploadButtones}
                  />
                </div>
              ) : ''
            }
            {
              /*
              *文章评论抽奖
            */
              Number(GetQueryString('type')) === 1 ? (
                <div>
                  <ActivityMoment
                    titleFun={title}
                    rules={rules}
                    formItemLayout={formItemLayout}
                    form={form}
                    showModelTextNews={this.showModelTextNews}
                    title={this.state.title}
                    activityGetInfo={this.state.activityGetInfo}
                  />
                </div>
              ) : ''
            }
            {
              /*
              *积分海报
            */
              Number(GetQueryString('type')) === 0 ? (
                <div>
                  <ActivityPoster
                    brandName={this.state.brandName}
                    brandNameFun={brandName}
                    imageUrlAbstr={this.state.imageUrlAbstr}
                    styles={styles}
                    action={this.state.action}
                    handleChangeAbstract={this.handleChangeAbstract}
                    formItemLayout={formItemLayout}
                    uploadButton1={uploadButton1}
                    form={form}
                    activityGetInfo={activityGetInfo}
                    isDefaultPosterFun={isDefaultPoster}
                    isDefaultPoster={this.state.isDefaultPoster}
                    handleChangeAbstractEs={this.handleChangeAbstractEs}
                    photoUrls={this.state.photoUrls}
                    uploadButtones={uploadButtones}
                    helpNum={this.state.helpNum}
                    isOpen={this.state.isOpen}
                    helpNumFun={helpNum}
                    rules={rules}
                  />
                </div>
              ) : ''
            }
            {
              /*
              *同桌拼手气
            */
              Number(GetQueryString('type'))=== 5 ? (
                <div>
                  <ActivityDesk
                    formItemLayout={formItemLayout}
                    imageUrlAbstr={this.state.imageUrlAbstr}
                    action={this.state.action}
                    styles={styles}
                    handleChangeAbstractCoverUrl={this.handleChangeAbstractCoverUrl}
                    handleChangeAbstract={this.handleChangeAbstract}
                    uploadButton2={uploadButton2}
                    imageUrlAbstrCoverUrl={this.state.imageUrlAbstrCoverUrl}
                    uploadButton1={uploadButton1}
                    uploadButtones={uploadButtones}
                    photoUrlsArr={photoUrlsArr}
                    handleChangeAbstractEsMoment={this.handleChangeAbstractEsMoment}
                    form={form}
                    activityGetInfo={activityGetInfo}
                    deletePhotoUrl={deletePhotoUrl}
                    rules={this.rules}
                  />
                </div>
              ) : ''
            }
            <FormItem {...formItemLayout} label="">
              <div style={{ marginLeft: '70%', width: '400px' }}>
                <Button loading={loading} type="primary" style={{ marginBottom: 16, marginRight: 20 }} onClick={this.handleSubmit}>
                  提交
                </Button>
              </div>
            </FormItem>
          </Form>
        </Card>
        <Modal
          title="卡券列表"

          visible={this.state.visible}
          footer={null}
          width="80%"
          onCancel={this.handleCancel}
        >
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>
              {this.renderForm()}
            </div>
            <div className={styles.tableListOperator}>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              data={saveCardList}
              loading={loading}
              columns={columnsTab}
              onChange={this.handleStandardTableChange}
            />
          </div>
        </Modal>
        <Modal
          title="图文列表"

          visible={this.state.visibleTextNews}
          footer={null}
          width="80%"
          onCancel={this.handleCancelTextNews}
        >
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>
              {this.renderFormDateText()}
            </div>
            <div className={styles.tableListOperator}>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              data={commentGetarticlesummary}
              loading={loading}
              columns={columnsTabTextNews}
              onChange={this.handleStandardTableChange}
            />
          </div>
        </Modal>
        <Modal
          title="关键词列表"
          visible={this.state.visibleKeyWord}
          footer={null}
          width="80%"
          onCancel={this.handleCancelKeyWord}
        >
          <div>
            <div>
              {this.renderFormKeyWord()}
            </div>
            <div className={styles.tableListOperator}>
              {selectedRowsKeyWord.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRowsKeyWord}
              data={autoReplyList}
              loading={loading}
              columns={columnsKeyWordTab}
              onChange={this.handleStandardTableChangeKeyWord}
            />
          </div>
        </Modal>
      </PageHeaderLayout>
    );
  }
}

export default connect(({ newActivity, loading }) => ({
  newActivity,
  loading: loading.models.newActivity,
}))(Step2);
