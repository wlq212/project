/* eslint-disable no-unused-vars,react/sort-comp,class-methods-use-this,no-undef,react/no-unused-state,react/jsx-boolean-value,react/destructuring-assignment,prefer-arrow-callback,default-case */
import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Icon,
  Radio,
  Button,
  Dropdown,
  Menu,
  message,
} from 'antd';
import StandardTable from 'components/StandardTable';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from './newActivity.less';

function GetQueryString(name) {
  const reg = new RegExp(`(^|&)${  name  }=([^&]*)(&|$)`);
  const num = window.location.href.indexOf('?');
  const r = window.location.href.substr(num + 1).match(reg);
  if (r != null)
    return unescape(r[2]);
  return null;
};
const FormItem = Form.Item;
@connect(({ newActivity, loading }) => ({
  newActivity,
  loading: loading.models.newActivity,
}))
@Form.create()
export default class TableList extends PureComponent {
  constructor(props){
    super(props);
    this.state = {
      modalVisible: false,
      expandForm: false,
      selectedRows: [],
      formValues: {},
    };
  }

  componentDidMount() {
    const { dispatch } = this.props;
    const params = {
      referId: GetQueryString('activityId'),
      type:GetQueryString('type'),
      pageNo: 1,
      pageSize: 10,
    };
    dispatch({
      type: 'newActivity/activitySelectSubjectListButton',
      payload: params,
    });
  }

  static GetQueryString(name) {
    const reg = new RegExp(`(^|&)${  name  }=([^&]*)(&|$)`);
    const num = window.location.href.indexOf('?');
    const r = window.location.href.substr(num + 1).match(reg);
    if (r != null) return unescape(r[2]);
    return null;
  };

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      referId: GetQueryString('activityId'),
      type:GetQueryString("type"),
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }

    dispatch({
      type: 'newActivity/activitySelectSubjectListButton',
      payload: params,
    });
  };

  handleFormReset = () => {
    const { form,dispatch} = this.props;
    form.resetFields();
    const params = {
      referId: GetQueryString('activityId'),
      type:GetQueryString('type'),
      pageNo: 1,
      pageSize: 10,
    };
    dispatch({
      type: 'newActivity/activitySelectSubjectListButton',
      payload: params,
    });
    this.setState({
      formValues:params,
    });

  };


  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (!selectedRows) return;

    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'rule/remove',
          payload: {
            no: selectedRows.map(row => row.no).join(','),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
  };

  handleSearch = e => {
    e.preventDefault();

    const { dispatch, form } = this.props;

    form.validateFields((err, fieldsValue) => {
      if (err) return;

      const values = {
        ...fieldsValue,
        referId: GetQueryString('activityId'),
        type:GetQueryString('type'),
        pageSize: 10,
        pageNo: 1,
      };

      this.setState({
        formValues: values,
      });
      dispatch({
        type: ' newActivity/activitySelectSubjectListButton',
        payload: values,
      });
    });
  };

  /*
  公布答案
   */


  handleModalVisible = flag => {
    this.setState({
      modalVisible: !!flag,
    });
  };

  handleAdd = fields => {
    const { dispatch } = this.props;
    dispatch({
      type: 'rule/add',
      payload: {
        description: fields.desc,
      },
    });

    message.success('添加成功');
    this.setState({
      modalVisible: false,
    });
  };

  renderSimpleForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="查询参数">
              {getFieldDecorator('title')(<Input placeholder="请输入优惠券名称" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <span className={styles.submitButtons}>
              <Button type="primary" htmlType="submit">
                查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                重置
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }

   /*
   选择答案
   */
   RadioCheck=(data)=>{
    this.setState({
      sId:data.sId,
    })
   };

  render() {
    const {
      newActivity: { activitySelectSubjectListSave },
      loading,
    } = this.props;
    const { selectedRows} = this.state;
    const columns = [
      {
        title: '序号',
        dataIndex: 'id',
      },
      {
        title: '选题',
        dataIndex: 'question',
      },
      {
        title: '操作',
        align:"right",
        fixed:"right",
        render: (text, record) => (
          <Fragment>
            <Radio onChange={()=>{this.RadioCheck(record)}}>正确</Radio>
          </Fragment>
        ),
      },
    ];

    const menu = (
      <Menu onClick={this.handleMenuClick} selectedKeys={[]}>
        <Menu.Item key="remove">删除</Menu.Item>
        <Menu.Item key="approval">批量审批</Menu.Item>
      </Menu>
    );
    const url=`/marketingManage/newActivity`;
    const posterOpenAPrizeButtonGG=()=>{
      const { dispatch} = this.props;
      if(this.state.sId){
        const obj={
          type:GetQueryString("type"),
          activityId:GetQueryString("activityId"),
          sId:this.state.sId,
        };
        dispatch({
          type: 'newActivity/posterOpenAPrizeButton',
          payload: obj,
        }).then(function(result) {
          if(result){
            switch (result.code) {
              case "200":
                dispatch(routerRedux.push(`/marketingManage/newActivity`));
                message.success("公布答案成功");
                break;
              case "500":
                message.error("公布答案失败");
                break;
            }
          }
        })
      }else{
        message.error("请选择要公布的题目");
      }
    };
    return (
      <PageHeaderLayout title="" showReturn={true} url={url}>
        <Card bordered={false}>
          <div className={styles.tableList}>
            <div className={styles.tableListOperator}>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                  <Dropdown overlay={menu}>
                    <Button>
                      更多操作 <Icon type="down" />
                    </Button>
                  </Dropdown>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={activitySelectSubjectListSave}
              columns={columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
            />
            <div style={{width:"100px",margin:"0 auto"}}>
            <Button type="primary" style={{margin:"10px auto"}} onClick={posterOpenAPrizeButtonGG}>公布答案</Button>
            </div>
          </div>
        </Card>
      </PageHeaderLayout>
    );
  }
}
