/* eslint-disable no-unused-vars,react/no-unused-state,no-undef,object-shorthand,prefer-arrow-callback,prefer-destructuring,react/destructuring-assignment,react/no-access-state-in-setstate */
import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Select,
  Icon,
  List,
  Button,
  Dropdown,
  Pagination,
  Divider,
  Menu,
  Modal,
  Radio,
  InputNumber,
  DatePicker,
  message,
} from 'antd';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from './newActivity.less';

const RadioGroup = Radio.Group;

const FormItem = Form.Item;
const { Option } = Select;

/**
 * @return {null}
 */
function GetQueryString(name) {
  const reg = new RegExp(`(^|&)${  name  }=([^&]*)(&|$)`);
  const num = window.location.href.indexOf('?');
  const r = window.location.href.substr(num + 1).match(reg);
  if (r != null) return unescape(r[2]);
  return null;
};

@connect(({ newActivity, loading }) => ({
  newActivity,
  loading: loading.models.newActivity,
}))
@Form.create()
export default class TableList extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      modalVisible: false,
      modalVisibleOne: false,
      expandForm: false,
      selectedRows: [],
      pageSize: 10,
      pageNo: 1,
      subjectOptionListOne: {
        question: '',
        score: 0,
        referId: GetQueryString('activityId'),
        sNo: '',
        sex: 1,
        subjectOptionList: [],
      },
      eDitdata: {
        question: '',
        score: 0,
        referId: GetQueryString('activityId'),
        sNo: '',
        sex: 1,
        subjectOptionList: [],
      },
      formValues: {},
      defaultCurrent: 1,
      subjectList: {
        question: '',
        score: 0,
        referId: GetQueryString('activityId'),
        sNo: '',
        sex: 1,
        subjectOptionList: [],
      },
    };
    this.handleCancelOne = this.handleCancelOne.bind(this);
    this.saveSublist = this.saveSublist.bind(this);
    this.handleCancelOneEs = this.handleCancelOneEs.bind(this);
    this.handleOkOneEs = this.handleOkOneEs.bind(this);
    this.saveSublistUpdate = this.saveSublistUpdate.bind(this);
    this.handleCancelOneUpdete = this.handleCancelOneUpdete.bind(this);
    this.onShowSizeChange = this.onShowSizeChange.bind(this);
    this.changePage = this.changePage.bind(this);
  }


  componentDidMount() {
    const { dispatch } = this.props;
    const params = {
      type: GetQueryString('type'),
      referId: GetQueryString('activityId'),
      pageNo: 1,
      pageSize: 10,
    };

    dispatch({
      type: 'newActivity/activitySelectSubjectListButton',
      payload: params,
    });
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      type: GetQueryString('type'),
      referId: GetQueryString('activityId'),
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }

    dispatch({
      type: 'newActivity/activitySelectSubjectListButton',
      payload: params,
    });
  };

  handleFormReset = () => {
    const { form,dispatch} = this.props;
    form.resetFields();
    const params = {
      type: GetQueryString('type'),
      referId: GetQueryString('activityId'),
      pageNo: 1,
      pageSize: 10,
    };

    dispatch({
      type: 'newActivity/activitySelectSubjectListButton',
      payload: params,
    });
    this.setState({
      formValues:params,
    });


  };

  handleOkOne() {
    const { dispatch } = this.props;
    this.setState({
      modalVisible: false,
    });
    dispatch({
      type: 'newActivity/addKon',
    });
  }

  handleOkOneEs() {
    const { dispatch } = this.props;
    this.setState({
      modalVisibleOne: false,
    });
    dispatch({
      type: 'newActivity/addKon',
    });
  }

  handleCancelOne() {
    const { dispatch } = this.props;
    this.setState({
      modalVisible: false,
    });
    dispatch({
      type: 'newActivity/addKon',
    });
  }

  handleCancelOneUpdete() {
    const { dispatch } = this.props;
    this.setState({
      modalVisibleOne: false,
    });
    dispatch({
      type: 'newActivity/addKon',
    });
  }

  handleCancelOneEs() {
    const { dispatch } = this.props;
    this.setState({
      modalVisibleOne: false,
    });
    dispatch({
      type: 'newActivity/addKon',
    });
  }

  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (!selectedRows) return;

    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'rule/remove',
          payload: {
            no: selectedRows.map(row => row.no).join(','),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
  };

  handleSearch = e => {
    e.preventDefault();

    const { dispatch, form } = this.props;

    form.validateFields((err, fieldsValue) => {
      if (err) return;

      const values = {
        referId: GetQueryString('activityId'),
        type: GetQueryString('type'),
        ...fieldsValue,
        pageSize: 10,
        pageNo: 1,
      };

      dispatch({
        type: 'newActivity/activitySelectSubjectListButton',
        payload: values,
      });
    });
  };

  handleModalVisible = flag => {
    this.setState({
      modalVisible: !!flag,
    });
  };

  // 助力明细
  posterDetaillist = rows => {
    const { dispatch } = this.props;
    dispatch(routerRedux.push(`/marketingManage/activity/poster/posterDetailList?referId=${  rows.pUserId}`));
  };

  handleAdd = fields => {
    const { dispatch } = this.props;
    this.setState({
      subjectList: {
        question: '',
        score: 0,
        referId: GetQueryString('activityId'),
        sNo: '',
        sex: 1,
        subjectOptionList: [],
      },
    });
    this.setState({
      modalVisible: true,
    });
  };


  renderSimpleForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="查询参数">
              {getFieldDecorator('question')(<Input placeholder="请输入要搜索题目名称" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <span className={styles.submitButtons}>
              <Button type="primary" htmlType="submit">
                查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                重置
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }

  renderAdvancedForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="规则编号">
              {getFieldDecorator('no')(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>,
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="调用次数">
              {getFieldDecorator('number')(<InputNumber style={{ width: '100%' }} />)}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="更新日期">
              {getFieldDecorator('date')(
                <DatePicker style={{ width: '100%' }} placeholder="请输入更新日期" />,
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status3')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>,
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status4')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>,
              )}
            </FormItem>
          </Col>
        </Row>
        <div style={{ overflow: 'hidden' }}>
          <span style={{ float: 'right', marginBottom: 24 }}>
            <Button type="primary" htmlType="submit">
              查询
            </Button>
            <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
              重置
            </Button>
            <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
              收起 <Icon type="up" />
            </a>
          </span>
        </div>
      </Form>
    );
  }

  renderForm() {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm();
  }

  async saveSublist() {
    const { dispatch } = this.props;
    const { defaultCurrent } = this.state;
    const result = await dispatch({
      type: 'newActivity/activitySaveSubjectButton',
      payload: this.state.subjectList,
    });
    if (result) {
      switch (result.code) {
        case '200':
          this.setState({
            eDitdata: '',
            modalVisible: false,
          });
          message.success('保存成功');
          const params = {
            type: GetQueryString('type'),
            referId: GetQueryString('activityId'),
            pageNo: defaultCurrent,
            pageSize: 10,
          };
          dispatch({
            type: 'newActivity/activitySelectSubjectListButton',
            payload: params,
          });
          break;
        case '500':
          message.error(result.msg || '保存失败');
          break;
      }
    }
  }

  // 更新保存
  async saveSublistUpdate() {
    const { dispatch } = this.props;
    const { defaultCurrent } = this.state;
    const result = await dispatch({
      type: 'newActivity/activitySaveSubjectButton',
      payload: this.state.eDitdata,
    });
    if (result) {
      switch (result.code) {
        case '200':
          message.success('保存成功');
          const params = {
            type: GetQueryString('type'),
            referId: GetQueryString('activityId'),
            pageNo: defaultCurrent,
            pageSize: 10,
          };
          this.setState({
            eDitdata: '',
            modalVisibleOne: false,
          });
          dispatch({
            type: 'newActivity/activitySelectSubjectListButton',
            payload: params,
          });
          break;
        case '500':
          message.error(result.msg || '保存失败');
          break;
      }
    }
  }

  // 分页·
  changePage(page, pageSize) {
    const { dispatch } = this.props;
    const params = {
      type: GetQueryString('type'),
      referId: GetQueryString('activityId'),
      pageNo: page,
      pageSize: pageSize,
    };
    this.setState({
      pageNo: page,
      pageSize: pageSize,
      defaultCurrent: page,
    });
    dispatch({
      type: 'newActivity/activitySelectSubjectListButton',
      payload: params,
    });
  }

  onShowSizeChange(current, pageSize) {
    const { dispatch } = this.props;
    const params = {
      type: GetQueryString('type'),
      referId: GetQueryString('activityId'),
      pageNo: current,
      pageSize: pageSize,
    };
    this.setState({
      pageNo: current,
      pageSize: pageSize,
      defaultCurrent: current,
    });
    dispatch({
      type: 'newActivity/activitySelectSubjectListButton',
      payload: params,
    });
  }

  showTotal(total, range){
    return `共${total}条`
  }

  render() {
    const {
      newActivity: { activitySelectSubjectListSave },
      form,
      loading,
    } = this.props;
    const { index, pageSize, pageNo } = this.state;
    const columns = [
      {
        title: '排名',
        dataIndex: 'id',
      },
      {
        title: '头像',
        dataIndex: 'subtitle',
        render: (text, record) => (
          <img alt="" src={record.headUrl} style={{ width: 40, height: 40 }} />
        ),
      },
      {
        title: '昵称',
        dataIndex: 'nickName',

      },
      {
        title: '主攻好友数',
        dataIndex: 'assistsFriendNum',
        render: (text, record) => (
          <span>{record.assistsFriendNum}次</span>
        ),
      },
      {
        title: '积分',
        dataIndex: 'voucherNumber',
        render: (text, record) => (
          <span>{record.integral}分</span>
        ),
      },
      {
        title: '中奖状态',
        render: (text, record) => (
          <span>{Number(record.isPrize) === 0 ? '未中奖' : '中奖'}</span>
        ),
      },
      {
        title: '通知状态',
        render: (text, record) => (
          <span>{Number(record.isPrize) === 1 ? Number(record.isPrize) === 1 ? '通知成功' : '' : '--'}</span>
        ),
      },
      {
        title: '参与时间',
        dataIndex: 'createTime',
      },
      {
        title: '操作',
        align: 'right',
        fixed: 'right',
        render: (text, record) => (
          <Fragment>
            <a onClick={() => this.posterDetaillist(record)}>助力明细</a>
          </Fragment>
        ),
      },

    ];
    // 删除
    const seleteSubjectList = data => {
      const { dispatch } = this.props;
      const { defaultCurrent } = this.state;
      const confirm = Modal.confirm;
      confirm({
        title: '提示?',
        content: '确定要删除吗',
        onOk() {
          const obj = { sId: data.sId, referId: data.referId };
          dispatch({
            type: 'newActivity/activityDeleteSubjectButton',
            payload: obj,
          }).then(function(result) {
            if (result) {
              switch (result.code) {
                case '200':
                  message.success('删除成功');
                  const params = {
                    type: GetQueryString('type'),
                    referId: GetQueryString('activityId'),
                    pageNo: defaultCurrent,
                    pageSize: 10,
                  };
                  dispatch({
                    type: 'newActivity/activitySelectSubjectListButton',
                    payload: params,
                  });
                  break;
                case '500':
                  message.error(result.msg || '删除失败');
                  break;
              }
            }
          });
        },
        onCancel() {
        },
      });
    };

    const menu = (
      <Menu onClick={this.handleMenuClick} selectedKeys={[]}>
        <Menu.Item key="remove">删除</Menu.Item>
        <Menu.Item key="approval">批量审批</Menu.Item>
      </Menu>
    );
    /*
  *查看答案
  */
    const programSearch= rows => {
      const { dispatch } = this.props;
      dispatch(routerRedux.push(`/marketingManage/newActivity/guessResultList?activityId=${GetQueryString("activityId")}&type=${GetQueryString("type")}&sId=${  rows.sId}`));
    };
    const question = e => {
      this.state.subjectList.question = e.target.value;
      this.setState({
        subjectList: this.state.subjectList,
      });
    };
    const score = e => {
      this.state.subjectList.score = e.target.value;
      this.setState({
        subjectList: this.state.subjectList,
      });
    };
    const questionUpdaten = e => {
      this.state.eDitdata.question = e.target.value;
      this.setState({
        eDitdata: this.state.eDitdata,
      });
    };
    const scoreUpdate = e => {
      this.state.eDitdata.score = e.target.value;
      this.setState({
        eDitdata: this.state.eDitdata,
      });
    };
    const key = index => {
      this.setState({
        key: index,
      });
    };
    const sex = e => {
      this.state.subjectList.sex = e.target.value;
      this.setState({
        subjectList: this.state.subjectList,
      });
    };
    const sexUpdate = e => {
      this.state.eDitdata.sex = e.target.value;
      this.setState({
        eDitdata: this.state.eDitdata,
      });
    };
    // 添加选项
    const addSelect = () => {
      const { dispatch } = this.props;
      const params = {
        optName: '',
        grade: '',
      };

      this.state.subjectList.subjectOptionList.push(params);
      this.setState({
        subjectList: this.state.subjectList,
      });
      dispatch({
        type: 'newActivity/addKon',
      });

    };
    // 添加选项
    const addSelectOne = () => {
      const { dispatch } = this.props;
      const params = {
        optName: '',
        grade: '',
      };

      this.state.eDitdata.subjectOptionList.push(params);
      this.setState({
        eDitdata: this.state.eDitdata,
      });
      dispatch({
        type: 'newActivity/addKon',
      });

    };
    // 删除选项
    const deleteOption = (index) => {
      const { dispatch } = this.props;
      this.state.subjectList.subjectOptionList.splice(index, 1);
      this.setState({
        subjectList: this.state.subjectList,
      });
      dispatch({
        type: 'newActivity/addKon',
      });

    };
    const deleteOptionUpdate = (index) => {
      const { dispatch } = this.props;
      this.state.eDitdata.subjectOptionList.splice(index, 1);
      this.setState({
        eDitdata: this.state.eDitdata,
      });
      dispatch({
        type: 'newActivity/addKon',
      });

    };
    // 选项名字
    const optName = e => {
      const { dispatch } = this.props;
      this.state.subjectList.subjectOptionList[this.state.index].optName = e.target.value;
      this.setState({
        subjectList: this.state.subjectList,
      });
      dispatch({
        type: 'newActivity/addKon',
      });

    };
    const optNameUpdate = e => {
      const { dispatch } = this.props;
      this.state.eDitdata.subjectOptionList[this.state.index].optName = e.target.value;
      this.setState({
        eDitdata: this.state.eDitdata,
      });
      dispatch({
        type: 'newActivity/addKon',
      });

    };

    const grade = e => {
      const { dispatch } = this.props;
      this.state.subjectList.subjectOptionList[this.state.index].grade = e.target.value;
      this.setState({
        subjectList: this.state.subjectList,
      });
      dispatch({
        type: 'newActivity/addKon',
      });
    };
    const gradeUpdate = e => {
      const { dispatch } = this.props;
      this.state.eDitdata.subjectOptionList[this.state.index].grade = e.target.value;
      this.setState({
        eDitdata: this.state.eDitdata,
      });
      dispatch({
        type: 'newActivity/addKon',
      });
    };
    const keyValue = (index) => {
      this.setState({
        index: index,
      });
    };
    const keyValueUpdate = (index) => {
      this.setState({
        indexUpdate: index,
      });
    };
    const handleAddOne = data => {
      const { dispatch } = this.props;
      this.setState({
        modalVisibleOne: true,
      });
      this.setState({
        eDitdata: data,
        subjectOptionListOne: data,
      });
      dispatch({
        type: 'newActivity/addKon',
      });
    };
    return (
      <PageHeaderLayout title="" showReturn url="/marketingManage/newActivity">
        <Card bordered={false} type="inner">
          <List loading={loading}>
            <div className={styles.tableList}>
              <div className={styles.tableListForm}>{this.renderForm()}</div>
              <div className={styles.tableListOperator}>
                {
                  Number(GetQueryString('type')) !== 3 ? (
                    <Button
                      icon="plus"
                      type="primary"
                      onClick={() => this.handleAdd(true)}
                      className={styles.buttonAddClass}
                    >
                      新增
                    </Button>
                  ) : ''
                }

                {
                  activitySelectSubjectListSave ? activitySelectSubjectListSave.list.map(function(item, index) {
                    return (
                      <Card
                        style={{ marginTop: '10px' }}
                        key={index}
                        title={pageNo === 1 ? (`Q${(index + 1)}、${item.question}(${item.score}分)`) : (`Q${index + 1 + (pageNo - 1) * pageSize}、${item.question}(${item.score}分)`)}
                        extra={Number(GetQueryString('type')) !== 3 ? (
                          <span>
                            <a onClick={() => handleAddOne(item)}>编辑</a>
                            <Divider type="vertical" />
                            <a onClick={() => {
                              seleteSubjectList(item);
                            }}
                            >删除
                            </a>
                          </span>
                        ) : <a onClick={()=>{programSearch(item)}}>查看答案</a>}
                      >
                        {
                          item.subjectOptionList ? item.subjectOptionList.map(function(item) {
                            return (<p>{`${item.optName}(${item.grade}分)`}</p>);
                          }) : ''
                        }
                      </Card>
                    );
                  }) : ''
                }
                {
                  activitySelectSubjectListSave ? (
                    <Pagination
                      showSizeChanger
                      onShowSizeChange={this.onShowSizeChange}
                      defaultCurrent={this.state.defaultCurrent}
                      total={activitySelectSubjectListSave.pagination.total}
                      onChange={this.changePage}
                      showTotal={this.showTotal}
                      style={{ marginTop: '20px', float: 'right' }}
                    />
                    )
                    : ''
                }
              </div>
            </div>
          </List>
        </Card>

        <Modal
          title="新增题目"
          visible={this.state.modalVisible}
          footer={null}
          width="60%"
          onOk={this.handleOkOne}
          onCancel={this.handleCancelOne}
        >
          <div>
            <table style={{ border: '1px solid #ddd', width: '830px', margin: '0 auto' }}>
              <tr>
                <td style={{ border: '1px solid #ddd', textAlign: 'center', width: '100px' }}>题目</td>
                <td style={{ border: '1px solid #ddd', textAlign: 'center' }}><Input onChange={question} /></td>
                <td style={{ border: '1px solid #ddd', textAlign: 'center', width: '100px' }}>分值</td>
                <td style={{ border: '1px solid #ddd', textAlign: 'center' }}><Input onChange={score} type="number" />
                </td>
              </tr>
              <tr>
                <td style={{ border: '1px solid #ddd', textAlign: 'center', width: '100px' }}>选项</td>
                <td style={{ border: '1px solid #ddd', textAlign: 'center' }} colSpan={3}>
                  <table>
                    <tr>
                      <td style={{ textAlign: 'center', width: '320px' }}>内容</td>
                      <td style={{ textAlign: 'center', width: '220px' }}>分值</td>
                      <td style={{ textAlign: 'center', width: '220px' }}>操作</td>
                    </tr>
                    <tbody>
                      {
                      this.state.subjectList ? this.state.subjectList.subjectOptionList.map(function(item, index) {
                        return (
                          <tr key={index}>
                            <td style={{ border: '1px solid #ddd', textAlign: 'center', width: '160px' }}>
                              <Input
                                onChange={optName}
                                onFocus={() => {
                                  keyValue(index);
                                }}
                              />
                            </td>
                            <td style={{ border: '1px solid #ddd', textAlign: 'center', width: '100px' }}>
                              <Input
                                type="number"
                                onChange={grade}
                                onFocus={() => {
                                  keyValue(index);
                                }}
                              />
                            </td>
                            <td
                              style={{
                                border: '1px solid #ddd',
                                textAlign: 'center',
                                width: '100px',
                                color: '#5AA532',
                              }}
                              onClick={() => {
                                deleteOption(index);
                              }}
                            >删除
                            </td>
                          </tr>
                        );
                      }) : ''
                    }
                    </tbody>
                    <tr>
                      <td colSpan="3" style={{ border: '1px solid #ddd', textAlign: 'center' }} onClick={addSelect}>
                        <a><Icon type="plus-circle-o" />添加</a>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
              <tr>
                <td style={{ border: '1px solid #ddd', textAlign: 'center', width: '100px' }}>性别</td>
                <td style={{ border: '1px solid #ddd', textAlign: 'left' }} colSpan="3">
                  {form.getFieldDecorator('sex', {
                    initialValue:1,
                  })(
                    <RadioGroup onChange={sexUpdate}>
                      <Radio value={1}>男</Radio>
                      <Radio value={2}>女</Radio>
                    </RadioGroup>)}
                </td>
              </tr>
            </table>
            <div style={{ width: '280px', margin: '0 auto', marginTop: '20px', paddingLeft: '70px' }}><Button
              type="primary"
              style={{ marginRight: '10px' }}
              onClick={this.saveSublist}
            >保存
                                                                                                      </Button>
              <Button onClick={this.handleCancelOne}>取消</Button>
            </div>
          </div>
        </Modal>
        <Modal
          title="更新题目"
          visible={this.state.modalVisibleOne}
          footer={null}
          width="60%"
          onOk={this.handleOkOneEs}
          onCancel={this.handleCancelOneEs}
        >
          {
            this.state.eDitdata ? (
              <div>
                <table style={{ border: '1px solid #ddd', width: '830px', margin: '0 auto' }}>
                  <tr>
                    <td style={{ border: '1px solid #ddd', textAlign: 'center', width: '100px' }}>题目</td>
                    {
                      this.state.eDitdata ? (
                        <td style={{ border: '1px solid #ddd', textAlign: 'center' }}>
                          {form.getFieldDecorator('question1', {
                            initialValue: this.state.eDitdata ? this.state.eDitdata.question : '',
                          })(<Input onChange={questionUpdaten} />)}
                        </td>
                      ) : ''
                    }

                    <td style={{ border: '1px solid #ddd', textAlign: 'center', width: '100px' }}>分值</td>
                    {
                      this.state.eDitdata ? (
                        <td style={{ border: '1px solid #ddd', textAlign: 'center' }}>
                          {form.getFieldDecorator('score', {
                            initialValue: this.state.eDitdata ? this.state.eDitdata.score : '',
                          })(<Input onChange={scoreUpdate} type="number" />)}
                        </td>
                      ) : ''
                    }
                  </tr>
                  <tr>
                    <td style={{ border: '1px solid #ddd', textAlign: 'center', width: '100px' }}>选项</td>
                    <td style={{ border: '1px solid #ddd', textAlign: 'center' }} colSpan="3">
                      <table>
                        <tr>
                          <td style={{ textAlign: 'center', width: '320px' }}>内容</td>
                          <td style={{ textAlign: 'center', width: '220px' }}>分值</td>
                          <td style={{ textAlign: 'center', width: '220px' }}>操作</td>
                        </tr>
                        <tbody>
                          {
                          this.state.eDitdata ? this.state.eDitdata.subjectOptionList.map(function(item1, index1) {
                            return (
                              <tr>
                                <td style={{ border: '1px solid #ddd', textAlign: 'center', width: '160px' }}>
                                  <Input
                                    value={item1.optName}
                                    onChange={optNameUpdate}
                                    onFocus={() => {
                                      keyValue(index1);
                                    }}
                                    id={`one${index1}`}
                                  />
                                </td>
                                <td style={{ border: '1px solid #ddd', textAlign: 'center', width: '100px' }}>
                                  <Input
                                    type="number"
                                    value={item1.grade}
                                    onChange={gradeUpdate}
                                    onFocus={() => {
                                      keyValue(index1);
                                    }}
                                  />
                                </td>
                                <td
                                  style={{
                                    border: '1px solid #ddd',
                                    textAlign: 'center',
                                    width: '100px',
                                    color: '#5AA532',
                                  }}
                                  onClick={() => {
                                    deleteOptionUpdate(index1);
                                  }}
                                >删除
                                </td>
                              </tr>
                            );
                          }) : ''
                        }
                        </tbody>
                        <tr>
                          <td
                            colSpan="3"
                            style={{ border: '1px solid #ddd', textAlign: 'center' }}
                            onClick={addSelectOne}
                          >
                            <a><Icon type="plus-circle-o" />添加</a>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td style={{ border: '1px solid #ddd', textAlign: 'center', width: '100px' }}>性别</td>
                    {
                      this.state.eDitdata ? (
                        <td style={{ border: '1px solid #ddd', textAlign: 'left' }} colSpan="3">
                          {form.getFieldDecorator('sex', {
                            initialValue: this.state.eDitdata ? this.state.eDitdata.sex : 1,
                          })(<RadioGroup onChange={sexUpdate}>
                            <Radio value={1}>男</Radio>
                            <Radio value={2}>女</Radio>
                          </RadioGroup>)}
                        </td>
                      ) : ''
                    }
                  </tr>
                </table>
                <div style={{ width: '280px', margin: '0 auto', marginTop: '20px', paddingLeft: '70px' }}><Button
                  type="primary"
                  style={{ marginRight: '10px' }}
                  onClick={this.saveSublistUpdate}
                >保存
                </Button><Button
                                                                                                            onClick={this.handleCancelOneUpdete}
                                                                                                          >取消
                                                                                                          </Button>
                </div>
              </div>
            ) : ''
          }

        </Modal>
      </PageHeaderLayout>
    );
  }
}
