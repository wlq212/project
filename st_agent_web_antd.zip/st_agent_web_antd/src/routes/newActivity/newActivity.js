/* eslint-disable no-unused-vars,prefer-destructuring,default-case,no-case-declarations,no-shadow,no-undef,react/destructuring-assignment,react/destructuring-assignment,lines-between-class-members,react/no-access-state-in-setstate,react/sort-comp,react/no-unused-state */
import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Select,
  Icon,
  DatePicker,
  Button,
  Dropdown,
  Menu,
  InputNumber,
  Modal,
  message,
  Divider,
} from 'antd';
import StandardTable from 'components/StandardTable';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from './newActivity.less';
import moment from 'moment';
import activiTypelist from '../../assets/js/cardConst';
import { getStore, setStore } from '../../assets/js/mUtils';

const { RangePicker} = DatePicker;
const FormItem = Form.Item;
const { Option } = Select;
@connect(({ newActivity, loading }) => ({
  newActivity,
  loading: loading.models.newActivity,
}))
@Form.create()
export default class TableList extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      modalVisible: false,
      linkvalue: '',
      modalVisibleOne: false,
      expandForm: false,
      modelTitle:"",
      selectedRows: [],
      formValues: {
        pageNo: 1,
        pageSize: 10,
      },
      activityList: {
        list: [],
        total: 0,
      },
    };
    this.time = this.time.bind(this);
  }


  componentDidMount() {
    const { dispatch } = this.props;

    if(getStore("formValues")){
      dispatch({
        type: 'newActivity/ActiveButton',
        payload:{
          ...JSON.parse(getStore("formValues")),
        },
      });
      this.setState({
        formValues:{
          ...JSON.parse(getStore("formValues")),
        },
      })
    }else{
      const params = {
        pageNo: 1,
        pageSize: 10,
      };
      dispatch({
        type: 'newActivity/ActiveButton',
        payload: params,
      });
    }
  }

  // 留言列表跳转
  posterPartakeList = rows => {
    const { dispatch } = this.props;
    switch (rows.type) {
      case 5:
        dispatch(routerRedux.push(`/marketingManage/newActivity/deskLuckPartakeList?activityId=${  rows.activityId}&type=${rows.type }&isOpen=${rows.isOpen}&prizeCount=${rows.prizeCount}`));
        break;
      case 4:
        dispatch(routerRedux.push(`/marketingManage/newActivity/answerPartakeList?activityId=${  rows.activityId}&type=${rows.type }&isOpen=${rows.isOpen}&prizeCount=${rows.prizeCount}`));
        break;
      case 3:
        dispatch(routerRedux.push(`/marketingManage/newActivity/newActivityPartakeList?activityId=${  rows.activityId}&type=${rows.type }&isOpen=${rows.isOpen}&prizeCount=${rows.prizeCount}`));
        break;
      case 2:
        dispatch(routerRedux.push(`/marketingManage/newActivity/friendsPartakeList?activityId=${  rows.activityId}&type=${rows.type }&isOpen=${rows.isOpen}&prizeCount=${rows.prizeCount}`));
        break;
      case 1:
        dispatch(routerRedux.push(`/marketingManage/newActivity/newActivityPartakeList?activityId=${  rows.activityId}&type=${rows.type }&isOpen=${rows.isOpen}&prizeCount=${rows.prizeCount}`));
        break;
      case 0:
        dispatch(routerRedux.push(`/marketingManage/newActivity/newActivityPartakeList?activityId=${  rows.activityId}&type=${rows.type }&isOpen=${rows.isOpen}&prizeCount=${rows.prizeCount}`));
        break;
    }
    setStore("formValues",this.state.formValues)
  };



  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});
    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      beginTime: this.state.beginTime,
      endTime: this.state.endTime,
      ...formValues,
      ...filters,
    };
    params.pageNo = pagination.current;
    params.pageSize = pagination.pageSize;
    this.setState({
      formValues: params,
    });
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'newActivity/ActiveButton',
      payload: params,
    });
  };

  handleFormReset = () => {
    const { form,dispatch} = this.props;
    form.resetFields();
    const params = {
      pageNo: 1,
      pageSize: 10,
    };
    dispatch({
      type: 'newActivity/ActiveButton',
      payload: params,
    });
    this.setState({
      formValues:params,
    });
  };


  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (!selectedRows) return;

    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'rule/remove',
          payload: {
            no: selectedRows.map(row => row.no).join(','),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
  };

  handleSearch = e => {
    const { dispatch, form } = this.props;

    form.validateFields((err, fieldsValue) => {
      if (err) return;
      if(fieldsValue.activityName){
        fieldsValue.activityName=fieldsValue.activityName.replace(/\s/gi,'');
      }
      const values = {
        ...fieldsValue,
        beginTime: this.state.beginTime,
        endTime: this.state.endTime,
        pageSize: 10,
        pageNo: 1,
      };

      this.setState({
        formValues: values,
      });
      dispatch({
        type: 'newActivity/ActiveButton',
        payload: values,
      });
    });
  };
  handleSearchType=e=>{
    const { dispatch} = this.props;
    const obj={
      pageSize: 10,
      pageNo: 1,
      type:e,
    };

    dispatch({
      type: 'newActivity/ActiveButton',
      payload: obj,
    });
    this.setState({
      formValues:Object.assign(this.state.formValues,obj),
    })
  };

  handleModalVisible = flag => {
    this.setState({
      modalVisible: !!flag,
    });
  };

  // 添加
  handleAdd = () => {
    this.setState({
      modalVisibleOne: true,
    });
  };

  // 编辑
  edit = rows => {
    const { dispatch } = this.props;
    dispatch(routerRedux.push(`/marketingManage/newActivity/newActivityEdit?activityId=${rows.activityId}&type=${rows.type}&isOpen=${rows.isOpen}`));
    setStore("formValues",this.state.formValues)
  };

  delete = rows => {
    const { dispatch } = this.props;
    const {formValues}=this.state;
    const confirm = Modal.confirm;
    confirm({
      title: '提示?',
      content: '确定要删除吗',
      onOk() {
        const params = {
          activityId: rows.activityId,
          type: rows.type,
        };
        const response = dispatch({
          type: 'newActivity/posterDeleteButton',
          payload: params,
        });
        response.then((result) => {
          if (result) {
            switch (result.code) {
              case '200':
                message.success('删除成功');
                const params = {
                  pageNo:formValues.pageNo,
                  pageSize:formValues.pageSize,
                };
                dispatch({
                  type: 'newActivity/ActiveButton',
                  payload: params,
                });
                break;
              case '500':
                message.error(result.msg || '删除失败');
                break;
            }
          }
        }, (result) => {
          // console.log(result);
        });


      },
      onCancel() {
      },
    });
  };

  // 积分海报开奖
  openPrize = (rows) => {
    const { dispatch } = this.props;
    const {formValues}=this.state;
    const confirm = Modal.confirm;
    confirm({
      title: '提示?',
      content: '确定是否开奖',
      onOk() {
        dispatch({
          type: 'newActivity/posterOpenAPrizeButton',
          payload: { activityId: rows.activityId, type: rows.type },
        }).then((result) => {
          switch (result.code) {
            case '200':
              message.success('开奖成功');
              const params = {
                pageNo: formValues.pageNo,
                pageSize: formValues.pageSize,
              };
              dispatch({
                type: 'newActivity/ActiveButton',
                payload: params,
              });
              break;
            case '500':
              message.error(result.msg || '开奖失败');
              break;
          }
        });
      },
      onCancel() {
      },
    });
  };
  // 查看链接模态框
  handleOk = () => {
    this.setState({
      modalVisible: false,
    });
  };
  // 查看题目
  searchProgram = (rows) => {
    const { dispatch } = this.props;
    dispatch(routerRedux.push(`/marketingManage/newActivity/activitySelectSubjectList?activityId=${  rows.activityId}&type=${rows.type }`));
    setStore("formValues",this.state.formValues)
  };
  handleCancel = () => {
    this.setState({
      modalVisible: false,
    });
  };
  // 活动类型模态框
  handleOkOne = () => {
    this.setState({
      modalVisibleOne: false,
    });
  };
  handleCancelOne = () => {
    this.setState({
      modalVisibleOne: false,
    });
  };
  /*
  *积分海报排名链接
  */
  posterRankLink = rows => {
    // this.setState({
    //   linkvalue: `http://api.shitan.me/h5#/poster?appId=${  JSON.parse(getStore('userInfo')).user.appId  }&posterId=${  rows.activityId}&type=${  rows.type}`,
    //   modalVisible: true,
    // });
    const that=this;
    switch (rows.type) {
      case 0:
        // 积分海报
        that.setState({
          linkvalue: `<a href='http://oper.shitan.me/h5#/poster?appId=${getStore('userInfo')?JSON.parse(getStore('userInfo')).user.appId:""}&posterId=${rows.activityId}&type=0'>点击跳小程序</a>`,
          modalVisible: true,
          modelTitle:"排名链接",
        });
        // that.setState({
        //   linkvalue: `<a href=' ' data-miniprogram-appid='${getStore('userInfo')?JSON.parse(getStore('userInfo')).user.miniAppId:""}' data-miniprogram-path='pages/posterRank/posterRank?activityId=${rows.activityId}'>点击跳小程序</a>`,
        //   modalVisible: true,
        //   modelTitle:"排名链接",
        // });
        break;
      case 4:
        // 答题
        that.setState({
          linkvalue: `<a href=' ' data-miniprogram-appid='${getStore('userInfo')?JSON.parse(getStore('userInfo')).user.miniAppId:""}' data-miniprogram-path='pages/answer/index?activityId=${rows.activityId}'>点击跳小程序</a>`,
          modalVisible: true,
          modelTitle:"小程序链接",
        });
        break;
      case 3:
        // 竞猜
        that.setState({
          linkvalue: `pages/posterRank/posterRank?activityId=${  rows.activityId}`,
          modalVisible: true,
          modelTitle:"小程序链接",
        });
        break;
      case 2:
        // 朋友圈转发抽奖
        that.setState({
          linkvalue: `pages/posterRank/posterRank?activityId=${  rows.activityId}`,
          modalVisible: true,
          modelTitle:"小程序链接",
        });
        break;
    }

  };
  selectActiveType = data => {
    const { dispatch } = this.props;
    dispatch(routerRedux.push(`/marketingManage/newActivity/newActivityAdd?activeType=${data}`));
    this.setState({
      modalVisibleOne: false,
    });
    setStore("formValues",this.state.formValues)
  };

  time(a, b) {
    this.setState({
      beginTime: b[0],
      endTime: b[1],
    });
    const { dispatch } = this.props;
    const obj={
      pageSize: 10,
      pageNo: 1,
      beginTime: b[0],
      endTime: b[1],
    };
    this.setState({
      formValues:Object.assign(this.state.formValues,obj),
    });
    setStore("formValues",Object.assign(this.state.formValues,obj));
    dispatch({
      type: 'newActivity/ActiveButton',
      payload: obj,
    });

  }

  renderSimpleForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={24} sm={24} lg={7}>
            <FormItem label="活动时间">
              {getFieldDecorator('time',{
                initialValue:this.state.formValues.endTime?[moment(this.state.formValues.beginTime,"YYYY-MM-DD"),moment(this.state.formValues.endTime,"YYYY-MM-DD")]:"",
              })(
              <RangePicker onChange={this.time} />
              )}
            </FormItem>

          </Col>
          <Col md={24} sm={24} lg={4}>
            <FormItem label="">
              {getFieldDecorator('type',{
                initialValue:this.state.formValues?this.state.formValues.type:"",
              })(
                <Select placeholder="请选择活动类型" onChange={this.handleSearchType}>
                  <Option value="">全部</Option>
                  <Option value="0">积分海报</Option>
                  <Option value="1">文章评论抽奖</Option>
                  <Option value="2">朋友圈转发抽奖</Option>
                  <Option value="3">竞猜</Option>
                  <Option value="4">答题</Option>
                  <Option value="5">同桌拼手气</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={24} sm={24} lg={5}>
            <FormItem label="">
              {getFieldDecorator('activityName',{
                initialValue:this.state.formValues?this.state.formValues.activityName:"",
              })(<Input placeholder="请输入要搜索的名称" />)}
            </FormItem>
          </Col>
          <Col md={24} sm={24} lg={8} style={{overflow: "hidden"}}>
            <span className={styles.submitButtons}>
              <Button type="primary" onClick={this.handleSearch} style={{float:"left" }}>
                查询
              </Button>
              <Button style={{ marginLeft: 8,float:"left" }} onClick={this.handleFormReset}>
                重置
              </Button>
              <Button icon="plus" type="primary" onClick={() => this.handleAdd(true)} style={{float:"right"}}>
                新建活动
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }

  renderAdvancedForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="规则编号">
              {getFieldDecorator('no')(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>,
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="调用次数">
              {getFieldDecorator('number')(<InputNumber style={{ width: '100%' }} />)}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="更新日期">
              {getFieldDecorator('date')(
                <DatePicker style={{ width: '100%' }} placeholder="请输入更新日期" />,
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status3')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>,
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="使用状态">
              {getFieldDecorator('status4')(
                <Select placeholder="请选择" style={{ width: '100%' }}>
                  <Option value="0">关闭</Option>
                  <Option value="1">运行中</Option>
                </Select>,
              )}
            </FormItem>
          </Col>
        </Row>
        <div style={{ overflow: 'hidden' }}>
          <span style={{ float: 'right', marginBottom: 24 }}>
            <Button type="primary" htmlType="submit">
              查询
            </Button>
            <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
              重置
            </Button>
            <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
              收起 <Icon type="up" />
            </a>
          </span>
        </div>
      </Form>
    );
  }

  renderForm() {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm();
  }

  // 查看答案
  guessResult = rows => {
    const { dispatch } = this.props;
    dispatch(routerRedux.push(`/marketingManage/newActivity/guessResultList?activityId=${  rows.activityId}&type=${  rows.type}`));
    setStore("formValues",this.state.formValues)
  };
  // 留言列表
  commentUserList = rows => {
    const { dispatch } = this.props;
    dispatch(routerRedux.push(`/marketingManage/newActivity/newActivityCommentUser?prizeCount=${rows.prizeCount}&type=${rows.type}&aId=${ rows.activityId }&msgDataId=${  
      JSON.parse(rows.extraInfo).msgDataId}`));
    setStore("formValues",this.state.formValues)
  };

  render() {
    const {
      loading,
      newActivity: { activityListNews },
    } = this.props;
    activityListNews.pagination.current = this.state.formValues.pageNo;
    const that=this;
    const { selectedRows } = this.state;
    const columns = [
      {
        title: '活动名称',
        key: 'activityName',
        dataIndex: 'activityName',
      },
      {
        title: '活动类型',
        key: 'type',
        render: (text, record) => (
          <span>
            {
             record.type === 4 ? '答题' :
             record.type === 3 ? '竞猜' :
             record.type === 2 ? '朋友圈转发抽奖' :
             record.type === 1 ? '文章评论抽奖' :
             record.type === 0 ? '积分海报' :
             record.type === 5 ? '同桌拼手气':""
            }
          </span>
        ),
      },
      {
        title: '创建时间',
        key: 'createTime',
        dataIndex: 'createTime',
      },
      {
        title: '中奖/参与人数',
        key: 'prizeCount',
        render: (text, record) => (
          <span>{`${record.prizeSize}/${record.userSize}人`}</span>
        ),
      },
      {
        title: '状态',
        key: 'state',
        dataIndex: 'state',
        render: (text, record) => (
          <span>{record.state === 1 ? '有效' : '无效'}</span>
        ),
      },
      {
        title: '操作',
        key: 'id',
        align: 'right',
        fixed: 'right',
        render: (text, record) => (
          <Fragment>

            <a onClick={() => this.edit(record)}>编辑</a>
            <Divider type="vertical" />
            <a onClick={() => this.delete(record)}>删除</a>
            {
              record.type === 5 ? (
                <span>
                  <Divider type="vertical" />
                  <a onClick={() => this.posterPartakeList(record)}>参与情况</a>
                </span>
              ) : ''
            }
            {
              record.type === 4 ? (
                <span>
                  <Divider type="vertical" />
                  <a onClick={() => this.posterPartakeList(record)}>参与情况</a>
                  <Divider type="vertical" />
                  <a onClick={() => this.searchProgram(record)}>查看题目</a>
                   <Divider type="vertical" />
                  <a onClick={() => this.posterRankLink(record)}>小程序链接</a>
                </span>
              ) : ''
            }
            {
              record.type === 3 ? (
                record.isOpen===0? (
                  <span> <Divider type="vertical" /><a onClick={() => this.guessResult(record)}>查看答案</a>   <Divider
                    type="vertical"
                  /><a onClick={() => this.posterPartakeList(record)}>参与情况</a>
                  </span>
            ): (
              <span>
                <Divider type="vertical" />
                <span>已公布答案</span>
                <Divider type="vertical" />
                <a onClick={() => this.posterPartakeList(record)}>参与情况</a>
              </span>
              )) : ''
            }
            {
              record.type === 2 ?
                <span> <Divider type="vertical" /><a onClick={() => this.posterPartakeList(record)}>参与情况</a></span> : ''
            }
            {
              record.type === 1 ?
                <span> <Divider type="vertical" /><a onClick={() => this.commentUserList(record)}>留言列表</a></span> : ''
            }
            {
              record.type === 0 ? (
                <span>
                  <Divider type="vertical" />
                  <a onClick={() => this.posterPartakeList(record)}>参与情况</a>
                  <Divider type="vertical" />
                  <a onClick={() => this.posterRankLink(record)}>排名链接</a>
                </span>
              ) : ''
            }
          </Fragment>
        ),
      },
    ];

    const menu = (
      <Menu onClick={this.handleMenuClick} selectedKeys={[]}>
        <Menu.Item key="remove">删除</Menu.Item>
        <Menu.Item key="approval">批量审批</Menu.Item>
      </Menu>
    );
    return (
      <PageHeaderLayout title="">
        <Card bordered={false}>
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>{this.renderForm()}</div>
            <div className={styles.tableListOperator}>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                  <Dropdown overlay={menu}>
                    <Button>
                      更多操作 <Icon type="down" />
                    </Button>
                  </Dropdown>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={activityListNews}
              columns={columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
            />
          </div>
        </Card>
        <Modal
          title="活动类型列表"
          visible={this.state.modalVisibleOne}
          footer={null}
          width="60%"
          onOk={this.handleOkOne}
          onCancel={this.handleCancelOne}
        >
          <ul style={{listStyle: 'none',display:"flex",justifyContent:"left",flexWrap:"wrap",marginRight:"00px",paddingLeft:"0px"}}>
            {
            activiTypelist.activityTypes?activiTypelist.activityTypes.map((item) => {
              return (
                <li
                  style={{
                  width:"150px",
                  lineHeight: '88px',
                  height:'88px',
                  textAlign: 'center',
                  background: '#D8D8D8',
                  border: '1px solid #979797',
                  color: '#666666',
                  fontSize: '18px',
                  marginBottom:"10px",
                  marginRight:"10px",
                  cursor: 'pointer',
                   }}
                  onClick={() => {
                    that.selectActiveType(item.value);
                      }}
                 >
                  {item.name}
                </li>
              )
            }):""
           }
          </ul>
        </Modal>
        <Modal
          title={this.state.modelTitle}
          visible={this.state.modalVisible}
          footer={null}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
          <Input value={this.state.linkvalue} />
        </Modal>
      </PageHeaderLayout>
    );
  }
}
