/* eslint-disable no-unused-vars,react/destructuring-assignment,react/sort-comp,no-param-reassign,default-case,eqeqeq,no-script-url,no-undef,react/jsx-boolean-value */
import React, { PureComponent,Fragment } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Form,
  Input,
  Select,
  Button,
  Card,
  Row,
  Col,
  message,
  Modal,
  } from 'antd';

import StandardTable from 'components/StandardTable';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from '../../assets/css/style.less';

const FormItem = Form.Item;
const { Option } = Select;
@connect(({ qrcode, loading }) => ({
  qrcode,
  loading: loading.models.qrcode,
}))
@Form.create()
export  default class BasicForms extends PureComponent {
  constructor(props){

    super(props)

    this.state={
      visibleKeyWord: false,
      keyword:"",
      selectedRowsKeyWord:[],
      autoReplyId:"",
    }

    this.handleCancelKeyWord = this.handleCancelKeyWord.bind(this);

    this.showModelKeyWord=this.showModelKeyWord.bind(this);
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'qrcode/fetchshop',
      payload: '',
    });
  }
;
  handleCancelKeyWord() {
    this.setState({
      visibleKeyWord: false,
    });
  }

  selectKeyWord = rows => {
    this.setState({
      visibleKeyWord: false,
      autoReplyId:rows.autoReplyId,
      keyword: rows.keyword,
    });
  };

  // 条件查询关键词
  handleSearchKeyWord() {
    const { dispatch } = this.props;
    const params = {
      keyword: this.state.keyword,
      pageSize: 10,
      pageNo: 1,
    };
    dispatch({
      type: 'qrcode/autoReplyListButton',
      payload: params,
    });
  }

  renderFormKeyWord() {
    return (
      <Form layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={7} sm={24} style={{ margin: '-10px 0 10px 0' }}>
            <FormItem label="查询参数">
              <Input placeholder="请输入关键词" onChange={this.keyword} />
            </FormItem>
          </Col>
          <Col md={1} sm={24} style={{ margin: '-5px 0 10px 0' }}>
            <span className={styles.submitButtons}>
              <Button type="primary" htmlType="submit" onClick={this.handleSearchKeyWord}>
              查询
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }
;
  handleStandardTableChangeKeyWord = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      keyword: this.state.keyword,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'qrcode/autoReplyListButton',
      payload: params,
    });
  };

  cancel = e => {
    e.preventDefault();
    const { dispatch } = this.props;
    dispatch(routerRedux.push('/Data/qrcode'));
  };

  handleSubmit = e => {
    e.preventDefault();
    const { form, dispatch} = this.props;
    form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        values.autoReplyId=this.state.autoReplyId;
        dispatch({
          type: 'qrcode/addQrcodeShop',
          payload: values,
        }).then((result) => {
          if (result) {
            switch (result.code) {
              case '200':
                message.success('添加成功');
                dispatch(routerRedux.push('/Data/qrcode'));
                break;
              case '500':
                message.error(result.msg);
                break;
            }
          }
        }, (result) => {

        });
      }
    });

  };

  // 显示关键词model
  showModelKeyWord() {
    const { dispatch } = this.props;
    const params = {
      pageSize: 10,
      pageNo: 1,
    };
    dispatch({
      type: 'qrcode/autoReplyListButton',
      payload: params,
    });
    this.setState({
      visibleKeyWord: true,
    });

  }

  render() {
    const { submitting, form, qrcode,loading} = this.props;
    const {selectedRowsKeyWord}=this.state;
    const { TextArea } = Input;
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 },
        md: { span: 10 },
      },
    };

    const submitFormLayout = {
      wrapperCol: {
        xs: { span: 24, offset: 0 },
        sm: { span: 10, offset: 7 },
      },
    };
    // 关键词
    const columnsKeyWordTab = [
      {
        title: '关键词',
        key: 'keyword',
        dataIndex: 'keyword',
      },
      {
        title: '类型',
        key: 'msgType',
        render: (text, record) => (
          <span>
            {record.msgType === 'image'
              ? '图片'
              : record.msgType === 'news'
                ? '图文'
                :record.msgType === 'text'
                  ? '文本'
                  : ''}
          </span>
        ),
      },
      {
        title: '回复内容',
        width: 200,
        render: (text, record) => (
          <a
            className={styles.tdClass}
            href={
              record.msgType === 'image'
                ? record.picUrl
                : record.msgType ==='news'
                ? record.url
                : '#'
            }
          >
            {record.msgType === 'image'
              ? '查看图片'
              : record.msgType === 'news'
                ? '查看图文'
                : record.msgType === 'text'
                  ? record.content
                  : ''}
          </a>
        ),
      },
      {
        title: '状态',
        key: 'state',
        render: (text, record) => <span>{record.state === 0 ? '无效' : '有效'}</span>,
      },
      {
        title: '创建时间',
        dataIndex: 'createTime',
        key: 'createTime',
      },
      {
        title: '操作',
        width: 180,
        fixed: 'right',
        render: (text, record) => (
          <Fragment>
            <a href="javaScript:void(0)" onClick={() => this.selectKeyWord(record)}>
              选择
            </a>
          </Fragment>
        ),
      },
    ];

    return (
      <PageHeaderLayout showReturn={true} url="/Data/qrcode">
        <Card bordered={false}>
          <Form onSubmit={this.handleSubmit} hideRequiredMark style={{ marginTop: 8 }}>
            <FormItem {...formItemLayout} label="渠道名称">
              {form.getFieldDecorator('channelName', {
                rules: [{ required: true, message: '请输入渠道名称' }],
              })(<Input placeholder="请输入渠道名称" id="channelName" />)}
            </FormItem>
            <FormItem {...formItemLayout} label="渠道类别">
              {form.getFieldDecorator('channelType', {
                rules: [{ required: true, message: '请输入选择门店' }],
              })(<Select
                showSearch
                placeholder="门店"
                optionFilterProp="children"
              >
                <Option value="">选择门店</Option>
                <Option value="1">文章</Option>
                <Option value="0">门店</Option>
              </Select>)}
            </FormItem>
            <FormItem {...formItemLayout} label="关键词">
              {form.getFieldDecorator('keyword', {
                initialValue:this.state.keyword,
                rules: [{ required: true, message: '请输入关键词' }],
              })(
                <div onClick={this.showModelKeyWord}>
                  <Select
                    placeholder="请选择关键词"
                    value={this.state.keyword}
                  />
                </div>
              )}
            </FormItem>
            <FormItem {...formItemLayout} label="备注">
              {form.getFieldDecorator('note')(<TextArea rows={4} />)}

            </FormItem>
            <FormItem {...submitFormLayout} style={{ marginTop: 32 }}>
              <Button type="primary" htmlType="submit" loading={loading}>
                提交
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.cancel}>取消</Button>
            </FormItem>
          </Form>
        </Card>
        <Modal
          title="关键词列表"
          visible={this.state.visibleKeyWord}
          footer={null}
          width="80%"
          onCancel={this.handleCancelKeyWord}
        >
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>
              {this.renderFormKeyWord()}
            </div>
            <div className={styles.tableListOperator}>
              {selectedRowsKeyWord.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRowsKeyWord}
              data={qrcode.autoReplyList}
              loading={loading}
              columns={columnsKeyWordTab}
              onChange={this.handleStandardTableChangeKeyWord}
            />
          </div>
        </Modal>
      </PageHeaderLayout>
    );
  }
}
