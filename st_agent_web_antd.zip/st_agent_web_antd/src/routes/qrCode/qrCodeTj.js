/* eslint-disable no-unused-vars,react/destructuring-assignment,no-script-url,prefer-destructuring,no-shadow,no-case-declarations,default-case,react/no-unused-state,react/sort-comp */
import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Select,
  Icon,
  Button,
  Alert,
  Modal,
  message,
  DatePicker,
  Divider,
} from 'antd';
import {
  ChartCard,
  yuan,
  MiniArea,
  MiniBar,
  MiniProgress,
  Field,
  Bar,
  Pie,
  TimelineChart,
} from 'components/Charts';
import StandardTable from 'components/StandardTable';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from '../../assets/css/common.less';
const { RangePicker } = DatePicker;

/**
 * @return {null}
 */
function GetQueryString(name) {
  const reg = new RegExp(`(^|&)${  name  }=([^&]*)(&|$)`);
  const num = window.location.href.indexOf('?');
  const r = window.location.href.substr(num + 1).match(reg);
  if (r != null) return unescape(r[2]);
  return null;
};



const FormItem = Form.Item;
const { Option } = Select;
const getValue = obj =>
  Object.keys(obj)
    .map(key => obj[key])
    .join(',');
const CreateForm = Form.create()(props => {
  const { modalVisible, form, handleAdd, handleModalVisible, handleChange } = props;
  const okHandle = () => {
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      handleAdd(fieldsValue);
    });
  };
  return (
    <Modal
      title="账号添加"
      visible={modalVisible}
      onOk={okHandle}
      onCancel={() => handleModalVisible()}
    >
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号类型" validateStatus="success">
        {form.getFieldDecorator('roleType', {
          rules: [{ required: true, message: '请选择账号类型' }],
        })(<Select
          style={{ width: 290 }}
          placeholder="请选择账号类型"
          optionFilterProp="children"
          onChange={handleChange}
        >
          <Option value="200">管理员</Option>
          <Option value="300">普通成员</Option>
        </Select>)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="品牌名称" validateStatus="success">
        {form.getFieldDecorator('brandName', {
          rules: [{ required: true, message: '请输入品牌名称' }],
        })(<Input placeholder="请输入品牌名称" id="brandNameOne" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号" validateStatus="success">
        {form.getFieldDecorator('userName', {
          rules: [{ required: true, message: '请输入账号' }],
        })(<Input placeholder="请输入账号" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="密码">
        {form.getFieldDecorator('pwd', {
          rules: [{ required: true, message: '请输入密码' }],
        })(<Input placeholder="请输入密码" type="password" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="微信号">
        {form.getFieldDecorator('city')(<Button type="primary">关联微信</Button>)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="手机号">
        {form.getFieldDecorator('city')(<Input placeholder="请输入手机号" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="城市">
        {form.getFieldDecorator('mobile')(<Input placeholder="请输入" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="状态">
        {form.getFieldDecorator('state', {
          rules: [{ required: true, message: '请选择状态' }],
        })(<Select
          style={{ width: 290 }}
          placeholder="请选择状态"
          optionFilterProp="children"
          onChange={handleChange}
        >
          <Option value="0">停用</Option>
          <Option value="1">正常</Option>
        </Select>)}
      </FormItem>
    </Modal>
  );
});

const CollectionCreateForm = Form.create({
  mapPropsToFields(props) {
    return {
      roleType: Form.createFormField(props.selectRowData.roleType),
      brandName: Form.createFormField(props.selectRowData.brandName),
      userName: Form.createFormField(props.selectRowData.userName),
      pwd: Form.createFormField(props.selectRowData.pwd),
      city: Form.createFormField(props.selectRowData.city),
      mobile: Form.createFormField(props.selectRowData.mobile),
      state: Form.createFormField(props.selectRowData.state),
    };
  },
})(
  class basekk extends React.Component {
    render() {
      const { visible, onCancel, onCreate, form } = this.props;
      return (
        <Modal
          visible={visible}
          title="更新"
          okText="更新"
          onCancel={onCancel}
          onOk={onCreate}
        >
          <Form layout="vertical">
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号类型" validateStatus="success">
              {form.getFieldDecorator('roleType', {
                rules: [{ required: true, message: '请选择账号类型' }],
              })(<Select
                style={{ width: 290 }}
                placeholder="请选择账号类型"
                optionFilterProp="children"
              >
                <Option value="200">管理员</Option>
                <Option value="300">普通成员</Option>
              </Select>)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="品牌名称" validateStatus="success">
              {form.getFieldDecorator('brandName', {
                rules: [{ required: true, message: '请输入品牌名称' }],
              })(<Input placeholder="请输入品牌名称" id="brandNameOne" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号" validateStatus="success">
              {form.getFieldDecorator('userName', {
                rules: [{ required: true, message: '请输入账号' }],
              })(<Input placeholder="请输入账号" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="密码">
              {form.getFieldDecorator('pwd', {
                rules: [{ required: true, message: '请输入密码' }],
              })(<Input placeholder="请输入密码" type="password" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="微信号">
              {form.getFieldDecorator('city')(<Button type="primary">关联微信</Button>)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="手机号">
              {form.getFieldDecorator('city')(<Input placeholder="请输入手机号" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="城市">
              {form.getFieldDecorator('mobile')(<Input placeholder="请输入" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="状态">
              {form.getFieldDecorator('state', {
                rules: [{ required: true, message: '请选择状态' }],
              })(<Select
                style={{ width: 290 }}
                placeholder="请选择状态"
                optionFilterProp="children"
              >
                <Option value="0">停用</Option>
                <Option value="1">正常</Option>
              </Select>)}
            </FormItem>
          </Form>
        </Modal>
      );
    }
  },
);


@connect(({ qrcode, loading }) => ({
  qrcode,
  loading: loading.models.qrcode,
}))
@Form.create()
export  default class TableList extends PureComponent {
  constructor(props){
    super(props)
    this.state = {
      visible: false,
      modalVisible: false,
      selectRowData: {},
      message: '',
      type: '',
      timeArr:[],
      modelTitle: '添加管理员',
      alertVisible: false,
      expandForm: false,
      selectedRows: [],
      formValues: {},
    };
    this.timeonChange=this.timeonChange.bind(this)
  }


  handleCancel = () => {
    this.setState({ visible: false });
  };

  handleCreate = () => {
    const form = this.formRef.props.form;
    form.validateFields((err) => {
      if (err) {
        return;
      }
      form.resetFields();
      this.setState({ visible: false });
    });
  };

  saveFormRef = (formRef) => {
    this.formRef = formRef;
  };

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'qrcode/qrcodeGetAnalysisDataButton',
      payload:{
        type:"0",
        referId:GetQueryString("qrCodeId"),
        beginTime:this.state.timeArr?this.state.timeArr[0]:"",
        endTime:this.state.timeArr?this.state.timeArr[1]:"",
      },
    });

  }

  handleChange = flag => {

  };

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }

    dispatch({
      type: 'qrcode/fetchQrcodeList',
      payload: params,
    });
  };

  handleFormReset = () => {
    const { form,dispatch} = this.props;
    form.resetFields();
    dispatch({
      type: 'qrcode/qrcodeGetAnalysisDataButton',
      payload:{
        type:"0",
        referId:GetQueryString("qrCodeId"),
        beginTime:this.state.timeArr?this.state.timeArr[0]:"",
        endTime:this.state.timeArr?this.state.timeArr[1]:"",
      },
    });
    this.setState({
      formValues: {
        type:"0",
        referId:GetQueryString("qrCodeId"),
        beginTime:this.state.timeArr?this.state.timeArr[0]:"",
        endTime:this.state.timeArr?this.state.timeArr[1]:"",
      },
    });
  };

  toggleForm = () => {
    const { expandForm } = this.state;
    this.setState({
      expandForm: !expandForm,
    });
  };

  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (!selectedRows) return;

    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'rule/remove',
          payload: {
            no: selectedRows.map(row => row.no).join(','),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
  };

  handleSearch = e => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = {
          type:"0",
          referId:GetQueryString("qrCodeId"),
          beginTime:this.state.timeArr?this.state.timeArr[0]:"",
          endTime:this.state.timeArr?this.state.timeArr[1]:"",
      };
      this.setState({
        formValues: values,
      });
      dispatch({
        type: 'qrcode/qrcodeGetAnalysisDataButton',
        payload: values,
      });
    });
  };

  msg;

  delete = rows => {
    const { dispatch} = this.props;
    const confirm = Modal.confirm;
    confirm({
      title: '提示?',
      content: '确定要删除门店吗？',
      onOk() {
        const params = {
          qrCodeId: rows.qrCodeId,
        };
        dispatch({
          type: 'qrcode/deleteQrcodeShop',
          payload: params,
        }).then((result) => {
          // console.log(result);
          if (result) {
            switch (result.code) {
              case '200':
                message.success('删除成功');
                const params = {
                  pageNo: 1,
                  pageSize: 10,
                };
                dispatch({
                  type: 'qrcode/fetchshop',
                  payload: '',
                });

                dispatch({
                  type: 'qrcode/fetchQrcodeList',
                  payload: params,
                });
                break;
              case '500':
                message.error(result.msg || '删除失败');
                break;
            }
          }
        }, (result) => {

        });

      },
      onCancel() {
      },
    });
  };

  add = () => {
    const { dispatch} = this.props;
    dispatch(routerRedux.push('/Data/qrcode/qrcodeAdd'));

  };

  update = data => {
    const { dispatch} = this.props;
    dispatch({
      type: 'qrcode/updateParams',
      payload: data,
    });
    dispatch(routerRedux.push('/Data/qrcode/qrcodeUpdate'));

  };

  handleModalVisible = flag => {
    this.setState({
      modalTitle: '管理员添加',
      modalVisible: !!flag,
    });
  };

  handleClose = () => {
    this.setState({ alertVisible: false });
  };
  //数据统计
  qrCodeTj=(data)=>{
    const { dispatch} = this.props;
    dispatch(routerRedux.push('/Data/qrcode/qrCodeTj'));
  };
  timeonChange(a,b){
   this.setState({
     timeArr:b,
   })
  }
  renderSimpleForm() {
    const { form, qrcode } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="">
              {getFieldDecorator('channelName')(  <RangePicker onChange={this.timeonChange} />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <span className={styles.submitButtons}>
              <Button type="primary" htmlType="submit">
              查询
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  };

  renderAdvancedForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="查询参数">
              {getFieldDecorator('branchName')(<Input placeholder="请输入门店分店名" />)}
            </FormItem>
          </Col>
        </Row>
        <div style={{ overflow: 'hidden' }}>
          <span style={{ float: 'right', marginBottom: 24 }}>
            <Button type="primary" htmlType="submit">
              查询
            </Button>
            <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
            重置
            </Button>
            <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
            收起 <Icon type="up" />
            </a>
          </span>
        </div>
      </Form>
    );
  };

  renderForm(data) {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm(data);
  };

  render() {
    const { qrcode, loading } = this.props;
    const { selectedRows, modalVisible, alertVisible, message, type, modalTitle, selectRowData } = this.state;
    const data = qrcode.data;
    const columns = [
      {
        title: '渠道名称',
        key: 'channelName',
        dataIndex: 'channelName',
      },
      {
        title: '所属门店',
        key: 'shopName',
        dataIndex: 'shopName',
      },
      {
        title: '备注',
        dataIndex: 'note',
        key: 'note',
      },
      {
        title: '创建时间',
        dataIndex: 'updateTime',
        key: 'updateTime',
      },
      {
        title: '操作',
        render: (text, record) => (
          <Fragment>
            <a href={record.url}>下载</a>
            <Divider type="vertical" />
            <a href="javaScript:void(0)" onClick={() => this.qrCodeTj(record)}>数据</a>
            <Divider type="vertical" />
            <a href="javaScript:void(0)" onClick={() => this.update(record)}>编辑</a>
            <Divider type="vertical" />
            <a href="javaScript:void(0)" onClick={() => this.delete(record)}>删除</a>
          </Fragment>
        ),
      },
    ];
    const xs= ['3时','6时','9时','12时','15时','18时','21时','24时'];
    const offlineChartData=[];
     if(JSON.stringify(qrcode.qrcodeGetAnalysisData)!=="{}"&&qrcode.qrcodeGetAnalysisData){
       qrcode.qrcodeGetAnalysisData.timeData.map(function(item,index) {
         const obj={
           x:new Date().getTime() + 1000 * 60 * 30 * index,
           y:item,
         }
         offlineChartData.push(obj)
       })
       console.log(offlineChartData)
     }else{
       xs.map(function(item,index) {
         const obj={
           x:new Date().getTime() + 1000 * 60 * 30 * index,
           y:0,
         }
         offlineChartData.push(obj)
       })

     }




    const salesTypeDataOnline=[{x:"男",y:qrcode.qrcodeGetAnalysisData?qrcode.qrcodeGetAnalysisData.menSexCount:""},{x:"女",y:qrcode.qrcodeGetAnalysisData?qrcode.qrcodeGetAnalysisData.womenSexCount:""},{x:"未知",y:qrcode.qrcodeGetAnalysisData?qrcode.qrcodeGetAnalysisData.unKnownSexCount:""}];
    const parentMethods = {
      handleAdd: this.handleAdd,
      handleModalVisible: this.handleModalVisible,
    };
    console.log((12/13).toFixed(2))
    return (
      <PageHeaderLayout title="" showReturn={true} url="/Data/qrcode">
        {
          alertVisible ? (
              <Alert
                message={message}
                showIcon
                type={type}
                closable
                afterClose={this.handleClose
                }
              />
            ) :
            null
        }
        <Card bordered={false}>
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>
              {this.renderForm(qrcode)}
            </div>
          </div>
        </Card>
        {
          qrcode.qrcodeGetAnalysisData?<Card title="数据概况" style={{margin:"10px 0px"}}>
            <div style={{height:"120px",marginTop:"120px"}}>
              <div style={{float:"left",marginRight:"20%",paddingLeft:"10%"}}>
                <h2>累计扫码人数</h2>
                <h2 className="spanTitle" style={{marginLeft:"50px"}}>{qrcode.qrcodeGetAnalysisData?qrcode.qrcodeGetAnalysisData.scanCount:""}</h2>
              </div>
              <div style={{float:"left",marginRight:"20%"}}>
                <h4 style={{color: "#E03941",marginLeft:"50px"}}>转化率{(qrcode.qrcodeGetAnalysisData.scanCount!==0||qrcode.qrcodeGetAnalysisData.subscribeCount!==0)?(((qrcode.qrcodeGetAnalysisData.subscribeCount)/(qrcode.qrcodeGetAnalysisData.scanCount)).toFixed(2))*100:0}%</h4>
                <h4>
                  -------------------->
                </h4>
              </div>
              <div style={{float:"left"}}>
                <h2>关注人数</h2>
                <h2 className="spanTitle" style={{marginLeft:"30px"}}>{qrcode?qrcode.qrcodeGetAnalysisData.subscribeCount:""}</h2>
              </div>
            </div>
          </Card>:""
        }

        <div>
          <Card title="时间段流量" style={{width:"49.5%",float:"left"}}>
            <div style={{width:"500px"}}>
            <TimelineChart
              height={300}
              width={100}
              data={offlineChartData}
              titleMap={{ y: '客流量'}}
            />
            </div>
          </Card>
          <Card title="年龄与性别画像" style={{width:"49.5%",float:"right"}}>
            <div style={{width:"500px"}}>
              <Pie
                hasLegend
                subTitle="年龄与性别画像"
                data={salesTypeDataOnline}
                valueFormat={value => {value}}
                height={330}
                lineWidth={4}
              />
            </div>
          </Card>
        </div>
        <CollectionCreateForm
          wrappedComponentRef={this.saveFormRef}
          visible={this.state.visible}
          onCancel={this.handleCancel}
          onCreate={this.handleCreate}
          selectRowData={selectRowData}
        />
        <CreateForm {...parentMethods} modalVisible={modalVisible} modalTitle={modalTitle} />
      </PageHeaderLayout>
    );
  }
}
