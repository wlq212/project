/* eslint-disable no-unused-vars,react/destructuring-assignment,no-script-url,prefer-destructuring,no-shadow,no-case-declarations,default-case,react/no-unused-state,react/sort-comp */
import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Select,
  Icon,
  Button,
  Alert,
  Modal,
  message,
  Divider,
} from 'antd';
import StandardTable from 'components/StandardTable';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from '../../assets/css/common.less';
import { setStore,getStore} from '../../assets/js/mUtils';

const FormItem = Form.Item;
const { Option } = Select;
const getValue = obj =>
  Object.keys(obj)
    .map(key => obj[key])
    .join(',');
const CreateForm = Form.create()(props => {
  const { modalVisible, form, handleAdd, handleModalVisible, handleChange } = props;
  const okHandle = () => {
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      handleAdd(fieldsValue);
    });
  };
  return (
    <Modal
      title="账号添加"
      visible={modalVisible}
      onOk={okHandle}
      onCancel={() => handleModalVisible()}
    >
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号类型" validateStatus="success">
        {form.getFieldDecorator('roleType', {
          rules: [{ required: true, message: '请选择账号类型' }],
        })(<Select
          style={{ width: 290 }}
          placeholder="请选择账号类型"
          optionFilterProp="children"
          onChange={handleChange}
        >
          <Option value="200">管理员</Option>
          <Option value="300">普通成员</Option>
        </Select>)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="品牌名称" validateStatus="success">
        {form.getFieldDecorator('brandName', {
          rules: [{ required: true, message: '请输入品牌名称' }],
        })(<Input placeholder="请输入品牌名称" id="brandNameOne" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号" validateStatus="success">
        {form.getFieldDecorator('userName', {
          rules: [{ required: true, message: '请输入账号' }],
        })(<Input placeholder="请输入账号" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="密码">
        {form.getFieldDecorator('pwd', {
          rules: [{ required: true, message: '请输入密码' }],
        })(<Input placeholder="请输入密码" type="password" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="微信号">
        {form.getFieldDecorator('city')(<Button type="primary">关联微信</Button>)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="手机号">
        {form.getFieldDecorator('city')(<Input placeholder="请输入手机号" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="城市">
        {form.getFieldDecorator('mobile')(<Input placeholder="请输入" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="状态">
        {form.getFieldDecorator('state', {
          rules: [{ required: true, message: '请选择状态' }],
        })(<Select
          style={{ width: 290 }}
          placeholder="请选择状态"
          optionFilterProp="children"
          onChange={handleChange}
        >
          <Option value="0">停用</Option>
          <Option value="1">正常</Option>
        </Select>)}
      </FormItem>
    </Modal>
  );
});

const CollectionCreateForm = Form.create({
  mapPropsToFields(props) {
    return {
      roleType: Form.createFormField(props.selectRowData.roleType),
      brandName: Form.createFormField(props.selectRowData.brandName),
      userName: Form.createFormField(props.selectRowData.userName),
      pwd: Form.createFormField(props.selectRowData.pwd),
      city: Form.createFormField(props.selectRowData.city),
      mobile: Form.createFormField(props.selectRowData.mobile),
      state: Form.createFormField(props.selectRowData.state),
    };
  },
})(
class basekk extends React.Component {
    render() {
      const { visible, onCancel, onCreate, form } = this.props;
      return (
        <Modal
          visible={visible}
          title="更新"
          okText="更新"
          onCancel={onCancel}
          onOk={onCreate}
        >
          <Form layout="vertical">
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号类型" validateStatus="success">
              {form.getFieldDecorator('roleType', {
                rules: [{ required: true, message: '请选择账号类型' }],
              })(<Select
                style={{ width: 290 }}
                placeholder="请选择账号类型"
                optionFilterProp="children"
              >
                <Option value="200">管理员</Option>
                <Option value="300">普通成员</Option>
              </Select>)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="品牌名称" validateStatus="success">
              {form.getFieldDecorator('brandName', {
                rules: [{ required: true, message: '请输入品牌名称' }],
              })(<Input placeholder="请输入品牌名称" id="brandNameOne" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号" validateStatus="success">
              {form.getFieldDecorator('userName', {
                rules: [{ required: true, message: '请输入账号' }],
              })(<Input placeholder="请输入账号" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="密码">
              {form.getFieldDecorator('pwd', {
                rules: [{ required: true, message: '请输入密码' }],
              })(<Input placeholder="请输入密码" type="password" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="微信号">
              {form.getFieldDecorator('city')(<Button type="primary">关联微信</Button>)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="手机号">
              {form.getFieldDecorator('city')(<Input placeholder="请输入手机号" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="城市">
              {form.getFieldDecorator('mobile')(<Input placeholder="请输入" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="状态">
              {form.getFieldDecorator('state', {
                rules: [{ required: true, message: '请选择状态' }],
              })(<Select
                style={{ width: 290 }}
                placeholder="请选择状态"
                optionFilterProp="children"
              >
                <Option value="0">停用</Option>
                <Option value="1">正常</Option>
              </Select>)}
            </FormItem>
          </Form>
        </Modal>
      );
    }
  },
);


@connect(({ qrcode, loading }) => ({
  qrcode,
  loading: loading.models.qrcode,
}))
@Form.create()
export  default class TableList extends PureComponent {
  state = {
    visible: false,
    modalVisible: false,
    selectRowData: {},
    message: '',
    type: '',
    modelTitle: '添加管理员',
    alertVisible: false,
    expandForm: false,
    selectedRows: [],
    formValues: {
      pageNo:1,
      pageSize:10,
    },
  };

  handleCancel = () => {
    this.setState({ visible: false });
  };

  handleCreate = () => {
    const form = this.formRef.props.form;
    form.validateFields((err) => {
      if (err) {
        return;
      }
      form.resetFields();
      this.setState({ visible: false });
    });
  };

  saveFormRef = (formRef) => {
    this.formRef = formRef;
  };

  componentDidMount() {
    const { dispatch } = this.props;
    const params = {
      pageNo: 1,
      pageSize: 10,
    };
    dispatch({
      type: 'qrcode/fetchshop',
      payload:params,
    });
    if(getStore("formValues")){
      dispatch({
        type: 'qrcode/fetchQrcodeList',
        payload: {
          ...getStore("formValues"),
        },
      });
    }else{
      const obj = {
        pageNo: 1,
        pageSize: 10,
      };
      dispatch({
        type: 'qrcode/fetchQrcodeList',
        payload: obj,
      });
    }
  }

  handleChange = flag => {

  };

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    this.setState({
      formValues:params,
    })
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }

    dispatch({
      type: 'qrcode/fetchQrcodeList',
      payload: params,
    });
  };

  handleFormReset = () => {
    const { form,dispatch} = this.props;
    form.resetFields();
    const obj = {
      pageNo: 1,
      pageSize: 10,
    };
    dispatch({
      type: 'qrcode/fetchQrcodeList',
      payload: obj,
    });
    this.setState({
      formValues: obj,
    });
  };

  toggleForm = () => {
    const { expandForm } = this.state;
    this.setState({
      expandForm: !expandForm,
    });
  };

  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (!selectedRows) return;

    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'rule/remove',
          payload: {
            no: selectedRows.map(row => row.no).join(','),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
  };

  handleSearch = e => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = {
        ...fieldsValue,
        pageNo: 1,
        pageSize: 10,
      };
      this.setState({
        formValues: values,
      });
      dispatch({
        type: 'qrcode/fetchQrcodeList',
        payload: values,
      });
    });
  };
  handleSearchBusinessName= e => {
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      fieldsValue.poiId=e;
      const values = {
        ...fieldsValue,
        pageNo: 1,
        pageSize: 10,
      };
      this.setState({
        formValues: values,
      });
      dispatch({
        type: 'qrcode/fetchQrcodeList',
        payload: values,
      });
    });
  };

  msg;

  delete = rows => {
    const { dispatch} = this.props;
    const {formValues}=this.state;
    const confirm = Modal.confirm;
    confirm({
      title: '提示?',
      content: '确定要删除门店吗？',
      onOk() {
        const params = {
          qrCodeId: rows.qrCodeId,
        };
        dispatch({
          type: 'qrcode/deleteQrcodeShop',
          payload: params,
        }).then((result) => {
          // console.log(result);
          if (result) {
            switch (result.code) {
              case '200':
                message.success('删除成功');
                const params = {
                  pageNo: formValues.pageNo,
                  pageSize: formValues.pageSize,
                };
                dispatch({
                  type: 'qrcode/fetchshop',
                  payload: '',
                });

                dispatch({
                  type: 'qrcode/fetchQrcodeList',
                  payload: params,
                });
                break;
              case '500':
                message.error(result.msg || '删除失败');
                break;
            }
          }
        }, (result) => {

        });

      },
      onCancel() {
      },
    });
  };

  add = () => {
    const { dispatch} = this.props;
    dispatch(routerRedux.push('/Data/qrcode/qrcodeAdd'));
  };

  update = data => {
    const { dispatch} = this.props;
    dispatch({
      type: 'qrcode/updateParams',
      payload: data,
    });
    dispatch(routerRedux.push('/Data/qrcode/qrcodeUpdate'));
    setStore("formValues",this.state.formValues)

  };

  handleModalVisible = flag => {
    this.setState({
      modalTitle: '管理员添加',
      modalVisible: !!flag,
    });
  };

  handleClose = () => {
    this.setState({ alertVisible: false });
  };

  // 数据统计
  qrCodeTj=(data)=>{
    const { dispatch} = this.props;
    dispatch(routerRedux.push(`/Data/qrcode/qrCodeTj?qrCodeId=${data.qrCodeId}`));
    setStore("formValues",this.state.formValues);
  };

  renderSimpleForm() {
    const { form, qrcode } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={4} sm={24}>
            <FormItem>
              {getFieldDecorator('poiId')(
                <Select
                  showSearch
                  style={{ width: 150 }}
                  onChange={this.handleSearchBusinessName}
                  placeholder="门店"
                  optionFilterProp="children"
                >
                  <Option value="">选择门店</Option>
                  {
                    qrcode.data.saveAddresult?qrcode.data.saveAddresult.map((item) => {
                      return (
                        <Option value={item.sId}>{item.businessName}</Option>
                      );
                    }):""
                  }
                </Select>)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="查询参数">
              {getFieldDecorator('channelName')(<Input placeholder="请输入要搜索的渠道名" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <span className={styles.submitButtons}>
              <Button type="primary" htmlType="submit">
              查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
            重置
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  };

  renderAdvancedForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="查询参数">
              {getFieldDecorator('branchName')(<Input placeholder="请输入门店分店名" />)}
            </FormItem>
          </Col>
        </Row>
        <div style={{ overflow: 'hidden' }}>
          <span style={{ float: 'right', marginBottom: 24 }}>
            <Button type="primary" htmlType="submit">
              查询
            </Button>
            <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
            重置
            </Button>
            <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
            收起 <Icon type="up" />
            </a>
          </span>
        </div>
      </Form>
    );
  };

  renderForm(data) {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm(data);
  };

  render() {
    const { qrcode, loading } = this.props;
    const { selectedRows, modalVisible, alertVisible, message, type, modalTitle, selectRowData } = this.state;
    qrcode.data.pagination.current=this.state.formValues.pageNo;
    const data = qrcode.data;
    const columns = [
      {
        title: '渠道名称',
        key: 'channelName',
        dataIndex: 'channelName',
      },
      {
        title: '所属门店',
        key: 'shopName',
        dataIndex: 'shopName',
      },
      {
        title: '备注',
        dataIndex: 'note',
        key: 'note',
      },
      {
        title: '创建时间',
        dataIndex: 'updateTime',
        key: 'updateTime',
      },
      {
        title: '操作',
        align:"right",
        fixed:"right",
        render: (text, record) => (
          <Fragment>
            <a href={record.url}>下载</a>
            <Divider type="vertical" />
            <a href="javaScript:void(0)" onClick={() => this.qrCodeTj(record)}>数据</a>
            <Divider type="vertical" />
            <a href="javaScript:void(0)" onClick={() => this.update(record)}>编辑</a>
            <Divider type="vertical" />
            <a href="javaScript:void(0)" onClick={() => this.delete(record)}>删除</a>
          </Fragment>
        ),
      },
    ];
    const parentMethods = {
      handleAdd: this.handleAdd,
      handleModalVisible: this.handleModalVisible,
    };
    return (
      <PageHeaderLayout title="">
        {
          alertVisible ? (
            <Alert
              message={message}
              showIcon
              type={type}
              closable
              afterClose={this.handleClose
                }
            />
            ) :
            null
        }
        <Card bordered={false}>
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>
              {this.renderForm(qrcode)}
              <Button className={styles.buttonAddClass} type="primary" onClick={() => this.add()}>
                新建二维码
              </Button>
            </div>
            <div className={styles.tableListOperator}>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={data}
              columns={columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
            />
          </div>
        </Card>
        <CollectionCreateForm
          wrappedComponentRef={this.saveFormRef}
          visible={this.state.visible}
          onCancel={this.handleCancel}
          onCreate={this.handleCreate}
          selectRowData={selectRowData}
        />
        <CreateForm {...parentMethods} modalVisible={modalVisible} modalTitle={modalTitle} />
      </PageHeaderLayout>
    );
  }
}
