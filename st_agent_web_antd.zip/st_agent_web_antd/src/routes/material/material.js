/* eslint-disable default-case,react/no-unused-state,prefer-destructuring,no-unused-vars,eqeqeq,no-shadow,react/sort-comp,no-underscore-dangle,react/jsx-equals-spacing,react/jsx-indent,react/jsx-props-no-multi-spaces,react/destructuring-assignment */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import {
  Card,
  Pagination,
  Form,
  Icon,
  Button,
  Tabs,
  List,
  Alert,
  Modal,
  message,
  Upload,
} from 'antd';
import moment from 'moment';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from '../../assets/css/common.less';
import { getStore } from '../../assets/js/mUtils';
const TabPane = Tabs.TabPane;
@connect(({ material, loading }) => ({
  material,
  loading: loading.effects['material/materialDelete'] || loading.effects['material/fetch'] || loading.effects['material/fetchCount'] || loading.effects['material/fetchnews'] || loading.effects['material/fetchnewsCount'],
}))
@Form.create()
export default class TableList extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      modalVisible: false,
      loadingImage: false,
      selectRowData: {},
      previewVisible: false,
      IconVisiable: false,
      previewImage: '',
      pageNo: 1,
      fileList: [
        {
          uid: -1,
          name: 'xxx.png',
          status: 'done',
          url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
        },
      ],
      message: '',
      type: 'image',
      expandForm: false,
      selectedRows: [],
      formValues: {
        pageNo: 1,
        pageSize: 10,
      },
    };
    this.mouseOverState = this.mouseOverState.bind(this);
    this.mouseLeaveState = this.mouseLeaveState.bind(this);
    this.deleteImage = this.deleteImage.bind(this);
    this.tabSwitch = this.tabSwitch.bind(this);
    this.syncMater=this.syncMater.bind(this);
  }

  deleteImage(e) {
    e.preventDefault();
    const { dispatch } = this.props;
    const confirm = Modal.confirm;
    const mediaId = e.target.id;
    const that=this;
    confirm({
      title: '提示?',
      content: '确定删除该素材吗？',
      onOk() {
        if (mediaId) {
          dispatch({
            type: 'material/materialDelete',
            payload: { mediaId },
          }).then((result) => {
            if (result) {
              switch (result.code) {
                case '200':
                  that.initData();
                  message.success('删除成功');
                  break;
                case '500':
                  message.error(result.msg);
                  break;
              }
            }
          });
        }
      },
      onCancel() {
      },
    });
  }

  mouseOverState(e) {
    e.preventDefault();
    this.setState({
      IconVisiable: e.target.id,
    });
  }

  mouseLeaveState(e) {
    e.preventDefault();
    this.setState({
      IconVisiable: '',
    });
  }

  componentDidMount() {
    this.initData();
  }

  initData() {
    const { dispatch } = this.props;
    const { pageNo } = this.state;
    if(this.state.type=="image"){
      const params = {
        pageNo,
        pageSize: 36,
        type: 'image',
      };

      dispatch({
        type: 'material/fetch',
        payload: params,
      });
    }else{
      const params = {
        pageNo,
        pageSize: 36,
        type: 'news',
      };
      dispatch({
        type: 'material/fetch',
        payload: params,
      });
    }
  }

  changePage = e => {
    const { dispatch } = this.props;
    this.setState({
      pageNo: e,
    });
    const params = {
      pageNo: e,
      pageSize: 36,
      type: 'image',
    };
    dispatch({
      type: 'material/fetch',
      payload: params,
    });
  };

  changePageNews(data) {
    this._data = data;
    const { dispatch } = this.props;
    const { pageNo } = this.state;
    const params = {
      pageNo,
      pageSize: 18,
      type: 'news',
    };
    dispatch({
      type: 'material/fetchnews',
      payload: params,
    });
  };

// tab切换获取数据
  tabSwitch(e) {
    const { dispatch } = this.props;
    if (String(e) === '1') {
      const paramsOne = {
        pageNo: 1,
        pageSize: 36,
        type: 'image',
      };
      this.setState({
        pageNo: 1,
        pageSize: 36,
        type: 'image',
      });
      dispatch({
        type: 'material/fetch',
        payload: paramsOne,
      });
    }
    if (String(e) === '2') {
      const paramsOne = {
        pageNo: 1,
        pageSize: 18,
        type: 'news',
      };
      this.setState({
        pageNo: 1,
        pageSize: 36,
        type: 'news',
      });
      dispatch({
        type: 'material/fetchnews',
        payload: paramsOne,
      });
    }
  }

  showTotal(total, range){
     return `共${total}条`
  }

  syncMater(data){
    const { dispatch } = this.props;
    const that=this;
    const confirm = Modal.confirm;
    confirm({
      title: '提示?',
      content: '确定同步素材吗？',
      onOk() {
          dispatch({
            type: 'material/materialSyncMaterialButton',
            payload: { type:data },
          }).then((result) => {
            if (result) {
              switch (result.code) {
                case '200':
                  that.initData();
                  message.success('同步成功');
                  break;
                case '500':
                  message.error(result.msg);
                  break;
              }
            }
          });
      },
      onCancel() {
      },
    });
  };

  render() {
    const { material, loading } = this.props;
    const that=this;
    const props = {
      name: 'file',
      action: `/api/admin/material/addImg?token=${getStore('userInfo') ? JSON.parse(getStore('userInfo')).token : ''}`,
      data: {
        type: 3,
        token: `${getStore('userInfo') ? JSON.parse(getStore('userInfo')).token : ''}`,
      },
      showUploadList: false,
      headers: {
        authorization: 'authorization-text',
      },
      onChange(info) {
        if (info.file.status !== 'uploading') {
          setData(true)
        }
        if (info.file.status === 'done') {
          setData(false)
          that.initData();
          message.success(`${info.file.name} 上传成功`);
        } else if (info.file.status === 'error') {
          message.error(`${info.file.name} file upload failed.`);
        }
      },
    };
    const setData=data=>{
      this.setState({
        loadingUpload: data,
      });
    };
    const operations = (
      <div>
       <Upload {...props}>
         <Button>
           <Icon type={this.state.loadingUpload?"loading":"upload"} /> 点击上传
         </Button>
       </Upload>
        <Button type="primary" onClick={()=>{this.syncMater("image")}} loading={loading} style={{marginLeft:"10px"}}>
          同步图片
        </Button>
      </div>
    );
    const operationsSync = (
      <Button type="primary" onClick={()=>{this.syncMater("news")}} loading={loading}>
        同步图文
      </Button>
    );
    const {
      alertVisible,
      message,
      type,
    } = this.state;
    const dataImag = material.data.list;
    const datanews = material.dataOne.list;
    const mouseOverState = this.mouseOverState;
    const mouseLeaveState = this.mouseLeaveState;
    const IconVisiable = this.state.IconVisiable;
    const deleteImage = this.deleteImage;
    return (
      <PageHeaderLayout title="">
        {alertVisible ? (
          <Alert message={message} showIcon type={type} closable afterClose={this.handleClose}/>
        ) : null}
        <Card bordered={false}>
          <Tabs defaultActiveKey="1" tabBarExtraContent={this.state.type=="image"?operations:operationsSync} onChange={this.tabSwitch}>
            <TabPane tab="图片" key="1">
              <List loading={loading}>
                <div>
                  <ul style={{
                    display: 'flex',
                    listStyle: 'none',
                    flexWrap: 'wrap',
                    justifyContent: 'space-around',
                    padding: '0px',
                  }}>
                    {
                      dataImag ? dataImag.map((item) => {
                        return (
                          <li
                            onMouseOver={mouseOverState}
                            onMouseLeave={mouseLeaveState}
                            id={item.mediaId}
                            style={{ margin: '5px', marginBottom: '10px' }}
                          >
                            <div style={{ position: 'relative', width: '50%', height: '10%' }}>
                              <a href={item.url} target="_blank" rel="noopener noreferrer">
                                <img src={`${item.localUrl}`} style={{ border: '1px solid #ddd' }} id={item.mediaId} alt=""
                                     width="160px" height="140px"/>
                                <div className={styles.imagedownOverflow} style={{ marginTop: '5px' }}>{item.title}</div>
                              </a>
                              {
                                IconVisiable === item.mediaId ? (
                                  <Icon
                                    id={item.mediaId}
                                    type="delete"
                                    className={styles.IconDeleteIcon}
                                    style={{zIndex:"111"}}
                                    onClick={deleteImage}
                                  />
                                ) : (
                                  ''
                                )}
                            </div>
                          </li>
                        );
                      }) : ''
                    }
                  </ul>
                </div>
                <div style={{ marginTop: '30px', float: 'right' }}>
                  <Pagination current={this.state.pageNo} defaultPageSize={36} defaultCurrent={this.state.pageNo}
                              total={material.data.pagination.total} style={{ float: 'right' }}
                              onChange={this.changePage}  showTotal={this.showTotal}/>
                </div>
              </List>
            </TabPane>
            <TabPane tab="图文" key="2">
              <List
                itemLayout="vertical"
                size="small"
                loading={loading}
                pagination={{
                  onChange: page => {
                    this.changePageNews(page);
                  },
                  showTotal:(total, range)=>{
                    return `共${total}条`
                  },
                  pageSize: 18,
                }}
                dataSource={datanews || ''}
                renderItem={(item,index)=> (
                  item ? (
                    <List.Item
                      key={index}
                      style={{ overflow: 'hidden', paddingBottom: '10px' }}
                      actions={[]}
                      extra={<img width={130} alt="logo"
                                  src={item.localUrl}
                                  style={{ border: '1px solid #ddd'}}/>}
                    >
                      <List.Item.Meta
                        // avatar={<Avatar src={item.content.news_item[0].thumb_url} />}
                        title={
                          <a href={item.url} target="_blank">
                            {item.title}
                          </a>
                        }
                        description={item.digest}
                      />
                      <div style={{marginTop:"60px"}}>发表时间：{item.updateTime }&nbsp;&nbsp;&nbsp;&nbsp;</div>
                    </List.Item>
                  ) : ''

                )}
              />
            </TabPane>
          </Tabs>
        </Card>
      </PageHeaderLayout>
    );
  }
}
