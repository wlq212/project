/* eslint-disable no-unused-vars,default-case,react/self-closing-comp,lines-between-class-members,no-plusplus,array-callback-return,eqeqeq,no-param-reassign,object-shorthand,prefer-arrow-callback,prefer-destructuring */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Form,
  Input,
  Select,
  Modal,
  Button,
  Card,
  message,
  Popover,
  Badge,
} from 'antd';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import { getStore } from '../../assets/js/mUtils';

const miniAuthList = [
  { name: '帐号管理权限（小程序）', value: 17 },
  { name: '开发管理与数据分析权限（小程序）', value: 18 },
  { name: '客服消息管理权限（小程序）', value: 19 },
  { name: '微信登录权限（小程序）', value: 20 },
  { name: '数据分析权限（小程序）', value: 21 },
  { name: '开放平台帐号管理权限（小程序）', value: 25 },
];
const authList = [
  { name: '消息管理权限', value: 1 },
  { name: '用户管理权限', value: 2 },
  { name: '帐号服务权限', value: 3 },
  { name: '网页服务权限', value: 4 },
  { name: '微信小店权限', value: 5 },
  { name: '微信多客服权限', value: 6 },
  { name: '群发与通知权限', value: 7 },
  { name: '微信卡券权限', value: 8 },
  { name: '微信扫一扫权限', value: 9 },
  { name: '微信连WIFI权限', value: 10 },
  { name: '素材管理权限', value: 11 },
  { name: '微信摇周边权限', value: 12 },
  { name: '微信门店权限', value: 13 },
  { name: '微信支付权限', value: 14 },
  { name: '自定义菜单权限', value: 15 },
  { name: '获取认证状态及信息', value: 16 },
  { name: '城市服务接口权限', value: 22 },
  { name: '广告管理权限', value: 23 },
  { name: '开放平台帐号管理权限', value: 24 },
  { name: '微信电子发票权限', value: 26 },
];
const FormItem = Form.Item;
const { Option } = Select;
const { confirm } = Modal;
@connect(({ auth, loading }) => ({
  auth,
  loading: loading.models.auth,
}))
@Form.create()
export default class BasicForms extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      miniDetail:[],
    };
    this.wxgetAuthParamsButton = this.wxgetAuthParamsButton.bind(this);
    this.wxgetAuthDeatail = this.wxgetAuthDeatail.bind(this);
    this.unbundling=this.unbundling.bind(this);
  };

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'auth/wxGetAuthInfoButton0',
      payload: { type: '0' },
    });
    dispatch({
      type: 'auth/wxGetAuthInfoButton1',
      payload: { type: '1' },
    });
    dispatch({
      type: 'auth/wxGetNewestVersionButton2',
      payload: { type: '1' },
    });
  };

  cancel = e => {
    e.preventDefault();
    const { dispatch } = this.props;
    dispatch(routerRedux.push('/setting/manage'));
  };

  hideModal = () => {
    this.setState({
      visible: false,
    });
  };

  handleSubmit = e => {
    e.preventDefault();
    const { form, dispatch } = this.props;
    form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        dispatch({
          type: 'manage/add',
          payload: values,
          callback: () => {
          },
        }).then(
          (result) => {
            if (result) {
              switch (result.code) {
                case '200':
                  message.success('添加成功');
                  dispatch(routerRedux.push('/setting/manage'));
                  break;
                case '500':
                  message.success(result.msg);
                  break;
              }
            }
          },
          (result) => {
          },
        );
      }
    });
  };

  /**
   * 撤回审核
   */
  clickUndocodeaudit = () =>{
    const { auth,dispatch } = this.props;
    confirm({
      title: '提示?',
      content: '确定要撤回审核？',
      onOk() {
        dispatch({
          type: 'auth/wxUndocodeaudit',
          payload: {id:auth.wxGetNewestVersion.auditid},
        }).then(res => {
          if(res.code === "200"){
            message.success("撤消成功");
            this.hideModal();
          }else {
            message.error(res.msg);
          }
        }).catch(err => {
          message.error(err.msg);
        });
      },
    })
  };

  /**
   * 重新提交审核
   */
  clickAgainReleaseVsersion = () =>{
    const { auth:{wxGetNewestVersion},dispatch } = this.props;
    confirm({
      title: '提示?',
      content: '确定要重新提交审核？',
      onOk() {
        dispatch({
          type: 'auth/wxAgainReleaseVsersion',
          payload: {templateId:wxGetNewestVersion.templateId,user_version:wxGetNewestVersion.versionCode,user_desc:wxGetNewestVersion.vdesc},
        }).then(res => {
          if(res.code === "200"){
            message.success("提交成功");
            this.hideModal();
          }else {
            message.error(res.msg);
          }
        }).catch(err => {
          message.error(err.msg);
        });
      },
    });

  };

  // 查看详情
  wxgetAuthDeatail(userName) {
    const {dispatch} = this.props;
    dispatch({
      type:"auth/wxamplinkgetFetch",
      payload:{},
    }).then(() => {
      const {auth:{wxamplinkget}} = this.props;
      let miniDetail = {};
      wxamplinkget.map(item => {
        if(item.username === userName){
          miniDetail = item;
        }
      });
      this.setState({
        visible: true,
        miniDetail,
      });
    });

  };

  // 解除关联
  unbundling(){
    const { dispatch,auth} = this.props;
    confirm({
      title:"解除关联",
      content: '确定要解除关联吗',
      onOk:function() {
        dispatch({
          type: 'auth/wxampunlinkButton',
          payload: {miniAppId:auth.miniProgressInfo.authorizer_info.userName},
        }).then(function(result) {
          if (result) {
            switch (result.code) {
              case '200':
                message.success('解除关联成功');
                break;
              case '500':
                message.success(result.msg);
                break;
            }
          }
        });
      },
      onCancel:function() {

      },
    })
  }

  // 授权 公众号授权1为公众号授权，2为小程序授权
  wxgetAuthParamsButton(data) {
    const { dispatch } = this.props;
    dispatch({
      type: 'auth/wxgetAuthParamsButton',
      payload: {},
    }).then(function(result) {
      if (result) {
        switch (result.code) {
          case '200':
            window.location.href =(result.obj)+data;
            break;
          case '500':
            message.success(result.msg);
            break;
        }
      }
    });
  }

  render() {
    const { auth, form ,loading} = this.props;
    const {wxGetNewestVersion} = auth;
    const {visible,miniDetail} = this.state;
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 17 },
        md: { span: 15 },
      },
    };
    const isInArray = value => {
      const WxamplinkgetInfoArray = auth.miniProgressInfo.func_info.split(',');
      for (let i = 0; i < WxamplinkgetInfoArray.length; i++) {
        if (value == WxamplinkgetInfoArray[i]) {
          return true;
        }
      }
      return false;
    };
    if (auth.miniProgressInfo) {
      miniAuthList.map((item) => {
        if (isInArray(item.value)) {
          item.checked = true;
        }
      });
    }

    const isInArray1 = value => {
      const WxamplinkgetInfoArray = auth.wxAccountInfo.func_info.split(',');
      for (let i = 0; i < WxamplinkgetInfoArray.length; i++) {
        if (value == WxamplinkgetInfoArray[i]) {
          return true;
        }
      }
      return false;
    };
    if (auth.wxAccountInfo) {
      authList.map((item) => {
        if (isInArray1(item.value)) {
          item.checked = true;
        }
      });
    }
    return (
      <PageHeaderLayout>
        <Card bordered={false} title="公众号" style={{ marginTop: '20px' }}>
          <div style={{ width: '100%' }}>
            {
              getStore('userInfo') ? JSON.parse(getStore('userInfo')).user.hasAuth !== 1 ? (
                <div style={{ margin: '20px auto', width: '290px', textAlign: 'center' }}>
                  <div style={{ margin: '20px' }}>尚未授权，请点击授权按钮进行授权</div>
                  <Button loading={loading} type="primary" onClick={()=>{this.wxgetAuthParamsButton("1")}}>立即授权</Button>
                </div>
              ) : (
                auth.wxAccountInfo ? (
                  <div>
                    <div style={{ display: 'flex' }}>
                      <dl>
                        <dd>
                          <div style={{ textAlign: 'center' }}>
                            <img
                              alt=""
                              src={auth.wxAccountInfo.authorizer_info.qrcodeUrl}
                              style={{ height: '113px', width: '113px', border: '1px solid #ddd' }}
                            />
                            <div>微信扫一扫进入</div>
                          </div>
                        </dd>
                      </dl>
                      <dl style={{ marginLeft: '60px' }}>

                        <dd>公众号名称:<span>{auth.wxAccountInfo.authorizer_info.nickName}</span></dd>
                        <dd>微信号:<span>{auth.wxAccountInfo.authorizer_info.alias}</span></dd>
                        <dd>appId:<span>{auth.wxAccountInfo.authorizer_info.appId}</span></dd>
                        <dd>原始ID:<span>{auth.wxAccountInfo.authorizer_info.userName}</span></dd>
                        <dd>认证类别:
                          <span>
                            {auth.wxAccountInfo.authorizer_info.verifyType === '-1' ? '未认证' : auth.wxAccountInfo.authorizer_info.verifyType === '0' ? '微信认证' : auth.wxAccountInfo.authorizer_info.verifyType === '1' ? '新浪微博认证' : auth.wxAccountInfo.authorizer_info.verifyType === '2' ? '腾讯微博认证' : auth.wxAccountInfo.authorizer_info.verifyType === '3' ? '已资质认证通过但未通过名称认证' : auth.wxAccountInfo.authorizer_info.verifyType === '4' ? '已资质认证通过，还未通过名称认证' : '已资质认证通过，还未通过名称认证，但通过了腾讯微博认证'}
                            {auth.wxAccountInfo.authorizer_info.serviceType === '0' ? '订阅号' : auth.wxAccountInfo.authorizer_info.serviceType === '1' ? '有历史账号升级后的订阅号' : '服务号'}
                          </span>
                        </dd>
                        <dd><a style={{ color: '#59A430' }} onClick={()=>{this.wxgetAuthParamsButton("1")}}>重新授权</a></dd>
                      </dl>
                    </div>
                  </div>
                ) : ''

              ) : ''
            }
          </div>
          <div style={{ width: '100%', borderTop: '.08333333rem dashed #ddd', paddingTop: '10px' }}>
            {/* <div style={{ color: '#333333', fontSize: '13px', fontWeight: 'bloder', marginBottom: '10px' }}>授权说明：</div> */}
            {/* <div style={{color:"#999",fontSize:"12px"}}>1、为保证所有功能的正常使用，授权时请保持默认选择，把权限统一授权给食探</div> */}
            <dl style={{ overFlow: 'hidden' }}>
              <dt>已授权权限：</dt>
              <dd style={{
                margin: '10px',
                marginLeft: '0px',
                marginTop: '0px',
                overFlow: 'hidden',
              }}
              >
                {
                  authList.map((item,index) => {
                    if (item.checked) {
                      return (
                        <span key={item.value} style={{display:"inline-block"}}>
                          <span style={{color:"#999",fontSize:"12px"}}>{item.name}</span>
                          <span className="iconfont icon-yes" style={{ color: '#40a9ff',fontSize:"12px",marginRight:20 }}></span>
                        </span>
                      );
                    } else {
                      return (
                        <span key={item.value} style={{display:"inline-block"}}>
                          <span style={{color:"#999",fontSize:"12px"}}>{item.name}</span>
                          <span className="iconfont icon-no" style={{ color: 'red',fontSize:"12px",marginRight:20 }}></span>
                        </span>
                      );
                    }
                  })
                }
              </dd>
            </dl>
          </div>
        </Card>
        <Card bordered={false} title="小程序" style={{ marginTop: '20px' }}>
          <div style={{ width: '100%' }}>
            {
              getStore('userInfo') ? JSON.parse(getStore('userInfo')).user.hasMiniAuth !== 1 ? (
                <div style={{ margin: '20px auto', width: '290px', textAlign: 'center' }}>
                  <div style={{ margin: '20px' }}>尚未授权，请点击授权按钮进行授权</div>
                  <Button loading={loading} type="primary" onClick={()=>{this.wxgetAuthParamsButton("2")}}>立即授权</Button>
                </div>
              ) : (
                auth.miniProgressInfo ? (
                  <div>
                    <div style={{ display: 'flex' }}>
                      <dl>
                        <dd>
                          <div style={{ textAlign: 'center' }}>
                            <img
                              alt=""
                              src={auth.miniProgressInfo.authorizer_info.qrcodeUrl}
                              style={{ height: '113px', width: '113px', border: '1px solid #ddd' }}
                            />
                            <div>微信扫一扫进入</div>
                          </div>
                        </dd>
                      </dl>
                      <dl style={{ marginLeft: '60px' }}>

                        <dd>小程序名称:<span>{auth.miniProgressInfo.authorizer_info.nickName}</span></dd>
                        <dd>微信号:<span>{auth.miniProgressInfo.authorizer_info.alias}</span></dd>
                        <dd>appId:<span>{auth.miniProgressInfo.authorizer_info.appId}</span></dd>
                        <dd>原始ID:<span>{auth.miniProgressInfo.authorizer_info.userName}</span></dd>
                        <dd>认证类别:
                          <span>
                            {auth.miniProgressInfo.authorizer_info.verifyType === '-1' ? '未认证' : auth.miniProgressInfo.authorizer_info.verifyType === '0' ? '微信认证' : auth.miniProgressInfo.authorizer_info.verifyType === '1' ? '新浪微博认证' : auth.miniProgressInfo.authorizer_info.verifyType === '2' ? '腾讯微博认证' : auth.miniProgressInfo.authorizer_info.verifyType === '3' ? '已资质认证通过但未通过名称认证' : auth.miniProgressInfo.authorizer_info.verifyType === '4' ? '已资质认证通过，还未通过名称认证' : '已资质认证通过，还未通过名称认证，但通过了腾讯微博认证'}
                            {auth.miniProgressInfo.authorizer_info.serviceType === '0' ? '订阅号' : auth.miniProgressInfo.authorizer_info.serviceType === '1' ? '有历史账号升级后的订阅号' : '服务号'}
                          </span>
                        </dd>
                        <dd><a style={{ color: '#59A430' }} onClick={()=>{this.wxgetAuthParamsButton("2")}}>重新授权</a>
                          <a style={{ color: '#59A430', marginLeft: '20px' }} onClick={() => this.wxgetAuthDeatail(auth.miniProgressInfo.authorizer_info.userName)}>详情</a>
                        </dd>
                      </dl>

                    </div>
                  </div>
                ) : ''

              ) : ''
            }
          </div>
          <div style={{ width: '100%', borderTop: '.08333333rem dashed #ddd', paddingTop: '10px' }}>
            {/* <div style={{ color: '#333333', fontSize: '13px', fontWeight: 'bloder', marginBottom: '10px' }}>授权说明：</div> */}
            {/* <div style={{color:"#999",fontSize:"12px"}}>1、为保证所有功能的正常使用，授权时请保持默认选择，把权限统一授权给食探</div> */}
            <dl style={{ overFlow: 'hidden' }}>
              <dt>已授权权限：</dt>
              <dd style={{
                margin: '10px',
                marginLeft: '0px',
                marginTop: '0px',
              }}
              >
                {
                  miniAuthList.map((item,index) => {
                    if (item.checked) {
                      return (
                        <span key={item.value} style={{display:"inline-block"}}>
                          <span style={{color:"#999",fontSize:"12px"}}>{item.name}</span>
                          <span className="iconfont icon-yes" style={{ color: '#40a9ff',fontSize:"12px",marginRight:20 }}></span>
                        </span>
                      );
                    } else {
                      return (
                        <span key={item.value} style={{display:"inline-block"}}>
                          <span style={{color:"#999",fontSize:"12px"}}>{item.name}</span>
                          <span className="iconfont icon-no" style={{ color: 'red',fontSize:"12px",marginRight:20 }}></span>
                        </span>
                      );
                    }
                  })
                }
              </dd>
            </dl>
          </div>
        </Card>
        <Modal
          title="小程序详情"
          visible={visible}
          onCancel={this.hideModal}
          footer={null}
        >
          {
            miniDetail ? (
              <div key={miniDetail.username}>
                <FormItem
                  {...formItemLayout}
                  label="小程序"
                >
                  {miniDetail.nickname}
                </FormItem>
                <FormItem
                  {...formItemLayout}
                  label="原始ID"
                >
                  {miniDetail.username}
                </FormItem>
                <FormItem
                  {...formItemLayout}
                  label="登录邮箱"
                >
                  {miniDetail.email?miniDetail.email:"--"}
                </FormItem>
                <FormItem
                  {...formItemLayout}
                  label="状态"
                >{miniDetail.status === 1 ? '已关联' : (miniDetail.status === 2 ? "等待小程序管理员确认中" :(miniDetail.status === 3 ? "小程序管理员拒绝关联" : "等到公众号管理员确认中"))}
                  <a onClick={this.unbundling} style={{marginLeft:"20px"}}>{miniDetail.status === 1? '解除关联' : ''}</a>
                </FormItem>
                {
                  miniDetail.func_infos?miniDetail.func_infos.map((obj) => (
                    <FormItem
                      key={obj.id}
                      {...formItemLayout}
                      label={obj.name}
                    >
                      {obj.status === 0 ? '未开通' : '已开通'}
                    </FormItem>
                  )):""
                }
                <FormItem
                  {...formItemLayout}
                  label="当前版本"
                >
                  {wxGetNewestVersion != null ? <div><span style={{ marginRight: 20 }}>{wxGetNewestVersion.versionCode}</span>{(wxGetNewestVersion.status === 1 ?  <Badge dot style={{right:-6}}><Popover content={wxGetNewestVersion.reason} title="失败原因" trigger="hover">审核失败 </Popover> </Badge> : (wxGetNewestVersion.status === 2 ? '审核中' : ''))}{wxGetNewestVersion.status === 2 ? <a onClick={this.clickUndocodeaudit} style={{ marginLeft: 20 }}>撤回审核</a> : (wxGetNewestVersion.status === 1 ? <a onClick={this.clickAgainReleaseVsersion} style={{ marginLeft: 20 }}>重新提交审核</a> : '')}</div> : '--'}
                </FormItem>

              </div>
) : <div />
          }
        </Modal>
      </PageHeaderLayout>
    );
  }
}
