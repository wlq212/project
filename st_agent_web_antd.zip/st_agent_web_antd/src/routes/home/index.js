/* eslint-disable no-unused-vars,react/jsx-boolean-value,no-useless-constructor */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import {
  Form,
  } from 'antd';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
@connect(({home, loading }) => ({
  home,
  loading: loading.models.home,
}))
@Form.create()
export  default class BasicForms extends PureComponent {
  constructor(props){
    super(props)


  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'home/wxGetAuthInfoButton0',
      payload: { type: '0' },
    });
  };

  render() {
    return (
      <PageHeaderLayout />
    );
  }
}
