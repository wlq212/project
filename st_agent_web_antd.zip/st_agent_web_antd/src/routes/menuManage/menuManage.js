/* eslint-disable no-shadow */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { isUndefined } from 'lodash';
import {
  Tree ,
  Card,
  Modal,
  Form,
  Input,
  Button,
  Radio,
  message} from 'antd';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';

const {TreeNode} = Tree;
const FormItem = Form.Item;
const RadioGroup = Radio.Group;

@connect(({ menuManage, loading }) => ({
  menuManage,
  loading: loading.models.menuManage,
}))
@Form.create()
export default class MenuManage extends PureComponent{

  constructor(props) {
    super(props);
    this.state = {
      treeData:[],
      defaultExpandAll:true,
      isShowModal:false,// 是否显示模态框
      modalTitle:"新增菜单",
      isMenuSelected:false,// 菜单是否被选中
      isAdd:false,// 是否是新增
      node:{},
    };
  }

  componentDidMount() {
    this.getMenuList();
  }

  /**
   * 同级菜单拖拽排序
   * @param info
   */
  onDrop = (info) => {
    const {dispatch} = this.props;
    const dragPos = info.dragNode.props.pos.split('-');
    const dropPos = info.node.props.pos.split('-');
    if(dragPos.length !== dropPos.length || dragPos[dragPos.length - 2] !== dropPos[dropPos.length - 2]){
      message.error("只能拖拽更改同级菜单");
      return;
    }

    const {treeData} =  this.state;
    const parentNode = this.getParentMenuItem(info.dragNode);
    const menuList = [];
    if(parentNode == null){
      const item = treeData[dragPos[dragPos.length - 1]];
      treeData.splice(dragPos[dragPos.length - 1],1);
      treeData.splice(dropPos[dropPos.length - 1],0,item);
      for(let i =0;i<treeData.length;i+=1){
        const o = treeData[i];
        o.sortNo = i;
        o.children = null;
        menuList.push(o);
      }
    }else{
      const item = parentNode.children[dragPos[dragPos.length - 1]];
      parentNode.children.splice(dragPos[dragPos.length - 1],1);
      parentNode.children.splice(dropPos[dropPos.length - 1],0,item);
      for(let i =0;i<parentNode.children.length;i+=1){
        const o = parentNode.children[i];
        o.sortNo = i;
        o.children = null;
        menuList.push(o);
      }
    }
    dispatch({
      type:"menuManage/menuListSaveFetch",
      payload: {menuList},
    }).then(result => {
      if(result.code === "200"){
        this.setState({isShowModal:false});
        // 刷新列表
        this.getMenuList();
      }else {
        message.error(result.msg);
      }
    })

  };

  /**
   * 右键进行菜单编辑
   * @param event
   * @param node
   */
  onRightClick = ({node}) => {
    const {dispatch}=this.props;
    this.setState({isAdd:false,isShowModal:true,modalTitle:"编辑/删除菜单",node});
    dispatch({
      type:"menuManage/changeState",
      payload:"",
    })
  };

  /**
   * 选中菜单
   */
  onClickMenu = (selectedKeys,{node}) => {
    const {selected} = node.props;
    if(!selected){
      this.setState({modalTitle:"新增菜单",node,isMenuSelected:true});
    }else{
      this.setState({modalTitle:"新增菜单",node,isMenuSelected:false});
    }
  };

  /**
   * 获取菜单列表
   */
  getMenuList(){
    const { dispatch } = this.props;
    dispatch({
      type:'menuManage/fetchMenuList',
      payload:{},
    }).then(() => {
      const {menuManage:{menuList}} = this.props;
      if(menuList.length > 0){
        this.setState({treeData:menuList});
      }else{
        this.setState({treeData:[]});
      }
    })
  }

  /**
   * 获取点击树形菜单的节点数据
   * @param node
   * @returns {*}
   */
  getMenuItem(node){
    const {treeData} =  this.state;
    if(isUndefined(node.props)){
      return {menuId:null,parentMenuId:null, name:null,icon:null,path:null, sortNo:treeData.length,state:1};
    }
    const posArr = node.props.pos.split("-");
    let currMenu = treeData[posArr[1]];
    let index = 2;
    while(index < posArr.length){
      currMenu = currMenu.children[posArr[index]];
      index += 1;
    }
    return currMenu;
  };

  /**
   * 获取点击树形菜单的父节点数据
   * @param node
   * @returns {*}
   */
  getParentMenuItem(node){
    const posArr = node.props.pos.split("-");
    if(posArr.length === 2){
      return null;
    }
    const {treeData} =  this.state;
    let currMenu = treeData[posArr[1]];
    let index = 2;
    while(index < (posArr.length - 1)){
      currMenu = currMenu.children[posArr[index]];
      index += 1;
    }
    return currMenu;
  }


  /**
   * 新增或修改菜单
   */
  addMenu = () => {
    const {dispatch,form:{validateFieldsAndScroll} } = this.props;
    const {isAdd,node,treeData,isMenuSelected} = this.state;
    const currMenu = this.getMenuItem(node);

    const tempMenu = {menuId:currMenu.menuId,parentMenuId:currMenu.parentMenuId,
                      name:currMenu.name,icon:currMenu.icon,path:currMenu.path,
                      sortNo:currMenu.sortNo,state:currMenu.state};
    let {sortNo} = tempMenu;
    if(isAdd){
       if(isMenuSelected){
         tempMenu.parentMenuId = isUndefined(tempMenu.menuId)?null:tempMenu.menuId;
         const menuItem = this.getMenuItem(node);
         sortNo = isUndefined(menuItem.children)?0:menuItem.children.length;
       }else{
         tempMenu.parentMenuId = null;
         sortNo = treeData.length;
       }
       tempMenu.menuId = null;
    }

    validateFieldsAndScroll((err, values) => {
      if(!err){
        if(isAdd){
          Object.assign(tempMenu,{...values,sortNo});
        }else{
          Object.assign(tempMenu,{...values});
        }
        dispatch({
          type:"menuManage/menuAddFetch",
          payload: tempMenu,
        }).then((res) => {
          if(res.code === "200"){
            message.success(isAdd?"保存成功":"修改成功");
            this.setState({isShowModal:false});
            // 刷新列表
            this.getMenuList();
          }else {
            message.error(res.msg);
          }
        }).catch(error => {
          message.error(error.msg);
        })
      }
    })
  };

  /**
   * 删除菜单
   */
  deleteMenu = () => {
    const {dispatch} = this.props;
    const {node,treeData} = this.state;
    const currMenu = this.getMenuItem(node);
    if(!isUndefined(currMenu.children) && currMenu.children.length > 0){
      message.error("包含子菜单，不允许删除");
    }else{
      const params = {menuId:currMenu.menuId};
      dispatch({
        type:"menuManage/menuDeleteFetch",
        payload: params,
      }).then((res) => {
        if(res.code === "200"){
          message.success("删除成功");
          const parentMenu = this.getParentMenuItem(node);
          let menuList = [];
          if(parentMenu === null){
            menuList = treeData.filter(item => {
               return item.menuId !== currMenu.menuId
             });
          }else{
            menuList = parentMenu.children.filter((item) => {
              return item.menuId !== currMenu.menuId
            });
          }
          for(let i =0;i<menuList.length;i+=1){
            menuList[i].sortNo = i;
          }
          dispatch({
            type:"menuManage/menuListSaveFetch",
            payload: {menuList},
          }).then(result => {
            if(result.code === "200"){
              this.setState({isShowModal:false});
              // 刷新列表
              this.getMenuList();
            }else {
              message.error(result.msg);
            }
          })
        }else {
          message.error(res.msg);
        }
      }).catch(error => {
        message.error(error.msg);
      })
    }
  };

  /**
   * 打开新增菜单按钮
   */
  openAddModal = () => {
    this.setState({isAdd:true,isShowModal:true,modalTitle:"新增菜单"});
  };

  /**
   * 关闭编辑框
   */
  closeModal = () => {
    this.setState({isShowModal:false});
  };


  /**
   * 新增/编辑/删除模态框
   * @returns {*}
   */
  formModal = () => {
    const {isAdd,node} = this.state;
    let currMenu = {};
    if(isAdd){
      currMenu = {name:"",icon:"",path:"",state:1};
    }else {
      currMenu = this.getMenuItem(node);
    }
    const {form:{getFieldDecorator}} = this.props;
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 5 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 17 },
      },
    };
    const submitFormLayout = {
      wrapperCol: {
        xs: { span: 24, offset: 0 },
        sm: { span: 17, offset: 5 },
      },
    };
    return (
      <Form hideRequiredMark>
        <FormItem {...formItemLayout} label="菜单名称">
          {getFieldDecorator('name', {
            initialValue: currMenu.name,
          })(
            <Input />
          )}
        </FormItem>
        <FormItem {...formItemLayout} label="菜单图标">
          {getFieldDecorator('icon', {
            initialValue: currMenu.icon,
          })(
            <Input />
          )}
        </FormItem>
        <FormItem {...formItemLayout} label="子路径">
          {getFieldDecorator('path', {
            initialValue:currMenu.path,
          })(
            <Input />
          )}
        </FormItem>
        <FormItem {...formItemLayout} label="状态">
          {getFieldDecorator('state', {
            initialValue:currMenu.state,
          })(
            <RadioGroup>
              <Radio value={0}>无效</Radio>
              <Radio value={1}>有效</Radio>
            </RadioGroup>
          )}
        </FormItem>
        <FormItem {...submitFormLayout}>
          <Button type="primary" style={{marginLeft:20}} onClick={this.addMenu}>
            {isAdd?'新增':'保存'}
          </Button>
          {!isAdd ?
            <Button style={{marginLeft: 20,color:'red'}} onClick={this.deleteMenu}>删除</Button>
            :
            ""
          }
          <Button style={{ marginLeft: 20 }} onClick={this.closeModal}>取消</Button>
        </FormItem>
      </Form>
    )
  };


  render() {
    const {isShowModal,defaultExpandAll,treeData,modalTitle} = this.state;
    const that = this;
    const loop = data => data.map((item) => {
      if (item.children && item.children.length) {
        return <TreeNode key={item.menuId} title={item.name}>{loop(item.children)}</TreeNode>;
      }
      return <TreeNode key={item.menuId} title={item.name} />;
    });
    return (
      <PageHeaderLayout>
        <div style={{display:"flex"}}>
          <div style={{width:400}}>
            <div style={{display:"flex",height:50,border:"1px solid #ddd",justifyContent: "space-between",lineHeight:"50px",padding:"0 10px"}}>
              <div>管理系统左侧菜单</div>
              <div style={{cursor: "pointer"}} onClick={this.openAddModal}>+新增菜单</div>
            </div>
            <Card style={{height:500,overflow:"auto"}}>
              <Tree
                showLine
                className="draggable-tree"
                defaultExpandAll={defaultExpandAll}
                onSelect={that.onClickMenu}
                onRightClick={that.onRightClick}
                draggable
                onDrop={this.onDrop}
              >
                {loop(treeData)}
              </Tree>
            </Card>
          </div>
          <div style={{flex:1,padding:"100px 0 0 100px"}}>
            <h4>使用说明</h4>
            <div>1、“ + 新增菜单 ” 创建父菜单</div>
            <div>2、单击选中某个菜单，然后点击 “ + 新增菜单 ” 按钮可以创建子菜单</div>
            <div>3、右键菜单，可弹出编辑/删除对话框</div>
            <div>4、同级菜单，可拖拽菜单更改排序</div>
          </div>
        </div>
        <Modal visible={isShowModal} title={modalTitle} footer={null} onCancel={() => this.setState({ isShowModal: false })}>
          {isShowModal?this.formModal():""}
        </Modal>
      </PageHeaderLayout>

    );
  }
}
// export default DragDropContext(HTML5Backend)(MenuManage);

