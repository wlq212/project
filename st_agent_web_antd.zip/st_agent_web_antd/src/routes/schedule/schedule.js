/* eslint-disable no-param-reassign,radix,react/react-in-jsx-scope */

import React,{PureComponent}  from 'react';
import { connect } from 'dva';
import {Card,Modal,Button,Form,Input,DatePicker,Select,message} from 'antd';
import moment from 'moment';
import {isUndefined,isArray} from 'lodash';

import PageHeaderLayout from '../../layouts/PageHeaderLayout';


const H = (function() {

  // 一些私有变量

  // 一些公有变量、函数

  /**
   * 给月份数组附上每月天数
   * @param year 年份
   * @private
   */
  function initMonthDayNumber(year) {
    const dateArray = [];

    for (let i = 0; i < 12; i+=1) {
      switch (i + 1) {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
          dateArray.push(31);
          break;
        case 4:
        case 6:
        case 9:
        case 11:
          dateArray.push(30);
          break;
        case 2:
          if (H.isLeapYear(year)) {
            dateArray.push(29);
          } else {
            dateArray.push(28);
          }
          break;
        default:
          break;
      }
    }

    return dateArray;
  }

  /**
   * 获取某个日期当天是星期几
   * @param year
   * @param month
   * @param day
   * @returns {*}
   */
  function getWeek(year,month,day) {
    const date = new Date(year, month,day);
    const week = date.getDay();
    switch(week){
      case 0:
        return (<font color="red">周日</font>);
      case 1:
        return "周一";
      case 2:
        return "周二";
      case 3:
        return "周三";
      case 4:
        return "周四";
      case 5:
        return "周五";
      case 6:
        return getYearWeek(year,month,day)%2 === 0?(<font color="red">周六</font>):"周六";
      // let w = getYearWeek(year,month,day);
      // if(w%2 === 0){
      //     return (<font color="red">周六</font>);
      // }else{
      //     return "周六";
      // }
      default:
        return "";
    }
  }

  /**
   * 判断指定日期的周六、日是单休还是双休
   * @param year
   * @param month
   * @param day
   * @returns {*}
   */
  function getColorDay(year,month,day) {
    const date = new Date(year, month,day);
    const week = date.getDay();
    if(week === 0){
      return (<font color="red">{month+1}月{day}日</font>);
    }else if(week === 6){
      const w = getYearWeek(year,month,day);
      if(w%2 === 0){
        return (<font color="red">{month+1}月{day}日</font>);
      }
    }
    return `${month+1}月${day}日`;
  }

  /**
   * 获取当前日期是一年中的第几周
   * @param a
   * @param b
   * @param c
   * @returns {number}
   */
  function getYearWeek(a, b, c) {
    // date1是当前日期
    // date2是当年第一天
    // d是当前日期是今年第多少天
    // 用d + 当前年的第一天的周差距的和在除以7就是本年第几周
    const date1 = new Date(a, parseInt(b) - 1, c); const date2 = new Date(a, 0, 1);

      
const d = Math.round((date1.valueOf() - date2.valueOf()) / 86400000);
    return Math.ceil((d + ((date2.getDay() + 1) - 1)) / 7);
  }

  /**
   *
   * 判断这一年是闰年还是平年
   * @param year {String/Number} 年份
   * @returns {boolean}
   */

  function isLeapYear(year) {
    if (typeof(year) !== 'number') {
      throw new Error("年份格式不正确");
    }

    if (+year < 1790) {
      throw new Error("年份不能低于1790年");
    }

    // 计算闰年方法
    // 1.能被4整除而不能被100整除
    // 2.能被400整除

    return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  }

  /**
   * 返回月份中的第一天是星期几
   * @returns {number}
   * 1 星期一
   * 2 星期二
   * 3 星期三
   * 4 星期四
   * 5 星期五
   * 6 星期六
   * 0 星期天
   */
  function weekOfMonth(date) {
    if (!date) date = new Date();
    return new Date(getFullYear(date), getMonth(date), 1).getDay();
  }

  /**
   * 获取月份
   * @param date
   * @returns {*|number}
   */
  function getMonth(date) {
    if (!date) date = new Date();
    return date.getMonth();
  }

  /**
   * 获取年份
   * @param date
   * @returns {number}
   */
  function getFullYear(date) {
    if (!date) date = new Date();
    return date.getFullYear();
  }

  /**
   * 获取一月中的某一天
   * @param date
   * @returns {number}
   */
  function getDate(date) {
    if (!date) date = new Date();
    return date.getDate();
  }

  // 暴露需要提供的方法
  return {
    initMonthDayNumber,
    getWeek,
    getYearWeek,
    getColorDay,
    isLeapYear,
    weekOfMonth,
    getFullYear,
    getMonth,
    getDate,
  };

})();
const now = new Date();
const FormItem = Form.Item;
const {RangePicker} = DatePicker;
const {Option} = Select;
const {TextArea} = Input;
const {confirm} = Modal;

// 是否正在滚动
let isScrolling = true;

@connect(({ schedule, loading }) => ({
  schedule,
  loading: loading.models.schedule,
}))
@Form.create()

export default class Schedule extends PureComponent{
  constructor(props){
    super(props);
    this.state = {
      selectYear : H.getFullYear(),
      selectMonth : H.getMonth(),
      year: now.getFullYear(),
      month: now.getMonth(),
      day: now.getDate(),
      scheduleTitle:"新增排档",
      visible:false,
      currData:{},
      schId:"",
      trHeight:60,
      tdWidth:110,
      tdTop:5,
      tableData:[],// index=0为上个月，1为当前月，2为下个月
    };
    this.tableBoxScroll = this.tableBoxScroll.bind(this);

  }


  componentDidMount(){
    const { year, month} = this.state;
    const that = this;
    that.setState({selectYear:year,selectMonth:month});
    that.scheduleListFunc(year,month);
    const tableBox = document.getElementById("tableBox");
    tableBox.addEventListener('scroll', this.tableBoxScroll);
  }


  getItemLeft = (beginTime) => {
    const {selectYear,selectMonth} = this.state;
    const subTime = this.subMonth(selectYear,selectMonth+1);
    const preDays = moment(`${subTime.year}-${subTime.month}`, "YYYY_MM").daysInMonth();// 上个月天数
    const currDays = moment(`${selectYear}-${selectMonth+1}`, "YYYY-MM").daysInMonth();// 当前月天数
    const month = Number(moment(new Date(beginTime)).format("MM"));// 参数传值月
    const day = Number(moment(new Date(beginTime)).format("DD"));// 参数传值日
    if(month > selectMonth+1){// 下一个月数据
      return (preDays + currDays + day - 1);
    }else if(month < selectMonth+1){// 上一个月数据
      return (day-1);
    }else{// 当前月数据
      return preDays+day-1;
    }
  };

  /**
   * 解析活动/推文/事项
   * @param arr
   * @param year
   * @param month
   * @param day
   */
  getDataList = (arr) => {
    const data = [];
    if(arr === null || arr === undefined || arr.length === 0){
      return data;
    }

    for(let i = 0 ; i < arr.length ; i +=1) {
      const r = this.getItemRow(data,arr[i]);
      const item = this.getItemColSpan(arr[i]);
      if(r >= data.length){
        const tmpArr = [];
        tmpArr.push(item);
        data.push(tmpArr);
      }else{
        data[r].push(item);
      }
    }
    return data;
  };

  /**
   * 计算合并多少列
   * @param item
   * @returns {*}
   */
  getItemColSpan = (item) => {
    const data = item;
    const beginTime = moment(data.beginTime);
    const endTime = moment(data.endTime);
    data.colSpan = endTime.diff(beginTime,'day')+1;
    return data;
  };

  /**
   * 获取元素所在行
   * @param data
   * @param item
   * @returns {number}
   */
  getItemRow = (data,item) => {
    let k = 0;
    for(let m = 0; m < data.length ; m += 1){
      let isHit = false;
      for(let n = 0; n < data[m].length; n += 1){
        if((item.beginTime >= data[m][n].beginTime && item.beginTime <= data[m][n].endTime) ||
          (item.endTime >= data[m][n].beginTime && item.endTime <= data[m][n].endTime)){
          isHit = true;
          break;
        }
      }
      if(!isHit){
        return m;
      }else{
        k += 1;
      }
    }
    return k;
  };

  /**
   * 初始获取数据
   * @param year
   * @param month
   * @param flag
   */
  scheduleListFunc = (year,month) => {
    const { dispatch} = this.props;
    const that = this;
    const subTime = this.subMonth(year,month);
    const addTime = this.addMonth(year,month);
    const beginTime = moment(new Date(subTime.year,subTime.month)).startOf('month').format("YYYY-MM-DD");
    const endTime = moment(new Date(addTime.year,addTime.month)).endOf('month').format("YYYY-MM-DD");
    dispatch({
      type: "schedule/scheduleListFetch",
      payload: {beginTime,endTime},
    }).then(() => {
      const {schedule:{scheduleList:{activity,article,item}}} = this.props;
      const monthDay = moment(`${year}-${month+1}`, "YYYY-MM").daysInMonth();
      const preMonthDay = moment(`${subTime.year}-${subTime.month+1}`, "YYYY-MM").daysInMonth();
      const nextMonthDay = moment(`${addTime.year}-${addTime.month+1}`, "YYYY-MM").daysInMonth();
      const list = {
        days:preMonthDay + monthDay + nextMonthDay,
        monthDay,
        preMonthDay,
        nextMonthDay,
        header:[],
        activityList:this.getDataList(activity),
        articleList:this.getDataList(article),
        itemList:this.getDataList(item),
      };
      for(let i = 1; i <= preMonthDay; i+=1){
        const dTime = `${subTime.year}-${subTime.month+1}-${i}`;
        const day = `${subTime.month+1}月${i}日`;
        const week = H.getWeek(subTime.year,subTime.month,i);
        list.header.push({day,week,dTime});
      }
      for(let i = 1; i <= monthDay; i+=1){
        const dTime = `${year}-${month+1}-${i}`;
        const day = `${month+1}月${i}日`;
        const week = H.getWeek(year,month,i);
        list.header.push({day,week,dTime});
      }
      for(let i = 1; i <= nextMonthDay; i+=1){
        const dTime = `${addTime.year}-${addTime.month+1}-${i}`;
        const day = `${addTime.month+1}月${i}日`;
        const week = H.getWeek(addTime.year,addTime.month,i);
        list.header.push({day,week,dTime});
      }
      that.handleScroll(preMonthDay);
      that.setState({tableData:list});
    }).catch(()=> {
      isScrolling = false;
    });
  };

  /**
   * 新增排档按钮
   */
  addSchedule = () => {
    const currData = {type:"",status:"",color:"#000",note:"",time:""};
    this.setState({scheduleTitle:"新增排档",visible:true,currData,schId:""});
  };

  /**
   * 取消按钮
   */
  cancel = () => {
    this.setState({visible:false});
  };

  /**
   * 保存
   * @param e
   */
  handleSubmit = e => {
    e.preventDefault();
    const { form, dispatch} = this.props;
    const { year, month, day,schId} = this.state;
    let beginTime = "";
    let endTime = "";
    let url = "schedule/addScheduleFetch";
    let text = "添加成功";
    form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        const rangeValue = values.time;
        if(!isUndefined(rangeValue) && rangeValue.length > 0){
          beginTime = rangeValue[0].format('YYYY-MM-DD');
          endTime = rangeValue[1].format('YYYY-MM-DD');
        }
        const params = {
          beginTime,
          endTime,
          type:values.type,
          status:values.status,
          note:values.note,
          color:values.color,
          schId,
        };
        if(schId !== "" && schId != null){
          url = "schedule/updateScheduleFetch";
          text = "更新成功";
        }
        dispatch({
          type: url,
          payload: params,
        }).then(
          (res) => {
            if (res.code === "200") {
              message.success(text);
              this.setState({visible:false,currData:{}});
              this.scheduleListFunc(year,month,day);
            }else {
              message.success(res.msg);
            }
          },
        ).catch(error => {
          message.error(error.msg);
        });
      }
    });
  };

  /**
   * 选中某个排档
   * @param obj
   */
  selectSchedule = (obj) => {
    const beginTime = moment(new Date(obj.beginTime)).format("YYYY-MM-DD");
    const endTime = moment(new Date(obj.endTime)).format("YYYY-MM-DD");
    const currData = obj;
    currData.time = [moment(beginTime),moment(endTime)];
    this.setState({schId:obj.schId,scheduleTitle:"编辑排档",visible:true,currData},()=> {
       console.log("xxxxxxxxxxx");
    });
  };

  /**
   * 删除排档
   * @param schId
   */
  deleteSchedule = (schId) => {
    const {dispatch} = this.props;
    const {selectYear,selectMonth} = this.state;
    const that = this;
    confirm({
      title: '提示?',
      content: '确定要删除此档期吗？',
      cancelText:"取消",
      okText:"删除",
      onOk() {
        dispatch({
          type: "schedule/deleteScheduleFetch",
          payload: {schId},
        }).then(
          (res) => {
            if (res.code === "200") {
              message.success("删除成功");
              that.setState({visible:false,currData:{}});
              that.scheduleListFunc(selectYear,selectMonth);
            }else {
              message.success(res.msg);
            }
          },
        ).catch(error => {
          message.error(error.msg);
        });
      },
    })

  };

  /**
   * 加一个月
   * @param year
   * @param month
   */
  addMonth = (year,month) => {
    const addTime = {};
    const time = moment(new Date(year,month));
    addTime.month = time.add(1,'month').month();
    addTime.year = time.year();
    return addTime;
  };

  /**
   * 减一个月
   * @param year
   * @param month
   */
  subMonth = (year,month) => {
    const subTime = {};
    const time = moment(new Date(year,month));
    subTime.month = time.subtract(1,'month').month();
    subTime.year = time.year();
    return subTime;
  };

  /**
   * 上一个月
   * @param year
   * @param month
   */
  previousMonth = (year,month) => {
    const subTime = this.subMonth(year,month);
    this.setState({selectYear:subTime.year,selectMonth:subTime.month});
    this.scheduleListFunc(subTime.year,subTime.month);
  };

  /**
   * 下一个月
   * @param year
   * @param month
   */
  nextMonth = (year,month) => {
    const addTime = this.addMonth(year,month);
    this.setState({selectYear:addTime.year,selectMonth:addTime.month});
    this.scheduleListFunc(addTime.year,addTime.month);
  };

  /**
   * 滚动监听
   */
  tableBoxScroll(e){
    if(isScrolling){
      return;
    }
    const {tdWidth,tableData,selectYear,selectMonth} = this.state;
    const currMonthRight = (tableData.preMonthDay + tableData.monthDay)*tdWidth;
    if(e.target.scrollLeft < tdWidth){
      isScrolling = true;
      console.log("往左拉，加载上一个月数据");
      this.previousMonth(selectYear,selectMonth);
    }else if(e.target.scrollLeft - currMonthRight > 0){
      isScrolling = true;
      console.log("往右拉，加载下一个月数据");
      this.nextMonth(selectYear,selectMonth);
    }

  }

  /**
   * 初始滚动
   */
  handleScroll(days) {
    const {tdWidth} = this.state;
    const tableBox = document.getElementById("tableBox");
    setTimeout(()=>{
      tableBox.scrollLeft+=1;
      tableBox.scrollLeft = (days) * tdWidth;
      isScrolling = false;
    },100);
  }

  scheduleEditModal(){
    const { form,submitting} = this.props;
    const {currData,schId} = this.state;
    let data = currData;
    if(schId === "" || schId === null){
      data = {type:"",status:"",note:"",color:"#000",time:""};
    }
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 },
        md: { span: 10 },
      },
    };
    const submitFormLayout = {
      wrapperCol: {
        xs: { span: 24, offset: 0 },
        sm: { span: 10, offset: 7 },
      },
    };
    return (
      <div>
        <Form onSubmit={this.handleSubmit}>
          <FormItem {...formItemLayout} label="类型">
            {form.getFieldDecorator('type', {
              initialValue: data.type,
              rules: [{ required: true, message: '请选择类型' }],
            })(
              <Select placeholder="请选择类型">
                <Option value={0}>活动</Option>
                <Option value={1}>推文</Option>
                <Option value={2}>事项</Option>
              </Select>
            )}
          </FormItem>
          <FormItem {...formItemLayout} label="规划时间">
            {form.getFieldDecorator('time', {
              initialValue: data.time,
              rules: [{ required: true, message: '请选择规划时间' }],
            })(<RangePicker style={{width:"100%"}} />)}
          </FormItem>
          <FormItem {...formItemLayout} label="标注颜色">
            {form.getFieldDecorator('color', {
              initialValue: data.color,
              rules: [{ required: true, message: '请选择颜色' }],
            })(
              <Input type="color" />
            )}
          </FormItem>
          <FormItem {...formItemLayout} label="状态">
            {form.getFieldDecorator('status', {
              initialValue: data.status,
              rules: [{ required: true, message: '请选择状态' }],
            })(
              <Select placeholder="请选择状态">
                <Option value={0}>进行中</Option>
                <Option value={1}>已完成</Option>
                <Option value={2}>已结束</Option>
              </Select>
            )}
          </FormItem>
          <FormItem {...formItemLayout} label="摘要">
            {form.getFieldDecorator('note', {
              initialValue: data.note,
              rules: [{ required: true, message: '请选择摘要' }],
            })(<TextArea placeholder="请选择摘要" />)}
          </FormItem>
          <FormItem {...submitFormLayout} style={{ marginTop: 32 }}>
            <Button type="primary" htmlType="submit" loading={submitting}>
              保存
            </Button>
            {
              schId !== "" && schId != null ? (
                <Button type="danger" style={{ marginLeft: 20 }} onClick={() => this.deleteSchedule(schId)}>
                  删除
                </Button>
): ""
            }

            <Button style={{ marginLeft: 20 }} onClick={this.cancel}>
              取消
            </Button>
          </FormItem>
        </Form>
      </div>
    )
  };

  render(){
    const {selectYear,selectMonth,scheduleTitle,visible,schId,trHeight,tdWidth,tableData,tdTop} = this.state;

    return (
      <PageHeaderLayout>
        <Card style={{position:"relative"}}>
          <div style={{marginBottom:24}}>
            <Button type="primary" onClick={() => this.previousMonth(selectYear,selectMonth)}>上一月</Button>
            <b style={{display:"inline-block",margin:10}}>{selectYear}年{selectMonth+1}月</b>
            <Button type="primary" onClick={() => this.nextMonth(selectYear,selectMonth)}>下一月</Button>
            <div style={{float:"right"}}>
              <Button type="primary" onClick={this.addSchedule}>新增排档</Button>
            </div>
          </div>
          <div style={{overflow:"auto"}} id="tableBox">

            {/* ***********begin 左侧栏**************** */}
            <table style={{position:"absolute",left:32,zIndex:20,background:"#fff"}} border="1">
              <thead>
                <tr style={{height:60}}>
                  <th style={{width:tdWidth}}>&nbsp;</th>
                </tr>
              </thead>
              <tbody>
                <tr style={{height:(isArray(tableData.activityList) && tableData.activityList.length > 0 ? tableData.activityList.length:1)*trHeight}}>
                  <td style={{textAlign:"center",background:"#f2f2f2"}}><h1 style={{marginBottom:0}}>活动</h1></td>
                </tr>
                <tr style={{height:(isArray(tableData.articleList) && tableData.articleList.length > 0 ? tableData.articleList.length:1)*trHeight}}>
                  <td style={{textAlign:"center",background:"#f2f2f2"}}><h1 style={{marginBottom:0}}>推文</h1></td>
                </tr>
                <tr style={{height:(isArray(tableData.itemList) && tableData.itemList.length > 0 ? tableData.itemList.length:1)*trHeight}}>
                  <td style={{textAlign:"center",background:"#f2f2f2"}}><h1 style={{marginBottom:0}}>事项</h1></td>
                </tr>
              </tbody>
            </table>
            {/* ***********end 左侧栏**************** */}

            <table style={{width:(tableData.days+1)*tdWidth,textAlign:"center",borderColor:"#999"}} border="1">
              <thead>
                {/* ******************日期******************* */}
                <tr style={{ height: 30 }}>
                  <th width={tdWidth}>&nbsp;</th>
                  {
                    isArray(tableData.header) && tableData.header.length > 0 ? tableData.header.map((item) => (
                      <th key={item.day} width={tdWidth} style={{background:"#f2f2f2"}}>{item.day}</th>
                    )):<td />
                  }
                </tr>
                {/* ******************星期******************* */}
                <tr style={{ height: 30 }}>
                  <th width={tdWidth}>&nbsp;</th>
                  {
                    isArray(tableData.header) && tableData.header.length > 0 ? tableData.header.map((item) => (
                      <th key={item.dTime} style={{background:"#f2f2f2"}}>{item.week}</th>
                    )):<td />
                  }
                </tr>
              </thead>
              <tbody>
                {/* ******************活动内容******************* */}
                {
                  isArray(tableData.activityList) && tableData.activityList.length > 0 ? tableData.activityList.map((item,i) => (
// eslint-disable-next-line react/no-array-index-key
                    <tr style={{height:trHeight}} key={`ac${i}`}>
                      <td width={tdWidth}>&nbsp;</td>
                      <td colSpan={tableData.days} style={{ position: 'relative',borderColor:"#ddd" }}>
                        {
                          item.map(obj => (
                            <div
                              style={{ position: 'absolute', left: this.getItemLeft(obj.beginTime) * tdWidth, top: tdTop, cursor: 'pointer' }}
                              onClick={() => this.selectSchedule(obj)}
                            >
                              <div style={{
                                background: obj.color,
                                width: obj.colSpan * tdWidth,
                                height: trHeight - tdTop*2,
                                lineHeight: `${trHeight - tdTop*2}px`,
                                textAlign: 'center',
                              }}
                              >{obj.note}
                              </div>
                              {schId === obj.schId ? (
                                <div style={{
                                  position: 'absolute',
                                  top: 0,
                                  left: 0,
                                  right: 0,
                                  bottom: 0,
                                  border: '2px solid blue',
                                }}
                                />
                              ) : ''}
                            </div>
                          ))
                        }
                      </td>
                    </tr>
                  )) : <tr style={{height:trHeight}}><td colSpan={tableData.days} style={{borderColor:"#ddd"}}>&nbsp;</td></tr>
                }


                {/* ******************推文内容******************* */}
                {
                  isArray(tableData.articleList) && tableData.articleList.length > 0 ? tableData.articleList.map((item,i) => (
// eslint-disable-next-line react/no-array-index-key
                    <tr style={{height:trHeight}} key={`ar${i}`}>
                      <td width={tdWidth}>&nbsp;</td>
                      <td colSpan={tableData.days} style={{ position: 'relative',borderColor:"#ddd" }}>
                        {
                          item.map(obj => (
                            <div
                              style={{ position: 'absolute', left: this.getItemLeft(obj.beginTime) * tdWidth, top: tdTop, cursor: 'pointer' }}
                              onClick={() => this.selectSchedule(obj)}
                            >
                              <div style={{
                                background: obj.color,
                                width: obj.colSpan * tdWidth,
                                height: trHeight - tdTop*2,
                                lineHeight: `${trHeight - tdTop*2}px`,
                                textAlign: 'center',
                              }}
                              >{obj.note}
                              </div>
                              {schId === obj.schId ? (
                                <div style={{
                                  position: 'absolute',
                                  top: 0,
                                  left: 0,
                                  right: 0,
                                  bottom: 0,
                                  border: '2px solid blue',
                                }}
                                />
                              ) : ''}
                            </div>
                          ))
                        }
                      </td>
                    </tr>
                  )) : <tr style={{height:trHeight}}><td colSpan={tableData.days} style={{borderColor:"#ddd"}}>&nbsp;</td></tr>
                }

                {/* ******************事项内容******************* */}
                {
                  isArray(tableData.itemList) && tableData.itemList.length > 0 ? tableData.itemList.map((item,i) => (
// eslint-disable-next-line react/no-array-index-key
                    <tr style={{height:trHeight}} key={`it${i}`}>
                      <td width={tdWidth}>&nbsp;</td>
                      <td colSpan={tableData.days} style={{ position: 'relative',borderColor:"#ddd" }}>
                        {
                          item.map(obj => (
                            <div
                              style={{ position: 'absolute', left: this.getItemLeft(obj.beginTime) * tdWidth, top: tdTop, cursor: 'pointer' }}
                              onClick={() => this.selectSchedule(obj)}
                            >
                              <div style={{
                                background: obj.color,
                                width: obj.colSpan * tdWidth,
                                height: trHeight - tdTop*2,
                                lineHeight: `${trHeight - tdTop*2}px`,
                                textAlign: 'center',
                              }}
                              >{obj.note}
                              </div>
                              {schId === obj.schId ? (
                                <div style={{
                                  position: 'absolute',
                                  top: 0,
                                  left: 0,
                                  right: 0,
                                  bottom: 0,
                                  border: '2px solid blue',
                                }}
                                />
                              ) : ''}
                            </div>
                          ))
                        }
                      </td>
                    </tr>
                  )) : <tr style={{height:trHeight}}><td colSpan={tableData.days} style={{borderColor:"#ddd"}}>&nbsp;</td></tr>
                }
              </tbody>


            </table>
          </div>


        </Card>
        <Modal width="50%" title={scheduleTitle} visible={visible} footer={null} onCancel={() => this.setState({ visible: false })}>
          {visible?this.scheduleEditModal():""}
        </Modal>
      </PageHeaderLayout>
    )
  }
}
