/* eslint-disable no-param-reassign,radix,react/react-in-jsx-scope */

import React,{PureComponent}  from 'react';
import { connect } from 'dva';
import {Card,Modal,Button,Form,Input,DatePicker,Select,message} from 'antd';
import moment from 'moment';
import {isUndefined,isArray} from 'lodash';

import PageHeaderLayout from '../../layouts/PageHeaderLayout';


const H = (function() {

  // 一些私有变量

  // 一些公有变量、函数

  /**
   * 给月份数组附上每月天数
   * @param year 年份
   * @private
   */
  function initMonthDayNumber(year) {
    const dateArray = [];

    for (let i = 0; i < 12; i+=1) {
      switch (i + 1) {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
          dateArray.push(31);
          break;
        case 4:
        case 6:
        case 9:
        case 11:
          dateArray.push(30);
          break;
        case 2:
          if (H.isLeapYear(year)) {
            dateArray.push(29);
          } else {
            dateArray.push(28);
          }
          break;
        default:
          break;
      }
    }

    return dateArray;
  }

  /**
   * 获取某个日期当天是星期几
   * @param year
   * @param month
   * @param day
   * @returns {*}
   */
  function getWeek(year,month,day) {
    const date = new Date(year, month,day);
    const week = date.getDay();
    switch(week){
      case 0:
        return (<font color="red">周日</font>);
      case 1:
        return "周一";
      case 2:
        return "周二";
      case 3:
        return "周三";
      case 4:
        return "周四";
      case 5:
        return "周五";
      case 6:
        return getYearWeek(year,month,day)%2 === 0?(<font color="red">周六</font>):"周六";
      // let w = getYearWeek(year,month,day);
      // if(w%2 === 0){
      //     return (<font color="red">周六</font>);
      // }else{
      //     return "周六";
      // }
      default:
        return "";
    }
  }

  /**
   * 判断指定日期的周六、日是单休还是双休
   * @param year
   * @param month
   * @param day
   * @returns {*}
   */
  function getColorDay(year,month,day) {
    const date = new Date(year, month,day);
    const week = date.getDay();
    if(week === 0){
      return (<font color="red">{month+1}月{day}日</font>);
    }else if(week === 6){
      const w = getYearWeek(year,month,day);
      if(w%2 === 0){
        return (<font color="red">{month+1}月{day}日</font>);
      }
    }
    return `${month+1}月${day}日`;
  }

  /**
   * 获取当前日期是一年中的第几周
   * @param a
   * @param b
   * @param c
   * @returns {number}
   */
  function getYearWeek(a, b, c) {
    // date1是当前日期
    // date2是当年第一天
    // d是当前日期是今年第多少天
    // 用d + 当前年的第一天的周差距的和在除以7就是本年第几周
    const date1 = new Date(a, parseInt(b) - 1, c); const date2 = new Date(a, 0, 1);

      
const d = Math.round((date1.valueOf() - date2.valueOf()) / 86400000);
    return Math.ceil((d + ((date2.getDay() + 1) - 1)) / 7);
  }

  /**
   *
   * 判断这一年是闰年还是平年
   * @param year {String/Number} 年份
   * @returns {boolean}
   */

  function isLeapYear(year) {
    if (typeof(year) !== 'number') {
      throw new Error("年份格式不正确");
    }

    if (+year < 1790) {
      throw new Error("年份不能低于1790年");
    }

    // 计算闰年方法
    // 1.能被4整除而不能被100整除
    // 2.能被400整除

    return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  }

  /**
   * 返回月份中的第一天是星期几
   * @returns {number}
   * 1 星期一
   * 2 星期二
   * 3 星期三
   * 4 星期四
   * 5 星期五
   * 6 星期六
   * 0 星期天
   */
  function weekOfMonth(date) {
    if (!date) date = new Date();
    return new Date(getFullYear(date), getMonth(date), 1).getDay();
  }

  /**
   * 获取月份
   * @param date
   * @returns {*|number}
   */
  function getMonth(date) {
    if (!date) date = new Date();
    return date.getMonth();
  }

  /**
   * 获取年份
   * @param date
   * @returns {number}
   */
  function getFullYear(date) {
    if (!date) date = new Date();
    return date.getFullYear();
  }

  /**
   * 获取一月中的某一天
   * @param date
   * @returns {number}
   */
  function getDate(date) {
    if (!date) date = new Date();
    return date.getDate();
  }

  // 暴露需要提供的方法
  return {
    initMonthDayNumber,
    getWeek,
    getYearWeek,
    getColorDay,
    isLeapYear,
    weekOfMonth,
    getFullYear,
    getMonth,
    getDate,
  };

})();
const now = new Date();
const FormItem = Form.Item;
const {RangePicker} = DatePicker;
const {Option} = Select;
const {TextArea} = Input;
@connect(({ schedule, loading }) => ({
  schedule,
  loading: loading.models.schedule,
}))
@Form.create()
export default class Schedule extends PureComponent{
  constructor(props){
    super(props);
    this.state = {
      selectYear : H.getFullYear(),
      selectMonth : H.getMonth(),
      year: now.getFullYear(),
      month: now.getMonth(),
      day: now.getDate(),
      scheduleTitle:"新增排档",
      visible:false,
      currData:{},
      selected:"",
      trHeight:50,
      tdWidth:110,
      tableData:[[],[],[]],// index=0为上个月，1为当前月，2为下个月
      dayList:[],// 全部日期列表
    };
  }

  componentDidMount(){

    const { year, month} = this.state;
    this.setState({selectYear:year,selectMonth:month});
    this.initData();
  }


  /**
   * 解析活动/推文/事项
   * @param arr
   * @param year
   * @param month
   * @param day
   */
  getDataList = (arr) => {
    const data = [];
    if(arr === null || arr === undefined || arr.length === 0){
      return data;
    }

    for(let i = 0 ; i < arr.length ; i +=1) {
      const r = this.getItemRow(data,arr[i]);
      const item = this.getItemColSpan(arr[i]);
      if(r >= data.length){
        const tmpArr = [];
        tmpArr.push(item);
        data.push(tmpArr);
      }else{
        data[r].push(item);
      }
    }
    return data;
  };

  /**
   * 计算合并多少列
   * @param item
   * @returns {*}
   */
  getItemColSpan = (item) => {
    const data = item;
    const beginTime = moment(data.beginTime);
    const endTime = moment(data.endTime);
    data.colSpan = endTime.diff(beginTime,'day')+1;
    return data;
  };

  /**
   * 获取元素所在行
   * @param data
   * @param item
   * @returns {number}
   */
  getItemRow = (data,item) => {
    let k = 0;
    for(let m = 0; m < data.length ; m += 1){
      let isHit = false;
      for(let n = 0; n < data[m].length; n += 1){
        if((item.beginTime >= data[m][n].beginTime && item.beginTime <= data[m][n].endTime) ||
          (item.endTime >= data[m][n].beginTime && item.endTime <= data[m][n].endTime)){
          isHit = true;
          break;
        }
      }
      if(!isHit){
        return m;
      }else{
        k += 1;
      }
    }
    return k;
  };

  getMonthDataList = (year,month,activity,article,item) => {
    const monthDay = moment(`${year}-${month+1}`, "YYYY-MM").daysInMonth();
    const list = {
      dTime:[],
      headerDay:[],
      headerWeek:[],
      activityList:this.getDataList(activity),
      articleList:this.getDataList(article),
      itemList:this.getDataList(item),
    };
    for(let i = 1; i <= monthDay; i+=1){
      list.dTime.push(`${year}-${month+1}-${i}`);
      list.headerDay.push(`${month+1}月${i}日`);
      list.headerWeek.push(H.getWeek(year,month,i));
    }
    return list;
  };

  initData = () => {
    const {selectYear,selectMonth} = this.state;
    const subTime = this.subMonth(selectYear,selectMonth);
    const addTime = this.addMonth(selectYear,selectMonth);
    this.scheduleListFunc(subTime.year,subTime.month,0);
    this.scheduleListFunc(selectYear,selectMonth,1);
    this.scheduleListFunc(addTime.year,addTime.month,2);
  };

  /**
   * 初始获取数据
   * @param year
   * @param month
   * @param flag
   */
  scheduleListFunc = (year,month,flag) => {
    const { dispatch} = this.props;
    const {tableData} = this.state;
    const beginTime = moment(new Date(year,month)).startOf('month').format("YYYY-MM-DD");
    const endTime = moment(new Date(year,month)).endOf('month').format("YYYY-MM-DD");
    dispatch({
      type: "schedule/scheduleListFetch",
      payload: {beginTime,endTime},
    }).then(() => {
      const {schedule:{scheduleList:{activity,article,item}}} = this.props;
      const monthDay = moment(`${year}-${month+1}`, "YYYY-MM").daysInMonth();
      const list = {
        dTime:[],
        monthDay,
        headerDay:[],
        headerWeek:[],
        activityList:this.getDataList(activity),
        articleList:this.getDataList(article),
        itemList:this.getDataList(item),
      };
      for(let i = 1; i <= monthDay; i+=1){
        list.dTime.push(`${year}-${month+1}-${i}`);
        list.headerDay.push(`${month+1}月${i}日`);
        list.headerWeek.push(H.getWeek(year,month,i));
      }
      tableData[flag] = list;
      // let obj = {};
      // flag === 0 ? obj = list :obj = Object.assign(obj,list);
      // this.setState({tableData:Object.assign(list,list)});
      // console.log(obj);
    });
    this.setState({tableData});

  };

  /**
   * 新增排档按钮
   */
  addSchedule = () => {
    this.setState({scheduleTitle:"新增排档",visible:true,currData:{}});
  };

  /**
   * 取消按钮
   */
  cancel = () => {
    this.setState({visible:false});
  };

  /**
   * 保存
   * @param e
   */
  handleSubmit = e => {
    e.preventDefault();
    const { form, dispatch} = this.props;
    const { year, month, day} = this.state;
    let beginTime = "";
    let endTime = "";
    form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        const rangeValue = values.time;
        if(!isUndefined(rangeValue) && rangeValue.length > 0){
          beginTime = rangeValue[0].format('YYYY-MM-DD');
          endTime = rangeValue[1].format('YYYY-MM-DD');
        }
        const params = {
          beginTime,
          endTime,
          type:values.type,
          status:values.status,
          note:values.note,
          color:values.color,
        };
        dispatch({
          type: 'schedule/addScheduleFetch',
          payload: params,
        }).then(
          (res) => {
            if (res.code === "200") {
              message.success('添加成功');
              this.setState({visible:false,currData:{}});
              this.scheduleListFunc(year,month,day);
            }else {
              message.success(res.msg);
            }
          },
        ).catch(error => {
          message.error(error.msg);
        });
      }
    });
  };

  /**
   * 选中某个排档
   * @param schId
   */
  selectSchedule = (schId) => {
    this.setState({selected:schId});
  };

  /**
   * 加一个月
   * @param year
   * @param month
   */
  addMonth = (year,month) => {
    const addTime = {};
    const time = moment(new Date(year,month));
    addTime.month = time.add(1,'month').month();
    addTime.year = time.year();
    return addTime;
  };

  /**
   * 减一个月
   * @param year
   * @param month
   */
  subMonth = (year,month) => {
    const subTime = {};
    const time = moment(new Date(year,month));
    subTime.month = time.subtract(1,'month').month();
    subTime.year = time.year();
    return subTime;
  };

  /**
   * 上一个月
   * @param year
   * @param month
   */
  previousMonth = (year,month) => {
    const subTime = this.subMonth(year,month);
    this.setState({selectYear:subTime.year,selectMonth:subTime.month});
  };

  /**
   * 下一个月
   * @param year
   * @param month
   */
  nextMonth = (year,month) => {
    const addTime = this.addMonth(year,month);
    this.setState({selectYear:addTime.year,selectMonth:addTime.month});
  };

  scheduleEditModal(){
    const { form,submitting} = this.props;
    const {currData} = this.state;
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 },
        md: { span: 10 },
      },
    };
    const submitFormLayout = {
      wrapperCol: {
        xs: { span: 24, offset: 0 },
        sm: { span: 10, offset: 7 },
      },
    };
    return (
      <div>
        <Form onSubmit={this.handleSubmit}>
          <FormItem {...formItemLayout} label="类型">
            {form.getFieldDecorator('type', {
              initialValue: currData.type,
              rules: [{ required: true, message: '请选择类型' }],
            })(
              <Select placeholder="请选择类型">
                <Option value={0}>活动</Option>
                <Option value={1}>推文</Option>
                <Option value={2}>事项</Option>
              </Select>
            )}
          </FormItem>
          <FormItem {...formItemLayout} label="规划时间">
            {form.getFieldDecorator('time', {
              initialValue: currData.time,
              rules: [{ required: true, message: '请选择规划时间' }],
            })(<RangePicker style={{width:"100%"}} />)}
          </FormItem>
          <FormItem {...formItemLayout} label="标注颜色">
            {form.getFieldDecorator('color', {
              initialValue: currData.color,
              rules: [{ required: true, message: '请选择颜色' }],
            })(
              <Input type="color" />
            )}
          </FormItem>
          <FormItem {...formItemLayout} label="状态">
            {form.getFieldDecorator('status', {
              initialValue: currData.status,
              rules: [{ required: true, message: '请选择状态' }],
            })(
              <Select placeholder="请选择状态">
                <Option value={0}>进行中</Option>
                <Option value={1}>已完成</Option>
                <Option value={2}>已结束</Option>
              </Select>
            )}
          </FormItem>
          <FormItem {...formItemLayout} label="摘要">
            {form.getFieldDecorator('note', {
              initialValue: currData.note,
              rules: [{ required: true, message: '请选择摘要' }],
            })(<TextArea placeholder="请选择摘要" />)}
          </FormItem>
          <FormItem {...submitFormLayout} style={{ marginTop: 32 }}>
            <Button type="primary" htmlType="submit" loading={submitting}>
              保存
            </Button>
            <Button type="danger" style={{ marginLeft: 20 }} onClick={this.delete}>
              删除
            </Button>
            <Button style={{ marginLeft: 20 }} onClick={this.cancel}>
              取消
            </Button>
          </FormItem>
        </Form>
      </div>
    )
  };

  getRowsHeigth(){
    const {tableData} =  this.state;
    let acHeight = 1;
    let arHeight = 1;
    let itemHeight = 1;
    for(let i =0;i<tableData.length;i+=1){
      if(!isUndefined(tableData[i].activityList) && tableData[i].activityList.length > acHeight){
        acHeight = tableData[i].activityList.length;
      }
      if(!isUndefined(tableData[i].articleList) && tableData[i].articleList.length > arHeight){
        arHeight = tableData[i].articleList.length;
      }
      if(!isUndefined(tableData[i].itemList) && tableData[i].itemList.length > itemHeight){
        itemHeight = tableData[i].itemList.length;
      }
    }
    return {acHeight,arHeight,itemHeight};
  }

  render(){
    const {selectYear,selectMonth,scheduleTitle,visible,selected,trHeight,tdWidth,tableData} = this.state;
    const {acHeight,arHeight,itemHeight} = this.getRowsHeigth();
    return (
      <PageHeaderLayout>
        <Card style={{position:"relative"}}>
          <div style={{marginBottom:24}}>
            <Button type="primary" onClick={() => this.previousMonth(selectYear,selectMonth)}>上一月</Button>
            <b style={{display:"inline-block",margin:10}}>{selectYear}年{selectMonth+1}月</b>
            <Button type="primary" onClick={() => this.nextMonth(selectYear,selectMonth)}>下一月</Button>
            <div style={{float:"right"}}>
              <Button type="primary" onClick={this.addSchedule}>新增排档</Button>
            </div>
          </div>
          <div style={{overflow:"auto"}}>
            <table style={{position:"absolute",left:32,zIndex:20,background:"#fff"}} border="1">
              <thead>
                <tr style={{height:60}}>
                  <th style={{width:tdWidth}}>&nbsp;</th>
                </tr>
              </thead>
              <tbody>
                <tr style={{height:acHeight*trHeight}}>
                  <td style={{textAlign:"center"}}><h4>活动</h4></td>
                </tr>
                <tr style={{height:arHeight*trHeight}}>
                  <td style={{textAlign:"center"}}><h4>推文</h4></td>
                </tr>
                <tr style={{height:itemHeight*trHeight}}>
                  <td style={{textAlign:"center"}}><h4>事项</h4></td>
                </tr>
              </tbody>
            </table>
            <table>
              <tr>
                <td>
                  <div style={{width:106}}>&nbsp;</div>
                </td>
                {
                  isArray(tableData) && tableData.length > 0 ? tableData.map((tData,index) => (
                    <td key={index}>
                      <table style={{ width: (tData.monthDay) * tdWidth }} border="1">
                        <thead>
                          <tr style={{ height: 30 }}>
                            {
                            isArray(tData.headerDay) && tData.headerDay.length?tData.headerDay.map((o,i) => (
                              <th key={i} style={{ textAlign: 'center', width: tdWidth }}>
                                <div>{o}</div>
                              </th>
                            )):""
                          }
                          </tr>
                          <tr style={{ height: 30 }}>
                            {
                            isArray(tData.headerWeek) && tData.headerWeek.length?tData.headerWeek.map((o,i) => (
                              <th key={i} style={{ textAlign: 'center', width: tdWidth }}>
                                <div>{o}</div>
                              </th>
                            )):""
                          }
                          </tr>
                        </thead>
                        <tbody>
                          <tr style={{height:acHeight * trHeight}}>
                            <td>
                              <table>
                                {
                                  isArray(tData.activityList) && tData.activityList.length > 0 ? tData.activityList.map((obj) => (
                                    <tr style={{ height: trHeight }}>
                                      <td colSpan={tData.monthDay} style={{ position: 'relative' }} >
                                        {obj.map(data => (
                                          <div
                                            style={{
                                              position: 'absolute',
                                              left: (moment(data.beginTime).format('D') - 1) * tdWidth,
                                              top: 0,
                                              cursor: 'pointer',
                                            }}
                                            onClick={() => this.selectSchedule(data.schId)}
                                          >
                                            <div style={{
                                              background: data.color,
                                              width: data.colSpan * tdWidth,
                                              height: trHeight - 1,
                                              lineHeight: `${trHeight - 1}px`,
                                              textAlign: 'center',
                                            }}
                                            >{moment(data.beginTime).format('YYYY-MM-DD')}--{moment(data.endTime).format('YYYY-MM-DD')}
                                            </div>
                                            {selected === data.schId ? (
                                              <div style={{
                                                position: 'absolute',
                                                top: 0,
                                                left: 0,
                                                right: 0,
                                                bottom: 0,
                                                border: '2px solid blue',
                                              }}
                                              />
                                            ) : ''}
                                          </div>
                                        ))}
                                      </td>
                                    </tr>
                                  )) : ''
                                }
                              </table>
                            </td>
                          </tr>
                          {
                          isArray(tData.articleList) && tData.articleList.length > 0 ? tData.articleList.map((obj) => (
                            <tr style={{ height: trHeight }}>
                              <td colSpan={tData.monthDay} style={{ position: 'relative' }}>
                                {obj.map(data => (
                                  <div
                                    style={{
                                      position: 'absolute',
                                      left: (moment(data.beginTime).format('D') - 1) * tdWidth,
                                      top: 0,
                                      cursor: 'pointer',
                                    }}
                                    onClick={() => this.selectSchedule(data.schId)}
                                  >
                                    <div style={{
                                      background: data.color,
                                      width: data.colSpan * tdWidth,
                                      height: trHeight - 1,
                                      lineHeight: `${trHeight - 1}px`,
                                      textAlign: 'center',
                                    }}
                                    >{moment(data.beginTime).format('YYYY-MM-DD')}--{moment(data.endTime).format('YYYY-MM-DD')}
                                    </div>
                                    {selected === data.schId ? (
                                      <div style={{
                                        position: 'absolute',
                                        top: 0,
                                        left: 0,
                                        right: 0,
                                        bottom: 0,
                                        border: '2px solid blue',
                                      }}
                                      />
                                    ) : ''}
                                  </div>
                                ))}
                              </td>
                            </tr>
                          )) : ''
                        }
                          {
                          isArray(tData.itemList) && tData.itemList.length > 0 ? tData.itemList.map((obj) => (
                            <tr style={{ height: trHeight }}>
                              <td colSpan={tData.monthDay} style={{ position: 'relative' }}>
                                {obj.map(data => (
                                  <div
                                    style={{
                                      position: 'absolute',
                                      left: (moment(data.beginTime).format('D') - 1) * tdWidth,
                                      top: 0,
                                      cursor: 'pointer',
                                    }}
                                    onClick={() => this.selectSchedule(data.schId)}
                                  >
                                    <div style={{
                                      background: data.color,
                                      width: data.colSpan * tdWidth,
                                      height: trHeight - 1,
                                      lineHeight: `${trHeight - 1}px`,
                                      textAlign: 'center',
                                    }}
                                    >{moment(data.beginTime).format('YYYY-MM-DD')}--{moment(data.endTime).format('YYYY-MM-DD')}
                                    </div>
                                    {selected === data.schId ? (
                                      <div style={{
                                        position: 'absolute',
                                        top: 0,
                                        left: 0,
                                        right: 0,
                                        bottom: 0,
                                        border: '2px solid blue',
                                      }}
                                      />
                                    ) : ''}
                                  </div>
                                ))}
                              </td>
                            </tr>
                          )) : ''
                        }
                        </tbody>
                      </table>
                    </td>

                  )):""
                }
              </tr>
            </table>


          </div>


        </Card>
        <Modal width="50%" title={scheduleTitle} visible={visible} footer={null} onCancel={() => this.setState({ visible: false })}>
          {this.scheduleEditModal()}
        </Modal>
      </PageHeaderLayout>
    )
  }
}
