/* eslint-disable react/sort-comp,no-debugger,no-shadow */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Select,
  Button,
  Modal,
  message,
  Radio,
} from 'antd';
import { isArray } from 'lodash';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from './selfMenu.less';
import { getStore } from '../../assets/js/mUtils';
import SelectActivityList from '../../assets/js/SelectActivityList';
import KeywordList from '../../assets/js/keyword';


const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const {Option} = Select;
const {confirm} = Modal;
const getValue = obj =>
  Object.keys(obj)
    .map(key => obj[key])
    .join(',');

@connect(({ pageManage, selfMenu, autoReply, loading }) => ({
  pageManage,
  selfMenu,
  autoReply,
  loading: loading.models.selfMenu,
}))
@Form.create()
export default class selfMenu extends PureComponent {
constructor(props){
  super(props);
  this.state = {
    maxMenuNum: 3, // 一级菜单最大数
    maxSubMenuNum: 5, // 二级菜单最大数
    type: 'click', // 默认
    selectIndex: 0, // 默认选中的父菜单索引
    selectSubIndex: -1, // 默认选中的子菜单索引
    currMenu: {},
    menuList: [],
    selectedRows: [],
    formValues: {},
    activityFormValues:{},
    isShowActivityModal:false,
    isShowKeywordModal:false,
    activityName:"",
    keyword:"",
  };
}


  menuModel = {
    name: '+ 新增菜单',
    type: 'click',
    _id: -1,
    subMenuList: [],
  };

  subMenuModel = {
    name: '+ 新增子菜单',
    type: 'click',
    _id: -1,
  };


  componentDidMount() {
    const { dispatch } = this.props;
    const params = {
      pageNo: 1,
      pageSize: 99999,
      type:1,
    };
    dispatch({
      type: 'pageManage/pageList',
      payload: params,
    });
    dispatch({
      type: 'selfMenu/authListFetch',
      payload: { adminUserId: JSON.parse(getStore('userInfo')).user.adminUserId },
    });
    this.getMenuList();
  }

  /**
   * 获取初始化数据
   */
  getMenuList = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'selfMenu/menuListFetch',
      payload: {},
    }).then(() => {
      const {
        selfMenu: {
          menuList: { data },
        },
      } = this.props;
      if(data){
        this.setState({
          menuList: data,
          selectIndex: 0,
          selectSubIndex: -1,
          currMenu: data[0],
          type: data[0].type,
        });
      }
    });
  };

  /**
   * 保存
   * @param e
   */
  save = e => {
    const { dispatch,form:{validateFieldsAndScroll} } = this.props;
    const that = this;
    e.preventDefault();
    validateFieldsAndScroll((err, values) => {
      if (!err) {
        const { selectIndex, selectSubIndex, menuList, type, currMenu } = that.state;
        let data;
        if (selectSubIndex === -1) {
          data = menuList[selectIndex];
        } else {
          data = menuList[selectIndex].subMenuList[selectSubIndex];
        }
        data.name = values.name;
        data.keyword = values.keyword;
        data.orderNo = values.orderNo;
        data.url = values.url;
        data.pagepath = values.pagepath;
        data.pageParams = currMenu.activityId ? `?activityId=${  currMenu.activityId}` : currMenu.pageParams;
        data.miniId = values.miniId;
        data.type = type;
        let uri;
        let content;
        if (Object.prototype.hasOwnProperty.call(data, 'selfMenuId') && data.selfMenuId !== null && data.selfMenuId !== '') {
          uri = 'selfMenu/menuUpdateFetch';
          content = "修改成功";
        } else {
          uri = 'selfMenu/menuAddFetch';
          content = "保存成功";
        }
        dispatch({
          type: uri,
          payload: data,
        })
          .then(res => {
            if (res.code === '200') {
              message.success(content);
              that.getMenuList();
            }
          })
          .catch(error => {
            message.error(error.msg);
          });
      }
    });
  };

  /**
   * 当selfMenuId为null时，作前端删除，否则提交后台删除
   */
  deleteMenu = () => {
    const { dispatch } = this.props;
    const { selectIndex, selectSubIndex, menuList, currMenu } = this.state;
    const that = this;
    confirm({
      title: '提示',
      content: '是否删除该菜单？',
      okText: '删除',
      okType: 'danger',
      cancelText: '取消',
      onOk() {
        if (
          Object.prototype.hasOwnProperty.call(currMenu, 'selfMenuId') &&
          currMenu.selfMenuId !== null &&
          currMenu.selfMenuId !== ''
        ) {
          dispatch({
            type: 'selfMenu/menuDeleteFetch',
            payload: { selfMenuId: currMenu.selfMenuId },
          })
            .then(res => {
              if (res.code === '200') {
                message.success('删除成功');
                that.getMenuList();
              }
            })
            .catch(err => {
              message.error(err.msg);
            });
        } else {
          if (selectSubIndex === -1) {
            menuList.splice(selectIndex, 1);
          } else {
            menuList[selectIndex].subMenuList.splice(selectSubIndex, 1);
          }
          that.getMenuList();
        }
      },
    });
  };

  /**
   * 校验菜单是否保存
   * @param menuList
   * @returns {boolean} true 未保存，false 已保存
   */
  validateMenu = (menuList) => {
    for (let i = 0; i < menuList.length;i+=1) {
      if (!menuList[i].selfMenuId) {
        return true;
      }
      for (let j = 0; j < menuList[i].subMenuList.length; j+=1) {
        if (!menuList[i].subMenuList[j].selfMenuId) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * 子菜单点击事件
   * @param e
   * @param data 子菜单数据对象
   * @param index 子菜单索引
   * @param parentIndex 所在父菜单的索引
   */
  subMenuClick = (e, data, index, parentIndex) => {
    e.stopPropagation();
    const { menuList } = this.state;
    if (this.validateMenu(menuList)) {
      message.info('请先保存/删除当前菜单');
      return;
    }
    const {
      form: { resetFields },
    } = this.props;
    resetFields();
    let currMenu; let selectSubIndex;
    if (Object.prototype.hasOwnProperty.call(data, '_id') && index === menuList[parentIndex].subMenuList.length) {
      currMenu = data;
      currMenu.name = `子菜单${  index}`;
      selectSubIndex = 0;
      const subItem = JSON.parse(JSON.stringify(this.subMenuModel));
      subItem.parentSelfMenuId = menuList[parentIndex].selfMenuId;
      menuList[parentIndex].subMenuList.unshift(subItem);
    } else {
      currMenu = menuList[parentIndex].subMenuList[index];
      selectSubIndex = index;
    }
    this.setState({
      currMenu,
      selectIndex: parentIndex,
      selectSubIndex,
      type: data.type,
      menuList,
    });
  }

  /**
   *
   * @param data
   * @param index
   * @returns {*}
   */

  subMenuList = (data, index) => {
    const subMenuModels = this.subMenuModel;
    const { selectIndex, selectSubIndex,maxSubMenuNum } = this.state;
    return (
      <div
        className={styles.subMenuBox}
        style={{
          top:
            data.length < maxSubMenuNum
              ? `-${  (data.length + 1) * 51 + 20  }px`
              : `-${  data.length * 51 + 20  }px`,
        }}
      >
        {data.length < maxSubMenuNum ? (
          <div
            className={styles.subMenuBtn}
            onClick={e => this.subMenuClick(e, subMenuModels, data.length, index)}
          >
            + 子菜单
          </div>
        ) : (
          <div />
        )}
        {data?data.map((item, i) => (
          <div
            key={item.selfMenuId}
            className={styles.subMenuBtn}
            onClick={e => this.subMenuClick(e, item, i, index)}
          >
            {item.name == null || item.name === '' ? '菜单' : item.name}
            <div
              className={selectIndex === index && selectSubIndex === i ? styles.selectSubMenuBtn : ''}
            />
          </div>
        )):""}
        <div className={styles.arrowBottom} />
      </div>
    );
  }

  /**
   * 主菜单点击
   * @param data
   * @param i 点击当前菜单的索引
   */
  onMenuClick = (data, i) => {
    const { menuList } = this.state;
    if (this.validateMenu(menuList)) {
      message.info('请先保存/删除当前菜单');
      return;
    }
    const {
      form: { resetFields },
    } = this.props;
    resetFields();
    let currMenu;
    if (Object.prototype.hasOwnProperty.call(data, '_id') && i === menuList.length) {
      currMenu = data;
      currMenu.name = `菜单${  i}`;
      menuList.push(JSON.parse(JSON.stringify(data)));
    } else {
      currMenu = menuList[i];
    }
    this.setState({ currMenu, selectIndex: i, selectSubIndex: -1, type: data.type, menuList });
  };

  /**
   * 主菜单栏
   */
  selfMenuList = () => {
    const { menuList, selectIndex, selectSubIndex, maxMenuNum} = this.state;

    return (
      <div style={{ flex: 1 }}>
        {isArray(menuList) && menuList.length > 0 ? (
          menuList.map((item, i) => (
            <div key={item.selfMenuId} className="menuBtn" onClick={() => this.onMenuClick(item, i)}>
              {this.subMenuList(item.subMenuList, i)}
              {item.name == null || item.name === '' ? '菜单' : item.name}
              <div className={selectIndex === i && selectSubIndex === -1 ? styles.selectBtn : ''} />
            </div>
          ))
        ) : (
          <div />
        )}
        {menuList.length < maxMenuNum ? (
          <div
            className="menuBtn"
            onClick={() => this.onMenuClick(this.menuModel, menuList.length)}
          >
            + 主菜单
          </div>
        ) : (
          <div />
        )}
      </div>
    );
  };

  /**
   * 公众号菜单面板
   * @returns {*}
   */
  menuModal = () => {
    return (
      <div>
        <div
          style={{
            width: "100%",
            height: 40,
            background: '#000',
            color: '#fff',
            textAlign: 'center',
            lineHeight: "40px",
          }}
        >
          公众号
        </div>
        <div style={{ width: "100%", minHeight: 410, background: '#aaa' }} />
        <div className="left-modal-foot">
          <div style={{ width: 50, borderRight: '1px solid #ddd', height: 50,textAlign:"center", lineHeight:"50px"}}>
            <span className="iconfont icon-keyboard" style={{fontSize:35}} />
          </div>
          {this.selfMenuList()}
        </div>
      </div>
    );
  };

  nameChange = e => {
    const { selectIndex, selectSubIndex, menuList } = this.state;
    if (selectSubIndex === -1) {
      menuList[selectIndex].name = e.target.value;
    } else {
      menuList[selectIndex].subMenuList[selectSubIndex].name = e.target.value;
    }
  };

  /**
   * 选择菜单内容
   * @param e
   */
  menuContentChange = e => {
    const {currMenu} = this.state;
    currMenu.miniId = "";
    currMenu.pagepath = "";
    this.setState({ type: e.target.value,currMenu });
  };

  /**
   * 同步菜单
   */
  syncMenu = () => {
    const {dispatch} = this.props;
    const that = this;
    confirm({
      title: '提示',
      content: '是否同步菜单？',
      okText: '同步',
      okType: 'danger',
      cancelText: '取消',
      onOk() {
          dispatch({
            type: 'selfMenu/menuSyncMenuFetch',
            payload: {},
          }).then(res => {
              if (res.code === '200') {
                message.success('同步成功');
                that.getMenuList();
              }
            })
            .catch(err => {
              message.error(err.msg);
            });
        },
      });
  };

  /**
   * 选择不程序
   * @param e
   */
  selectMiniId = (e) => {
    const {currMenu} = this.state;
    currMenu.miniId = e;
    this.setState({currMenu});
  };

  /**
   * 选择小程序页面
   * @param e
   */
  pagePathChange = (e) => {
    const {currMenu} = this.state;
    currMenu.pagepath = e;
    this.setState({currMenu});
  };


  /**
   * 菜单编辑
   */
  menuEdit() {
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 24 },
        md: { span: 4 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 24 },
        md: { span: 7 },
      },
    };
    const { type, currMenu,selectSubIndex } = this.state;
    const { pageManage, selfMenu: { authorizerList }, form: { getFieldDecorator },loading} = this.props;
    return (
      <div>
        <div className={styles.rightHd}>
          <div>编辑菜单</div>
          <div>
            <Button type="primary" onClick={() => this.syncMenu()}>同步菜单</Button>
          </div>
        </div>
        <Card style={{ marginTop: 10, minHeight: 460 }}>
          <Form onSubmit={this.save}>
            <FormItem {...formItemLayout} label="菜单名称">
              {selectSubIndex === -1?
                getFieldDecorator('name', { initialValue: currMenu?currMenu.name:"" })(<Input onChange={e => this.nameChange(e)} maxLength={4} />)
                :getFieldDecorator('name', { initialValue: currMenu?currMenu.name:"" })(<Input onChange={e => this.nameChange(e)} maxLength={7} />)}

            </FormItem>
            <FormItem wrapperCol={{sm:{ span: 20 }}} labelCol={{ xs: { span: 24 }, sm: { span: 24 }, md: { span: 4 } }} label="菜单内容">
              {getFieldDecorator('type', {
                initialValue: type,
              })(
                <RadioGroup id="type1" onChange={e => this.menuContentChange(e)}>
                  <Radio value="click">发送信息</Radio>
                  <Radio value="view">跳转链接</Radio>
                  <Radio value="miniprogram">小程序</Radio>
                </RadioGroup>
              )}
            </FormItem>
            {type === 'click' ? (
              <FormItem {...formItemLayout} label="关键词">
                {getFieldDecorator('keyword', {
                  initialValue:currMenu?currMenu.keyword:"",
                })(
                  <div style={{position: "relative"}}>
                    <Input
                      maxLength={0}
                      placeholder="请选择关键词"
                      onClick={() => this.getKeywordList()}
                      value={currMenu?currMenu.keyword:""}
                    />
                    <span className="iconfont icon-arrow_down" style={{position: "absolute",top:4,right:10}} />
                  </div>
                )}
              </FormItem>
            ) : type === 'view' ? (
              <FormItem {...formItemLayout} label="页面地址">
                {getFieldDecorator('url', {
                  initialValue: currMenu?(currMenu.url?currMenu.url:"http://shitan.me"):"",
                })(<Input />)}
              </FormItem>
            ) : (
              <div>
                <FormItem wrapperCol={{md:{ span: 20 }}} labelCol={{ xs: { span: 24 }, sm: { span: 24 }, md: { span: 4 } }} label="小程序选择">
                  <Row>
                    <Col md={8} sm={24} xs={24}>
                      {getFieldDecorator('miniId', {
                        initialValue: currMenu?currMenu.miniId:"",
                      })(
                        <Select style={{width:"100%"}} onChange={e => this.selectMiniId(e)} placeholder="请选择小程序">
                          <Option value="">请选择小程序</Option>
                          {(isArray(authorizerList.data) && authorizerList.data.length > 0) ? authorizerList.data.map((item) => (<Option value={item.id} key={item.id}>{item.nickName}</Option>)):""}
                        </Select>
                      )}
                    </Col>
                    {
                      (currMenu && currMenu.miniId !== "" && currMenu.miniId != null) ? (
                        <Col md={8} sm={24} xs={24}>
                          {getFieldDecorator('pagepath', {
                            initialValue: currMenu?currMenu.pagepath:"",
                          })(
                            <Select onChange={e => this.pagePathChange(e)} style={{width:"100%"}} placeholder="请选择页面">
                              <Option value="">请选择页面</Option>
                              { (isArray(pageManage.data.list) && pageManage.data.list.length > 0)?pageManage.data.list.map((item) => <Option value={item.path} key={item.id}>{item.name}</Option>):""}
                            </Select>
                          )}
                        </Col>
                      ):""
                    }
                    {
                      currMenu&&currMenu.pagepath !== ""&& currMenu.pagepath !=null? (
                        <Col md={8} sm={24} xs={24}>
                          {getFieldDecorator('activityName', {
                            initialValue: currMenu?currMenu.activityName:"",
                          })(
                            <div style={{position: "relative",width:"100%",display:"inline-block"}}>
                              <Input
                                maxLength={0}
                                placeholder="请选择活动"
                                onClick={this.getActivityList}
                                value={currMenu?currMenu.activityName:""}
                              />
                              <span className="iconfont icon-arrow_down" style={{position: "absolute",top:4,right:10}} />
                            </div>
                          )}
                        </Col>
                      ):""
                    }
                  </Row>

                </FormItem>
                <FormItem {...formItemLayout} label="页面地址">
                  {getFieldDecorator('url', {
                    initialValue: currMenu?(currMenu.url?currMenu.url:"http://shitan.me"):"",
                  })(<Input />)}
                </FormItem>
              </div>
            )}
            <FormItem {...formItemLayout} label="排序号">
              {getFieldDecorator('orderNo', {
                initialValue: currMenu?(currMenu.orderNo?currMenu.orderNo:0):"",
              })(<Input />)}
            </FormItem>
            <FormItem wrapperCol={{ md: { span: 20, offset: 4 },sm: { span: 24 } }}>
              <Button loading={loading} type="primary" htmlType="submit">
                保存
              </Button>
              <Button onClick={this.deleteMenu} style={{ marginLeft: 20 }}>
                删除
              </Button>
            </FormItem>
          </Form>
        </Card>
      </div>
    );
  }

  /**
   * 获取关键词列表，打开模态框
   */
  getKeywordList = () => {
    const {dispatch}=this.props;
    const {keyword} = this.state;
    const params = {
      pageNo: 1,
      type:"0",
      state:"1",
      keyword:keyword?keyword.replace(/\s/gi,''):"",
      pageSize: 10,
    };
    dispatch({
      type:"selfMenu/keywordListFetch",
      payload:params,
    }).then(() => {
      this.setState({isShowKeywordModal:true})
    })
  };

  /**
   * 选中关键词
   * @param res
   */
  selectedKeyword = (res) => {
    const { currMenu } = this.state;
    currMenu.keyword = res.keyword;
    currMenu.autoReplyId = res.autoReplyId;
    this.setState({ currMenu, isShowKeywordModal: false });
  };

  /**
   * 关键词分页
   * @param pagination
   * @param filtersArg
   * @param sorter
   */

  keywordPaginationChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      type:0,
      state:1,
      ...formValues,
      ...filters,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }

    dispatch({
      type: 'selfMenu/keywordListFetch',
      payload: params,
    });
  };

  /**
   * 请选择活动
   */
  getActivityList = () => {
    const { dispatch } = this.props;
    const {activityName} = this.state;
    dispatch({
      type: 'selfMenu/activityListFetch',
      payload: { pageNo: 1, pageSize: 10,activityName:activityName?activityName.replace(/\s/gi,''):""},
    }).then(() => {
      this.setState({ isShowActivityModal: true });
    });
  };

  /**
   * 活动翻页
   * @param pagination
   * @param filtersArg
   * @param sorter
   */
  activityPaginationChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { activityFormValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});
    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...activityFormValues,
      ...filters,
    };
    activityFormValues.pageNo=pagination.current;
    this.setState({
      activityFormValues,
    })
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'selfMenu/activityListFetch',
      payload: params,
    });
  };

  /**
   * 选中活动
   * @param data
   */
  selectedActivity = (data) => {
    const { currMenu } = this.state;
    currMenu.activityName = data.activityName;
    currMenu.activityId = data.activityId;
    this.setState({ currMenu, isShowActivityModal: false });
  };

  render() {
    const { selfMenu,loading } = this.props;
    const { isShowActivityModal ,selectedRows,isShowKeywordModal} = this.state;
    const keywordFun=e=>{
      this.setState({
        keyword:e.target.value,
      })
    };
    const activityFun=e=>{
      this.setState({
        activityName:e.target.value,
      })
    };
    return (
      <PageHeaderLayout>
        <Row className={styles.selfMenuBd}>
          <Col className={styles.selfMenuBdLeft}>{this.menuModal()}</Col>
          <Col className={styles.selfMenuBdRight}>{this.menuEdit()}</Col>
        </Row>
        <Row>
          <Card style={{ background: 'transparent' }}>
            注意：<br />
            &nbsp;&nbsp;&nbsp;&nbsp;1、自定义菜单最多包括3个一级菜单，每个一级菜单最多包含5个二级菜单。<br />
            &nbsp;&nbsp;&nbsp;&nbsp;2、一级菜单最多4个汉字，二级菜单最多7个汉字，多出来的部分将会以“...”代替。<br />
            &nbsp;&nbsp;&nbsp;&nbsp;3、菜单刷新策略，距离上一次进入菜单5分钟，或取消关注，重新关注进入会刷新菜单。
          </Card>
        </Row>

        <Modal width="70%" title="活动列表" visible={isShowActivityModal} footer={null} onCancel={() => this.setState({ isShowActivityModal: false,activityName:"" })}>
          <SelectActivityList activityList={selfMenu.activityList} loading={loading} selectedRows={selectedRows} onSelectedActivity={this.selectedActivity} activityChange={this.activityPaginationChange} getActivityList={this.getActivityList} activityFun={activityFun} />
        </Modal>
        <Modal width="70%" title="关键词列表" visible={isShowKeywordModal} footer={null} onCancel={() => this.setState({ isShowKeywordModal: false,keyword:"" })}>
          <KeywordList keywordList={selfMenu.keywordList} loading={loading} selectedRows={selectedRows} onSelectKeyWord={this.selectedKeyword} keyWordChange={this.keywordPaginationChange} getKeywordList={this.getKeywordList} keywordFun={keywordFun} />
        </Modal>
      </PageHeaderLayout>
    );
  }
}
