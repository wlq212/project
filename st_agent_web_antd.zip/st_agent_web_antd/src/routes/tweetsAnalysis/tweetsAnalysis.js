/* eslint-disable no-unused-vars,react/destructuring-assignment,react/no-unused-state,class-methods-use-this,no-undef,no-shadow,react/sort-comp,prefer-destructuring,react/no-access-state-in-setstate,default-case,no-prototype-builtins,no-const-assign */
import React, { Component, Fragment } from 'react';
import { connect } from 'dva';
import {
  Row,
  Col,
  Card,
  Table,
  Radio,
  DatePicker,
  Tooltip,
  List,
  Select,
  } from 'antd';
import {
  ChartCard,
  yuan,
  MiniArea,
  MiniBar,
  MiniProgress,
  Field,
  Bar,
  Pie,
  TimelineChart,
} from 'components/Charts';
import moment from 'moment';
import { getTimeDistance } from '../../utils/utils';
import styles from './tweetsAnalysis.less';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import { getStore } from '../../assets/js/mUtils';

const { RangePicker } = DatePicker;
const rankingListData = [];
for (let i = 0; i < 7; i += 1) {
  rankingListData.push({
    title: `工专路 ${i} 号店`,
    total: 323234,
  });
}
@connect(({ tweetsAnalysis, loading }) => ({
  tweetsAnalysis,
  loading: loading.models.tweetsAnalysis,
}))
export default class Analysis extends Component {
  constructor(props) {
    super(props);
    this.state = {
      salesType: '0',
      downModel: false,
      activityModel: false,
      channelModel: false,
      channel: '',
      activity:"",
      selectedRows: [],
      currentTabKey: '',
      numberName:"阅读量",
      rateName:"阅读率",
      positionName:"intPageReadUser",
      position0:"refDate*intPageReadUser",
      positionName1:"readRate",
      position1:"refDate*readRate",
      formValues: {
        pageNo: 1,
        pageSize: 10,
      },
      initMap:[{
        title:"",
        refDate:moment(Date.now()).format('YYYY-MM-DD'),
        intPageReadUser:0,
        readRate:0,
        sharingAndCollection: 0,
        contentRate: 0,
        targetUser: 0,
        commentCount: 0,
        interactRate: 0,
        unSubscribeUser: 0,
        unSubscribeRate: 0,
        sessionReadUser: 0,
        sessionReadRate:0,
      }],
      formValuesActivity: {
        pageNo: 1,
        pageSize: 10,
      },
      search:{
        beginTime:getTimeDistance('month')[0].format('YYYY-MM-DD'),
        endTime:getTimeDistance('month')[1].format('YYYY-MM-DD'),
      },
      rangePickerValue: getTimeDistance('month'),
    };
    this.handleDownCancel = this.handleDownCancel.bind(this);
    this.handleActivityCancel = this.handleActivityCancel.bind(this);
    this.handleChannelCancel = this.handleChannelCancel.bind(this);
    this.hanndleDownModelActivity=this.hanndleDownModelActivity.bind(this);
    this.hanndleDownModelChannel=this.hanndleDownModelChannel.bind(this);
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'tweetsAnalysis/dataCountChannelAnalysisList',
      payload:this.state.search,
    })
  }

  componentWillUnmount() {

  }

  pageOnChange=(pagination, filtersArg) =>{
    const {dispatch}=this.props;
    this.state.search.pageNo=pagination;
    this.state.search.pageSize=filtersArg;
    this.setState({
      search: this.state.search,
    });
    dispatch({
      type: 'tweetsAnalysis/dataCountChannelAnalysisList',
      payload:this.state.search,
    })
  };

  handleStandardTableChangeChannel = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    params.pageNo = pagination.current;
    params.pageSize = pagination.pageSize;
    this.setState({
      formValues: params,
    });
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'tweetsAnalysis/qrcodeListFetch',
      payload: params,
    });
  };

  showTooltip(tooltip,x,y){

  };

  handleChannelCancelActivity = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValuesActivity } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValuesActivity,
      ...filters,
    };
    params.pageNo = pagination.current;
    params.pageSize = pagination.pageSize;
    this.setState({
      formValuesActivity: params,
    });
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'tweetsAnalysis/fetchActivity',
      payload: params,
    });
  };

  // 下载模太框关闭
  handleDownCancel() {
    this.setState({
      downModel: false,
    });
  }

  handleActivityCancel() {
    this.setState({
      activityModel: false,
    });
  }

  hanndleDownModelActivity(){
    this.setState({
      activityModel: true,
    });
  }

  handleChannelCancel() {
    this.setState({
      channelModel: false,
    });
  }

  handleChannelSubmit() {

  }

  handleActivitySubmit() {

  }

  // 下载提交
  handleDownSubmit() {

  }

  showDownModel = () => {
    this.setState({
      downModel: true,
    });
  };

  showActivityModel = () => {
    this.setState({
      activityModel: true,
    });
  };

  hanndleDownModelChannel=()=>{
    this.setState({
      channelModel: true,
    });
  };

  showChannelModel = () => {
    this.setState({
      channelModel: true,
    });
  };


  handleChangeSalesType = e => {
    const that=this;
    switch (e.target.value) {
      case "0":
        that.setState({
          numberName:"阅读量",
          rateName:"阅读率",
          positionName:"intPageReadUser",
          position0:"refDate*intPageReadUser",
          positionName1:"readRate",
          position1:"refDate*readRate",
        });
        break;
      case "1":
        that.setState({
          numberName:"非扫码取关",
          rateName:"非扫码取关率",
          positionName:"unSubscribeUser",
          position0:"refDate*unSubscribeUser",
          positionName1:"unSubscribeRate",
          position1:"refDate*unSubscribeRate",
        });
        break;
      case "2":
        that.setState({
          numberName:"公众号会话阅读",
          rateName:"标题题图指数",
          positionName:"sessionReadUser",
          position0:"refDate*sessionReadUser",
          positionName1:"sessionReadRate",
          position1:"refDate*sessionReadRate",
        });
        break;
      case "3":
        that.setState({
          numberName:"分享与收藏",
          rateName:"内容指数",
          positionName:"sharingAndCollection",
          position0:"refDate*sharingAndCollection",
          positionName1:"contentRate",
          position1:"refDate*contentRate",
        });
        break;
      case "4":
        that.setState({
          numberName:"留言数",
          rateName:"互动指数",
          positionName:"commentCount",
          position0:"refDate*commentCount",
          positionName1:"interactRate",
          position1:"refDate*interactRate",
        });
        break;
    }
    this.setState({
      salesType: e.target.value,
    });
  };

  handleTabChange = key => {
    this.setState({
      currentTabKey: key,
    });
  };

  handleRangePickerChange = rangePickerValue => {
    this.setState({
      rangePickerValue,
    });
    const { dispatch } = this.props;
    if(rangePickerValue.length>0){
      this.state.search.beginTime=rangePickerValue[0].format('YYYY-MM-DD');
      this.state.search.endTime=rangePickerValue[1].format('YYYY-MM-DD');
    }
    this.setState({
      search:this.state.search,
    });
    dispatch({
      type: 'tweetsAnalysis/dataCountChannelAnalysisList',
      payload:this.state.search,
    })
  };



  selectActivity=(data)=> {
    const  {dispatch}=this.props;
    if(this.state.downModel){
      this.setState({
        modelActivity: data.activityName,
        activityModel:false,
      });
    }else{
      this.state.search.activityId=data.activityId;
      this.setState({
        activity: data.activityName,
        search: this.state.search,
        activityModel:false,
      });
      dispatch({
        type: 'tweetsAnalysis/dataCountChannelAnalysisList',
        payload:this.state.search,
      })
    }
  };

  typeChange=(e)=>{
    const  {dispatch}=this.props;
    this.state.search.channelType=e;
    this.setState({
      type: e,
      search: this.state.search,
    });
    dispatch({
      type: 'tweetsAnalysis/dataCountChannelAnalysisList',
      payload:this.state.search,
    })
  };

  typeChangeModel=(e)=>{
    this.setState({
      typeModel: e,
    });
  };

  shopChangeModel=(e)=>{
    this.setState({
      shopModel: e,
    });
  };



  shopChange=(e)=>{
    const  {dispatch}=this.props;
    this.state.search.sId=e;
    this.setState({
      shop: e,
      search:this.state.search,
    });
    dispatch({
      type: 'tweetsAnalysis/dataCountChannelAnalysisList',
      payload:this.state.search,
    })
  };

  selectDate = type => {
    this.setState({
      rangePickerValue: getTimeDistance(type),
    });
    this.state.search.beginTime=getTimeDistance(type)[0].format('YYYY-MM-DD');
    this.state.search.endTime=getTimeDistance(type)[1].format('YYYY-MM-DD');
    const { dispatch } = this.props;
    this.setState({
      search:this.state.search,
    });
    dispatch({
      type: 'tweetsAnalysis/dataCountChannelAnalysisList',
      payload:this.state.search,
    });
  };

  isActive(type) {
    const { rangePickerValue } = this.state;
    const value = getTimeDistance(type);
    if (!rangePickerValue[0] || !rangePickerValue[1]) {
      return;
    }
    if (
      rangePickerValue[0].isSame(value[0], 'day') &&
      rangePickerValue[1].isSame(value[1], 'day')
    ) {
      return styles.currentDate;
    }
  }

  render() {
    const { rangePickerValue, salesType} = this.state;
    const { tweetsAnalysis, loading } = this.props;
    const salesExtra = (
      <div className={styles.salesExtraWrap}>
        <div className={styles.salesExtra}>
          <a className={this.isActive('week')} onClick={() => this.selectDate('week')}>
            最近7天
          </a>
          <a className={this.isActive('selfMonth')} onClick={() => this.selectDate('selfMonth')}>
            最近15天
          </a>
          <a className={this.isActive('month')} onClick={() => this.selectDate('month')}>
            最近30天
          </a>
        </div>
        <RangePicker
          value={rangePickerValue}
          disabledDate={current => {
            return current.isAfter();
          }}
          onChange={this.handleRangePickerChange}
          style={{ width: 256 }}
        />
      </div>
    );
    const columns = [{
      width: '7%',
      title: '文章标题',
      key:"title",
      dataIndex: 'title',
    }, {
      title: '文章群发日期',
      width: '10%',
      key:"refDate",
      dataIndex: 'refDate',
      render:(text, record) => (
        <span>{ moment(record.refDate).format('YYYY-MM-DD')}</span>
      ),
    },{
      width: '7%',
      title: '送达人数',
      key:"targetUser",
      dataIndex: 'targetUser',
    }, {
      title: '阅读量',
      width: '20%',
      children: [
        {
          title: '阅读量',
          key:"intPageReadUser",
          dataIndex: 'intPageReadUser',
        },
        {
          title: '阅读率',
          key:"readRate",
          dataIndex: 'readRate',
          render: (text) =>text?`${text}%`:"--",
        },
      ],
    }, {
      title: '非扫码取关',
      children: [
        {
          title: '非扫码取关人数',
          key:"oldNumber",
          dataIndex: 'unSubscribeUser',
        },
        {
          title: '非扫码取关率',
          key:"unSubscribeRate",
          dataIndex: 'unSubscribeRate',
          render: (text) =>text?`${text}%`:"--",
        },
      ],
    },
      {
        title: '公众号会话阅读',
        children: [
          {
            title: '公众号会话阅读人数',
            key:"sessionReadUser",
            dataIndex: 'sessionReadUser',
          },
          {
            title: '标题题图指数',
            key:"sessionReadRate",
            dataIndex: 'sessionReadRate',
            render: (text) =>text?`${text}%`:"--",
          },
        ],
      }, {
        title: '分享与收藏',
        children: [
          {
            title: '分享与收藏人数',
            key:"sharingAndCollection",
            dataIndex: 'sharingAndCollection',
          },
          {
            title: '内容指数',
            key:"contentRate",
            dataIndex: 'contentRate',
            render: (text) =>text?`${text}%`:"--",
          },
        ],
      },
      {
        title: '留言',
        children: [
          {
            title: '留言数',
            key:"commentCount",
            dataIndex: 'commentCount',
          },
          {
            title: '互动指数',
            key:"interactRate",
            dataIndex: 'interactRate',
            render: (text) =>text?`${text}%`:"--",
          },
        ],
      }];
    const { Chart, Geom, Axis, Tooltip, Legend, View} = window.BizCharts;
    function pick(data, field) {
      return data.map((item) => {
        const result = {};
        for (const key in item) {
          if (item.hasOwnProperty(key) && field.indexOf(key) !== -1) {
            result[key] = item[key];
          }
        }
        return result;
      });
    }
    const scale = {
      refDate: {
        alias: '文章群发日期',
        type: 'time',
        mask: 'YYYY-MM-DD',
      },
      intPageReadUser: {
        min: 0,
        alias: "阅读量",
      },
      readRate:{
        min: 0,
        alias: "阅读率",
        formatter(value) {
          return `${value}%`;
        },
      },
      sharingAndCollection:{
        min:0,
        alias:"收藏与分享人数",
      },
      contentRate:{
        min:0,
        alias:"内容指数",
        formatter(value) {
          return `${value}%`;
        },
      },
      targetUser:{
        min: 0,
        alias:"送达人数",
      },
      commentCount:{
        min: 0,
        alias:"留言数",
      },
      interactRate:{
        min:0,
        alias:"互动指数",
        formatter(value) {
          return `${value}%`;
        },
      },
      unSubscribeUser:{
        min: 0,
        alias:"非扫码取关人数",
      },
      unSubscribeRate:{
        min: 0,
        alias:"非扫码取关率",
        formatter(value) {
          return `${value}%`;
        },
      },
      sessionReadUser:{
        min:0,
        alias:"公众号阅读人数",
      },
      sessionReadRate:{
        min:0,
        alias:"标题题图指数",
        formatter(value) {
          return `${value}%`;
        },
      },
    };
    const reqStr = {

    };
    if(this.state.search.activityId){
      reqStr.activityId = this.state.search.activityId;
    }
    if(this.state.search.dId){
      reqStr.dId = this.state.search.dId;
    }
    reqStr.beginTime = moment(this.state.search.beginTime).format("YYYY-MM-DD");
    reqStr.endTime = moment(this.state.search.endTime).format("YYYY-MM-DD");
    if(this.state.search.qrCodeId){
      reqStr.qrCodeId = this.state.search.qrCodeId;
    }
    if(this.state.search.sId){
      reqStr.sId = this.state.search.sId;
    }
    if(this.state.search.channelType){
      reqStr.channelType = this.state.search.channelType;
    }

    const url={};
    if(getStore("userInfo")){
      url.url=`/api/admin/article/exportExcel?reqStr=${JSON.stringify(reqStr)}&token=${JSON.parse(getStore("userInfo")).token}`;
    }
    return (
      <PageHeaderLayout title="">
        <Fragment>
          <List loading={loading}>
            <Card
              bordered={false}
              bodyStyle={{ padding: 0 }}
              extra={salesExtra}
            >
              <div className={styles.salesCard}>
                <Radio.Group
                  value={salesType}
                  onChange={this.handleChangeSalesType}
                  style={{ marginTop: '20px', marginLeft: '30px' }}
                >
                  <Radio.Button value="0">阅读量</Radio.Button>
                  <Radio.Button value="1">非扫码取关</Radio.Button>
                  <Radio.Button value="2">公众号会话阅读</Radio.Button>
                  <Radio.Button value="3">分享与收藏</Radio.Button>
                  <Radio.Button value="4">留言</Radio.Button>
                </Radio.Group>
                <Row>
                  <Col xl={24} lg={24} md={24} sm={24} xs={24}>
                    <div>
                      <div style={{ marginTop: '20px',width:"97%"}}>
                        <div className={styles.salesBar}>
                          {
                           <Chart
                              height={400}
                              padding={[20, 70, 80, 40]}
                              forceFit
                              scale={{time: {sync: true}}}
                            >
                              <Tooltip />
                              <Legend />
                              <View
                                data={pick(tweetsAnalysis.channelAnalysisList.list.length>0?tweetsAnalysis.channelAnalysisList.list:this.state.initMap, ['refDate', this.state.positionName, this.state.positionName1])}
                                scale={scale}
                              >
                                <Axis name="time" grid={null} />
                                <Geom type="line" position={this.state.position0} color="#4FAAEB" size={3} shape="genre" />
                                <Geom
                                  type="point"
                                  shape="circle"
                                  position={this.state.position0}
                                  style={{
                                    stroke: "#fff",
                                    lineWidth: 1,
                                  }}
                                  size={4}
                                />
                                {
                                  this.state.position1 ? (
                                    <div>
                                      <Geom
                                        type="line"
                                        position={this.state.position1}
                                        color="#9AD681"
                                        size={2}
                                        shape="genre"
                                      />
                                      <Geom
                                        type="point"
                                        position={this.state.position1}
                                        size={4}
                                        shape="circle"
                                        color="#9AD681"
                                        style={{
                                          stroke: "#fff",
                                          lineWidth: 1,
                                        }}
                                      />
                                    </div>

                                  ): ""
                                }
                              </View>
                            </Chart>
                          }
                        </div>
                        <div style={{width:"400px",marginLeft:"40%",marginTop:"-40px"}}>
                          <span><span style={{display:"inline-block",height:"10px",width:"40px",background:"#4FAAEB",marginRight:"10px"}} />{this.state.numberName}</span>
                          {
                        this.state.rateName?<span><span style={{display:"inline-block",height:"10px",width:"40px",background:"#9AD681",marginLeft:"40px",marginRight:"10px"}} />{this.state.rateName}</span>:""
                      }
                        </div>
                      </div>
                    </div>
                  </Col>
                </Row>
                <Row style={{ position: 'relative' }}>
                  <div style={{float:"right",marginRight:"30px"}}>
                    <a href={url.url} style={{display:"block",height:"40px",width:"70px",background:"#4FAAEB",textAlign:"center",lineHeight:"40px",color:"#fff",marginBottom:"10px",borderRadius:"5px"}}>导出excel</a>
                  </div>
                  <div style={{padding:"30px"}}>
                    <Table pagination={{defaultCurrent:this.state.search.pageNo,pageSize:10,pageNo:this.state.search.pageNo,showSizeChanger:true,showQuickJumper:true}} columns={columns} dataSource={tweetsAnalysis.channelAnalysisList.list.length>0?tweetsAnalysis.channelAnalysisList.list:[]} size="middle" bordered  />
                  </div>
                </Row>
              </div>
            </Card>
          </List>
        </Fragment>
      </PageHeaderLayout>
    );
  }


}
