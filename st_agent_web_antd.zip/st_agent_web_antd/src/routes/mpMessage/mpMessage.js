/* eslint-disable no-param-reassign */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { Row, Col, Card, Form, Input, Select, DatePicker } from 'antd';
import StandardTable from 'components/StandardTable';
import { isUndefined } from 'lodash';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from '../../assets/css/common.less';

const FormItem = Form.Item;
const { Option } = Select;
const InputSearch = Input.Search;
const getValue = obj =>
  Object.keys(obj)
    .map(key => obj[key])
    .join(',');
const DatePickerRangePicker = DatePicker.RangePicker;

@connect(({mpMessage, loading }) => ({
  mpMessage,
  loading: loading.models.mpMessage,
}))
@Form.create()
export default class MessageList extends PureComponent {
  state = {
    selectedRows: [],
    formValues: {},
  };

  componentDidMount() {
    const { dispatch } = this.props;
    const params = {
      pageNo: 1,
      pageSize: 10,
    };
    dispatch({
      type: 'mpMessage/messageListFetch',
      payload: params,
    });
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});
    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    formValues.pageNo=pagination.current;
    this.setState({
      formValues,
    })
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'mpMessage/messageListFetch',
      payload: params,
    });
  };

  handleSearch = () => {
    const { dispatch, form } = this.props;
    let sTime;
    let eTime;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const rangeValue = fieldsValue.time;debugger
      if(!isUndefined(rangeValue) && rangeValue.length > 0){
        sTime = rangeValue[0].format('YYYY-MM-DD');
        eTime = rangeValue[1].format('YYYY-MM-DD');
      }
      const values = {
        pageNo: 1,
        pageSize: 10,
        startTime: sTime,
        endTime: eTime,
        msgType:fieldsValue.msgType,
        content:fieldsValue.content,
      };
      this.setState({
        formValues:values,
      });
      dispatch({
        type: 'mpMessage/messageListFetch',
        payload: values,
      });
    });
  };

  /**
   * 搜索时间
   * @param a
   * @param b 为时间
   */
  handleSearchTime =(a,b) => {
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      const values = {
        pageNo: 1,
        pageSize: 10,
        startTime: b[0],
        endTime: b[1],
        msgType:fieldsValue.msgType,
        content:fieldsValue.content,
      };
      this.setState({
        formValues:values,
      });
      dispatch({
        type: 'mpMessage/messageListFetch',
        payload: values,
      });
    });
  };

  /**
   * 搜索类型
   * @param e
   */

  handleSearchMsgType =e => {
    const { dispatch, form } = this.props;
    let sTime;
    let eTime;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const rangeValue = fieldsValue.time;
      if(!isUndefined(rangeValue) && rangeValue.length > 0){
        sTime = rangeValue[0].format('YYYY-MM-DD');
        eTime = rangeValue[1].format('YYYY-MM-DD');
      }
      const values = {
        pageNo: 1,
        pageSize: 10,
        startTime: sTime,
        endTime: eTime,
        msgType:e,
        content:fieldsValue.content?fieldsValue.content.replace(/\s/gi,''):"",
      };
      this.setState({
        formValues:values,
      });
      dispatch({
        type: 'mpMessage/messageListFetch',
        payload: values,
      });
    });
  };

  renderSimpleForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;

    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={4} sm={24}>
            <FormItem>
              {getFieldDecorator('msgType')(
                <Select
                  placeholder="请选择类型"
                  onChange={this.handleSearchMsgType}
                >
                  <Option value="">请选择类型</Option>
                  <Option value="text">文本</Option>
                  <Option value="image">图片</Option>
                  <Option value="location">位置</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={6} sm={24}>
            <FormItem label="发送时间">
              {getFieldDecorator('time')(<DatePickerRangePicker onChange={this.handleSearchTime} />)}
            </FormItem>
          </Col>
          <Col md={7} sm={24}>
            <FormItem>
              {getFieldDecorator('content')(
                <InputSearch
                  placeholder="请输入要搜索的消息内容"
                  onSearch={this.handleSearch}
                  enterButton
                />
              )}
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  }

  render() {
    // noinspection JSAnnotator
    const columns = [
      {
        title: '头像',
        key: 'headImgUrl',
        width:"5%",
        render: (text, record) => (
          <img src={record.headImgUrl} alt={record.nickName} className={styles.awart} />
        ),
      },
      {
        title: '昵称',
        dataIndex: 'nickName',
        key: 'nickName',
        width:"8%",
        render:(text,record) => (
          <div style={{width:120,display: "block",whiteSpace: "nowrap", textOverflow: "ellipsis", overflow: "hidden"}}>{record.nickName}</div>
        ),
      }
      ,
      {
        title: '消息类型',
        dataIndex: 'msgType',
        key: 'msgType',
        width:"10%",
        render: (text, record) => (
          <span>
            {record.msgType === 'text' ? '文本' : record.msgType === 'image' ? '图片' : '位置'}
          </span>
        ),
      },
      {
        title: '发送内容',
        dataIndex: 'content',
        key: 'content',
        render: (text, record) => (
          <div>
            {record.msgType === 'text' ? (
              <span>{record.content}</span>
            ) : record.msgType === 'image' ? (
              <a href={record.picUrl} target="_blank" rel="noopener noreferrer">
                查看图片
              </a>
            ) : (
              <span>{record.label}</span>
            )}
          </div>
        ),
      },
      {
        title: '发送时间',
        dataIndex: 'createTime',
        key: 'createTime',
        width:"17%",
        overflow:"hidden",
      },
      {
        title: '操作',
        align:"right",
        width:"6%",
        render: () => <span>--</span>,
      },
    ];
    const {
      mpMessage: { messageList },
      loading,
    } = this.props;
    const { selectedRows,formValues:{pageNo} } = this.state;
    messageList.pagination.current = pageNo;
    return (
      <PageHeaderLayout>
        <Card>
          <div className={styles.tableListForm}>{this.renderSimpleForm()}</div>
        </Card>
        <Card>
          <StandardTable
            loading={loading}
            data={messageList}
            columns={columns}
            selectedRows={selectedRows}
            onChange={this.handleStandardTableChange}
          />
        </Card>
      </PageHeaderLayout>
    );
  }
}
