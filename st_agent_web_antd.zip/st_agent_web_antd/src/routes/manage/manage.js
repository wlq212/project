/* eslint-disable no-unused-vars,react/sort-comp,react/destructuring-assignment,react/no-unused-state,prefer-destructuring,default-case,no-shadow,lines-between-class-members,no-undef,no-case-declarations */
import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Select,
  Icon,
  Button,
  Alert,
  Modal,
  message,
  Divider,
} from 'antd';
import StandardTable from 'components/StandardTable';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from './manage.less';
import { setStore,removeStore,getStore} from '../../assets/js/mUtils';

const FormItem = Form.Item;
const { Option } = Select;
const getValue = obj =>
  Object.keys(obj)
    .map(key => obj[key])
    .join(',');
const CreateForm = Form.create()(props => {
  const { modalVisible, form, handleAdd, handleModalVisible, handleChange } = props;
  const okHandle = () => {
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      handleAdd(fieldsValue);
    });
  };
  return (
    <Modal
      title="账号添加"
      visible={modalVisible}
      onOk={okHandle}
      onCancel={() => handleModalVisible()}
    >
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号类型" validateStatus="success">
        {form.getFieldDecorator('roleType', {
          rules: [{ required: true, message: '请选择账号类型' }],
        })(<Select
          style={{ width: 290 }}
          placeholder="请选择账号类型"
          optionFilterProp="children"
          onChange={handleChange}
        >
          <Option value="200">管理员</Option>
          <Option value="300">普通成员</Option>
        </Select>)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="品牌名称" validateStatus="success">
        {form.getFieldDecorator('brandName', {
          rules: [{ required: true, message: '请输入品牌名称' }],
        })(<Input placeholder="请输入品牌名称" id="brandNameOne" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号" validateStatus="success">
        {form.getFieldDecorator('userName', {
          rules: [{ required: true, message: '请输入账号' }],
        })(<Input placeholder="请输入账号" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="密码">
        {form.getFieldDecorator('pwd', {
          rules: [{ required: true, message: '请输入密码' }],
        })(<Input placeholder="请输入密码" type="password" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="微信号">
        {form.getFieldDecorator('city')(<Button type="primary">关联微信</Button>)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="手机号">
        {form.getFieldDecorator('city')(<Input placeholder="请输入手机号" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="城市">
        {form.getFieldDecorator('mobile')(<Input placeholder="请输入" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="状态">
        {form.getFieldDecorator('state', {
          rules: [{ required: true, message: '请选择状态' }],
        })(<Select
          style={{ width: 290 }}
          placeholder="请选择状态"
          optionFilterProp="children"
          onChange={handleChange}
        >
          <Option value="0">停用</Option>
          <Option value="1">正常</Option>
        </Select>)}
      </FormItem>
    </Modal>
  );
});

const CollectionCreateForm = Form.create({
  mapPropsToFields(props) {
    return {
      roleType: Form.createFormField(props.selectRowData.roleType),
      brandName: Form.createFormField(props.selectRowData.brandName),
      userName: Form.createFormField(props.selectRowData.userName),
      pwd: Form.createFormField(props.selectRowData.pwd),
      city: Form.createFormField(props.selectRowData.city),
      mobile: Form.createFormField(props.selectRowData.mobile),
      state: Form.createFormField(props.selectRowData.state),
    };
  },
})(
  class extends React.Component {
    render() {
      const { visible, onCancel, onCreate, form } = this.props;
      return (
        <Modal
          visible={visible}
          title="更新"
          okText="更新"
          onCancel={onCancel}
          onOk={onCreate}
        >
          <Form layout="vertical">
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号类型" validateStatus="success">
              {form.getFieldDecorator('roleType', {
                rules: [{ required: true, message: '请选择账号类型' }],
              })(<Select
                style={{ width: 290 }}
                placeholder="请选择账号类型"
                optionFilterProp="children"
              >
                <Option value="200">管理员</Option>
                <Option value="300">普通成员</Option>
              </Select>)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="品牌名称" validateStatus="success">
              {form.getFieldDecorator('brandName', {
                rules: [{ required: true, message: '请输入品牌名称' }],
              })(<Input placeholder="请输入品牌名称" id="brandNameOne" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号" validateStatus="success">
              {form.getFieldDecorator('userName', {
                rules: [{ required: true, message: '请输入账号' }],
              })(<Input placeholder="请输入账号" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="密码">
              {form.getFieldDecorator('pwd', {
                rules: [{ required: true, message: '请输入密码' }],
              })(<Input placeholder="请输入密码" type="password" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="微信号">
              {form.getFieldDecorator('city')(<Button type="primary">关联微信</Button>)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="手机号">
              {form.getFieldDecorator('mobile')(<Input placeholder="请输入手机号" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="城市">
              {form.getFieldDecorator('city')(<Input placeholder="请输入" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="状态">
              {form.getFieldDecorator('state', {
                rules: [{ required: true, message: '请选择状态' }],
              })(<Select
                style={{ width: 290 }}
                placeholder="请选择状态"
                optionFilterProp="children"
              >
                <Option value="0">停用</Option>
                <Option value="1">正常</Option>
              </Select>)}
            </FormItem>
          </Form>
        </Modal>
      );
    }
  },
);

@connect(({ manage, loading }) => ({
  manage,
  loading: loading.models.manage,
}))
@Form.create()
export default class TableList extends PureComponent {
  state = {
    visible: false,
    modalVisible: false,
    selectRowData: {},
    message: '',
    type: '',
    modelTitle: '添加管理员',
    alertVisible: false,
    expandForm: false,
    selectedRows: [],
    formValues: {
      pageNo:1,
      pageSize:10,
    },
  };

  handleCancel = () => {
    this.setState({ visible: false });
  };

  handleCreate = () => {
    const form = this.formRef.props.form;
    form.validateFields((err) => {
      if (err) {
        return;
      }
      form.resetFields();
      this.setState({ visible: false });
    });
  };

  saveFormRef = (formRef) => {
    this.formRef = formRef;
  };

  componentDidMount() {
    const { dispatch } = this.props;
    if(getStore("formValues")){
      dispatch({
        type: 'manage/fetch',
        payload: {
          ...getStore("formValues"),
        },
      });
    }else{
      const params = {
        pageNo: 1,
        pageSize: 10,
      };
      dispatch({
        type: 'manage/fetch',
        payload: params,
      });
    }
  }

  handleChange = flag => {

  };

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    this.setState({
      formValues:params,
    })
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }

    dispatch({
      type: 'manage/fetch',
      payload: params,
    });
  };

  handleFormReset = () => {
    const { form,dispatch} = this.props;
    form.resetFields();
    const params = {
      pageNo: 1,
      pageSize: 10,
    };
    dispatch({
      type: 'manage/fetch',
      payload: params,
    });
    this.setState({
      formValues:params,
    });
  };

  toggleForm = () => {
    const { expandForm } = this.state;
    this.setState({
      expandForm: !expandForm,
    });
  };

  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (!selectedRows) return;

    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'rule/remove',
          payload: {
            no: selectedRows.map(row => row.no).join(','),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
  };

  handleSearch = e => {
    e.preventDefault();

    const { dispatch, form } = this.props;

    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = {
        ...fieldsValue,
        pageNo: 1,
        pageSize: 10,
        userName: fieldsValue.brandName?fieldsValue.brandName.replace(/\s/gi,''):"",
      };
      this.setState({
        formValues: values,
      });
      dispatch({
        type: 'manage/fetch',
        payload: values,
      });

    });
  };
  changeUser=rows=>{

    const { dispatch} = this.props;
    const confirm = Modal.confirm;
    confirm({
      title: '提示?',
      content: '确定要切换账户',
      onOk() {

        const params = {
          adminUserId: rows.adminUserId,
        };
        const response = dispatch({
          type: 'manage/switchAdminUserButton',
          payload: params,
        });
        response.then((result) => {
          if (result) {
            switch (result.code) {
              case '200':
                removeStore("userInfo");
                message.success('切换成功');
                setStore("userInfo",result.obj);
                window.location.href=window.location.origin;
                break;
              case '500':
                message.error(result.msg || '重置失败');
                break;
            }
          }
        }, (result) => {

        });


      },
      onCancel() {
      },
    });
  };
  passwordReset = rows => {
    const { dispatch} = this.props;
    const {formValues}=this.state;
    const confirm = Modal.confirm;
    confirm({
      title: '提示?',
      content: '确定要重置密码',
      onOk() {
        const params = {
          adminUserId: rows.adminUserId,
          roleType: rows.roleType,
          pwd:md5('123456'),
        };
        const response = dispatch({
          type: 'manage/passwordReset',
          payload: params,
        });
        response.then((result) => {
          if (result) {
            switch (result.code) {
              case '200':
                dispatch({
                  type: 'manage/fetch',
                  payload:{
                    pageNo:formValues.pageNo,
                    pageSize:formValues.pageSize,
                  },
                });
                message.success('重置成功');
                break;
              case '500':
                message.error(result.msg || '重置失败');
                break;
            }
          }
        }, (result) => {

        });


      },
      onCancel() {
      },
    });
  };

  handleAddManage = () => {
    const { dispatch } = this.props;
    dispatch(routerRedux.push('/setting/manage/accountAdd'));
  };

  handleClose = () => {
    this.setState({ alertVisible: false });
  };

  edit(data) {
    const { dispatch } = this.props;
    dispatch({
      type: 'manage/editData',
      payload: data,
    });
    dispatch(routerRedux.push('/setting/manage/accountEdit'));
    setStore("formValues",this.state.formValues)
  };

  renderSimpleForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem>
              {getFieldDecorator('brandName')(<Input placeholder="请输入品牌或者账号" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <span className={styles.submitButtons}>
              <Button type="primary" htmlType="submit">
                查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                重置
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  };

  renderAdvancedForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="查询参数">
              {getFieldDecorator('brandName')(<Input placeholder="请输入品牌或者账号" />)}
            </FormItem>
          </Col>
        </Row>
        <div style={{ overflow: 'hidden' }}>
          <span style={{ float: 'right', marginBottom: 24 }}>
            <Button type="primary" htmlType="submit">
              查询
            </Button>
            <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
              重置
            </Button>
            <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
              收起 <Icon type="up" />
            </a>
          </span>
        </div>
      </Form>
    );
  };

  renderForm() {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm();
  };

  render() {
    const { manage, loading } = this.props;
    const { selectedRows, modalVisible, alertVisible, message, type, modalTitle, selectRowData } = this.state;
    manage.data.pagination.current=this.state.formValues.pageNo;
    const data = manage.data;
    const columns = [
      {
        title: '品牌名',
        key: 'adminUserId',
        dataIndex: 'brandName',
      },
      {
        title: '账号',
        key: 'userName',
        dataIndex: 'userName',
      },
      {
        title: '手机号',
        dataIndex: 'mobile',
        key: 'mobile',
        render: (val) => (
          <span>{val || '--'}</span>
        ),
      },
      {
        title: '城市',
        dataIndex: 'city',
        key: 'city',
        render: (val) => (
          <span>{val || '--'}</span>
        ),
      },
      {
        title: '小程序版本',
        dataIndex: 'version',
        key: 'version',
        render: (text, record) => (
          <div>
            {
              record.version != null ? (
                <div>
                  {record.version.status === 0 ?
                    <span>{record.version.versionCode}</span>
                  :(record.version.status === 1?
                    <span>审核失败({record.version.versionCode})</span>
                    :(record.version.status === 2?
                      <span>审核中({record.version.versionCode})</span>:'--'))}
                </div>
              ): '--'
            }
          </div>
        ),
      },
      {
        title: '状态',
        dataIndex: 'state',
        key: 'state',
        render: (val) => (
          <span>{String(val) === '0' ? '停用' : '正常'}</span>
        ),
      },
      {
        title: '创建者',
        key: 'pUserName',
        dataIndex: 'pUserName',

      },
      {
        title: '操作',
        align:"right",
        fixed:"right",
        render: (text, record) => (
          <Fragment>
            <a onClick={() => this.passwordReset(record)}>密码重置</a>
            <Divider type="vertical" />
            <a onClick={() => this.changeUser(record)}>切换账号</a>
            <Divider type="vertical" />
            <a onClick={() => this.edit(record)}>编辑</a>
          </Fragment>
        ),
      },
    ];
    const parentMethods = {
      handleAdd: this.handleAdd,
      handleModalVisible: this.handleModalVisible,
    };
    return (
      <PageHeaderLayout title="">
        {
          alertVisible ? (
            <Alert
              message={message}
              showIcon
              type={type}
              closable
              afterClose={this.handleClose
                }
            />
            ) :
            null
        }
        <Card bordered={false}>
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>
              {this.renderForm()}
              <Button
                className={styles.buttonAddClass}
                icon="plus"
                type="primary"
                onClick={() => this.handleAddManage(true)}
              >
                新建
              </Button>
            </div>
            <div className={styles.tableListOperator}>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={data}
              columns={columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
            />
          </div>
        </Card>
        <CollectionCreateForm
          wrappedComponentRef={this.saveFormRef}
          visible={this.state.visible}
          onCancel={this.handleCancel}
          onCreate={this.handleCreate}
          selectRowData={selectRowData}
        />
        <CreateForm {...parentMethods} modalVisible={modalVisible} modalTitle={modalTitle} />
      </PageHeaderLayout>
    );
  }
}
