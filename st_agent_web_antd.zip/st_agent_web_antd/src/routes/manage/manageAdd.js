/* eslint-disable no-unused-vars,default-case,react/jsx-boolean-value */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Form,
  Input,
  Select,
  Button,
  Card,
  message,
  } from 'antd';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';

const FormItem = Form.Item;
const { Option } = Select;
@connect(({ manage, loading }) => ({
  manage,
  loading: loading.models.manage,
}))
@Form.create()
export default class BasicForms extends PureComponent {
  cancel = e => {
    e.preventDefault();
    const { dispatch } = this.props;
    dispatch(routerRedux.push('/setting/manage'));
  };

  componentDidMount(){
    const {dispatch}=this.props;
    dispatch({
      type:"manage/roleListFetch",
      payload:"",
    })
  }

  handleSubmit = e => {
    e.preventDefault();
    const { form, dispatch} = this.props;
    form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        dispatch({
          type: 'manage/add',
          payload: values,
          callback: () => {},
        }).then(
          (result) => {
            if (result) {
              switch (result.code) {
                case '200':
                  message.success('添加成功');
                  dispatch(routerRedux.push('/setting/manage'));
                  break;
                case '500':
                  message.success(result.msg);
                  break;
              }
            }
          },
          (result) => {}
        );
      }
    });
  };

  phoneValidator(e){
    const regex = /^((\+)?86|((\+)?86)?)0?1[3458]\d{9}$/;
    if (regex.test(e.target.value)) {

    } else {
      message.error('请输入正确的手机号码！');
    }
  }

  render() {
    const { submitting, form,manage,loading} = this.props;
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 },
        md: { span: 10 },
      },
    };
    const submitFormLayout = {
      wrapperCol: {
        xs: { span: 24, offset: 0 },
        sm: { span: 10, offset: 7 },
      },
    };
    return (
      <PageHeaderLayout showReturn={true} url="/setting/manage">
        <Card bordered={false}>
          <Form onSubmit={this.handleSubmit} hideRequiredMark style={{ marginTop: 8 }}>
            <FormItem {...formItemLayout} label="所属角色">
              {form.getFieldDecorator('roleId', {
                rules: [{ required: true, message: '请选择账号类型' }],
              })(
                <Select placeholder="请选择账号类型" optionFilterProp="children">
                  {
                    manage.roleList.list?manage.roleList.list.map(function(item,index) {
                      return(<Option key={index} value={item.roleId}>{item.name}</Option>)
                    }):""
                  }
                </Select>
              )}
            </FormItem>
            <FormItem {...formItemLayout} label="品牌名称">
              {form.getFieldDecorator('brandName', {
                rules: [{ required: true, message: '请输入品牌名称' }],
              })(<Input placeholder="请输入品牌名称" id="brandNameOne" />)}
            </FormItem>
            <FormItem {...formItemLayout} label="账号">
              {form.getFieldDecorator('userName', {
                rules: [{ required: true, message: '请输入账号' }],
              })(<Input placeholder="请输入账号" />)}
            </FormItem>
            <FormItem {...formItemLayout} label="密码">
              {form.getFieldDecorator('pwd', {
                rules: [{ required: true, message: '请输入密码' }],
              })(<Input placeholder="请输入密码" type="password" />)}
            </FormItem>
            <FormItem {...formItemLayout} label="手机号">
              {form.getFieldDecorator('mobile')(<Input placeholder="请输入手机号" onChange={this.phoneValidator} />)}
            </FormItem>
            <FormItem {...formItemLayout} label="城市">
              {form.getFieldDecorator('city')(<Input placeholder="请输入城市" />)}
            </FormItem>
            <FormItem {...formItemLayout} label="状态">
              {form.getFieldDecorator('state', {
                rules: [{ required: true, message: '请选择状态' }],
              })(
                <Select placeholder="请选择状态" optionFilterProp="children">
                  <Option value="0">停用</Option>
                  <Option value="1">正常</Option>
                </Select>
              )}
            </FormItem>
            <FormItem {...submitFormLayout} style={{ marginTop: 32 }}>
              <Button type="primary" htmlType="submit" loading={loading}>
                提交
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.cancel}>
                取消
              </Button>
            </FormItem>
          </Form>
        </Card>
      </PageHeaderLayout>
    );
  }
}
