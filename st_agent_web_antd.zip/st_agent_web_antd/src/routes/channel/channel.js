/* eslint-disable no-param-reassign,array-callback-return,no-shadow,jsx-a11y/anchor-has-content,react/self-closing-comp,prefer-destructuring */
import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Button,
  Select,
  Alert,
  Modal,
  Table,
  message,
  Divider,
} from 'antd';
import {isArray,isUndefined} from "lodash";
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from './channel.less';
import typeConst from '../../assets/js/cardConst';
import SelectActivityList from '../../assets/js/SelectActivityList';
import { getStore, setStore } from '../../assets/js/mUtils';

const {Option} = Select;
const FormItem = Form.Item;
const confirm = Modal.confirm;
const getValue = obj =>
  Object.keys(obj)
    .map(key => obj[key])
    .join(',');
const types = typeConst.channelTypes;

// 上传
@connect(({ channel, loading }) => ({
  channel,
  loading: loading.models.channel,
}))
@Form.create()
export  default class channelList extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isShowActivityModal:false,
      msg: '',
      type: '',
      alertVisible: false,
      activityId:"",
      activityName:"",
      selectedRows: [],
      formValues: {
        pageNo: 1,
        pageSize: 10,
      },
      selectedRowKeys:[],
      qrcodeIdList:[],
    };
  }

  componentDidMount() {
    const { dispatch } = this.props;
    if(getStore("formValues")){
      dispatch({
        type: 'channel/qrcodeListFetch',
        payload: {...JSON.parse(getStore("formValues"))},
      });
      this.setState({
        formValues:JSON.parse(getStore("formValues")),
      })
    }else{
      dispatch({
        type: 'channel/qrcodeListFetch',
        payload: {pageNo:1,pageSize:10},
      });
    }
    dispatch({
      type: 'channel/shopList',
      payload:{pageNo:1,pageSize:999999},
    });

  }

  /**
   * 获取活动列表，打开模态框
   */
  getActivityList = () => {
    const {dispatch}=this.props;
    const {activityName}=this.state;
    dispatch({
      type:"channel/activityListFetch",
      payload:{
        activityName,
      },
    }).then(() => {
      this.setState({isShowActivityModal:true})
    })
  };

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    this.setState({
      formValues:params,
      // selectedRowKeys:[],
      // qrcodeIdList:[],
    });
    setStore("formValues",params);
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'channel/qrcodeListFetch',
      payload: params,
    });

  };

  /**
   * 查询
   */
  handleSearch = () => {
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err)return;
      const {activityId} = this.state;
      if(!isUndefined(fieldsValue.channelName)){
        fieldsValue.channelName=fieldsValue.channelName.replace(/\s/gi,'');
      }
      const params = {
        ...fieldsValue,
        activityId,
        pageNo: 1,
        pageSize: 10,
      };
      this.setState({
        formValues: params,
      });
      setStore("formValues",params);
      dispatch({
        type: 'channel/qrcodeListFetch',
        payload: params,
      });

    });
  };

  /**
   * 搜索门店
   * @param e
   */
  handleSearchShop = e => {
    const { dispatch, form } = this.props;
    const {activityId} = this.state;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      fieldsValue.sId=e;
      const values = {
        ...fieldsValue,
        activityId,
        pageNo: 1,
        pageSize: 10,
      };
      this.setState({
        formValues: values,
      });
      setStore("formValues",values);
      dispatch({
        type: 'channel/qrcodeListFetch',
        payload: values,
      });

    });
  };

  /**
   * 搜索类型
   * @param e
   */
  handleSearchChannelType = e => {
    const { dispatch, form } = this.props;
    const {activityId} = this.state;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      fieldsValue.channelType=e;
      const values = {
        ...fieldsValue,
        activityId,
        pageNo: 1,
        pageSize: 10,
      };
      this.setState({
        formValues: values,
      });
      setStore("formValues",values);
      dispatch({
        type: 'channel/qrcodeListFetch',
        payload: values,
      });

    });
  };

  /**
   * 重置
   */
  handleFormReset = () => {
    const { form,dispatch} = this.props;
    form.resetFields();
    const params = {
      pageNo: 1,
      pageSize: 10,
    };
    setStore("formValues",params);
    this.setState({activityId:"",activityName:""});
    dispatch({
      type: 'channel/qrcodeListFetch',
      payload: params,
    });
    this.setState({
      formValues:params,
    });
  };

  /**
   * 选中活动
   * @param data
   */
  selectedActivity = (data) => {
    this.setState({activityId:data.activityId,activityName:data.activityName,isShowActivityModal:false});
    this.state.formValues.activityName=data.activityName;
    this.state.formValues.activityId=data.activityId;
    setStore("formValues",this.state.formValues)
  };

  downloadAll = () => {
    const {qrcodeIdList} = this.state;
    const reqStr = {};
    reqStr.qrcodeIdList = qrcodeIdList;
    const url=`/api/admin/qrcode/batchDown?reqStr=${JSON.stringify(reqStr)}&token=${JSON.parse(getStore("userInfo")).token}`;
    if(qrcodeIdList.length > 0){
      location.href = url;
    }else {
      message.info("必须勾选文件后才能下载")
    }
  };

  /**
   * 编辑关注渠道
   * @param data
   */
  editChannel = (data) => {
    const {dispatch}=this.props;
    const {formValues} = this.state;
    dispatch({
      type: 'channel/qrCodeInfoFetch',
      payload: data,
    });
    dispatch(routerRedux.push('/wxAccounts/channelAdd'));
    setStore("formValues",formValues)
  };

  /**
   * 删除关注渠道
   * @param data
   */
  deleteChannel = (data) => {
    const {dispatch}=this.props;
    const {formValues} = this.state;
    confirm({
      title: '删除提示',
      content: '是否真的删除此关注渠道',
      okText: '删除',
      okType: 'danger',
      cancelText: '取消',
      onOk() {
        dispatch({
          type:"channel/qrcodeUpdateFetch",
          payload:{state:0,qrCodeId:data.qrCodeId},
        }).then((res) => {
          if(res.code === "200"){
            dispatch({
              type:"channel/qrcodeListFetch",
              payload:{...formValues},
            });
            message.success("删除成功");
          }else {
            message.error(res.msg);
          }
        }).catch(error => {
          message.error(error.msg);
        })
      },
    });
  };

  /**
   * 新建渠道
   */
  addChannel(){
    const {dispatch}=this.props;
    dispatch(routerRedux.push('/wxAccounts/channelAdd'));
  }

  /**
   * 批量新增渠道
   */
  addListChannel(){
    const {dispatch}=this.props;
    dispatch(routerRedux.push('/wxAccounts/channelListAdd'));
  }

  renderSimpleForm() {
    const { form,channel,loading} = this.props;
    const { getFieldDecorator } = form;
    const {activityName} = this.state;
    return (
      <Form layout="inline">
        <Row gutter={{ md: 24, lg: 24, xl: 48 }} style={{flexWrap:"wrap"}}>
          <Col md={24} sm={24} lg={4} style={{paddingRight:"0px"}}>
            <FormItem>
              {getFieldDecorator('sId',{
                initialValue:this.state.formValues.sId,
              })(
                <Select placeholder="请选择门店" onChange={this.handleSearchShop}>
                  <Option value="">请选择门店</Option>
                  {
                    isArray(channel.shopList) && channel.shopList.length > 0 ?channel.shopList.map((item) => {
                      return(<Option key={item.sId} value={item.sId}>{item.businessName}</Option>)
                    }):""
                  }
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={24} sm={24} lg={4} style={{paddingRight:"0px"}}>
            <FormItem>
              {getFieldDecorator('channelType',{
                initialValue:this.state.formValues.channelType,
              })(
                <Select placeholder="请选择类型" onChange={this.handleSearchChannelType}>
                  <Option value="">请选择类型</Option>
                  {
                    types.map(item => (
                      <Option key={item.value} value={item.value}>{item.name}</Option>
                    ))
                  }
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={24} sm={24} lg={4} style={{paddingRight:"0px"}}>
            <FormItem>
              {getFieldDecorator('activityName',{
                initialValue:activityName || this.state.formValues.activityName,
              })(
                <div style={{position: "relative"}}>
                  <Input
                    maxLength={0}
                    placeholder="请选择所属活动"
                    onClick={() => this.getActivityList()}
                    value={activityName}
                  />
                  <span onClick={() => this.getActivityList()} className="iconfont icon-arrow_down" style={{position: "absolute",top:0,right:10,color:"#ddd"}} />
                </div>
              )}
            </FormItem>
          </Col>
          <Col md={24} sm={24} lg={4} style={{paddingRight:"0px"}}>
            <FormItem>
              {getFieldDecorator('channelName')(
                <Input placeholder="请输入渠道名称" />
              )}
            </FormItem>
          </Col>
          <Col md={24} sm={24} lg={3}>
            <span className={styles.submitButtons}>
              <Button type="primary" onClick={this.handleSearch}>
                查询
              </Button>
            </span>
            <span className={styles.submitButtons} style={{marginLeft:10}}>
              <Button onClick={this.handleFormReset}>
                重置
              </Button>
            </span>
          </Col>

        </Row>
        <Row>
          <Col md={24} sm={24} lg={4} style={{textAlign:"right"}}>
            <span className={styles.submitButtons}>
              <Button
                type="primary"
                style={{marginBottom:"10px"}}
                onClick={this.downloadAll}
                loading={loading}
              >
              下载全部
              </Button>
            </span>
            <span className={styles.submitButtons}>
              <Button
                type="primary"
                style={{marginLeft:"10px"}}
                onClick={() => this.addListChannel()}
              >
              批量新建
              </Button>
            </span>
            <span className={styles.submitButtons}>
              <Button
                type="primary"
                style={{marginLeft:"10px"}}
                onClick={() => this.addChannel()}
              >
              新建
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }


  render() {
    const { channel, loading} = this.props;
    const { selectedRows, alertVisible, msg, type, isShowActivityModal,selectedRowKeys} = this.state;
    const rowSelection = {
      // eslint-disable-next-line no-shadow
      onChange: (rowKeys) => {
        this.setState({selectedRowKeys:rowKeys});
      },
      // 选择单个
      onSelect: (record, selected) => {
        const {qrcodeIdList} = this.state;
        const arr = [...qrcodeIdList];
        if(selected){
          if(arr.length === 0){
            arr.push(record.qrCodeId);
          }else {
            arr.map(item => {
              if(item !== record.qrCodeId){
                arr.push(record.qrCodeId);
              }
            });
          }
          const set = new Set(arr);
          this.setState({qrcodeIdList:Array.from(set)});
        }else {
          this.setState({qrcodeIdList:arr.filter(item => (item !== record.qrCodeId))});
        }
      },
      // 选中所有
      onSelectAll: (selected, selectedRows, changeRows) => {
        const {qrcodeIdList} = this.state;
        const arr = [...qrcodeIdList];
        if(selected){
          for(let i=0;i<selectedRows.length;i+=1){
            arr.push(selectedRows[i].qrCodeId);
          }
          const set = new Set(arr);
          this.setState({qrcodeIdList:Array.from(set)});
        }else {
          const arr1 = [];
          const arr2 = [];
          for(let i=0;i<arr.length;i+=1){
            arr1[arr[i]] = true;
          }
          for(let i=0;i<changeRows.length;i+=1){
            if(!arr1[arr[i]]){
              arr2.push(arr[i]);
            }
          }
          this.setState({qrcodeIdList:arr2});
        }
      },
      selectedRowKeys,
      getCheckboxProps: record => ({
        disabled: record.channelType === types[8].value,
      }),
    };

    const list = channel.qrcodeList.list;
    if(list){
      list.map(item => {item.key = item.id});
    }



    const columns = [
      {
        title: '渠道名称',
        key: 'channelName',
        dataIndex: 'channelName',
      },
      {
        title: '类型',
        key: 'channelType',
        dataIndex: 'channelType',
        render: (text, record) => <span>{ types.map(item => {return record.channelType === item.value ? item.name : ''})}</span>,
      },
      {
        title: '所属活动',
        width: 200,
        key:"activityName",
        dataIndex:'activityName',
        render: (text, record) => <span>{record.activityName !== ""&&record.activityName != null ? record.activityName : '--'}</span>,
      },
      {
        title: '所属门店',
        key: 'shopName',
        dataIndex: 'shopName',
        render: (text, record) => <span>{record.shopName !== ""&&record.shopName != null ? record.shopName : '--'}</span>,
      },
      {
        title: '所属桌台',
        key: 'deskName',
        dataIndex: 'deskName',
        render: (text, record) => <span>{record.deskName !== ""&&record.deskName != null ? record.deskName : '--'}</span>,
      },
      {
        title: '关键词',
        key: 'keyword',
        dataIndex: 'keyword',
      },
      {
        title: '创建时间',
        key: 'createTime',
        dataIndex: 'createTime',
      },
      {
        title: '操作',
        width: 180,
        align:"right",
        fixed: 'right',
        render: (text, record) => (
          <Fragment>
            <span>
              <a onClick={() => this.editChannel(record)}>编辑</a>
              <Divider type="vertical" />
              <a onClick={() => this.deleteChannel(record)}>删除</a>
            </span>
            {
              record.channelType !== types[8].value ? (
                <span>
                  <Divider type="vertical" />
                  <a href={record.url} target="_blank" rel="noopener noreferrer">下载</a>
                </span>
): ""
            }
            {/* <a> */}
            {/* 更多 */}
            {/* </a> */}
          </Fragment>
        ),
      },
    ];
    const activityFun=e=>{
      this.setState({
        activityName:e.target.value,
      })
    };
    channel.qrcodeList.pagination.current=this.state.formValues.pageNo;
    return (
      <PageHeaderLayout title="">
        {alertVisible ? (
          <Alert message={msg} showIcon type={type} closable afterClose={this.handleClose} />
        ) : null}
        <Card bordered={false}>
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>
              {this.renderSimpleForm()}

            </div>
            <div className={styles.tableListOperator}>
              {selectedRows.length > 0 && (
              <span>
                <Button>批量操作</Button>
              </span>
                )}
            </div>
            <Table
              selectedRows={selectedRows}
              // loading={loading}
              dataSource={list}
              columns={columns}
              loading={loading}
              // onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
              rowSelection={rowSelection}
              pagination={channel.qrcodeList.pagination}
            />
          </div>
        </Card>
        <Modal width="70%" title="活动列表" visible={isShowActivityModal} footer={null} onCancel={() => this.setState({ isShowActivityModal: false })}>
          <SelectActivityList activityList={channel.activityList} loading={loading} selectedRows={selectedRows} onSelectedActivity={this.selectedActivity} activityFun={activityFun} getActivityList={this.getActivityList} />
        </Modal>
      </PageHeaderLayout>
    );
  }
}
