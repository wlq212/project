/* eslint-disable no-unused-vars,default-case,react/jsx-boolean-value,array-callback-return */
import React, { PureComponent,Fragment } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Form,
  Input,
  Select,
  Button,
  Card,
  Radio,
  message,
  Icon,
  Modal,
  Table,
  Row,
  Col,
} from 'antd';
import {isArray} from 'lodash';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import SelectActivityList from '../../assets/js/SelectActivityList';
import StandardTable from '../../components/StandardTable';

const RadioGroup = Radio.Group;
const FormItem = Form.Item;
const InputSearch = Input.Search;
const { Option } = Select;
const getValue = obj =>
  Object.keys(obj)
    .map(key => obj[key])
    .join(',');
@connect(({ channel, loading }) => ({
  channel,
  loading: loading.models.channel,
}))
@Form.create()
export default class BasicForms extends PureComponent {
  state = {
    currData:{
      isAllShop:1,
      isDesk:1,
    },
    isShowActivityModal:false,
    isShowShopModal:false,
    selectedRows:{},
    shopList:[],
    activityFormValues:{},
    formValues:{},
  };

  componentDidMount(){
    const { dispatch } = this.props;
    dispatch({
      type: 'channel/shopTableListFetch',
      payload:{pageNo:1,pageSize:10},
    });
  }

  /**
   * 选择门店
   * @param e
   */
  onSelectShop = (e) => {
    const {currData} = this.state;
    currData.isAllShop = e.target.value;
    this.setState({currData});
  };

  /**
   * 搜索门店列表
   */
  onSearchShop = e => {
    const {dispatch} = this.props;
    dispatch({
      type: 'channel/shopTableListFetch',
      payload:{pageNo:1,pageSize:10,branchName:e},
    });
  };

  /**
   * 获取活动列表，打开模态框
   */
  getActivityList = () => {
    const {dispatch}=this.props;
    const {activityName} = this.state;
    dispatch({
      type:"channel/activityListFetch",
      payload:{
        activityName,
      },
    }).then(() => {
      this.setState({isShowActivityModal:true})
    })
  };

  /**
   * 保存
   * @param e
   */
  handleSubmit = e => {
    e.preventDefault();
    const { form, dispatch} = this.props;
    const {currData,shopList} = this.state;
    const shopIds = [];
    for(let i=0;i<shopList.length;i+=1){
      shopIds.push(shopList[i].sId);
    }
    form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        Object.assign(currData,values,{shopIds});
        dispatch({
          type: 'channel/qrcodeListAddFetch',
          payload: currData,
        }).then(
          (res) => {
            if (res.code === "200") {
              message.success('添加成功');
              dispatch(routerRedux.push('/wxAccounts/channel'));
            }else {
              message.success(res.msg);
            }
          },
        ).catch(error => {
          message.error(error.msg);
        });
      }
    });
  };

  /**
   * 门店列表分页
   * @param pagination
   * @param filtersArg
   * @param sorter
   */
  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    this.setState({
      formValues:params,
    })
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'channel/shopTableListFetch',
      payload: params,
    });
  };


  /**
   * 活动列表分页
   * @param pagination
   * @param filtersArg
   * @param sorter
   */
  activityPaginationChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { activityFormValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});
    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...activityFormValues,
      ...filters,
    };
    activityFormValues.pageNo=pagination.current;
    this.setState({
      activityFormValues,
    })
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'channel/activityListFetch',
      payload: params,
    });
  };

  /**
   * 取消返回列表页
   * @param e
   */
  cancel = e => {
    e.preventDefault();
    const { dispatch } = this.props;
    dispatch(routerRedux.push('/wxAccounts/channel'));
  };

  /**
   * 添加门店
   */
  addShopList = () => {
    this.setState({ isShowShopModal: true });
  };

  /**
   * 选中活动
   * @param data
   */
  selectedActivity = (data) => {
    const { currData } = this.state;
    currData.activityName = data.activityName;
    currData.activityId = data.activityId;
    this.setState({ currData, isShowActivityModal: false });
  };

  /**
   * 选中模态框门店列表的门店
   * @param data
   */
  selectShopTableList = (data) => {
    const {shopList} = this.state;
    const arr = [...shopList];
    if(arr.length === 0){
      arr.push(data);
      this.setState({shopList:arr,isShowShopModal:false});
    }else {
      arr.map((item) => {
        if(item.sId !== data.sId){
          arr.push(data);
        }
      });
      const set = new Set(arr);
      this.setState({shopList:Array.from(set),isShowShopModal:false});
    }

  };

  deleteShop = (sId) => {
    const {shopList} = this.state;
    const data = [...shopList];
    this.setState({shopList:data.filter(item => item.sId !== sId )});
  };

  /**
   * 指定的门店列表
   * @returns {*}
   */
  shopList(){
    const {shopList} = this.state;
    const columns = [
      {
        title: '门店名',
        key: 'businessName',
        dataIndex: 'businessName',
      },
      {
        title: '门店地址',
        key: 'province',
        render: (text, record) => (
          <span>{record.province + record.city + record.district + record.address}</span>
        ),
      },
      {
        title: '操作',
        align:"right",
        width:"10%",
        render: (text, record) => (
          <Fragment>
            <a onClick={() => this.deleteShop(record.sId)}>
              删除
            </a>
          </Fragment>
        ),
      },
    ];
    return (
      <div>
        <Table
          bordered
          dataSource={shopList}
          columns={columns}
          footer={null}
          pagination={false}
        />
        <a onClick={this.addShopList}>添加门店</a>
      </div>
    )
  };

  /**
   * 模态框里的门店搜索
   */
  searchShop(){
    return (
      <InputSearch
        style={{ width: 230 }}
        placeholder="请输入门店名称"
        onSearch={this.onSearchShop}
        enterButton
      />
    );
  };

  /**
   * 模态框里的门店列表
   * @returns {*}
   */
  appointShop(){
    const {loading,channel:{shopTableList}} = this.props;
    const {selectedRows} = this.state;
    const columns = [
      {
        title: '门店名',
        key: 'businessName',
        dataIndex: 'businessName',
      },
      {
        title: '门店地址',
        key: 'province',
        render: (text, record) => (
          <span>{record.province + record.city + record.district + record.address}</span>
        ),
      },
      {
        title: '审核状态',
        dataIndex: 'availableState',
        key: 'availableState',
        render: (text, record) => (
          <span>
            {Number(record.availableState)=== 4
              ? '审核失败'
              : Number(record.availableState)=== 3
                ? '审核通过'
                : Number(record.availableState)=== 2
                  ? '审核中'
                  : Number(record.availableState)=== 1
                    ? '系统错误'
                      : '未提交审核'}
          </span>
        ),
      },
      {
        title: '记录状态',
        dataIndex: 'state',
        key: 'state',
        render: (text, record) => <span>{Number(record.state) === 1 ? '通过' : '不通过'}</span>,
      },
      {
        title: '操作',
        align:"right",
        fixed:"right",
        render: (text, record) => (
          <Fragment>
            <a onClick={() => this.selectShopTableList(record)}>
              选择
            </a>
          </Fragment>
        ),
      },
    ];
    return(
      <StandardTable
        selectedRows={selectedRows}
        loading={loading}
        data={shopTableList}
        columns={columns}
        onChange={this.handleStandardTableChange}
      />
    )
  };

  render() {
    const { form,channel,loading} = this.props;
    const {currData,isShowActivityModal,selectedRows,isShowShopModal} = this.state;
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 },
        md: { span: 10 },
      },
    };
    const submitFormLayout = {
      wrapperCol: {
        xs: { span: 24, offset: 0 },
        sm: { span: 15, offset: 7 },
      },
    };
    const activityFun=e=>{
      this.setState({
        activityName:e.target.value,
      })
    };
    return (
      <PageHeaderLayout showReturn={true} url="/wxAccounts/channel">
        <Card bordered={false}>
          <Form onSubmit={this.handleSubmit} hideRequiredMark style={{ marginTop: 8 }}>
            <FormItem {...formItemLayout} label="渠道前缀名">
              {form.getFieldDecorator('prefixName', {
                initialValue: currData.prefixName,
                rules: [{ required: true, message: '请输入渠道前缀名' }],
              })(<Input placeholder="请输入渠道前缀名" />)}
            </FormItem>
            <FormItem {...formItemLayout} label="所属活动">
              {form.getFieldDecorator('activityName', {
                initialValue: currData.activityName,
                rules: [{ required: true, message: '请选择所属活动' }],
              })(
                <div style={{position:"relative"}}>
                  <Input placeholder="请选择所属活动" maxLength={0} onClick={this.getActivityList} value={currData.activityName} />
                  <Icon type="down" style={{position:"absolute",right:"10px",top:"15px"}} />
                </div>
              )}
            </FormItem>
            <FormItem {...formItemLayout} label="所属门店">
              {form.getFieldDecorator('isAllShop', {
                initialValue: currData.isAllShop,
                rules: [{ required: true, message: '请选择所属门店' }],
              })(
                <RadioGroup onChange={this.onSelectShop}>
                  <Radio value={1}>所有门店</Radio>
                  <Radio value={0}>指定门店</Radio>
                </RadioGroup>
              )}
            </FormItem>
            {
              Number(currData.isAllShop) === 0 ? <FormItem {...submitFormLayout}>{this.shopList()}</FormItem> : ""
            }
            <FormItem {...formItemLayout} label="是否按桌台">
              {form.getFieldDecorator('isDesk', {
                initialValue: currData.isDesk,
                rules: [{ required: true, message: '请选择关键词' }],
              })(
                <RadioGroup>
                  <Radio value={1}>是</Radio>
                  <Radio value={0}>否</Radio>
                </RadioGroup>
              )}
            </FormItem>
            <FormItem {...submitFormLayout} style={{ marginTop: 32 }}>
              <Button type="primary" htmlType="submit" loading={loading}>
                提交
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.cancel}>
                取消
              </Button>
            </FormItem>
          </Form>
        </Card>
        <Modal width="70%" title="活动列表" visible={isShowActivityModal} footer={null} onCancel={() => this.setState({ isShowActivityModal: false })}>
          <SelectActivityList activityList={channel.activityList} loading={loading} selectedRows={selectedRows} onSelectedActivity={this.selectedActivity} activityChange={this.activityPaginationChange} getActivityList={this.getActivityList} activityFun={activityFun} />
        </Modal>
        <Modal width="70%" title="门店列表" visible={isShowShopModal} footer={null} onCancel={() => this.setState({ isShowShopModal: false })}>
          {this.searchShop()}
          <br />
          <br />
          {this.appointShop()}
        </Modal>
      </PageHeaderLayout>
    );
  }
}
