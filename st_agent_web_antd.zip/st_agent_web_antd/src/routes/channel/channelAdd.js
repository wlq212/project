import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import { withRouter } from 'react-router';
import {
  Form,
  Input,
  Select,
  Button,
  Card,
  message,
  Icon,
  Modal,
} from 'antd';
import {isArray,isUndefined} from "lodash";
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import typeConst from '../../assets/js/cardConst';
import SelectActivityList from '../../assets/js/SelectActivityList';
import KeywordList from '../../assets/js/keyword';

const FormItem = Form.Item;
const { Option } = Select;
const types = typeConst.channelTypes;
const getValue = obj =>
  Object.keys(obj)
    .map(key => obj[key])
    .join(',');
@connect(({ channel, loading }) => ({
  channel,
  loading: loading.models.channel,
}))
@Form.create()
export default class ChannelAdd extends PureComponent {
  state = {
    currData:{},
    keyword:"",
    activityName:"",
    isShowActivityModal:false,
    isShowKeywordModal:false,
    selectedRows:{},
    formValues: {},
    activityFormValues:{},
    isAdd:true,// 是否新增
  };

  componentDidMount(){
    const { dispatch } = this.props;
    dispatch({
      type: 'channel/shopList',
      payload:"",
    }).then(() => {
      const {channel} = this.props;
      if(!isUndefined(channel.qrCodeInfo.qrCodeId)){
        dispatch({
          type:"channel/fetchDeskList",
          payload:{state:1,pageNo:1,pageSize:999999,sId:channel.qrCodeInfo.sId},
        });
        this.setState({currData:channel.qrCodeInfo,isAdd:false});
        dispatch({
          type: 'channel/qrCodeInfoFetch',
          payload: {},
        });
      }

    });
  }

  /**
   * 获取活动列表，打开模态框
   */
  getActivityList = () => {
    const {dispatch}=this.props;
    const {activityName} = this.state;
    const params = {
      pageNo: 1,
      activityName:activityName?activityName.replace(/\s/gi,''):"",
      pageSize: 10,
    };
    dispatch({
      type:"channel/activityListFetch",
      payload:params,
    }).then(() => {
      this.setState({isShowActivityModal:true})
    })
  };

  /**
   * 获取关键词列表，打开模态框
   */
  getKeywordList = () => {
    const {dispatch}=this.props;
    const {keyword} = this.state;
    const params = {
      pageNo: 1,
      type:"0",
      state:"1",
      keyword:keyword?keyword.replace(/\s/gi,''):"",
      pageSize: 10,
    };
    dispatch({
      type:"channel/keywordListFetch",
      payload:params,
    }).then(() => {
      this.setState({isShowKeywordModal:true})
    })
  };

  /**
   * 选中活动
   * @param data
   */
  selectedActivity = (data) => {
    const { currData } = this.state;
    currData.activityName = data.activityName;
    currData.activityId = data.activityId;
    this.setState({ currData, isShowActivityModal: false });
  };

  /**
   * 选中关键词
   * @param data
   */
  selectedKeyword = (data) => {
    const { currData } = this.state;
    currData.keyword = data.keyword;
    currData.autoReplyId = data.autoReplyId;
    this.setState({ currData, isShowKeywordModal: false });
  };

  /**
   * 点击取消
   * @param e
   */
  cancel = e => {
    e.preventDefault();
    const { dispatch } = this.props;
    dispatch(routerRedux.push('/wxAccounts/channel'));
  };

  /**
   * 关键词分页
   * @param pagination
   * @param filtersArg
   * @param sorter
   */
  keywordPaginationChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      type: '0',
      state:"1",
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    this.setState({
      formValues:params,
    })
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'channel/keywordListFetch',
      payload: params,
    });
  };

  activityPaginationChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { activityFormValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});
    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...activityFormValues,
      ...filters,
    };
    activityFormValues.pageNo=pagination.current;
    this.setState({
      activityFormValues,
    })
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'channel/activityListFetch',
      payload: params,
    });
  };

  /**
   * 提交
   * @param e
   */
  handleSubmit = e => {
    e.preventDefault();
    const { form, dispatch} = this.props;
    const {currData,isAdd} = this.state;
    form.validateFieldsAndScroll((err, values) => {
      Object.assign(currData,values);
      if (!err) {
        const url = isAdd?"channel/qrcodeAddFetch":"channel/qrcodeUpdateFetch";
        dispatch({
          type: url,
          payload: currData,
          callback: () => {},
        }).then(
          (res) => {
            if (res.code === "200") {
              message.success(isAdd?'添加成功':'更新成功');
              dispatch(routerRedux.push('/wxAccounts/channel'));
            }else {
              message.error(res.msg);
            }
          },
        ).catch(error => {
          message.error(error.msg);
        });
      }
    });
  };

  /**
   * 选择类型
   * @param e
   */
  channelTypeChange = e => {
    const {currData} = this.state;
    if(e === 6){
      currData.sId = "";
      currData.dId = "";
    }
    if(e < 6 || e > 8){
      currData.activityId = "";
    }
    currData.channelType = e;
    this.setState({currData});
  };

  /**
   * 选择门店
   * @param e
   */
  selectShop = e => {
    const {dispatch} = this.props;
    const {currData} = this.state;
    currData.sId = e;
    this.setState({currData});
    dispatch({
      type:"channel/fetchDeskList",
      payload:{state:1,pageNo:1,pageSize:999999,sId:e},
    })
  };

  /**
   * 选择桌台
   * @param e
   */
  selectDesk = e => {
    const {currData} = this.state;
    currData.dId = e;
    this.setState({currData});
  };



  render() {
    const { form,channel,loading} = this.props;
    const {currData,isShowKeywordModal,isShowActivityModal,selectedRows,isAdd} = this.state;
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 },
        md: { span: 10 },
      },
    };
    const submitFormLayout = {
      wrapperCol: {
        xs: { span: 24, offset: 0 },
        sm: { span: 10, offset: 7 },
      },
    };
    const keywordFun=e=>{
      this.setState({
        keyword:e.target.value,
      })
    };
    const activityFun=e=>{
      this.setState({
        activityName:e.target.value,
      })
    };
    return (
      <PageHeaderLayout showReturn url="/wxAccounts/channel">
        <Card bordered={false}>
          <Form onSubmit={this.handleSubmit} hideRequiredMark style={{ marginTop: 8 }}>
            <FormItem {...formItemLayout} label="渠道名称">
              {form.getFieldDecorator('channelName', {
                initialValue: currData.channelName,
                rules: [{ required: true, message: '请输入渠道名称' }],
              })(<Input placeholder="请输入渠道名称" />)}
            </FormItem>
            <FormItem {...formItemLayout} label="类型">
              {form.getFieldDecorator('channelType', {
                initialValue: currData.channelType,
                rules: [{ required: true, message: '请选择类型' }],
              })(
                <Select placeholder="请选择类型" onChange={e => this.channelTypeChange(e)} disabled={!isAdd}>
                  <Option value="">请选择类型</Option>
                  {
                    types.map(item => (
                      <Option key={item.value} value={item.value}>{item.name}</Option>
                    ))
                  }
                </Select>)}
            </FormItem>
            {
              currData.channelType !== 6 && currData.channelType !== 8 ? (
                <FormItem {...formItemLayout} label="所属门店">
                  {form.getFieldDecorator('sId', {
                    initialValue: currData.sId,
                    rules: [{ required: currData.channelType !== 6 && currData.channelType !== 8, message: '请选择门店' }],
                  })(
                    <Select placeholder="请选择门店" style={{display:"inline-block",width:"50%"}} onChange={this.selectShop} disabled={!isAdd}>
                      <Option value="">请选择门店</Option>
                      {
                          isArray(channel.shopList) && channel.shopList.length > 0 ?channel.shopList.map((item) => {
                            return(<Option key={item.sId} value={item.sId}>{item.businessName+item.branchName}</Option>)
                          }):""
                        }
                    </Select>
                  )}{currData.sId ? form.getFieldDecorator('dId', {
                  initialValue: currData.dId,
                })(
                  <Select placeholder="请选择桌台" style={{display:"inline-block",width:"50%"}} onChange={this.selectDesk} disabled={!isAdd}>
                    <Option value="">请选择桌台</Option>
                    {
                      isArray(channel.deskList) && channel.deskList.length > 0 ?channel.deskList.map((item) => {
                        return(<Option key={item.dId} value={item.dId}>{item.name}</Option>)
                      }):""
                    }
                  </Select>
                ):""}

                </FormItem>
):""
            }
            {
              currData.channelType === 6 || currData.channelType === 7 || currData.channelType === 8 ? (
                <FormItem {...formItemLayout} label="所属活动">
                  {form.getFieldDecorator('activityName', {
                    initialValue: currData.activityName,
                    rules: [{ required: currData.channelType === 6 || currData.channelType === 7 || currData.channelType === 8, message: '请选择所属活动' }],
                  })(
                    <div style={{position:"relative"}}>
                      <Input placeholder="请选择所属活动" maxLength={0} onClick={this.getActivityList} value={currData.activityName} />
                      <Icon type="down" style={{position:"absolute",right:"10px",top:"15px"}} />
                    </div>
                  )}
                </FormItem>
): ""
            }
            <FormItem {...formItemLayout} label="关键词">
              {form.getFieldDecorator('keyword', {
                initialValue: currData.keyword,
              })(
                <div style={{position:"relative"}}>
                  <Input placeholder="请选择关键词" maxLength={0} onClick={this.getKeywordList} value={currData.keyword} />
                  <Icon type="down" style={{position:"absolute",right:"10px",top:"15px"}} />
                </div>
              )}
            </FormItem>
            <FormItem {...submitFormLayout} style={{ marginTop: 32 }}>
              <Button type="primary" htmlType="submit" loading={loading}>
                {isAdd?'保存':'更新'}
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.cancel}>
                取消
              </Button>
            </FormItem>
          </Form>
        </Card>
        <Modal width="70%" title="活动列表" visible={isShowActivityModal} footer={null} onCancel={() => this.setState({ isShowActivityModal: false,activityName:"" })}>

          <SelectActivityList activityList={channel.activityList} loading={loading} selectedRows={selectedRows} onSelectedActivity={this.selectedActivity} activityChange={this.activityPaginationChange} activityFun={activityFun} getActivityList={this.getActivityList} />
        </Modal>
        <Modal width="70%" title="关键词列表" visible={isShowKeywordModal} footer={null} onCancel={() => this.setState({ isShowKeywordModal: false,keyword:"" })}>
          <KeywordList keywordList={channel.keywordList} loading={loading} selectedRows={selectedRows} onSelectKeyWord={this.selectedKeyword} keyWordChange={this.keywordPaginationChange} getKeywordList={this.getKeywordList} keywordFun={keywordFun} />
        </Modal>
      </PageHeaderLayout>
    );
  }
}

