/* eslint-disable no-unused-vars,prefer-destructuring,react/no-unused-state,no-var,vars-on-top,eqeqeq,react/destructuring-assignment,react/no-access-state-in-setstate,react/no-access-state-in-setstate,no-underscore-dangle,default-case,react/sort-comp,no-case-declarations,no-shadow,no-script-url,no-undef,react/jsx-indent */
import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Row,
  Col,
  Card,
  Pagination,
  Form,
  Input,
  Icon,
  Button,
  Upload,
  Select,
  List,
  Tabs,
  Alert,
  Radio,
  Modal,
  message,
  Divider,
} from 'antd';
import StandardTable from 'components/StandardTable';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from './desk.less';
import { getStore, setStore } from '../../assets/js/mUtils';

const Option = Select.Option;
const FormItem = Form.Item;
const TabPane = Tabs.TabPane;
const RadioButton = Radio.Button;
const { TextArea } = Input;
const RadioGroup = Radio.Group;
const getValue = obj =>
  Object.keys(obj)
    .map(key => obj[key])
    .join(',');

// 上传
@connect(({ desk, loading }) => ({
  desk,
  loading: loading.models.desk,
}))
@Form.create()
export  default class deskTable extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      loading1: false,
      loading: false,
      modalVisible: false,
      visibleImageEidt:false,
      visibleNewsEdit:false,
      selectRowData: {},
      selectState1: {},
      switchType:"1",
      message: '',
      confirmDirty: false,
      editDeskData:"",
      editCateData:"",
      autoCompleteResult: [],
      type: '',
      alertVisible: false,
      expandForm: false,
      selectState: 'text',
      selectedRows: [],
      formValues: {
        pageNo: 1,
        pageSize: 10,
        state:"1",
      },
      cateName:"",
      sId:"",
      formValues1: {
        pageNo: 1,
        pageSize: 10,
        state:"1",
      },
      visibleImage: false,
      visibleNews: false,
    };
    
    this.tabSwitch=this.tabSwitch.bind(this);
    this.update=this.update.bind(this);
    this.handleCancelImage=this.handleCancelImage.bind(this);
    this.handleCancelImageEdit=this.handleCancelImageEdit.bind(this);
    this.handleCancelNews=this.handleCancelNews.bind(this);
    this.handleCancelNewsEdit=this.handleCancelNewsEdit.bind(this);
    this.submitDesk=this.submitDesk.bind(this);
    this.submitEidtDesk=this.submitEidtDesk.bind(this);
    this.submitEidtCate=this.submitEidtCate.bind(this);
    this.handleCancelNews=this.handleCancelNews.bind(this);
    this.submitCate=this.submitCate.bind(this);
    this.submitDesk=this.submitDesk.bind(this);
  }

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    this.setState({
      formValues:params,
    })
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'desk/fetchDeskList',
      payload: params,
    });
  };

  handleStandardTableChange1 = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    this.setState({
      formValues:params,
    })
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'desk/fetchCateList',
      payload: params,
    });
  };

  submitCate(){
    const { dispatch} = this.props;
    const that=this;
    if(this.state.cateName&&this.state.sId){
      dispatch({
        type:"desk/cateAddButton",
        payload:{
          cateName:this.state.cateName,
          sId:this.state.sId,
        },
      }).then((result) => {
        switch (result.code) {
          case '200':
            dispatch({
              type: 'desk/fetchCateList',
              payload: this.state.formValues1,
            });
            that.setState({
              visibleNews:false,
            })
            message.success('添加成功');
            break;
          case '500':
            message.error(result.msg);
            break;
        }
      })
    }
  }

  submitEidtCate(){
    const { dispatch} = this.props;
    const that=this;
    if(this.state.editCateData.cateName&&this.state.editCateData.sId){
      that.setState({
        visibleNewsEdit:false,
      });
      dispatch({
        type:"desk/cateUpdateButton",
        payload:Object.assign(this.state.editCateData,{
          cateName:this.state.cateName,
          sId:this.state.sId,
        }),
      }).then((result) => {
        switch (result.code) {
          case '200':
            dispatch({
              type: 'desk/fetchCateList',
              payload: this.state.formValues1,
            });
            message.success('更新成功');
            break;
          case '500':
            message.error(result.msg);
            break;
        }
      })
    }
  }

 // 添加台桌
  submitDesk(){
    const { dispatch} = this.props;
    const that=this;
    if(this.state.deskNum&&this.state.sIdDesk&&this.state.name&&this.state.cateId&&this.state.minPeople&&this.state.maxPeople){
      if((/^\d*$/.test(Number(this.state.deskNum)))&&(/^\d*$/.test(Number(this.state.minPeople)))&&(/^\d*$/.test(Number(this.state.maxPeople)))){
        dispatch({
          type:"desk/deskAddButton",
          payload:{
            name:this.state.name,
            sId:this.state.sIdDesk,
            cateId:this.state.cateId,
            deskNum:this.state.deskNum,
            mixPeople:this.state.minPeople,
            maxPeople:this.state.maxPeople,
          },
        }).then((result) => {
          switch (result.code) {
            case '200':
              dispatch({
                type: 'desk/fetchDeskList',
                payload: this.state.formValues,
              });
              that.setState({
                visibleImage:false,
              });
              message.success('添加成功');
              break;
            case '500':
              message.error(result.msg);
              break;
          }
        })
      }else{
        message.error("人数只能输入整数");
      }
    }else{
      message.error("您还有未填写的内容");
    }
  }

  // 更新桌台
  submitEidtDesk(){
    const { dispatch} = this.props;
    const that=this;
      that.setState({
        visibleImageEidt:false,
      });
      dispatch({
        type:"desk/deskUpdateButton",
        payload:Object.assign(this.state.editDeskData,{
          name:this.state.name,
          sId:this.state.sIdDesk,
          deskNum:this.state.deskNum,
          cateId:this.state.cateId,
          mixPeople:this.state.minPeople,
          maxPeople:this.state.maxPeople,
        }),
      }).then((result) => {
        switch (result.code) {
          case '200':
            dispatch({
              type: 'desk/fetchDeskList',
              payload: this.state.formValues,
            });
            message.success('更新成功');
            break;
          case '500':
            message.error(result.msg);
            break;
        }
      })
  }
  // 图片素材库model显示与隐藏

  handleCancelImageEdit(){
    this.setState({
      visibleImageEidt: false,
      editDeskData:"",
    });
  }
  handleCancelImage(){
    this.setState({
      visibleImage: false,
    });
  }

  handleConfirmBlur = e => {
    const value = e.target.value;
    this.setState({ confirmDirty: this.state.confirmDirty || !!value });
  };

  handleCancel = () => {
    this.setState({ visible: false });
  };

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'desk/fetchDeskList',
      payload: this.state.formValues,
    });
    dispatch({
      type: 'desk/shopList',
      payload:"",
    });
    dispatch({
      type: 'desk/fetchCateListForm',
      payload:{
        state:1,
      },
    });
  }

  // 设置有效和无效
  update=e=>{
    const {dispatch}=this.props;
    console.log(e)
    dispatch({
      type: 'desk/deskUpdateButton',
      payload:{state:e.state===1?0:1,dId:e.dId},
    }).then((result) => {
      switch (result.code) {
        case '200':
          dispatch({
            type: 'desk/fetchDeskList',
            payload: this.state.formValues,
          });
          message.success('设置成功');
          break;
        case '500':
          message.error(result.msg);
          break;
      }
    })
  };

  // 设置分类状态有效无效
  updateCate=e=>{
    const {dispatch}=this.props;
    dispatch({
      type: 'desk/cateUpdateButton',
      payload:{state:e.state===1?0:1,cateId:e.cateId},
    }).then((result) => {
      switch (result.code) {
        case '200':
          dispatch({
            type: 'desk/fetchCateList',
            payload: this.state.formValues1,
          });
          message.success('设置成功');
          break;
        case '500':
          message.error(result.msg);
          break;
      }
    })
  };

  handleFormReset = () => {
    const { form,dispatch} = this.props;
    form.resetFields();
    const params = {
      pageNo: 1,
      pageSize: 10,
    };
    dispatch({
      type: 'desk/fetchDeskList',
      payload: params,
    });
    this.setState({
      formValues:params,
    });
  };

  handleFormReset1 = () => {
    const { form,dispatch} = this.props;
    form.resetFields();
    const params = {
      pageNo: 1,
      pageSize: 10,
    };
    dispatch({
      type: 'desk/fetchCateList',
      payload: params,
    });
    this.setState({
      formValues:params,
    });
  };

  toggleForm = () => {
    const { expandForm } = this.state;
    this.setState({
      expandForm: !expandForm,
    });
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
  };

  handleSearch = e => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = {
        ...fieldsValue,
        sId:fieldsValue.sId1,
        pageNo: 1,
        pageSize: 10,
      };

      this.setState({
        formValues: values,
      });
      dispatch({
        type: 'desk/fetchDeskList',
        payload: values,
      });
    });
  };

  handleSearch1 = e => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = {
        ...fieldsValue,
        sId:fieldsValue.sId2,
        pageNo: 1,
        pageSize: 10,
      };
      this.setState({
        formValues1: values,
      });
      dispatch({
        type: 'desk/fetchCateList',
        payload: values,
      });
    });
  };

  cateShopListId=e=>{
    const {dispatch}=this.props;
    this.state.formValues1.sId=e;
    this.state.formValues1.pageNo=1;
    dispatch({
      type: 'desk/fetchCateList',
      payload: this.state.formValues1,
    });
    this.setState({
      formValues:this.state.formValues1,
    })
  };

  stateCate=e=>{
    const {dispatch}=this.props;
    this.state.formValues1.state=e;
    this.state.formValues1.pageNo=1;
    dispatch({
      type: 'desk/fetchCateList',
      payload: this.state.formValues1,
    });
    this.setState({
      formValues:this.state.formValues1,
    })
  };

  sidChange= e=>{
    const {dispatch}=this.props;
    this.state.formValues.sId=e;
    this.state.formValues.pageNo=1;
    dispatch({
      type: 'desk/fetchDeskList',
      payload: this.state.formValues,
    });
    this.setState({
      formValues:this.state.formValues,
    })
  };

  stateChange=e=>{
    const {dispatch}=this.props;
    this.state.formValues.state=e;
    this.state.formValues.pageNo=1;
    dispatch({
      type: 'desk/fetchDeskList',
      payload: this.state.formValues,
    });
    this.setState({
      formValues:this.state.formValues,
    })
  };

  cateId=e=>{
    const {dispatch}=this.props;
    this.state.formValues.cateId=e;
    this.state.formValues.pageNo=1;
    dispatch({
      type: 'desk/fetchDeskList',
      payload: this.state.formValues,
    });
    this.setState({
      formValues:this.state.formValues,
    })
  };

  renderSimpleForm(data) {
    this._data = data;
    const { form,desk} = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={4} sm={24}>
            <FormItem>
              {getFieldDecorator('sId1')(
                <Select placeholder="请选择所属门店" onChange={this.sidChange}>
                  <Option value="">请选择所属门店</Option>
                  {
                    desk.shopList?desk.shopList.map((item,i) => {
                      return(<Option key={i} value={item.sId}>{item.businessName}</Option>)
                    }):""
                  }
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={4} sm={24}>
            <FormItem>
              {getFieldDecorator('cateId')(
                <Select placeholder="请选择类型" onChange={this.cateId}>
                  <Option value="">请选择类型</Option>
                  {
                    desk.saveCateFormList?desk.saveCateFormList.map((item,index) => {
                      return(<Option key={index} value={item.cateId}>{item.cateName}</Option>)
                    }):""
                  }
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={4} sm={24}>
            <FormItem>
              {getFieldDecorator('state',{
                initialValue: this.state.formValues.state,
                }
              )(
                <Select placeholder="请选择状态" onChange={this.stateChange}>
                  <Option value="1">有效</Option>
                  <Option value="0">无效</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={12} sm={24}>
            <span className={styles.submitButtons}>
              <Button type="primary" htmlType="submit">
                查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                重置
              </Button>
                <Button
                  style={{float:"right"}}
                  type="primary"
                  onClick={() => this.addDesk()}
                >
                    新建桌台
                </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }



  renderSimpleForm1(data) {
    this._data = data;
    const { form,desk} = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch1} layout="inline">
        <Row gutter={{ md: 24, lg: 24, xl: 48 }}>
          <Col md={24} sm={24} lg={4}>
            <FormItem>
              {getFieldDecorator('sId2')(
                <Select placeholder="请选择所属门店" onChange={this.cateShopListId}>
                  <Option value="">请选择所属门店</Option>
                  {
                    desk.shopList?desk.shopList.map((item,index) => {
                      return(<Option key={index} value={item.sId}>{item.businessName}</Option>)
                    }):""
                  }
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={24} sm={24} lg={4}>
            <FormItem>
              {getFieldDecorator('state',{
                initialValue: this.state.formValues1.state,
              })(
                <Select placeholder="请选择状态" onChange={this.stateCate}>
                  <Option value="1">有效</Option>
                  <Option value="0">无效</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={24} sm={24} lg={16}>
            <span className={styles.submitButtons}>
              <Button type="primary" htmlType="submit">
                查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset1}>
                重置
              </Button>
                 <Button
                   style={{float:"right"}}
                   type="primary"
                   onClick={() => this.addClass()}
                 >
                    新建分类
                  </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }

  renderAdvancedForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="查询参数">
              {getFieldDecorator('keyword')(<Input placeholder="请输入关键词" />)}
            </FormItem>
          </Col>
        </Row>
        <div style={{ overflow: 'hidden' }}>
          <span style={{ float: 'right', marginBottom: 24 }}>
            <Button type="primary" htmlType="submit">
              查询
            </Button>
            <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
              重置
            </Button>
            <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
              收起 <Icon type="up" />
            </a>
          </span>
        </div>
      </Form>
    );
  }

  renderForm(data) {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm(data);
  }

   // 新建桌台
  addDesk(){
    this.setState({
      visibleImage:true,
    })
  }

  // 新增分类
  addClass(){
    this.setState({
      visibleNews:true,
    })
  }

  handleCancelNews(){
    this.setState({
      visibleNews:false,
    })
  }

  handleCancelNewsEdit(){
    this.setState({
      visibleNewsEdit:false,
      editCateData:"",
    })
  }

  // tab切换
  tabSwitch(e) {
    const { dispatch, autoReply } = this.props;
    switch (e) {
      case '1':
        this.state.formValues.pageNo=1;
        this.setState({
          switchType:e,
          formValues: this.state.formValues,
        })
        dispatch({
          type: 'desk/fetchDeskList',
          payload: this.state.formValues,
        });

        dispatch({
          type: 'desk/shopList',
          payload:"",
        });
        dispatch({
          type: 'desk/fetchCateListForm',
          payload:{
            state:1,
          },
        });
        break;
      case '2':
        // 判断选择
        this.state.formValues1.pageNo=1;
        dispatch({
          type: 'desk/fetchCateList',
          payload: this.state.formValues1,
        });
        dispatch({
          type: 'desk/shopList',
          payload:"",
        });
        dispatch({
          type: 'desk/fetchCateListForm',
          payload:{
            state:1,
          },
        });
        this.setState({
          switchType: e,
        });
        break;
    }

  }

  sIdDesk=e=>{
    this.setState({
      sIdDesk:e,
    })
  };

  editDesk=(data)=>{
    const {dispatch}=this.props;
    this.setState({
      visibleImageEidt:true,
      editDeskData:data,
    });
    dispatch({
      type:"desk/addon",
      payload:"",
    })

  };

  editCate=(data)=>{
    this.setState({
      visibleNewsEdit:true,
      editCateData:data,
    })
  };

  render() {
    const { desk, loading} = this.props;
    const { form } = this.props;
    const { getFieldDecorator } = form;
    const {
      selectedRows,
      alertVisible,
      message,
      type,
    } = this.state;
    const columns = [
      {
        title: '桌台名称',
        key: 'name',
        dataIndex: 'name',
      },
      {
        title: '所属门店',
        key: 'shopName',
        dataIndex: 'shopName',
      },
      {
        title: '分类',
        width: 200,
        key:"cateName",
        dataIndex:'cateName',
      },
      {
        title: '几人桌',
        width: 200,
        key:"deskNum",
        dataIndex:'deskNum',
      },
      {
        title: '状态',
        key: 'state',
        render: (text, record) => <span>{record.state === 0 ? '无效' : '有效'}</span>,
      },
      {
        title: '操作',
        width: 180,
        align:"right",
        fixed: 'right',
        render: (text, record) => (
          <Fragment>
            <a href="javaScript:void(0)" onClick={() => this.update(record)}>
              {record.state===0?"设置有效":"设置无效"}
            </a>
            <Divider type="vertical" />
            <a href="javaScript:void(0)" onClick={() => this.editDesk(record)}>
             编辑
            </a>
          </Fragment>
        ),
      },
    ];
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 8 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 },
      },
    };
    const columns1 = [
      {
        title: '分类名称',
        key: 'cateName',
        dataIndex: 'cateName',
      },
      {
        title: '所属门店',
        key: 'shopName',
        dataIndex: 'shopName',
      },
      {
        title: '状态',
        key: 'state',
        render: (text, record) => <span>{record.state === 0 ? '无效' : '有效'}</span>,
      },
      {
        title: '操作',
        width: 180,
        align:"right",
        fixed: 'right',
        render: (text, record) => (
          <Fragment>
            <a href="javaScript:void(0)" onClick={() => this.updateCate(record)}>
              {record.state===0?"设置有效":"设置无效"}
            </a>
            <Divider type="vertical" />
            <a href="javaScript:void(0)" onClick={() => this.editCate(record)}>
              编辑
            </a>
          </Fragment>
        ),
      },
    ];
    const cateName=e=>{
      this.setState({
        cateName:e.target.value,
      })
    };
    const sId=e=>{
      this.setState({
        sId:e,
      })
    };
    const prefixName=(e)=>{
      this.setState({
        cateId:e,
      })
    };
    const name=e=>{
      this.setState({
        name:e.target.value,
      })
    };
    const deskNum=e=>{
      if(! /^\d*$/.test(e.target.value)){
        message.error("只能输入整数")
        e.target.value=""
      }else{
        this.setState({
          deskNum:e.target.value,
        })
      }

    };
    const minPeople=e=>{
      if(! /^\d*$/.test(e.target.value)){
        message.error("只能输入整数")
        e.target.value=""
      }else{
        this.setState({
          minPeople:e.target.value,
        })
      }

    };
    const maxPeople=e=>{
      console.log(Number(e.target.value))
      if(! /^\d*$/.test(Number(e.target.value))){
        message.error("只能输入整数")
        e.target.value=""
      }else{
        this.setState({
          maxPeople:e.target.value,
        })
      }
    };

    return (
      <PageHeaderLayout title="">
        {alertVisible ? (
          <Alert message={message} showIcon type={type} closable afterClose={this.handleClose} />
        ) : null}
        <Card bordered={false}>
          <Tabs defaultActiveKey="1" onChange={this.tabSwitch} style={{marginTop:"-20px"}}>
            <TabPane tab="桌台设置" key="1">
              <div className={styles.tableList}>
                <div className={styles.tableListForm}>
                  {this.state.switchType==="1"?this.renderForm():""}

                </div>
                <div className={styles.tableListOperator}>
                  {selectedRows.length > 0 && (
                    <span>
                      <Button>批量操作</Button>
                    </span>
                  )}
                </div>
                <StandardTable
                  selectedRows={selectedRows}
                  loading={loading}
                  data={desk.deskList}
                  columns={columns}
                  onSelectRow={this.handleSelectRows}
                  onChange={this.handleStandardTableChange}
                />
              </div>
            </TabPane>
            <TabPane tab="分类设置" key="2">
              <div className={styles.tableList}>
                <div className={styles.tableListForm}>
                  {this.state.switchType==="2"?this.renderSimpleForm1():""}

                </div>
                <div className={styles.tableListOperator}>
                  {selectedRows.length > 0 && (
                    <span>
                      <Button>批量操作</Button>
                    </span>
                  )}
                </div>
                <StandardTable
                  selectedRows={selectedRows}
                  loading={loading}
                  data={desk.cateList}
                  columns={columns1}
                  onSelectRow={this.handleSelectRows}
                  onChange={this.handleStandardTableChange1}
                />
              </div>
            </TabPane>
          </Tabs>
        </Card>
        <Modal
          title="新建桌台"
          visible={this.state.visibleImage}
          footer={null}
          width="40%"
          onCancel={this.handleCancelImage}
        >
        <div style={{width:"500px",margin:"0 auto",padding:"0px 30px"}}>
          <Form style={{marginLeft:"-100px"}}>
            <FormItem {...formItemLayout} label="桌台名称">
              {getFieldDecorator('name')(<Input placeholder="请输入桌台名称" onChange={name}  />)}
            </FormItem>
            <FormItem {...formItemLayout} label="桌台所属门店">
              {getFieldDecorator('sIdDesk')(
                <Select placeholder="请选择所属门店" onChange={this.sIdDesk}>
                  <Option value="">请选择所属门店</Option>
                  {
                    desk.shopList?desk.shopList.map((item,index) => {
                      return(<Option key={index} value={item.sId}>{item.businessName}</Option>)
                    }):""
                  }
                </Select>
              )}
            </FormItem>
            <FormItem {...formItemLayout} label="桌台所属分类">
              {getFieldDecorator('prefixName')(
                <Select placeholder="请选择类型" onChange={prefixName}>
                  <Option value="">请选择类型</Option>
                  {
                    desk.saveCateFormList?desk.saveCateFormList.map((item,index) => {
                      return(<Option key={index} value={item.cateId}>{item.cateName}</Option>)
                    }):""
                  }
                </Select>
              )}
            </FormItem>
            <FormItem {...formItemLayout} label="几人桌">
              {getFieldDecorator('deskNum')(<Input type="number" placeholder="请输入人数" onChange={deskNum} />)}
            </FormItem>
            <FormItem {...formItemLayout} label="人数范围">
              {getFieldDecorator('mixPeople')(<div>
                <Input type="number" placeholder="请输入人数" onChange={minPeople} style={{width:"150px"}} /><span style={{margin:"0 20px"}}>至</span><Input type="number" placeholder="请输入人数" onChange={maxPeople} style={{width:"150px"}}/></div>)}
            </FormItem>

          </Form>
          <div style={{marginLeft:"45%"}}><Button type="primary" onClick={this.submitDesk} loading={loading}>确定</Button></div>
        </div>
        </Modal>
        <Modal
          title="编辑桌台"
          visible={this.state.visibleImageEidt}
          footer={null}
          width="40%"
          onCancel={this.handleCancelImageEdit}
        >
          {
            this.state.editDeskData? (
<div style={{width:"500px",margin:"0 auto",padding:"0px 30px"}}>
              <Form style={{marginLeft:"-100px"}}>
                <FormItem {...formItemLayout} label="桌台名称">
                  {getFieldDecorator('name',{
                    initialValue:this.state.editDeskData.name,
                  })(<Input placeholder="请输入桌台名称" onChange={name} />)}
                </FormItem>
                <FormItem {...formItemLayout} label="桌台所属门店">
                  {getFieldDecorator('sIdDesk',{
                    initialValue:this.state.editDeskData.sId,
                  })(
                    <Select placeholder="请选择所属门店" onChange={this.sIdDesk}>
                      <Option value="">请选择所属门店</Option>
                      {
                        desk.shopList?desk.shopList.map((item,index) => {
                          return(<Option key={index} value={item.sId}>{item.businessName}</Option>)
                        }):""
                      }
                    </Select>
                  )}
                </FormItem>
                <FormItem {...formItemLayout} label="桌台所属分类">
                  {getFieldDecorator('prefixName',{
                    initialValue:this.state.editDeskData.cateId,
                  })(
                    <Select placeholder="请选择类型" onChange={prefixName}>
                      <Option value="">请选择类型</Option>
                      {
                        desk.saveCateFormList?desk.saveCateFormList.map((item,index) => {
                          return(<Option key={index} value={item.cateId}>{item.cateName}</Option>)
                        }):""
                      }
                    </Select>
                  )}
                </FormItem>
                <FormItem {...formItemLayout} label="几人桌">
                  {getFieldDecorator('deskNum',{
                    initialValue:this.state.editDeskData.deskNum?this.state.editDeskData.deskNum:"",
                  })(<Input type="number" placeholder="请输入人数" onChange={deskNum} />)}
                </FormItem>
                <FormItem {...formItemLayout} label="人数范围">
                  {getFieldDecorator('mixPeople')(
                    <div>
                      <Input type="number" placeholder="请输入人数" onChange={minPeople} style={{width:"150px"}} defaultValue={this.state.editDeskData.mixPeople} />
                      <span style={{margin:"0 20px"}}>至</span>
                      <Input type="number" placeholder="请输入人数" onChange={maxPeople} style={{width:"150px"}} defaultValue={this.state.editDeskData.maxPeople} />
                    </div>)}
                </FormItem>
              </Form>
              <div style={{marginLeft:"45%"}}><Button type="primary" onClick={this.submitEidtDesk} loading={loading}>确定</Button></div>
</div>
):""
          }

        </Modal>
        <Modal
          title="添加分类"
          visible={this.state.visibleNews}
          footer={null}
          width="40%"
          onCancel={this.handleCancelNews}
        >
          <div style={{width:"500px",margin:"0 auto",padding:"0px 30px"}}>
            <Form style={{marginLeft:"-100px"}}>
              <FormItem {...formItemLayout} label="分类名称">
                {getFieldDecorator('cateName')(<Input placeholder="请输入分类名称" onChange={cateName} style={{width:"150px"}} />)}
              </FormItem>
              <FormItem {...formItemLayout} label="分类所属门店">
                {getFieldDecorator('sId')(
                  <Select placeholder="请选择所属门店" onChange={sId}>
                    <Option value="">请选择所属门店</Option>
                    {
                      desk.shopList?desk.shopList.map((item,index) => {
                        return(<Option key={index} value={item.sId}>{item.businessName}</Option>)
                      }):""
                    }
                  </Select>
                )}
              </FormItem>
            </Form>
            <div style={{marginLeft:"45%"}}><Button type="primary" onClick={this.submitCate} loading={loading}>确定</Button></div>
          </div>
        </Modal>
        <Modal
          title="更新分类"
          visible={this.state.visibleNewsEdit}
          footer={null}
          width="40%"
          onCancel={this.handleCancelNewsEdit}
        >
          {
            this.state.editCateData?  (
<div style={{width:"500px",margin:"0 auto",padding:"0px 30px"}}>
              <Form style={{marginLeft:"-100px"}}>
                <FormItem {...formItemLayout} label="分类名称">
                  {getFieldDecorator('cateName',{
                    initialValue:this.state.editCateData.cateName,
                  })(<Input placeholder="请输入分类名称" onChange={cateName}/>)}
                </FormItem>
                <FormItem {...formItemLayout} label="分类所属门店">
                  {getFieldDecorator('sId',{
                    initialValue:this.state.editCateData.sId,
                  })(
                    <Select placeholder="请选择所属门店" onChange={sId} >
                      <Option value="">请选择所属门店</Option>
                      {
                        desk.shopList?desk.shopList.map((item,index) => {
                          return(<Option key={index} value={item.sId}>{item.businessName}</Option>)
                        }):""
                      }
                    </Select>
                  )}
                </FormItem>
              </Form>
              <div style={{marginLeft:"45%"}}><Button type="primary" onClick={this.submitEidtCate} loading={loading}>确定</Button></div>
</div>
):""
          }
        </Modal>
      </PageHeaderLayout>
    );
  }
}
