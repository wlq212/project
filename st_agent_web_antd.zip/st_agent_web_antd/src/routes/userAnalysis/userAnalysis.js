/* eslint-disable no-unused-vars,react/destructuring-assignment,react/no-unused-state,class-methods-use-this,no-undef,no-shadow,react/sort-comp,prefer-destructuring,react/no-access-state-in-setstate,no-useless-escape,no-const-assign */
import React, { Component, Fragment } from 'react';
import { connect } from 'dva';
import moment from "moment";
import {
  Row,
  Col,
  Icon,
  Card,
  Table,
  Radio,
  DatePicker,
  Tooltip,
  Modal,
  Input,
  Select,
  Checkbox,
  List,
  Button,
  Pagination,
  Form,
  } from 'antd';
import {
  ChartCard,
  yuan,
  MiniArea,
  MiniBar,
  MiniProgress,
  Field,
  Bar,
  Pie,
  TimelineChart,
} from 'components/Charts';
import StandardTable from 'components/StandardTable';
import { getTimeDistance } from '../../utils/utils';
import styles from './userAnalysis.less';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import { getStore } from '../../assets/js/mUtils';

const { RangePicker } = DatePicker;
const Option = Select.Option;
const rankingListData = [];
for (let i = 0; i < 7; i += 1) {
  rankingListData.push({
    title: `工专路 ${i} 号店`,
    total: 323234,
  });
}
@connect(({ userAnalysis, loading }) => ({
  userAnalysis,
  loading: loading.models.userAnalysis,
}))
export default class Analysis extends Component {
  constructor(props) {
    super(props);
    this.state = {
      salesType: '0',
      downModel: false,
      activityModel: false,
      channelModel: false,
      channel: '',
      activity:"",
      selectedRows: [],
      currentTabKey: '',
      numberName:"新增关注人数",
      positionName:"newUser",
      userSource:"userSource",
      position0:"refDate*newUser",
      sortedInfo:"",
      formValues: {
        pageNo: 1,
        pageSize: 10,
      },
      formValuesActivity: {
        pageNo: 1,
        pageSize: 10,
      },
      initMap:[{
        cancelNumber:0,
        cancelRate: 0,
        date: "2018-08-24",
        goShopNumber: 0,
        netIncreaseNumber: 0,
        netIncreaseRate: 0,
        newNumber: 0,
        newRate: 0,
        oldNumber: 0,
        oldRate: 0,
        scanNumber: 0,
        scanRate: 0,
      }],
      search:{
        beginTime:getTimeDistance('month')[0].format('YYYY-MM-DD'),
        endTime:getTimeDistance('month')[1].format('YYYY-MM-DD'),
        userSource:"",
      },
      rangePickerValue: getTimeDistance('month'),
      rangePickerValueOne:getTimeDistance('month'),
    };
    this.handleDownCancel = this.handleDownCancel.bind(this);
    this.handleActivityCancel = this.handleActivityCancel.bind(this);
    this.handleChannelCancel = this.handleChannelCancel.bind(this);
    this.hanndleDownModelActivity=this.hanndleDownModelActivity.bind(this);
    this.hanndleDownModelChannel=this.hanndleDownModelChannel.bind(this);
    this.resetForm=this.resetForm.bind(this);
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'userAnalysis/userAnalysisListAllInfo',
      payload:this.state.search,
    });
    
    dispatch({
      type: 'userAnalysis/userAnalysisListAllInfoOne',
      payload:{
        beginTime:this.state.search.beginTime,
        endTime:this.state.search.endTime,
      },
    })
  }

  pageOnChange=(pagination, filtersArg, sorter) =>{
    const {dispatch}=this.props;
    this.state.search.pageNo=pagination;
    this.state.search.pageSize=filtersArg;
    this.setState({
      search: this.state.search,
    });
    dispatch({
      type: 'userAnalysis/userAnalysisListAllInfo',
      payload:this.state.search,
    });

  };

  handleStandardTableChangeChannel = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    params.pageNo = pagination.current;
    params.pageSize = pagination.pageSize;
    this.setState({
      formValues: params,
    });
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'userAnalysis/qrcodeListFetch',
      payload: params,
    });
  };

  showTooltip(tooltip,x,y){

  };

  handleChannelCancelActivity = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValuesActivity } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValuesActivity,
      ...filters,
    };
    params.pageNo = pagination.current;
    params.pageSize = pagination.pageSize;
    this.setState({
      formValuesActivity: params,
    });
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }
    dispatch({
      type: 'userAnalysis/fetchActivity',
      payload: params,
    });
  };

  // 下载模太框关闭
  handleDownCancel() {
    this.setState({
      downModel: false,
    });
  }

  handleActivityCancel() {
    this.setState({
      activityModel: false,
    });
  }

  hanndleDownModelActivity(){
    this.setState({
      activityModel: true,
    });
  }

  handleChannelCancel() {
    this.setState({
      channelModel: false,
    });
  }

  handleChannelSubmit() {

  }

  handleActivitySubmit() {

  }

  // 下载提交
  handleDownSubmit() {

  }

  showDownModel = () => {
    const {dispatch}=this.props;
    dispatch({
      type:"userAnalysis/dataExportExcel",
      payload:this.state.search,
    })
  };

  showActivityModel = () => {
    this.setState({
      activityModel: true,
    });
  };

  hanndleDownModelChannel=()=>{
    this.setState({
      channelModel: true,
    });
  };

  showChannelModel = () => {
    this.setState({
      channelModel: true,
    });
  };


  handleChangeSalesType = e => {
    const that=this;
    switch (e.target.value) {
      case "0":
        that.setState({
          numberName:"新增关注人数",
          positionName:"newUser",
          position0:"refDate*newUser",
        });
        break;
      case "1":
        that.setState({
          numberName:"取消关注人数",
          positionName:"cancelUser",
          position0:"refDate*cancelUser",
        });
        break;
      case "2":
        that.setState({
          numberName:"净增关注人数",
          positionName:"netIncreaseNumber",
          position0:"refDate*netIncreaseNumber",
        });
        break;
      case "3":
        that.setState({
          numberName:"累计人数",
          positionName:"cumulateUser",
          position0:"refDate*cumulateUser",
        });
        break;
    };
    this.setState({
      salesType: e.target.value,
    });
  };

  handleTabChange = key => {
    this.setState({
      currentTabKey: key,
    });
  };

  handleRangePickerChange = rangePickerValue => {
    console.log(rangePickerValue[0].format('YYYY-MM-DD'));
    console.log(rangePickerValue[1].format('YYYY-MM-DD'));
    this.setState({
      rangePickerValue,
    });
    const { dispatch } = this.props;
    if(rangePickerValue.length>0){
      this.state.search.beginTime=rangePickerValue[0].format('YYYY-MM-DD');
      this.state.search.endTime=rangePickerValue[1].format('YYYY-MM-DD');
      this.setState({
        search:this.state.search,
      });
      dispatch({
        type: 'userAnalysis/userAnalysisListAllInfo',
        payload:this.state.search,
      })
    }
  };

  handleRangePickerChangeOne= rangePickerValue => {
    this.setState({
      rangePickerValueOne:[...rangePickerValue],
    });
    const { dispatch } = this.props;
    if(rangePickerValue.length>0){
      this.setState({
        search:this.state.search,
      });
      dispatch({
        type: 'userAnalysis/userAnalysisListAllInfoOne',
        payload:{
          beginTime:rangePickerValue[0].format('YYYY-MM-DD'),
          endTime:rangePickerValue[1].format('YYYY-MM-DD'),
        },
      })
    }
  };



  selectActivity=(data)=> {
    const  {dispatch}=this.props;
    if(this.state.downModel){
      this.setState({
        modelActivity: data.activityName,
        activityModel:false,
      });
    }else{

      this.state.search.activityId=data.activityId
      this.setState({
        activity: data.activityName,
        search: this.state.search,
        activityModel:false,
      });
      dispatch({
        type: 'userAnalysis/userAnalysisListAllInfo',
        payload:this.state.search,
      })
    }
  };

  typeChange=(e)=>{
    const  {dispatch}=this.props;
    this.state.search.userSource=e;
    this.setState({
      userSource: e,
      search: this.state.search,
    });
    dispatch({
      type: 'userAnalysis/userAnalysisListAllInfo',
      payload:this.state.search,
    })
  };

  typeChangeModel=(e)=>{
    this.setState({
      typeModel: e,
    });
  };

  shopChangeModel=(e)=>{
    this.setState({
      shopModel: e,
    });
  };



  shopChange=(e)=>{
    const  {dispatch}=this.props;
    this.state.search.sId=e;
    this.setState({
      shop: e,
      search:this.state.search,
    });
    dispatch({
      type: 'userAnalysis/userAnalysisListAllInfo',
      payload:this.state.search,
    })
  };

  selectDate = type => {
    this.setState({
      rangePickerValue: getTimeDistance(type),
    });
    this.state.search.beginTime=getTimeDistance(type)[0].format('YYYY-MM-DD');
    this.state.search.endTime=getTimeDistance(type)[1].format('YYYY-MM-DD');
    const { dispatch } = this.props;
    this.setState({
      search:this.state.search,
    });
    dispatch({
      type: 'userAnalysis/userAnalysisListAllInfo',
      payload:this.state.search,
    });
  };

  isActive(type) {
    const { rangePickerValue } = this.state;
    const value = getTimeDistance(type);
    if (!rangePickerValue[0] || !rangePickerValue[1]) {
      return;
    }
    if (
      rangePickerValue[0].isSame(value[0], 'day') &&
      rangePickerValue[1].isSame(value[1], 'day')
    ) {
      return styles.currentDate;
    }
  }

  // 重置
  resetForm(){
    const {dispatch}=this.props;
    this.setState({
      activity:"",
      channel:"",
      search:{
        beginTime:getTimeDistance('week')[0].format('YYYY-MM-DD'),
        endTime:getTimeDistance('week')[1].format('YYYY-MM-DD'),
        channelType:"",
        sId:"",
        qrCodeId:"",
        pageNo:1,
        pageSize:10,
        dId:"",
        activityId:"",
      },
    })
    dispatch({
      type: 'userAnalysis/userAnalysisListAllInfo',
      payload:{
        beginTime:getTimeDistance('week')[0].format('YYYY-MM-DD'),
        endTime:getTimeDistance('week')[1].format('YYYY-MM-DD'),
        channelType:"",
        sId:"",
        qrCodeId:"",
        pageNo:1,
        pageSize:10,
        dId:"",
        activityId:"",
      },
    })
  }

  handleChange = (pagination, filters, sorter) => {
    this.setState({
      sortedInfo: sorter,
    });
  };

  getTypeVal(type){
    switch (Number(type)) {
      case 0:
        return "其他";
      case 1:
        return '公众号搜索';
      case 17:
        return '名片分享';
      case 30:
        return '扫描二维码';
      case 43:
        return '图文页右上角菜单';
      case 51:
        return '支付后关注';
      case 57:
        return '文页内公众号';
      case 75:
        return '公众号文章广告';
      case 78:
        return '朋友圈广告';
      default:
        return '全部来源';
    }
  }

  render() {
    const {dispatch,userAnalysis, loading}=this.props;
    const { rangePickerValue, salesType, initMap,sortedInfo} = this.state;
    const salesExtra = (
      <Row>
        <Col xl={24} lg={24} md={24} sm={24} xs={24} style={{overflow:'hidden'}}>
          <Select placeholder="请选择用户来源" defaultValue={this.state.type} style={{width:"300px",float:"left"}} onChange={this.typeChange}>
            <Option value="">所有来源</Option>
            <Option value="0">其他</Option>
            <Option value="1">公众号搜索 </Option>
            <Option value="17">名片分享</Option>
            <Option value="30">扫描二维码</Option>
            <Option value="43">图文页右上角菜单 </Option>
            <Option value="51">支付后关注</Option>
            <Option value="57">文页内公众号</Option>
            <Option value="75">公众号文章广告</Option>
            <Option value="78">朋友圈广告</Option>
          </Select>
          <div style={{float:"right"}}>
            <div className={styles.salesExtra}>
              <a className={this.isActive('week')} onClick={() => this.selectDate('week')} style={{marginLeft:"0px"}}>
                最近7天
              </a>
              <a className={this.isActive('selfMonth')} onClick={() => this.selectDate('selfMonth')}>
                最近15天
              </a>
              <a className={this.isActive('month')} onClick={() => this.selectDate('month')}>
                最近30天
              </a>
            </div>
            <RangePicker
              style={{marginBottom:"10px"}}
              value={rangePickerValue}
              onChange={this.handleRangePickerChange}

              disabledDate={current => {
                return current.isAfter();
              }}
            />

          </div>
        </Col>
      </Row>
    );
    const selectChannel = (data) => {
      if(this.state.downModel){
        this.setState({
          modelChannel: data.channelName,
          channelModel:false,
        });
      }else{
        this.state.search.dId=data.dId;
        this.state.search.qrCodeId=data.qrCodeId;
        this.setState({
          channel: data.channelName,
          search:this.state.search,
          channelModel:false,
        });
        dispatch({
          type: 'userAnalysis/userAnalysisListAllInfo',
          payload:this.state.search,
        })
      }
    };
    const columns = [{
      title: '时间',
      key:"refDate",
      sorter: (a, b) => a.refDate - b.refDate,
      sortOrder: sortedInfo.columnKey === 'refDate' && sortedInfo.order,
      render:(text, record) => (
        <span>{ moment(record.refDate).format('YYYY-MM-DD')}</span>
      ),
    }, {
      title: '新增关注人数',
      key:"newUser",
      dataIndex: 'newUser',
      sorter: (a, b) => a.newUser - b.newUser,
      sortOrder: sortedInfo.columnKey === 'newUser' && sortedInfo.order,
    }, {
      title: '取消关注人数',
      key:"cancelUser",
      dataIndex: 'cancelUser',
      sorter: (a, b) => a.cancelUser - b.cancelUser,
      sortOrder: sortedInfo.columnKey === 'cancelUser' && sortedInfo.order,
    }, {
      title: '净增关注人数',
      key:"c",
      render:(text, record) => (
        <span>{record.newUser-record.cancelUser}</span>
      ),
    },{
      title: '累计关注人数',
      key:"d",
      dataIndex: 'cumulateUser',
      sorter: (a, b) => a.cumulateUser - b.cumulateUser,
      sortOrder: sortedInfo.columnKey === 'cumulateUser' && sortedInfo.order,
    }];
    const { Chart, Geom, Axis, Tooltip, Coord, Label, Legend, View, Guide, Shape } = window.BizCharts;
    const second = 1000;
    const minute = 1000 * 60;
    const hour = 60 * minute;
    const day = 24 * hour;
    function pick(data, field) {
      return data.map((item) => {
        const result = {};
        for (const key in item) {
          if (item.hasOwnProperty(key) && field.indexOf(key) !== -1) {
            result[key] = item[key];
          }
        }
        return result;
      });
    };
    const data=userAnalysis.channelAnalysisList.list.length>0?userAnalysis.channelAnalysisList.list:[{
      appId:"京津冀",
      cancelUser:0,
      createTime:0,
      cumulateUser:0,
      id: "jjj",
      newUser:0,
      netIncreaseNumber:0,
      refDate:moment(Date.now()).format('YYYY-MM-DD'),
      userSource: "",
    }];
    const dataSource=userAnalysis.channelAnalysisList.list.length>0?userAnalysis.channelAnalysisList.list:[];
    const userDataKpiData=userAnalysis.channelAnalysisList.userDataKpi?userAnalysis.channelAnalysisList.userDataKpi:{
      allNumber: "",
      cancelNumber: "",
      dayAllRate:"",
      dayCancelRate:"",
      dayNetIncreaseRate:"",
      dayNewRate:"",
      netIncreaseNumber:"",
      newNumber:"",
    };
    const netIncreaseNumberArr=[];
    data.map((item) => {
      netIncreaseNumberArr.push(item.netIncreaseNumber)
    });
    const tag = this.getTypeVal(this.state.userSource);
    const scale = {
      refDate: {
        alias: '日期',
        type: 'time',
        mask: 'YYYY-MM-DD',
       },
       newUser: {
          min: 0,
          alias: `新增关注人数-${tag}`,
        },
      netIncreaseNumber: {
        min: Math.min(...netIncreaseNumberArr)>0?0:Math.min(...netIncreaseNumberArr),
        alias: `净增关注人数-${tag}`,
      },

      cancelUser: {
        min: 0,
        alias: `取消关注人数-${tag}`,
      },
      cumulateUser: {
        min: 0,
        alias: "累计关注人数",
      },
    };


    const reqStr = {

    };
    if(this.state.search.activityId){
      reqStr.activityId = this.state.search.activityId;
    }
    if(this.state.search.dId){
      reqStr.dId = this.state.search.dId;
    }
      reqStr.beginTime = moment(this.state.search.beginTime).format("YYYY-MM-DD");
      reqStr.endTime = moment(this.state.search.endTime).format("YYYY-MM-DD");
    if(this.state.search.qrCodeId){
      reqStr.qrCodeId = this.state.search.qrCodeId;
    }
    if(this.state.search.sId){
      reqStr.sId = this.state.search.sId;
    }
    if(this.state.search.channelType){
      reqStr.channelType = this.state.search.channelType;
    }
    const topColResponsiveProps = {
      xs: 24,
      sm: 12,
      md: 12,
      lg: 12,
      xl: 6,
      style: { marginBottom: 24 },
    };
    const url={};
     if(JSON.parse(getStore("userInfo"))){
       url.url=`/api/admin/userData/exportExcel?reqStr=${JSON.stringify(reqStr)}&token=${JSON.parse(getStore("userInfo")).token}`;
     }

    return (
      <PageHeaderLayout title="">
        <Card style={{marginBottom:"10px"}} title="昨日关键指标">
          <ul style={{display:"flex",listStyle:"none"}}>
            <li style={{width:"25%",textAlign: "center" ,borderRight:"1px solid #ddd"}}>
              <dl>
                <dt style={{fontSize:"16px"}}>新增关注人数</dt>
                <dd style={{fontSize:"30px"}}>{userDataKpiData.newNumber}</dd>
                <dd style={{overflow:"hidden"}}><span style={{float:"left",marginLeft:"35%"}}>日：</span>
                  <span style={{float:"left"}}>
                    {userDataKpiData.dayNewRate?<span>{Number(userDataKpiData.dayNewRate)<0?<i className="iconfont" style={{ color: "red" }}>&#xe7f2;</i>:<i className="iconfont" style={{ color: "green" }}>&#xe7f1;</i>}{Math.abs(userDataKpiData.dayNewRate)}%</span>:"--"}
                  </span>
                </dd>
                <dd style={{overflow:"hidden"}}><span style={{float:"left",marginLeft:"35%"}}>周：</span>
                  <span style={{float:"left"}}>
                    {userDataKpiData.weekNewRate?<span>{Number(userDataKpiData.weekNewRate)<0?<i className="iconfont" style={{ color: "red" }}>&#xe7f2;</i>:<i className="iconfont" style={{ color: "green" }}>&#xe7f1;</i>}{Math.abs(userDataKpiData.weekNewRate)}%</span>:"--"}
                  </span>
                </dd>
                <dd style={{overflow:"hidden"}}><span style={{float:"left",marginLeft:"35%"}}>月：</span>
                  <span style={{float:"left"}}>
                    {userDataKpiData.monthNewRate?<span>{Number(userDataKpiData.monthNewRate)<0?<i className="iconfont" style={{ color: "red" }}>&#xe7f2;</i>:<i className="iconfont" style={{ color: "green" }}>&#xe7f1;</i>}{Math.abs(userDataKpiData.monthNewRate)}%</span>:"--"}
                  </span>
                </dd>
              </dl>
            </li>
            <li style={{width:"25%",textAlign: "center",borderRight:"1px solid #ddd"}}>
              <dl>
                <dt style={{fontSize:"16px"}}>取消关注人数</dt>
                <dd style={{fontSize:"30px"}}>{userDataKpiData.cancelNumber}</dd>
                <dd style={{overflow:"hidden"}}><span style={{float:"left",marginLeft:"35%"}}>日：</span>
                  <span style={{float:"left"}}>
                    {userDataKpiData.dayCancelRate?<span>{Number(userDataKpiData.dayCancelRate)<0?<i className="iconfont" style={{ color: "red" }}>&#xe7f2;</i>:<i className="iconfont" style={{ color: "green" }}>&#xe7f1;</i>}{Math.abs(userDataKpiData.dayCancelRate)}%</span>:"--"}
                  </span>
                </dd>
                <dd style={{overflow:"hidden"}}><span style={{float:"left",marginLeft:"35%"}}>周：</span>
                  <span style={{float:"left"}}>
                    {userDataKpiData.weekCancelRate?<span>{userDataKpiData.weekCancelRate<0?<i className="iconfont" style={{ color: "red" }}>&#xe7f2;</i>:<i className="iconfont" style={{ color: "green" }}>&#xe7f1;</i>}{Math.abs(userDataKpiData.weekCancelRate)}%</span>:"--"}
                  </span>
                </dd>
                <dd style={{overflow:"hidden"}}><span style={{float:"left",marginLeft:"35%"}}>月：</span>
                  <span style={{float:"left"}}>
                    {userDataKpiData.monthCancelRate?<span>{userDataKpiData.monthCancelRate<0?<i className="iconfont" style={{ color: "red" }}>&#xe7f2;</i>:<i className="iconfont" style={{ color: "green" }}>&#xe7f1;</i>}{Math.abs(userDataKpiData.monthCancelRate)}%</span>:"--"}
                  </span>
                </dd>
              </dl>
            </li>
            <li style={{width:"25%",textAlign: "center",borderRight:"1px solid #ddd"}}>
              <dl>
                <dt style={{fontSize:"16px"}}>净增关注人数</dt>
                <dd style={{fontSize:"30px"}}>{userDataKpiData.netIncreaseNumber}</dd>
                <dd style={{overflow:"hidden"}}><span style={{float:"left",marginLeft:"35%"}}>日：</span>
                  <span style={{float:"left"}}>
                    {userDataKpiData.dayNetIncreaseRate?<span>{userDataKpiData.dayNetIncreaseRate<0?<i className="iconfont" style={{ color: "red" }}>&#xe7f2;</i>:<i className="iconfont" style={{ color: "green" }}>&#xe7f1;</i>}{Math.abs(userDataKpiData.dayNetIncreaseRate)}%</span>:"--"}
                  </span>
                </dd>
                <dd style={{overflow:"hidden"}}><span style={{float:"left",marginLeft:"35%"}}>周：</span>
                  <span style={{float:"left"}}>
                    {userDataKpiData.weekNetIncreaseRate?<span>{userDataKpiData.weekNetIncreaseRate<0?<i className="iconfont" style={{ color: "red" }}>&#xe7f2;</i>:<i className="iconfont" style={{ color: "green" }}>&#xe7f1;</i>}{Math.abs(userDataKpiData.weekNetIncreaseRate)}%</span>:"--"}
                  </span>
                </dd>
                <dd style={{overflow:"hidden"}}><span style={{float:"left",marginLeft:"35%"}}>月：</span>
                  <span style={{float:"left"}}>
                    {userDataKpiData.monthNetIncreaseRate?<span>{userDataKpiData.monthNetIncreaseRate<0?<i className="iconfont" style={{ color: "red" }}>&#xe7f2;</i>:<i className="iconfont" style={{ color: "green" }}>&#xe7f1;</i>}{Math.abs(userDataKpiData.monthNetIncreaseRate)}%</span>:"--"}
                  </span>
                </dd>
              </dl>
            </li>
            <li style={{width:"25%",textAlign: "center"}}>
              <dl>
                <dt style={{fontSize:"16px"}}>累计关注人数</dt>
                <dd style={{fontSize:"30px"}}>{userDataKpiData.allNumber}</dd>
                <dd style={{overflow:"hidden"}}><span style={{float:"left",marginLeft:"35%"}}>日：</span>
                  <span style={{float:"left"}}>
                    {userDataKpiData.dayAllRate?<span>{userDataKpiData.dayAllRate<0?<i className="iconfont" style={{ color: "red" }}>&#xe7f2;</i>:<i className="iconfont" style={{ color: "green" }}>&#xe7f1;</i>}{Math.abs(userDataKpiData.dayAllRate)}%</span>:"--"}
                  </span>
                </dd>
                <dd style={{overflow:"hidden"}}><span style={{float:"left",marginLeft:"35%"}}>周：</span>
                  <span style={{float:"left"}}>
                    {userDataKpiData.weekAllRate?<span>{userDataKpiData.weekAllRate<0?<i className="iconfont" style={{ color: "red" }}>&#xe7f2;</i>:<i className="iconfont" style={{ color: "green" }}>&#xe7f1;</i>}{Math.abs(userDataKpiData.weekAllRate)}%</span>:"--"}
                  </span>
                </dd>
                <dd style={{overflow:"hidden"}}><span style={{float:"left",marginLeft:"35%"}}>月：</span>
                  <span style={{float:"left"}}>
                    {userDataKpiData.monthAllRate?<span>{userDataKpiData.monthAllRate<0?<i className="iconfont" style={{ color: "red" }}>&#xe7f2;</i>:<i className="iconfont" style={{ color: "green" }}>&#xe7f1;</i>}{Math.abs(userDataKpiData.monthAllRate)}%</span>:"--"}
                  </span>
                </dd>
              </dl>
            </li>
          </ul>
        </Card>
        <Fragment>
          <List loading={loading}>
            <Card
              loading={loading}
              bordered={false}
              bodyStyle={{ padding: 0 }}
              title={salesExtra}
            >
              <div className={styles.salesCard}>
                <Radio.Group
                  value={salesType}
                  onChange={this.handleChangeSalesType}
                  style={{ marginTop: '20px', marginLeft: '30px',float:"left",zIndex:111,position:"absolute"}}
                >
                  <Radio.Button value="0">新增关注人数</Radio.Button>
                  <Radio.Button value="1">取消关注人数</Radio.Button>
                  <Radio.Button value="2">净增关注人数</Radio.Button>
                  <Radio.Button value="3">累计人数</Radio.Button>
                </Radio.Group>
                <Row>
                  <Col xl={24} lg={24} md={24} sm={24} xs={24}  style={{marginTop:"30px"}}>
                    <div className={styles.salesBar} style={{ marginTop: '20px' ,width:"95%"}}>
                      <Chart
                        height={400}
                        padding={[20, 40, 80, 40]}
                        forceFit

                        scale={{ time: { sync: true } }}
                      >
                        <Tooltip />
                        <Legend />
                        <View
                          data={pick(data.length>0?data:initMap, ['refDate', this.state.positionName])}
                          scale={scale}
                        >
                          <Axis name="time" grid={null} />
                          <Geom type="line" position={this.state.position0} color="#9AD681" size={3} shape="genre" />
                          <Geom
                            type="point"
                            shape="circle"
                            color="#9AD681"
                            position={this.state.position0}
                            style={{
                            stroke: "#fff",
                            lineWidth: 1,
                            }}
                            size={4}
                          />
                        </View>
                      </Chart>
                      <div style={{width:"400px",marginLeft:"40%",marginTop:"-40px"}}>
                        <span><span style={{display:"inline-block",height:"10px",width:"40px",background:"#9AD681",marginRight:"10px"}} />{this.state.numberName}</span>
                      </div>
                    </div>
                  </Col>
                </Row>
                <Row style={{ position: 'relative'}}>
                  <div style={{float:"right",marginRight:"30px"}}>
                    <a href={url.url} style={{display:"block",height:"40px",width:"70px",background:"#4FAAEB",textAlign:"center",lineHeight:"40px",color:"#fff",marginBottom:"10px",borderRadius:"5px"}}>导出excel</a>
                  </div>
                  <div style={{padding:"30px"}}>
                    <RangePicker
                      value={this.state.rangePickerValueOne}
                      onChange={this.handleRangePickerChangeOne}
                      style={{marginBottom:"10px"}}
                      disabledDate={current => {
                        return current.isAfter();
                      }}
                    />
                    <Table pagination={{defaultCurrent:this.state.search.pageNo,pageSize:10,pageNo:this.state.search.pageNo,showSizeChanger:true,showQuickJumper:true}} columns={columns} dataSource={userAnalysis.tableList.list} size="middle" bordered onChange={this.handleChange} />
                  </div>
                </Row>
              </div>
            </Card>
          </List>
        </Fragment>
      </PageHeaderLayout>
    );
  }


}
