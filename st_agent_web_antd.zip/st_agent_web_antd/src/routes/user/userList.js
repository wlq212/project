/* eslint-disable no-unused-vars,react/no-unused-state,react/destructuring-assignment,no-case-declarations,prefer-destructuring,no-shadow,react/sort-comp,no-param-reassign */
import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import {
  Row,
  Col,
  Card,
  Form,
  Input,
  Select,
  Icon,
  Button,
  Alert,
  Modal,
  DatePicker,
  message,
  Divider,
} from 'antd';
import {isUndefined} from 'lodash';
import moment from 'moment';
import StandardTable from 'components/StandardTable';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from '../../assets/css/common.less';
import { getStore,setStore} from '../../assets/js/mUtils';

const {RangePicker} = DatePicker;
const FormItem = Form.Item;
const { Option } = Select;
const getValue = obj =>
  Object.keys(obj)
    .map(key => obj[key])
    .join(',');
const CreateForm = Form.create()(props => {
  const { modalVisible, form, handleAdd, handleModalVisible, handleChange } = props;
  const okHandle = () => {
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      handleAdd(fieldsValue);
    });
  };
  return (
    <Modal
      title="账号添加"
      visible={modalVisible}
      onOk={okHandle}
      onCancel={() => handleModalVisible()}
    >
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号类型" validateStatus="success">
        {form.getFieldDecorator('roleType', {
          rules: [{ required: true, message: '请选择账号类型' }],
        })(<Select
          style={{ width: 290 }}
          placeholder="请选择账号类型"
          optionFilterProp="children"
          onChange={handleChange}
        >
          <Option value="200">管理员</Option>
          <Option value="300">普通成员</Option>
        </Select>)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="品牌名称" validateStatus="success">
        {form.getFieldDecorator('brandName',{
          rules: [{ required: true, message: '请输入品牌名称' }],
        })(<Input placeholder="请输入品牌名称" id="brandNameOne" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号" validateStatus="success">
        {form.getFieldDecorator('userName', {
          rules: [{ required: true, message: '请输入账号' }],
        })(<Input placeholder="请输入账号" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="密码">
        {form.getFieldDecorator('pwd', {
          rules: [{ required: true, message: '请输入密码' }],
        })(<Input placeholder="请输入密码" type="password" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="微信号">
        {form.getFieldDecorator('city')(<Button type="primary">关联微信</Button>)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="手机号">
        {form.getFieldDecorator('city')(<Input placeholder="请输入手机号" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="城市">
        {form.getFieldDecorator('mobile')(<Input placeholder="请输入" />)}
      </FormItem>
      <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="状态">
        {form.getFieldDecorator('state', {
          rules: [{ required: true, message: '请选择状态' }],
        })(<Select
          style={{ width: 290 }}
          placeholder="请选择状态"
          optionFilterProp="children"
          onChange={handleChange}
        >
          <Option value="0">停用</Option>
          <Option value="1">正常</Option>
        </Select>)}
      </FormItem>
    </Modal>
  );
});

const CollectionCreateForm = Form.create({
  mapPropsToFields(props) {
    return {
      roleType: Form.createFormField(props.selectRowData.roleType),
      brandName: Form.createFormField(props.selectRowData.brandName),
      userName: Form.createFormField(props.selectRowData.userName),
      pwd: Form.createFormField(props.selectRowData.pwd),
      city: Form.createFormField(props.selectRowData.city),
      mobile: Form.createFormField(props.selectRowData.mobile),
      state: Form.createFormField(props.selectRowData.state),
    };
  },
})(
  class extends React.Component {
    render() {
      const { visible, onCancel, onCreate, form } = this.props;
      return (
        <Modal
          visible={visible}
          title="更新"
          okText="更新"
          onCancel={onCancel}
          onOk={onCreate}
        >
          <Form layout="vertical">
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号类型" validateStatus="success">
              {form.getFieldDecorator('roleType', {
                rules: [{ required: true, message: '请选择账号类型' }],
              })(<Select
                style={{ width: 290 }}
                placeholder="请选择账号类型"
                optionFilterProp="children"
              >
                <Option value="200">管理员</Option>
                <Option value="300">普通成员</Option>
              </Select>)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="品牌名称" validateStatus="success">
              {form.getFieldDecorator('brandName', {
                rules: [{ required: true, message: '请输入品牌名称' }],
              })(<Input placeholder="请输入品牌名称" id="brandNameOne" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="账号" validateStatus="success">
              {form.getFieldDecorator('userName', {
                rules: [{ required: true, message: '请输入账号' }],
              })(<Input placeholder="请输入账号" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="密码">
              {form.getFieldDecorator('pwd', {
                rules: [{ required: true, message: '请输入密码' }],
              })(<Input placeholder="请输入密码" type="password" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="微信号">
              {form.getFieldDecorator('city')(<Button type="primary">关联微信</Button>)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="手机号">
              {form.getFieldDecorator('city')(<Input placeholder="请输入手机号" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="城市">
              {form.getFieldDecorator('mobile')(<Input placeholder="请输入" />)}
            </FormItem>
            <FormItem labelCol={{ span: 5 }} wrapperCol={{ span: 15 }} label="状态">
              {form.getFieldDecorator('state', {
                rules: [{ required: true, message: '请选择状态' }],
              })(<Select
                style={{ width: 290 }}
                placeholder="请选择状态"
                optionFilterProp="children"
              >
                <Option value="0">停用</Option>
                <Option value="1">正常</Option>
              </Select>)}
            </FormItem>
          </Form>
        </Modal>
      );
    }
  },
);

@connect(({ userList,loading }) => ({
  userList,
  loading: loading.models.userList,
}))

@Form.create()
export  default class TableList extends PureComponent {
  constructor(props){
    super(props);
    this.state = {
      visible: false,
      modalVisible: false,
      selectRowData: {},
      message: '',
      type: '',
      modelTitle: '添加管理员',
      alertVisible: false,
      expandForm: false,
      selectedRows: [],
      timeArr:[],
      formValues: {

      },
    };
    this.onChangeTime=this.onChangeTime.bind(this);
  }


  handleCancel = () => {
    this.setState({ visible: false });
  };

  handleCreate = () => {
    const form = this.formRef.props.form;
    form.validateFields((err) => {
      if (err) {
        return;
      }

      // console.log('Received values of form: ', values);
      form.resetFields();
      this.setState({ visible: false });
    });
  };

  saveFormRef = (formRef) => {
    this.formRef = formRef;
  };

  componentDidMount() {
    const { dispatch } = this.props;
    if(getStore("formValues")){
      dispatch({
        type: 'userList/fetch',
        payload: {
          ...JSON.parse(getStore("formValues")),
        },
      });
      this.setState({
        formValues:{
          ...JSON.parse(getStore("formValues")),
        },
      })
    }else{
      const params = {
        pageNo: 1,
        pageSize: 10,
      };

      dispatch({
        type: 'userList/fetch',
        payload: params,
      });
    }


  }

  handleChange = flag => {

  };

  handleStandardTableChange = (pagination, filtersArg, sorter) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});


    const params = {
      pageNo: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    params.pageNo=pagination.current;
    params.pageSize=pagination.pageSize;
    setStore("formValues",params);
     this.setState({
       formValues:params,
     });
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }

    dispatch({
      type: 'userList/fetch',
      payload: params,
    });
  };

  handleFormReset = () => {
    const { form,dispatch} = this.props;
    form.resetFields();
    const params = {
      pageNo: 1,
      pageSize: 10,
    };
    dispatch({
      type: 'userList/fetch',
      payload: params,
    });
    setStore("formValues",params);
    this.setState({
      formValues:params,
    });
  };

  toggleForm = () => {
    const { expandForm } = this.state;
    this.setState({
      expandForm: !expandForm,
    });
  };

  handleMenuClick = e => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (!selectedRows) return;

    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'rule/remove',
          payload: {
            no: selectedRows.map(row => row.no).join(','),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };

  handleSelectRows = rows => {
    this.setState({
      selectedRows: rows,
    });
  };

  handleSearch = e => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      if(fieldsValue.nickName){
        this.state.formValues.nickName=fieldsValue.nickName.replace(/\s/gi,'');
      }
      const values = {
        ...this.state.formValues,
        pageNo: 1,
        pageSize: 10,
      };
      this.setState({
        formValues: values,
      });
      setStore("formValues",this.state.formValues);
      dispatch({
        type: 'userList/fetch',
        payload: values,
      });

    });
  };

  handleSearchSubscribe= e => {
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      fieldsValue.subscribe=e;
      const values = {
        ...fieldsValue,
        pageNo: 1,
        pageSize: 10,
      };
      this.setState({
        formValues: values,
      });
      setStore("formValues",this.state.formValues);
      dispatch({
        type: 'userList/fetch',
        payload: values,
      });

    });
  };

  handleSearchSex= e => {
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      fieldsValue.sex=e;
      const values = {
        ...fieldsValue,
        pageNo: 1,
        pageSize: 10,
      };

      this.setState({
        formValues: values,
      });
      setStore("formValues",this.state.formValues);
      dispatch({
        type: 'userList/fetch',
        payload: values,
      });

    });
  };

  handleSearchSubscribeScene= e => {
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      fieldsValue.subscribeScene=e;
      const values = {
        ...fieldsValue,
        pageNo: 1,
        pageSize: 10,
      };
      this.state.formValues.subscribeScene=e;
      this.setState({
        formValues: this.state.formValues,
      });
      setStore("formValues",this.state.formValues);
      dispatch({
        type: 'userList/fetch',
        payload: values,
      });

    });
  };

  detail = rows => {
    const { dispatch } = this.props;
    dispatch({
      type: 'userList/userDetail',
      payload: rows,
    });
    dispatch(routerRedux.push('/userManage/userList/userDetail'));
    setStore("formValues",this.state.formValues)
  };

  actionData = data => {
    const { dispatch } = this.props;
    const values = {};
    if(data.unionId != null && data.unionId !== ""){
      values.unionId = data.unionId;
    }else {
      values.openId = data.openId;
    }
    dispatch(routerRedux.push({pathname:'/userManage/userList/userAction',params:{...values}}));
  };

  handleModalVisible = flag => {
    this.setState({
      modalTitle: '管理员添加',
      modalVisible: !!flag,
    });
  };

  handleClose = () => {
    this.setState({ alertVisible: false });
  };

  handleAdd = fields => {
    const { dispatch, userList } = this.props;
    dispatch({
      type: 'userList/add',
      payload: fields,
    });
    if (userList.saveAddresult) {
      switch (userList.saveAddresult.code) {
        case '200':
          const params = {
            pageNo: 1,
            pageSize: 10,
          };
          dispatch({
            type: 'userList/fetch',
            payload: params,
          });
          this.setState({
            modalVisible: false,
          });
          message.success('添加成功');
          break;
        case '500':
          message.error(userList.result.msg || '添加失败');
          break;
        default:
          message.error(userList.result.msg);
          break;
      }
    }

  };

  edit(data) {
    this.setState({
      selectRowData: data,
      visible: true,
    });
  };

  onChangeTime(e,dateString){
    const {dispatch}=this.props;
    const params = {
      pageNo: 1,
      pageSize: 10,
      beginTime:moment(e[0]).format('YYYY-MM-DD HH:mm:ss'),
      endTime:moment(e[1]).format('YYYY-MM-DD HH:mm:ss'),
    };
    this.state.formValues.beginTime=moment(e[0]).format('YYYY-MM-DD HH:mm:ss');
    this.state.formValues.endTime=moment(e[1]).format('YYYY-MM-DD HH:mm:ss');
    this.setState({
      formValues:this.state.formValues,
    });
    setStore("formValues",this.state.formValues);
    dispatch({
      type: 'userList/fetch',
      payload: params,
    });
  }

  renderSimpleForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    console.log(this.state.formValues)
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 24, lg: 24, xl: 48 }}>
          <Col md={24} sm={24} lg={4} style={{paddingRight:"0px"}}>
            <FormItem>
              {getFieldDecorator('subscribe',{
                initialValue:this.state.formValues.subscribe?this.state.formValues.subscribe:"",
              })(
                <Select
                  showSearch
                  onChange={this.handleSearchSubscribe}
                  placeholder="请选择订阅状态"
                  optionFilterProp="children"
                >
                  <Option value="">选择订阅状态</Option>
                  <Option value="1">已关注</Option>
                  <Option value="0">取消关注</Option>
                </Select>)}
            </FormItem>
          </Col>
          <Col md={24} sm={24} lg={4} style={{paddingRight:"0px"}}>
            <FormItem>
              {getFieldDecorator('sex',{
                  initialValue:this.state.formValues.sex?this.state.formValues.sex:"",
              })(
                <Select
                  showSearch
                  onChange={this.handleSearchSex}
                  placeholder="请选择性别"
                  optionFilterProp="children"
                >
                  <Option value="">选择性别</Option>
                  <Option value="1">男</Option>
                  <Option value="2">女</Option>
                  <Option value="0">未知</Option>
                </Select>)}
            </FormItem>
          </Col>
          <Col md={24} sm={24} lg={4} style={{paddingRight:"0px"}}>
            <FormItem>
              {getFieldDecorator('subscribeScene',{
                initialValue:this.state.formValues.subscribeScene?this.state.formValues.subscribeScene:"",
              })(
                <Select
                  showSearch
                  onChange={this.handleSearchSubscribeScene}
                  placeholder="请选择渠道"
                  optionFilterProp="children"
                >
                  <Option value="">选择渠道</Option>
                  <Option value="ADD_SCENE_SEARCH">公众号搜索</Option>
                  <Option value="ADD_SCENE_ACCOUNT_MIGRATION">公众号迁移</Option>
                  <Option value="ADD_SCENE_PROFILE_CARD">名片分享</Option>
                  <Option value="ADD_SCENE_QR_CODE">扫描二维码</Option>
                  <Option value="ADD_SCENEPROFILE_LINK">图文页内名称点击</Option>
                  <Option value="ADD_SCENE_PROFILE_ITEM">图文页右上角菜单</Option>
                  <Option value="ADD_SCENE_PAID">支付后关注</Option>
                  <Option value="ADD_SCENE_OTHERS">其他</Option>
                </Select>)}
            </FormItem>
          </Col>
          <Col md={24} sm={24} lg={6} style={{paddingRight:"0px"}}>
            <FormItem>
              {getFieldDecorator('timeArr',{
                initialValue:this.state.formValues.beginTime?[moment(this.state.formValues.beginTime,"YYYY-MM-DD HH:mm:ss"), moment(this.state.formValues.endTime, "YYYY-MM-DD HH:mm:ss")]:"",
              })(
                <RangePicker onChange={this.onChangeTime}  format="YYYY-MM-DD HH:mm:ss"/>
              )}
            </FormItem>
          </Col>
          <Col md={24} sm={24} lg={5} style={{paddingRight:"0px"}}>
            <FormItem>
              {getFieldDecorator('nickName',{
                initialValue:this.state.formValues.nickName,
              })(<Input placeholder="请输入用户昵称" />)}
            </FormItem>
          </Col>

        </Row>
        <Row>
          <Col md={24} sm={24} lg={4}>
            <span className={styles.submitButtons}>
              <Button type="primary" htmlType="submit">
              查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
            重置
              </Button>
            </span>
          </Col>
        </Row>
      </Form>
    );
  };

  renderAdvancedForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="查询参数">
              {getFieldDecorator('brandName')(<Input placeholder="请输入品牌或者账号" />)}
            </FormItem>
          </Col>
        </Row>
        <div style={{ overflow: 'hidden' }}>
          <span style={{ float: 'right', marginBottom: 24 }}>
            <Button type="primary" htmlType="submit">
              查询
            </Button>
            <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
            重置
            </Button>
            <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
            收起 <Icon type="up" />
            </a>
          </span>
        </div>
      </Form>
    );
  };

  renderForm() {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm();
  };

  render() {
    const { userList, loading } = this.props;
    const { selectedRows, modalVisible, alertVisible, message, type, modalTitle, selectRowData } = this.state;
    userList.data.pagination.current=this.state.formValues.pageNo;
    const data = userList.data;
    const columns = [
      {
        title: '头像',
        key: 'headImgUrl',
        render: (text, record) => (
          record.headImgUrl?<img alt="" src={record.headImgUrl} className={styles.awart} />:<img alt="" src={record.headImgUrl} className={styles.awart} />
        ),
      },
      {
        title: '昵称',
        key: 'nickName',
        dataIndex: 'nickName',
        render: (text, record) => (
          <span>{record.nickName?record.nickName:"未知"}</span>
        ),
      },
      {
        title: '性别',
        dataIndex: 'sex',
        key: 'sex',
        render: (text, record) => (
          <span>{record.sex === 1 ? '男' : record.sex === 2 ? '女' : '未知'}</span>
        ),
      },
      {
        title: '手机号',
        dataIndex: 'mobile',
        key: 'mobile',
        render: (val) => (
          <span>{val || '--'}</span>
        ),
      },
      {
        title: '地区',
        key: 'country',
        render: (text, record) => (
          <span>{`${record.country == null ? '' : record.country  }-${  record.province == null ? '' : record.province  }-${  record.city == null ? '' : record.city}`}</span>
        ),
      },
      {
        title: '订阅',
        key: 'subscribe',
        render: (text, record) => (
          <span>{record.subscribe === 0 ? '未订阅' : record.subscribe===1?'已订阅':'未知'}</span>
        ),
      },
      {
        title: '时间',
        key: 'subscribeTime',
        dataIndex: 'subscribeTime',

      },
      {
        title: '操作',
        render: (text, record) => (
          <Fragment>
            <a onClick={() => this.detail(record)}>详细</a>
            <Divider type="vertical" />
            <a onClick={() => this.actionData(record)}>行为数据</a>
          </Fragment>
        ),
      },
    ];
    const parentMethods = {
      handleAdd: this.handleAdd,
      handleModalVisible: this.handleModalVisible,
    };
    return (
      <PageHeaderLayout title="">
        {
          alertVisible ? (
            <Alert
              message={message}
              showIcon
              type={type}
              closable
              afterClose={this.handleClose
                }
            />
            ) :
            null
        }
        <Card bordered={false}>
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>
              {this.renderForm()}
            </div>
            <div className={styles.tableListOperator}>
              {selectedRows.length > 0 && (
                <span>
                  <Button>批量操作</Button>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={data}
              columns={columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
            />
          </div>
        </Card>
        <CollectionCreateForm
          wrappedComponentRef={this.saveFormRef}
          visible={this.state.visible}
          onCancel={this.handleCancel}
          onCreate={this.handleCreate}
          selectRowData={selectRowData}
        />
        <CreateForm {...parentMethods} modalVisible={modalVisible} modalTitle={modalTitle} />
      </PageHeaderLayout>
    );
  }
}
