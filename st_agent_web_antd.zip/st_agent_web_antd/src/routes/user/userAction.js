/* eslint-disable react/no-unused-state,no-param-reassign,class-methods-use-this */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import { Row, Col, Card, Form, Select, DatePicker,Timeline ,Icon,List} from 'antd';
import { isUndefined,isArray } from 'lodash';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from '../../assets/css/common.less';

const FormItem = Form.Item;
const { Option } = Select;
const DatePickerRangePicker = DatePicker.RangePicker;

@connect(({userList, loading }) => ({
  userList,
  loading: loading.models.userList,
}))
@Form.create()
export default class UserActionList extends PureComponent {
  state = {
    params:"",
  };

  componentDidMount() {
    const { dispatch,location:{params}} = this.props;
    if(isUndefined(params)){
      dispatch(routerRedux.push('/userManage/userList'));
      return;
    }
    this.setState({params});
    const data = {
      pageNo: 1,
      pageSize: 999999,
      ...params,
    };
    dispatch({
      type: 'userList/userActionListFetch',
      payload: data,
    });
  }

  /**
   * 搜索类型
   * @param e
   */
  handleSearchType = e => {
    const { dispatch, form } = this.props;
    const {params} = this.state;
    let beginTime;
    let endTime;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const rangeValue = fieldsValue.time;
      if(!isUndefined(rangeValue) && rangeValue.length > 0){
        beginTime = rangeValue[0].format('YYYY-MM-DD');
        endTime = rangeValue[1].format('YYYY-MM-DD');
      }
      const values = {
        pageNo: 1,
        pageSize: 999999,
        ...params,
        beginTime,
        endTime,
        type:e,
      };
      dispatch({
        type: 'userList/userActionListFetch',
        payload: values,
      });

    });
  };

  /**
   * 搜索时间
   * @param e
   * @param time
   */
  handleSearchTime =(e,time) => {
    const { dispatch, form } = this.props;
    const {params} = this.state;
    form.validateFields((err, fieldsValue) => {
      const values = {
        pageNo: 1,
        pageSize: 999999,
        beginTime: time[0],
        endTime: time[1],
        type:fieldsValue.type,
        ...params,
      };
      dispatch({
        type: 'userList/userActionListFetch',
        payload: values,
      });
    });
  };

  /**
   * 查询
   * @param e
   */
  handleSearch = e => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    const {params} = this.state;
    let beginTime;
    let endTime;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const rangeValue = fieldsValue.time;
      if(!isUndefined(rangeValue) && rangeValue.length > 0){
        beginTime = rangeValue[0].format('YYYY-MM-DD');
        endTime = rangeValue[1].format('YYYY-MM-DD');
      }
      const values = {
        pageNo: 1,
        pageSize: 999999,
        beginTime,
        endTime,
        ...fieldsValue,
        ...params,
      };
      dispatch({
        type: 'userList/userActionListFetch',
        payload: values,
      });
    });
  };

  parseChildData(userActionList) {
    const htmlStr = [];
    for(let i = 0 ; i < userActionList.length ; i +=1){
      const item = userActionList[i];
      if(i === 0){
        htmlStr.push(<Timeline.Item color="red" key={item.id}><h3 style={{color:"red"}}>{item.createTime.substring(0,10)}</h3></Timeline.Item>);
      }else if(i > 0){
        const prevItem = userActionList[i-1];
        if(prevItem.createTime.substring(0,10) !== item.createTime.substring(0,10)){
          htmlStr.push(<Timeline.Item color="red" key={item.id}><h3 style={{color:"red"}}>{item.createTime.substring(0,10)}</h3></Timeline.Item>);
        }
      }
      htmlStr.push(<Timeline.Item dot={<Icon type="clock-circle-o" style={{ fontSize: '16px' }} />}><p>【{item.createTime.substring(11,item.createTime.length)}】{item.action}</p></Timeline.Item>);
    }
    return htmlStr;
  };

  renderSimpleForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;

    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={6} sm={24}>
            <FormItem>
              {getFieldDecorator('time')(<DatePickerRangePicker onChange={this.handleSearchTime} />)}
            </FormItem>
          </Col>
          <Col md={4} sm={24} style={{paddingRight:"10px",paddingLeft:"10px"}}>
            <FormItem>
              {getFieldDecorator('type',{
                initialValue:"",
              })(
                <Select onChange={this.handleSearchType}>
                  <Option value="">请选择数据类型</Option>
                  <Option value={1}>操作数据</Option>
                  <Option value={2}>行为数据</Option>
                  <Option value={3}>消费数据</Option>
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
      </Form>
    );
  };



  render() {
    const { userList: { userActionList },loading } = this.props;
    return (
      <PageHeaderLayout showReturn url="/userManage/userList">
        <Card>
          <div className={styles.tableListForm}>
            {this.renderSimpleForm()}
          </div>
          <div style={{height:"65vh",overflow:"auto",borderTop:"1px solid #ddd",padding:30}}>
            <List loading={loading}>
              <Timeline>
                {
                  isArray(userActionList) && userActionList.length > 0 ? this.parseChildData(userActionList) : <div style={{textAlign:"center",color:"#999"}}>暂无数据</div>
                }
              </Timeline>
            </List>
          </div>
        </Card>
      </PageHeaderLayout>
    );
  }
}
