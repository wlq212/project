/* eslint-disable no-unused-vars,react/jsx-boolean-value */
import React, { PureComponent } from 'react';
import { connect } from 'dva';
import {
  Form,
  Input,
  Card,
  } from 'antd';
import PageHeaderLayout from '../../layouts/PageHeaderLayout';
import styles from '../../assets/css/style.less';

const FormItem = Form.Item;
@connect(({ userList, loading }) => ({
  userList,
  loading: loading.models.userList,
}))
@Form.create()
export  default class BasicForms extends PureComponent {
  render() {
    const { form, userList } = this.props;
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 },
        md: { span: 10 },
      },
    };
    return (
      <PageHeaderLayout showReturn={true} url="/userManage/userList">
        <Card bordered={false}>
          <Form onSubmit={this.handleSubmit} hideRequiredMark style={{ marginTop: 8 }}>
            <FormItem {...formItemLayout} label="头像">
              <img alt="" src={userList.saveAddresult.headImgUrl} className={styles.headImgUrl} />
            </FormItem>
            <FormItem {...formItemLayout} label="昵称">
              {form.getFieldDecorator('nickName', {
                initialValue: userList.saveAddresult.nickName,
              })(<Input placeholder="请输入品牌名称" id="nickName" disabled="disabled" />)}
            </FormItem>
            <FormItem {...formItemLayout} label="性别">
              {form.getFieldDecorator('sex', {
                initialValue: userList.saveAddresult.sex === '' ? '未知' : userList.saveAddresult.sex === 1 ? '男' : '女',
              })(<Input id="sex" disabled="disabled" />)}
            </FormItem>
            <FormItem {...formItemLayout} label="手机号">
              {form.getFieldDecorator('mobile', {
                initialValue: userList.saveAddresult.mobile == null ? '--' : userList.saveAddresult.mobile,
              })(<Input disabled="disabled"  />)}
            </FormItem>
            <FormItem {...formItemLayout} label="地址">
              {form.getFieldDecorator('country', {
                initialValue: `${userList.saveAddresult.country  }-${  userList.saveAddresult.province  }-${  userList.saveAddresult.city}`,
              })(<Input disabled="disabled" />)}
            </FormItem>
            <FormItem {...formItemLayout} label="来源">
              {form.getFieldDecorator('originId', {
                initialValue: userList.saveAddresult.originId,
              })(<Input disabled="disabled" />)}
            </FormItem>
            <FormItem {...formItemLayout} label="订阅情况">
              {form.getFieldDecorator('originId', {
                initialValue: userList.saveAddresult.subscribe === 1 ? '已订阅' : '未订阅',
              })(<Input disabled="disabled" />)}

            </FormItem>
          </Form>
        </Card>
      </PageHeaderLayout>
    );
  }
}
