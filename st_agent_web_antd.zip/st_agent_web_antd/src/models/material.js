import { materialList, materialCount, materialDelete,materialSyncMaterial } from '../services/api';

export default {
  namespace: 'material',
  state: {
    result: {},
    dataOne: {
      list: [],
      pagination: {},
    },
    data: {
      list: [],
      result: {},
      saveAddresult: {},
      pagination: {},
    },
  },

  effects: {
    *fetch({ payload }, { call, put }) {
      const response = yield call(materialList, payload);
      const responseCount = yield call(materialCount, payload);
      yield put({
        type: 'save',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *fetchnews({ payload }, { call, put }) {
      const response = yield call(materialList, payload);
      const responseCount = yield call(materialCount, payload);
      yield put({
        type: 'savenews',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *materialDelete({ payload }, { call, put }) {
      const response = yield call(materialDelete, payload);
      yield put({
        type: 'saveReset',
        payload: response,
      });
      return response;
    },
    *materialSyncMaterialButton({ payload }, { call, put }) {
      const response = yield call(materialSyncMaterial, payload);
      return response;
    },
  },

  reducers: {
    save(state, action) {
      state.data.list = action.payload.list;
      state.data.pagination.total = action.payload.total;
      return {
        ...state,
      };
    },
    savenews(state, action) {
      state.dataOne.list = action.payload.list;
      state.dataOne.pagination.total = action.payload.total;
      return {
        ...state,
      };
    },
    saveReset(state, action) {
      return {
        ...state,
        result: action.payload,
      };
    },
    saveAddCount(state, action) {
      return {
        ...state,
        saveAddresult: action.payload,
      };
    },
  },
};
