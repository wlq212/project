/* eslint-disable no-param-reassign */
import {
  roleList,
  roleCount,
  roleAdd,
  roleDelete,
  roleMenuList,
  saveRoleMenu,
} from '../services/api';

export default {
  namespace: 'roleManage',

  state: {
    roleList: {
      data:[],
      pagination: {
        total: 0,
      },
    },
    editData:{
      name:"",
      roleType:"",
      state:1,
    },
    roleMenuList:[],
  },

  effects: {
    *roleListFetch({ payload }, { call, put }) {
      const response = yield call(roleList, payload);
      const responseCount = yield call(roleCount, payload);
      yield put({
        type: 'roleList',
        payload: { list: response.obj, total: responseCount.obj },
      });
    },
    *roleAddFetch({ payload }, { call }) {
      const response = yield call(roleAdd, payload);
      return response;
    },
    *roleDeleteFetch({ payload }, { call }) {
      const response = yield call(roleDelete, payload);
      return response;
    },
    *roleEditData({ payload, callback }, {  put }) {
      yield put({
        type: 'changeState',
        payload,
      });
      if (callback) callback();
    },
    *roleMenuListFetch({ payload }, { call,put }) {
      const response = yield call(roleMenuList, payload);
      yield put({
        type: 'roleMenuList',
        payload: response.obj,
      });
    },
    *saveRoleMenuFetch({ payload }, { call }) {
      const response = yield call(saveRoleMenu, payload);
      return response;
    },
  },

  reducers: {
    roleList(state, action) {
      return {
        ...state,
        roleList:{
          list: action.payload.list,
          pagination: {
            total: action.payload.total,
          },
        },
      };
    },
    changeState(state, action) {
      state.editData=action.payload;
      return {
        ...state,
      };
    },
    roleMenuList(state, action) {
      state.roleMenuList=action.payload;
      return {
        ...state,
      };
    },
  },
};
