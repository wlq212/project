import {
  shop,
  shopcount,
  shopdelete,
  shopSync,
  addShop,
  shopDataCount,
  shopUpdate,
  shopDataList,
  addShopData,
  shopGet,
} from '../services/api';

export default {
  namespace: 'shop',
  state: {
    result:{
    },
    data: {
      list: [],
      result:{},
      saveAddresult:{},
      pagination: {
        current:"",
      },
    },
    shopDataList:{
      list: [],
      pagination: {
        total: 0,
      },
    },
    shopInfo:"",
    shopList:[],
  },

  effects: {
    *fetch({ payload }, { call, put }) {
      const response = yield call(shop, payload);
      const responseCount = yield call(shopcount, payload);
      yield put({
        type: 'save',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *deleteShop({ payload }, { call, put }) {
      const response = yield call(shopdelete, payload);
      yield put({
        type: 'saveReset',
        payload: response,
      });
    },
    *asyncShop({ payload, callback }, { call, put }) {
      const response = yield call(shopSync, payload);
      yield put({
        type: 'saveReset',
        payload: response,
      });
      return response;
    },
    *addShopButton({ payload }, { call, put }) {
      const response = yield call(addShop, payload);
      return response;
    },
    *updateShop({ payload }, { call, put }) {
      const response = yield call(shopUpdate, payload);
      return response;
    },
    *getShopInfo({ payload, callback }, { call, put }) {
      const response = yield call(shopGet, payload);
      yield put({
        type: 'saveShopInfo',
        payload: response,
      });
    },
    *remove({ payload, callback }, { call, put }) {
      const response = yield call(removeRule, payload);
      yield put({
        type: 'save',
        payload: response,
      });
      if (callback) callback();
    },
    *shopDataListFetch({ payload }, { call, put }) {
      const response = yield call(shopDataList, payload);
      const responseCount = yield call(shopDataCount, payload);
      yield put({
        type: 'shopDataList',
        payload: { list: response.obj, total: responseCount.obj },
      });
    },
    *addShopDataFetch({ payload }, { call }) {
      const response = yield call(addShopData, payload);
      return response;
    },
    // 搜索框专用，不用分页
    *shopListFetch({ payload }, { call, put }) {
      const response = yield call(shop, payload);
      yield put({
        type: 'shopList',
        payload:{list:response.obj},
      });
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data:{
          list:action.payload.list,
          pagination:{
            total:action.payload.total,
          },
        },
      };
    },
    saveShopInfo(state, action) {
      return {
        ...state,
        shopInfo:action.payload,
      };
    },
    saveReset(state, action) {
      return {
        ...state,
        result:action.payload,
      };
    },
    saveAddCount(state, action) {
      return {
        ...state,
        saveAddresult:action.payload,
      };
    },
    shopDataList(state,action){
      return{
        ...state,
        shopDataList:{
          list: action.payload.list,
          pagination: {
            total: action.payload.total,
          },
        },
      }
    },
    shopList(state,action){
      return{
        ...state,
        shopList: action.payload.list,
      }
    },
  },
};
