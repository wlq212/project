import {wxGetAuthInfo,wxgetAuthParams,wxampunlink,wxGetNewestVersion,undocodeaudit,againReleaseVsersion,wxWxamplinkget} from '../services/api';

export default {
  namespace: 'auth',
  state: {
    miniProgressInfo:"",
    wxAccountInfo:"",
    wxGetNewestVersion:"",
    wxamplinkget:[],
  },

  effects: {
  *wxGetAuthInfoButton0({ payload }, { call, put }) {
    const response = yield call(wxGetAuthInfo, payload);
    yield put({
      type: 'savewxGetAuthInfo0',
      payload:response.obj,
    });
    },
    *wxgetAuthParamsButton({ payload }, { call, put }) {
      const response = yield call(wxgetAuthParams, payload);
      return response;
    },
    *wxGetAuthInfoButton1({ payload }, { call, put }) {
      const response = yield call(wxGetAuthInfo, payload);
      yield put({
        type: 'savewxGetAuthInfo1',
        payload:response.obj,
      });
    },

    *wxGetNewestVersionButton2({ payload }, { call, put }) {
      const response = yield call(wxGetNewestVersion, payload);
      yield put({
        type: 'wxGetNewestVersion',
        payload:response.obj,
      });
    },
    *wxamplinkgetFetch({ payload }, { call, put }) {
      const response = yield call(wxWxamplinkget, payload);
      yield put({
        type: 'saveWxamplinkget',
        payload:response.obj,
      });
    },
    *wxampunlinkButton({ payload }, { call }) {
      const response = yield call(wxampunlink, payload);
       return response;
    },
    *wxUndocodeaudit({ payload }, { call}) {
      const response = yield call(undocodeaudit, payload);
      return response;
    },
    *wxAgainReleaseVsersion({ payload }, { call}) {
      const response = yield call(againReleaseVsersion, payload);
      return response;
    },
  },

  reducers: {
    savewxGetAuthInfo0(state, action) {
      state.wxAccountInfo= action.payload;
      return {
        ...state,
      };
    },
    wxGetNewestVersion(state, action) {
      state.wxGetNewestVersion= action.payload;
      return {
        ...state,
      };
    },
    savewxGetAuthInfo1(state, action) {
      state.miniProgressInfo= action.payload;
      return {
        ...state,
      };
    },
    saveWxamplinkget(state, action) {
      state.wxamplinkget = action.payload;
      return {
        ...state,
      };
    },
  },
};
