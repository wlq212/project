/* eslint-disable no-param-reassign,prefer-destructuring */
import {
  materialDelete,miniTplList,miniTplSave,shop,
} from '../services/api';

export default {
  namespace: 'tplSetting',
  state: {
    result:{

    },
    templateList:{},
    shopList:{},
  },

  effects: {
    *materialDelete({ payload }, { call, put }) {
      const response = yield call(materialDelete, payload);
      yield put({
        type: 'saveReset',
        payload: response,
      });
      return response;
    },
    *miniTplList({ payload }, { call, put }) {
      const response = yield call(miniTplList, payload);
      yield put({
        type: 'tplList',
        payload: response.obj,
      });
    },
    *miniTplSave({ payload }, { call }) {
      const response = yield call(miniTplSave, payload);
      return response;
    },
    *shopListFetch({ payload }, { call, put }) {
      const response = yield call(shop, payload);
      yield put({
        type: 'shopList',
        payload: response.obj,
      });
    },
  },
  reducers: {
    saveReset(state, action) {
      return {
        ...state,
        result: action.payload,
      };
    },
    tplList(state, action) {
      state.templateList = action.payload;
      return {
        ...state,
      };
    },
    shopList(state,action){
      state.shopList = action.payload[0];
      return {
        ...state,
      };
    },
  },
};
