/* eslint-disable no-param-reassign */
import {
  qrcodeList,
  deskList,
  cateCount,
  cateList,
  qrcodeCount,
  deskAdd,
  deskUpdate,
  cateUpdate,
  shop,
  shopcount,
  cateAdd,
  qrcodeAdd,
  qrcodeUpdate,
  activityList,
  activityCount,
  autoReplyList,
  autoReplyCount, qrcodeListAdd,
  qrCodeBatchDownload,
} from '../services/api';

export default {
  namespace: 'channel',
  state: {
    deskList:{},
    cateList:{
      list:[],
      pagination: {
        total:0,
      },
    },
    qrcodeList:{
      list:[],
      pagination: {
        total:0,
      },
    },
    shopList:[],
    shopTableList:{
      list:[],
      pagination: {
        total:0,
      },
    },
    saveCateFormList:[],
    activityList:{
      list:[],
      pagination: {
        total:0,
      },
    },
    keywordList:{
      list:[],
      pagination: {
        total:0,
      },
    },
    qrCodeInfo:{},
  },

  effects: {
    *fetchDeskList({ payload }, { call, put }) {
      const response = yield call(deskList, payload);
      yield put({
        type: 'saveDeskList',
        payload:{list:response.obj},
      });
    },
    *fetchCateList({ payload }, { call, put }) {
      const response = yield call(cateList, payload);
      const responseCount = yield call(cateCount, payload);
      yield put({
        type: 'saveCateList',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *shopList({ payload }, { call, put }) {
      const response = yield call(shop, payload);
      yield put({
        type: 'saveShopList',
        payload:{list:response.obj},
      });
    },
    *shopTableListFetch({ payload }, { call, put }) {
      const response = yield call(shop, payload);
      const responseCount = yield call(shopcount, payload);
      yield put({
        type: 'shopTableList',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *activityListFetch({ payload }, { call, put }) {
      const response = yield call(activityList, payload);
      const responseCount = yield call(activityCount, payload);
      yield put({
        type: 'activityList',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *keywordListFetch({ payload }, { call, put }) {
      const response = yield call(autoReplyList, payload);
      const responseCount = yield call(autoReplyCount, payload);
      yield put({
        type: 'keywordList',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *qrcodeListFetch({ payload }, { call, put }) {
      const response = yield call(qrcodeList, payload);
      const responseCount = yield call(qrcodeCount, payload);
      yield put({
        type: 'qrcodeList',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *qrCodeInfoFetch({ payload }, { put }){
      yield put({
        type: 'qrCodeInfo',
        payload,
      });
    },

    *qrcodeAddFetch({ payload }, { call }) {
      const response = yield call(qrcodeAdd, payload);
      return  response;
    },
    *qrcodeUpdateFetch({ payload }, { call }) {
      const response = yield call(qrcodeUpdate, payload);
      return  response;
    },
    *qrcodeListAddFetch({ payload }, { call }) {
      const response = yield call(qrcodeListAdd, payload);
      return  response;
    },
    *qrCodeBatchDownloadFetch({ payload }, { call }) {
      const response = yield call(qrCodeBatchDownload, payload);
      return  response;
    },
    *fetchCateListForm({ payload }, { call, put }) {
      const response = yield call(cateList, payload);
      yield put({
        type: 'saveCateFormList',
        payload:{list:response.obj},
      });
    },
    *deskAddButton({ payload }, { call }) {
      const response = yield call(deskAdd, payload);
      return  response;
    },
    *cateAddButton({ payload }, { call }) {
      const response = yield call(cateAdd, payload);
      return  response;
    },
    *cateUpdateButton({ payload }, { call }) {
      const response = yield call(cateUpdate, payload);
      return  response;
    },
    *deskUpdateButton({ payload }, { call }) {
      const response = yield call(deskUpdate, payload);
      return  response;
    },

  },

  reducers: {
    saveDeskList(state, action) {
      return {
        ...state,
        deskList:action.payload.list,
      };
    },
    saveCateList(state, action) {
      return {
        ...state,
        cateList:{list:action.payload.list,pagination:{total:action.payload.total}},
      };
    },
    saveShopList(state, action) {
      return {
        ...state,
        shopList:action.payload.list,
      };
    },
    shopTableList(state, action) {
      return {
        ...state,
        shopTableList:{list:action.payload.list,pagination:{total:action.payload.total}},
      };
    },

    saveCateFormList(state, action) {
      return {
        ...state,
        saveCateFormList:action.payload.list,
      };
    },
    activityList(state, action){
      return {
        ...state,
        activityList:{list:action.payload.list,pagination:{total:action.payload.total}},
      };
    },
    qrcodeList(state, action){
      return {
        ...state,
        qrcodeList:{list:action.payload.list,pagination:{total:action.payload.total}},
      };
    },
    keywordList(state, action){
      return {
        ...state,
        keywordList:{list:action.payload.list,pagination:{total:action.payload.total}},
      };
    },
    qrCodeInfo(state, action) {
      state.qrCodeInfo = action.payload;
      return {
        ...state,
      };
    },
  },
};
