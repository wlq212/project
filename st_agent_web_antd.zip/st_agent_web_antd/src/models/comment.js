import {
  commentList,
  commentCount,
  commentDelete,
  commentAdd,
  commentUserList,
  commentUserCount,
  commentUserAllCount,
  commentGetarticlesummary,
  commentGet,
  commentSyncComment,
  commentAwardPrizes,
  commentAgainNotice,
  commentUnmarkelectOrMarkelect,
  commentPrizeSetUp,
  commentUpdate,
  replyComment,
  cardList,
  cardCount,
} from '../services/api';

export default {
  namespace: 'comment',
  state: {
    commentGetarticlesummary:{
      list: [],
      pagination: {
        total:0,
      },
    },
    commentUserAllCount:{},
    saveCardList:{
      list: [],
      pagination: {
        total:0,
      },
    },
    // 图文列表
    commentList:{
      list: [],
      pagination: {
        total:0,
      },
    },
    commentUserList: {
      list: [],
      pagination: {
       total:0,
      },
    },
  },

  effects: {
    *cardListButton({ payload }, { call, put }) {
      const response = yield call(cardList, payload);
      const responseCount = yield call(cardCount, payload);
      yield put({
        type: 'cardList',
        payload: {list:response.obj,total:responseCount.obj},
      });
    },

    *commentListButton({ payload }, { call, put }) {
      const response = yield call(commentList, payload);
      const responseCount = yield call(commentCount, payload);
      yield put({
        type: 'commentList',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *commentUserListButton({ payload }, { call, put }) {
      const response = yield call(commentUserList, payload);
      const responseCount = yield call(commentUserCount, payload);
      yield put({
        type: 'commentUserList',
        payload:{list:response.obj,total:responseCount.obj},
      });
      return response;
    },
    *commentSyncCommentButton({ payload }, { call, put }) {
      const response = yield call(commentSyncComment, payload);
      return response;
    },
    *commentGetarticlesummaryButton({ payload }, { call, put }) {
      const response = yield call(commentGetarticlesummary, payload);
      yield put({
        type: 'commentGetarticlesummary',
        payload: {list:response.obj,total:""},
      });
    },
    *commentDeleteButton({ payload }, { call, put }) {
      const response = yield call(commentDelete, payload);
      return response;
    },
    *commentUserAllCount({ payload }, { call, put }) {
      const response = yield call(commentUserAllCount, payload);
      yield put({
        type: 'commentUserAllCount',
        payload: response.obj,
      });
    },
    *commentAddButton({ payload }, { call, put }) {
      const response = yield call(commentAdd, payload);
      return response;
    },
    *commentAwardPrizesButton({ payload }, { call, put }) {
      const response = yield call(commentAwardPrizes, payload);
      return response;
    },
    *commentAgainNoticeButton({ payload }, { call, put }) {
      const response = yield call(commentAgainNotice, payload);
      return response;
    },
    *replyCommentButton({ payload }, { call, put }) {
      const response = yield call(replyComment, payload);
      return response;
    },
    *commentPrizeSetUpButton({ payload }, { call, put }) {
      const response = yield call(commentPrizeSetUp, payload);
      return response;
    },
    *commentUpdateButton({ payload }, { call, put }) {
      const response = yield call(commentUpdate, payload);
      return response;
    },
    *commentGetButton({ payload }, { call, put }) {
      const response = yield call(commentGet, payload);
      return response;
    },
    *commentUnmarkelectOrMarkelectButton({ payload }, { call, put }) {
      const response = yield call(commentUnmarkelectOrMarkelect, payload);
      return response;
    },

  },
  reducers: {
    cardList(state, action) {
      return {
        ...state,
        saveCardList:{
          list:action.payload.list,
          pagination:{
            total:action.payload.total,
          },
        },
      };
    },
    commentList(state, action) {
      return {
        ...state,
        commentList:{
          list:action.payload.list,
          pagination:{
            total:action.payload.total,
          },
        },
      };
    },
    commentGetarticlesummary(state, action) {
      return {
        ...state,
        commentGetarticlesummary:action.payload,
      };
    },
    commentUserList(state, action) {
      return {
        ...state,
        commentUserList:
          {
            list:action.payload.list,
            pagination:{total:action.payload.total},
            },
      };
    },
    commentUserAllCount(state, action) {
      return {
        ...state,
        commentUserAllCount:action.payload,
      };
    },
  },
};
