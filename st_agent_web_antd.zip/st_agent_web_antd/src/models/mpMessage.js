import { messageCount, messageList } from '../services/api';

export default {
  namespace: 'mpMessage',

  state: {
    messageList: {
      list: [],
      pagination: {
        total: 0,
      },
    },
  },

  effects: {
    *messageListFetch({ payload }, { call, put }) {
      const response = yield call(messageList, payload);
      const responseCount = yield call(messageCount, payload);
      yield put({
        type: 'messageList',
        payload: { list: response.obj, total: responseCount.obj },
      });
    },
  },

  reducers: {
    messageList(state, action) {
      return {
        ...state,
        messageList: {
          list: action.payload.list,
          pagination: {
            total: action.payload.total,
          },
        },
      };
    },
  },
};
