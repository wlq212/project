import { addSchedule, deleteSchedule, scheduleList, updateSchedule } from '../services/api';

export default {
  namespace: 'schedule',
  state: {
    scheduleList:{
      activity:[],
      article:[],
      item:[],
    },
  },

  effects: {
    *scheduleListFetch({ payload }, { call, put }) {
      const response = yield call(scheduleList, payload);
      yield put({
        type: 'scheduleList',
        payload:{list:response.obj},
      });
    },
    *addScheduleFetch({ payload }, { call }) {
      const response = yield call(addSchedule, payload);
      return  response;
    },
    *updateScheduleFetch({ payload }, { call }) {
      const response = yield call(updateSchedule, payload);
      return  response;
    },
    *deleteScheduleFetch({ payload }, { call }) {
      const response = yield call(deleteSchedule, payload);
      return  response;
    },

  },

  reducers: {
    scheduleList(state, action) {
      return {
        ...state,
        scheduleList:action.payload.list,
      };
    },
  },
};
