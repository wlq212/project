/* eslint-disable no-unused-vars,no-param-reassign */
import {
  queryManage,
  queryManageCount,
  adminUsermodiPwd,
  addManage,
  updateManager,
  switchAdminUser,
  fakeAccountLogin,
  roleList,
} from '../services/api';
import { reloadAuthorized } from '../utils/Authorized';
import { setStore } from '../assets/js/mUtils';
import { getPageQuery } from '../utils/utils';

export default {
  namespace: 'manage',
  state: {
    result:{
    },
    roleList: {
      list:[],
    },
    editData: {},
    data: {
      list: [],
      pagination:{
      total:"",
      },
    },
  },

  effects: {
    *roleListFetch({ payload }, { call, put }) {
      const response = yield call(roleList, payload);
      yield put({
        type: 'roleList',
        payload: { list: response.obj},
      });
    },
    *fetch({ payload }, { call, put }) {
      const response = yield call(queryManage, payload);
      const responseCount = yield call(queryManageCount, payload);
      yield put({
        type: 'save',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *passwordReset({ payload }, { call, put }) {
      const response = yield call(adminUsermodiPwd, payload);
      yield put({
        type: 'saveReset',
        payload: response,
      });
      return response;
    },
    *add({ payload, callback }, { call, put }) {
      const response = yield call(addManage, payload);
      yield put({
        type: 'saveAddCount',
        payload: response,
      });
      return response;
    },

    *edit({ payload, callback }, { call, put }) {
      const response = yield call(updateManager, payload);
      yield put({
        type: 'saveAddCount',
        payload: response,
      });
      return response;
    },
    *switchAdminUserButton({ payload, callback }, { call, put }) {
      const response = yield call(switchAdminUser, payload);
      return response;
    },
    *editData({ payload, callback }, { call, put }) {
      yield put({
        type: 'saveData',
        payload,
      });
    },
  },

  reducers: {
    roleList(state, action) {
      return {
        ...state,
        roleList:{
          list: action.payload.list
        },
      };
    },
    save(state, action) {
      state.data.list=action.payload.list;
      state.data.pagination.total=action.payload.total;
      return {
        ...state,
      };
    },
    saveReset(state, action) {
      const {result}=state;
      return {
        ...state,
        result:{...result,...(action.payload)},
      };
    },
    saveAddCount(state, action) {
      state.result=action.payload;
      return {
        ...state,
      };
    },
    saveData(state, action) {
      state.editData=action.payload;
      return {
        ...state,
      };
    },
  },
};
