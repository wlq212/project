/* eslint-disable no-param-reassign */
import {
  autoReplyList,
  autoReplyCount,
  autoReplyUpdate,
  autoReplyAdd,
  materialList,
  materialGet,
  materialCount,
} from '../services/api';

export default {
  namespace: 'autoReply',
  state: {
    result:{
    },
    Image: {
      list: [],
      pagination: {},
    },
    news: {
      list: [],
      pagination: {},
    },
    eidtData:{},
    data: {
      list: [],
      list1:[{
        msgType:"text",
        content:"",
      }],
      list2:[
        {
          msgType:"text",
          content:"",
        },
      ],
      saveAddresult:[],
      pagination: {

      },
    },
  },

  effects: {
    *fetch({ payload }, { call, put }) {
      const response = yield call(materialList, payload);
      const responseCount = yield call(materialCount, payload);
      yield put({
        type: 'saveImage',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *fetchnews({ payload }, { call, put }) {
      const response = yield call(materialList, payload);
      const responseCount = yield call(materialCount, payload);
      yield put({
        type: 'savenews',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *fetchAutoReplyList({ payload }, { call, put }) {
      const response = yield call(autoReplyList, payload);
      const responseCount = yield call(autoReplyCount, payload);
      if(response.obj){
        yield put({
          type: 'save',
          payload:{list:response.obj,total:responseCount.obj},
        });
      }

    },
    *fetchAutoReplyList1({ payload }, { call, put }) {
      const response = yield call(autoReplyList, payload);
      yield put({
        type: 'save1',
        payload: response.obj,
      });
    },
    *fetchAutoReplyList2({ payload }, { call, put }) {
      const response = yield call(autoReplyList, payload);
      yield put({
        type: 'save2',
        payload: response.obj,
      });
    },

    *deleteAutoReply({ payload }, { call, put }) {
      const response = yield call(autoReplyUpdate, payload);
      yield put({
        type: 'saveReset',
        payload: response,
      });
      return response;
    },
    *addAutoReplyButton({ payload }, { call, put }) {
      const response = yield call(autoReplyAdd, payload);
      return response;
    },
    *materialGetButton({ payload }, { call, put }) {
      const response = yield call(materialGet, payload);
      return response;
    },
    *updateParams({ payload, callback }, { call, put }) {
      yield put({
        type: 'saveAddCount',
        payload,
      });
      if (callback) callback();
    },
    *updateState({ payload, callback }, { call, put }) {
      yield put({
        type: 'changeState',
        payload,
      });
      if (callback) callback();
    },
    *updateAutoReplyButton({ payload, callback }, { call, put }) {
      const response = yield call(autoReplyUpdate, payload);
      yield put({
        type: 'saveReset',
        payload: response,
      });
     return response;
    },
  },

  reducers: {
    saveImage(state, action) {
      state.Image.list = action.payload.list;
      state.Image.pagination.total = action.payload.total;
      return {
        ...state,
      };
    },
    savenews(state, action) {
      state.news.list = action.payload.list;
      state.news.pagination.total = action.payload.total;
      return {
        ...state,
      };
    },
    save(state, action) {
      state.data.list=action.payload.list;
      state.data.pagination.total=action.payload.total;
      return {
        ...state,
      };
    },
    save1(state, action) {
      if(action.payload.length>0){
        state.data.list1=action.payload;
        return {
          ...state,
        };
      }
      return {
        ...state,
      };
    },
    save2(state, action) {
      if(action.payload.length>0){
        state.data.list2=action.payload;
        return {
          ...state,
        };
      }
      return {
        ...state,
      };
    },
    saveshop(state, action) {
      state.data.saveAddresult=action.payload;
      return {
        ...state,
      };
    },
    saveReset(state, action) {
      state.result=action.payload;
      return {
        ...state,
        result:action.payload,
      };
    },
    changeState(state, action) {
      state.eidtData=action.payload;
      return {
        ...state,
      };
    },
    saveAddCount(state, action) {
      state.eidtData=action.payload;
      return {
        ...state,
      };
    },
  },
};
