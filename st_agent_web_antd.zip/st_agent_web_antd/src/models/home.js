import { wxGetAuthInfo } from '../services/api';

export default {
  namespace: 'home',
  state: {
    wxAccountInfo:{},
  },

  effects: {
    *wxGetAuthInfoButton0({ payload }, { call, put }) {
      const response = yield call(wxGetAuthInfo, payload);
      yield put({
        type: 'savewxGetAuthInfo0',
        payload:response.obj,
      });
    },
  },

  reducers: {
    savewxGetAuthInfo0(state, action) {
      state.wxAccountInfo= action.payload;
      return {
        ...state,
      };
    },
  },
};
