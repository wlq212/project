import {
  circleList,
  circleCount,
  circleDelete,
  circleParticipationCount,
  circleSelectParticipation,
  circleUpdate,
  circleIsPrize,
  circleLuckDraw,
  circleSendNotice,
  circleAgainNotice,
  circleGet,
  cardList,
  cardCount,
  autoReplyList,
  circleAdd,
  autoReplyCount,
} from '../services/api';

export default {
  namespace: 'moments',
  state: {
    circleGet:{

    },

    circleList:{
      list: [],
      pagination: {
       total:0,
      },
    },
    saveCardList:{
      list: [],
      pagination: {
        total:0,
      },
    },
    autoReplyList:{
      list: [],
      pagination: {
        total:0,
      },
    },
    circleSelectParticipation: {
      list: [],
      pagination: {
        total:0,
      },
    },
  },

  effects: {
    *cardListButton({ payload }, { call, put }) {
      const response = yield call(cardList, payload);
      const responseCount = yield call(cardCount, payload);
      yield put({
        type: 'cardList',
        payload: {list:response.obj,total:responseCount.obj},
      });
    },
    *autoReplyListButton({ payload }, { call, put }) {
      const response = yield call(autoReplyList, payload);
      const responseCount = yield call(autoReplyCount, payload);
      yield put({
        type: 'autoReplyList',
        payload: {list:response.obj,total:responseCount.obj},
      });
    },
    *circleListButton({ payload }, { call, put }) {
      const response = yield call(circleList, payload);
      const responseCount = yield call(circleCount, payload);
      yield put({
        type: 'circleList',
        payload: {list:response.obj,total:responseCount.obj},
      });
    },
    *circleSelectParticipationButton({ payload }, { call, put }) {
      const response = yield call(circleSelectParticipation, payload);
      const responseCount = yield call(circleParticipationCount, payload);
      yield put({
        type: 'circleSelectParticipation',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *circleIsPrizeButton({ payload }, { call, put }) {
      const response = yield call(circleIsPrize, payload);
      return response;
    },
    *circleAgainNoticeBtton({ payload }, { call, put }) {
      const response = yield call(circleAgainNotice, payload);
      return response;
    },
    *circleGetButton({ payload }, { call, put }) {
      const response = yield call(circleGet, payload);
      yield put({
        type: 'circleGet',
        payload: response.obj,
      });
      return response;
    },
    *circleDeleteButton({ payload }, { call, put }) {
      const response = yield call(circleDelete, payload);
      return response;
    },
    *circleSendNoticeButton({ payload }, { call, put }) {
      const response = yield call(circleSendNotice, payload);
      return response;
    },
    *circleLuckDrawButton({ payload }, { call, put }) {
      const response = yield call(circleLuckDraw, payload);
      return response;
    },
    *circleUpdate({ payload }, { call, put }) {
      const response = yield call(circleUpdate, payload);
      return response;
    },
    *circleAddButton({ payload }, { call, put }) {
      const response = yield call(circleAdd, payload);
      return response;
    },
  },
  reducers: {
    circleList(state, action) {
      return {
        ...state,
        circleList:{
          list:action.payload.list,
          pagination:{total:action.payload.total},
        },
      };
    },
    cardList(state, action) {
      return {
        ...state,
        saveCardList:{
          list:action.payload.list,
          pagination:{
            total:action.payload.total,
          },
        },
      };
    },
    autoReplyList(state, action) {
      return {
        ...state,
        autoReplyList:{
          list:action.payload.list,
          pagination:{
            total:action.payload.total,
          },
        },
      };
    },
    circleGet(state, action) {
      return {
        ...state,
        circleGet:action.payload,
      };
    },
    circleSelectParticipation(state, action) {
      return {
        ...state,
        circleSelectParticipation:
          {list:action.payload.list,
            pagination:{total:action.payload.total}},
      };
    },
  },
};
