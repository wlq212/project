/* eslint-disable no-param-reassign */
import {
  deskList,
  cateCount,
  cateList,
  deskCount,
  deskAdd,
  deskUpdate,
  cateUpdate,
  shop,
  cateAdd,
} from '../services/api';

export default {
  namespace: 'desk',
  state: {
    deskList:{
      list:[],
      pagination: {
       total:0,
      },
    },
    cateList:{
      list:[],
      pagination: {
        total:0,
      },
    },
    shopList:[],
    saveCateFormList:[],
  },

  effects: {
    *fetchDeskList({ payload }, { call, put }) {
      const response = yield call(deskList, payload);
      const responseCount = yield call(deskCount, payload);
      yield put({
        type: 'saveDeskList',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *fetchCateList({ payload }, { call, put }) {
      const response = yield call(cateList, payload);
      const responseCount = yield call(cateCount, payload);
      yield put({
        type: 'saveCateList',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *shopList({ payload }, { call, put }) {
      const response = yield call(shop, payload);
      yield put({
        type: 'saveShopList',
        payload:{list:response.obj},
      });
    },
    *fetchCateListForm({ payload }, { call, put }) {
      const response = yield call(cateList, payload);
      yield put({
        type: 'saveCateFormList',
        payload:{list:response.obj},
      });
    },
    *deskAddButton({ payload }, { call, put }) {
      const response = yield call(deskAdd, payload);
      return  response;
    },
    *cateAddButton({ payload }, { call, put }) {
      const response = yield call(cateAdd, payload);
      return  response;
    },
    *cateUpdateButton({ payload }, { call, put }) {
      const response = yield call(cateUpdate, payload);
      return  response;
    },
    *deskUpdateButton({ payload }, { call, put }) {
      const response = yield call(deskUpdate, payload);
      return  response;
    },
    *addon({ payload }, { call, put }) {

    },

  },

  reducers: {
    saveDeskList(state, action) {
      return {
        ...state,
        deskList:{list:action.payload.list,pagination:{total:action.payload.total}},
      };
    },
    saveCateList(state, action) {
      return {
        ...state,
        cateList:{list:action.payload.list,pagination:{total:action.payload.total}},
      };
    },
    saveShopList(state, action) {
      return {
        ...state,
        shopList:action.payload.list,
      };
    },
    saveCateFormList(state, action) {
      return {
        ...state,
        saveCateFormList:action.payload.list,
      };
    },
  },
};
