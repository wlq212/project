import {
  guessSelectGuessList,
  guessCount,
  guessSelectSubjectListByGuessId,
  guessSelectGuessUserListByGuessId,
  guessCountSelectGuessUserListByGuessId,
  guessDelete,
  guessSelectGuessOne,
  cardList,
  cardCount,
  guessAdd,
  guessUpdate,
} from '../services/api';

export default {
  namespace: 'guess',
  state: {
    guessSelectGuessOne:"",
    guessSelectSubjectListByGuessId:{
      list: [],
      pagination: {

      },
    },
    guessSelectGuessList:{
      list: [],
      pagination: {
        total:0,
      },
    },
    saveCardList:{
      list: [],
      pagination: {
        total:0,
      },
    },
    posterParticipation: {
      list: [],
      pagination: {

      },
    },
  },

  effects: {
    *cardListButton({ payload }, { call, put }) {
      const response = yield call(cardList, payload);
      const responseCount = yield call(cardCount, payload);
      yield put({
        type: 'cardList',
        payload: {list:response.obj,total:responseCount.obj},
      });
    },
    *guessAddButton({ payload }, { call, put }) {
      const response = yield call(guessAdd, payload);
      return response;
    },
    *guessSelectGuessOneButton({ payload }, { call, put }) {
      const response = yield call(guessSelectGuessOne, payload);
      yield put({
        type: 'guessSelectGuessOne',
        payload: response.obj,
      });
      return response;
    },
    *guessSelectGuessListButton({ payload }, { call, put }) {
      const response = yield call(guessSelectGuessList, payload);
      const responseCount = yield call(guessCount, payload);
      yield put({
        type: 'guessSelectGuessList',
        payload: {list:response.obj,total:responseCount.obj},
      });
    },
    *guessSelectSubjectListByGuessIdButton({ payload }, { call, put }) {
      const response = yield call(guessSelectSubjectListByGuessId, payload);
      yield put({
        type: 'guessSelectSubjectListByGuessId',
        payload: response.obj,
      });
    },
    *guessSelectGuessUserListByGuessIdBuuton({ payload }, { call, put }) {
      const response = yield call(guessSelectGuessUserListByGuessId, payload);
      const responseCount = yield call(guessCountSelectGuessUserListByGuessId, payload);
      yield put({
        type: 'posterParticipation',
        payload: {list:response.obj,total:responseCount.obj},
      });
    },

    *guessDeleteButton({ payload }, { call, put }) {
      const response = yield call(guessDelete, payload);
      return response;
    },

    *guessUpdate({ payload }, { call, put }) {
      const response = yield call(guessUpdate, payload);
      return response;
    },
  },
  reducers: {
    guessSelectGuessList(state, action) {
      return {
        ...state,
        guessSelectGuessList:{
          list:action.payload.list,
          pagination:{total:action.payload.total},
        },
      };
    },
    guessSelectSubjectListByGuessId(state, action) {
      return {
        ...state,
        guessSelectSubjectListByGuessId:{list:action.payload},
      };
    },
    cardList(state, action) {
      return {
        ...state,
        saveCardList:{
          list:action.payload.list,
          pagination:{
            total:action.payload.total,
          },
        },
      };
    },
    guessSelectGuessOne(state, action) {
      return {
        ...state,
        guessSelectGuessOne:action.payload,
      };
    },
    posterParticipation(state, action) {
      return {
        ...state,
        posterParticipation:
        {list:action.payload.list,
          pagination:{total:action.payload.total}},
      };
    },

  },
};
