import {wxGetTemplateList,getTemplatedRaftlist,wxAddToTemplate,wxDeleteTemplate,wxReleaseVsersion} from '../services/api';

export default {
  namespace: 'version',
  state: {
    result:{
    },
    data1:{
      listone:[],
      pagination: {

      },
    },
    data: {
      list: [],
      result:{},
      saveAddresult:{},
      pagination: {

      },
    },
  },

  effects: {
    *wxGetTemplateList({ payload }, { call, put }) {
      const response = yield call(wxGetTemplateList, payload);
      console.log(response)
      yield put({
        type: 'save',
        payload: response.obj,
      });
    },
    *getTemplatedRaftlist({ payload }, { call, put }) {
      const response = yield call(getTemplatedRaftlist, payload);
      yield put({
        type: 'saveListOne',
        payload: response.obj,
      });
    },
    *wxAddToTemplate({ payload }, { call, put }) {
      const response = yield call(wxAddToTemplate, payload);
      yield put({
        type: 'saveReset',
        payload: response,
      });
      return response;
    },
    *wxDeleteTemplate({ payload, callback }, { call, put }) {
      const response = yield call(wxDeleteTemplate, payload);
      yield put({
        type: 'saveReset',
        payload: response,
      });
     return response;
    },
    *wxReleaseVsersionButton({ payload, callback }, { call, put }) {
      const response = yield call(wxReleaseVsersion, payload);
      return response;
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data:{
          list:action.payload,
        },
      };
    },
    saveReset(state, action) {
      return {
        ...state,
        result:action.payload,
      };
    },
    saveAddCount(state, action) {
      return {
        ...state,
        saveAddresult:action.payload,
      };
    },
    saveListOne(state, action) {
      return {
        ...state,
        data1:{
          list:action.payload,
        },
      };
    },
  },
};
