import {pageList,pageCount,pageAdd,pageUpdate,pageDelete,wxGetTemplateList} from '../services/api';

export default {
  namespace: 'pageManage',
  state: {
    result:{
    },
    eidtData:{},
    templateList:{},
    data: {
      list: [],
      saveAddresult:[],
      pagination: {

      },
    },
  },

  effects: {
    *pageList({ payload }, { call, put }) {
      const response = yield call(pageList, payload);
      const responseCount = yield call(pageCount, payload);
      yield put({
        type: 'save',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },

    *wxGetTemplateList({ payload }, { call, put }) {

      const response = yield call(wxGetTemplateList, payload);
      yield put({
        type: 'saveTemplateList',
        payload: response.obj,
      });
    },
    *pageAdd({ payload }, { call, put }) {
      const response = yield call(pageAdd, payload);
      yield put({
        type: 'saveReset',
        payload: response,
      });
      return response;
    },
    *pageDelete({ payload }, { call, put }) {
      const response = yield call(pageDelete, payload);
      yield put({
        type: 'saveReset',
        payload: response,
      });
      return response;
    },
    *updateParams({ payload, callback }, { call, put }) {
      yield put({
        type: 'saveAddCount',
        payload,
      });
      if (callback) callback();

    },
    *pageUpdate({ payload, callback }, { call, put }) {
      const response = yield call(pageUpdate, payload);
      yield put({
        type: 'saveReset',
        payload: response,
      });
      return response;
    },
  },

  reducers: {
    save(state, action) {
      state.data.list=action.payload.list;
      state.data.pagination.total=action.payload.total;
      return {
        ...state,
      };
    },
    saveshop(state, action) {
      state.data.saveAddresult=action.payload;
      return {
        ...state,
      };
    },
    saveReset(state, action) {
      state.result=action.payload;
      return {
        ...state,
      };
    },
    saveAddCount(state, action) {
      state.eidtData=action.payload;
      return {
        ...state,
      };
    },
    saveTemplateList(state, action) {
      state.templateList=action.payload;
      return {
        ...state,
      };
    },
  },
};
