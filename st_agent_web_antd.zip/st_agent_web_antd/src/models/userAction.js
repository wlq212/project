/* eslint-disable no-param-reassign */
import { userActionCount, userActionList } from '../services/api';

export default {
  namespace: 'userAction',

  state: {
    userList: {
      list: [],
      pagination: {
        total: 0,
      },
    },
  },

  effects: {
    *userActionListFetch({ payload }, { call, put }) {
      const response = yield call(userActionList, payload);
      const responseCount = yield call(userActionCount, payload);
      yield put({
        type: 'userList',
        payload: { list: response.obj, total: responseCount.obj },
      });
    },
  },

  reducers: {
    userList(state, action) {
      return {
        ...state,
        userList: {
          list: action.payload.list,
          pagination: {
            total: action.payload.total,
          },
        },
      };
    },
  },
};
