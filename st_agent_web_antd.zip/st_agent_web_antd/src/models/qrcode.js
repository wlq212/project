import {
  shop,
  qrcodeList,
  qrcodeCount,
  qrcodeDelete,
  qrcodeUpdate,
  qrcodeAdd,
  autoReplyList,
  autoReplyCount,
  qrcodeGetAnalysisData,
} from '../services/api';

export default {
  namespace: 'qrcode',
  state: {
    result:{
    },
    eidtData:{},
    autoReplyList:{
      list: [],
      pagination: {
        total:0,
      },
    },
    qrcodeGetAnalysisData:{

    },
    data: {
      list: [],
      saveAddresult:[],
      pagination: {

      },
    },
  },

  effects: {
    *fetchshop({ payload }, { call, put }) {
      const response = yield call(shop, payload);
      console.log(response)
      yield put({
        type: 'saveshop',
        payload: response.obj,
      });
    },
    *autoReplyListButton({ payload }, { call, put }) {
      const response = yield call(autoReplyList, payload);
      const responseCount = yield call(autoReplyCount, payload);
      yield put({
        type: 'autoReplyList',
        payload: {list:response.obj,total:responseCount.obj},
      });
    },
    *fetchQrcodeList({ payload }, { call, put }) {
      const response = yield call(qrcodeList, payload);
      const responseCount = yield call(qrcodeCount, payload);
      console.log(responseCount)
      yield put({
        type: 'save',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *deleteQrcodeShop({ payload }, { call, put }) {
      const response = yield call(qrcodeDelete, payload);
      yield put({
        type: 'saveReset',
        payload: response,
      });
      return response;
    },
    *addQrcodeShop({ payload }, { call, put }) {
      const response = yield call(qrcodeAdd, payload);
      yield put({
        type: 'saveReset',
        payload: response,
      });
      return response;
    },
    *updateParams({ payload, callback }, { call, put }) {
      yield put({
        type: 'saveAddCount',
        payload,
      });
      if (callback) callback();

    },
    *qrcodeGetAnalysisDataButton({ payload, callback }, { call, put }) {
      const response = yield call(qrcodeGetAnalysisData, payload);
      yield put({
        type: 'qrcodeGetAnalysisData',
        payload: response.obj,
      });
    },
    *updateQrcode({ payload, callback }, { call, put }) {
      const response = yield call(qrcodeUpdate, payload);
      yield put({
        type: 'saveReset',
        payload: response,
      });
      return response;
    },
  },

  reducers: {
    save(state, action) {
      state.data.list=action.payload.list;
      state.data.pagination.total=action.payload.total;
      return {
        ...state,
      };
    },
    saveshop(state, action) {
      state.data.saveAddresult=action.payload;
      return {
        ...state,
      };
    },
    autoReplyList(state, action) {
      return {
        ...state,
        autoReplyList:{
          list:action.payload.list,
          pagination:{
            total:action.payload.total,
          },
        },
      };
    },
    saveReset(state, action) {
      state.result=action.payload;
      return {
        ...state,
      };
    },
    qrcodeGetAnalysisData(state, action) {
      state.qrcodeGetAnalysisData=action.payload;
      return {
        ...state,
      };
    },
    saveAddCount(state, action) {
      state.eidtData=action.payload;
      return {
        ...state,
      };
    },
  },
};
