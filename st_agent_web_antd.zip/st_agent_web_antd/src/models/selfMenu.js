/* eslint-disable no-param-reassign */
import {
  selfMenuList,
  selfMenuAdd,
  selfMenuUpdate,
  selfMenuDelete,
  selfMenuSyncMenu,
  getAuthorizerByAdminUserId, activityList, activityCount, autoReplyList, autoReplyCount,
} from '../services/api';

export default {
  namespace: 'selfMenu',

  state: {
    menuList: {
      data: [],
    },
    authorizerList: {},
    activityList:{
      list:[],
      pagination: {
        total:0,
      },
    },
    keywordList:{
      list:[],
      pagination: {
        total:0,
      },
    },
  },

  effects: {
    *menuListFetch({ payload }, { call, put }) {
      const response = yield call(selfMenuList, payload);
      yield put({
        type: 'menuList',
        payload: { data: response.obj },
      });
    },
    *menuAddFetch({ payload }, { call }) {
      const response = yield call(selfMenuAdd, payload);
      return response;
    },
    *menuUpdateFetch({ payload }, { call }) {
      const response = yield call(selfMenuUpdate, payload);
      return response;
    },
    *menuDeleteFetch({ payload }, { call }) {
      const response = yield call(selfMenuDelete, payload);
      return response;
    },
    *menuSyncMenuFetch({ payload }, { call }) {
      const response = yield call(selfMenuSyncMenu, payload);
      return response;
    },
    *authListFetch({ payload }, { call, put }) {
      const response = yield call(getAuthorizerByAdminUserId, payload);
      yield put({
        type: 'authorizerList',
        payload: { data: response.obj },
      });
    },
    *activityListFetch({ payload }, { call, put }) {
      const response = yield call(activityList, payload);
      const responseCount = yield call(activityCount, payload);
      yield put({
        type: 'activityList',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *keywordListFetch({ payload }, { call, put }) {
      const response = yield call(autoReplyList, payload);
      const responseCount = yield call(autoReplyCount, payload);
      yield put({
        type: 'keywordList',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
  },

  reducers: {
    menuList(state, action) {
      return {
        ...state,
        menuList: {
          data: action.payload.data,
        },
      };
    },
    authorizerList(state, action) {
      state.authorizerList = action.payload;
      return {
        ...state,
      };
    },
    activityList(state, action){
      return {
        ...state,
        activityList:{list:action.payload.list,pagination:{total:action.payload.total}},
      };
    },
    keywordList(state, action){
      return {
        ...state,
        keywordList:{list:action.payload.list,pagination:{total:action.payload.total}},
      };
    },
  },
};
