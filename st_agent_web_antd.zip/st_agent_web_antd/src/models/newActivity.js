import {
  activityList,
  activityCount,
  posterAdd,
  posterOpenAPrize,
  posterDelete,
  posterGET,
  posterUpdate,
  activityDeleteSubject,
  posterAssistanceSituationCount,
  posterAssistanceSituation,
  posterParticipation,
  posterParticipationCount,
  activitySaveSubject,
  activityReplyComment,
  acitivityLuckDraw,
  cardList,
  cardCount,
  autoReplyList,
  autoReplyCount,
  addNewActivity,
  deleteNewActivity,
  activityUserList,
  activityUserCount,
  activityHelpList,
  activityHelpCount,
  activityGetarticlesummary,
  activityGet,
  openAPrize,
  activitySelectSubjectList,
  activitySelectSubjectCount,
  commentGetarticlesummary,
  commentList,
  commentCount,
  commentUserList,
  commentUserCount,
  activitySyncComment,
  commentDelete,
  commentUserAllCount,
  commentAdd,
  commentAwardPrizes,
  activityAgainNotice,
  replyComment,
  activityPrizeSetUp,
  commentUpdate,
  commentGet,
  activityUnmarkelectOrMarkelect,
  guessSelectSubjectListByGuessId, qrcodeList, qrcodeCount,

} from '../services/api';

export default {
  namespace: 'newActivity',
  state: {
    posterGET:{

    },

    commentUserAllCount:{},
    // 图文列表
    commentList:{
      list: [],
      pagination: {
        total:0,
      },
    },
    qrcodeList:{
      list:[],
      pagination: {
        total:0,
      },
    },
    guessSelectSubjectListByGuessId:{
      list: [],
      pagination: {

      },
    },
    commentUserList: {
      list: [],
      pagination: {
        total:0,
      },
    },
    /*
    图文
     */
    commentGetarticlesummary:{
      list: [],
      pagination: {
        total:0,
      },
    },
    activityGetInfo:"",
    activityList:{
      list: [],
      pagination: {
        total:0,
      },
    },
    autoReplyList:{
      list: [],
      pagination: {
        total:0,
      },
    },
    activityListNews:{
      list: [],
      pagination: {
        total:0,
      },
    },
    saveCardList:{
      list: [],
      pagination: {
        total:0,
      },
    },
    editData:{

    },
    posterAssistance:{
      list: [],
      pagination: {
        total:0,
      },
    },
    posterParticipation: {
      list: [],
      pagination: {
        total:0,
      },
    },
    activityHelpList:{
      list: [],
      pagination: {
        total:0,
      },
    },
    activitySelectSubjectListSave:{
      list: [],
      pagination: {
        total:0,
      },
    },
  },

  effects: {

    *commentListButton({ payload }, { call, put }) {
      const response = yield call(commentList, payload);
      const responseCount = yield call(commentCount, payload);
      if(responseCount.code==="200"){
        yield put({
          type: 'commentList',
          payload:{list:response.obj,total:responseCount.obj},
        });
      }
    },
    *commentUserListButton({ payload }, { call, put }) {
      const response = yield call(activityUserList, payload);
      const responseCount = yield call(activityUserCount, payload);
      yield put({
        type: 'commentUserList',
        payload:{list:response.obj,total:responseCount.obj},
      });
      return response;
    },
    *qrcodeListFetch({ payload }, { call, put }) {
      const response = yield call(qrcodeList, payload);
      const responseCount = yield call(qrcodeCount, payload);
      yield put({
        type: 'qrcodeList',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *commentSyncCommentButton({ payload }, { call, put }) {
      const response = yield call(activitySyncComment, payload);
      return response;
    },
    *commentDeleteButton({ payload }, { call, put }) {
      const response = yield call(commentDelete, payload);
      return response;
    },
    *commentUserAllCount({ payload }, { call, put }) {
      const response = yield call(commentUserAllCount, payload);
      yield put({
        type: 'commentUserAllCount',
        payload: response.obj,
      });
    },
    *commentAddButton({ payload }, { call, put }) {
      const response = yield call(commentAdd, payload);
      return response;
    },
    *commentAwardPrizesButton({ payload }, { call, put }) {
      const response = yield call(commentAwardPrizes, payload);
      return response;
    },
    *commentAgainNoticeButton({ payload }, { call, put }) {
      const response = yield call(activityAgainNotice, payload);
      return response;
    },
    *replyCommentButton({ payload }, { call, put }) {
      const response = yield call(activityReplyComment, payload);
      return response;
    },
    *commentPrizeSetUpButton({ payload }, { call, put }) {
      const response = yield call(activityPrizeSetUp, payload);
      return response;
    },
    *commentUpdateButton({ payload }, { call, put }) {
      const response = yield call(commentUpdate, payload);
      return response;
    },
    *commentGetButton({ payload }, { call, put }) {
      const response = yield call(commentGet, payload);
      return response;
    },
    *acitivityLuckDrawButton({ payload }, { call, put }) {
      const response = yield call(acitivityLuckDraw, payload);
      return response;
    },
    *commentUnmarkelectOrMarkelectButton({ payload }, { call, put }) {
      const response = yield call(activityUnmarkelectOrMarkelect, payload);
      return response;
    },
    *cardListButton({ payload }, { call, put }) {
      const response = yield call(cardList, payload);
      const responseCount = yield call(cardCount, payload);
      yield put({
        type: 'cardList',
        payload: {list:response.obj,total:responseCount.obj},
      });
    },
    *newActivityHelpButton({ payload }, { call, put }) {
      const response = yield call(activityHelpList, payload);
      const responseCount = yield call(activityHelpCount, payload);
      yield put({
        type: 'activityHelpList',
        payload: {list:response.obj,total:responseCount.obj},
      });
    },
    *guessSelectSubjectListByGuessIdButton({ payload }, { call, put }) {
      const response = yield call(openAPrize, payload);
      yield put({
        type: 'guessSelectSubjectListByGuessId',
        payload: response.obj,
      });
    },
    *autoReplyListButton({ payload }, { call, put }) {
      const response = yield call(autoReplyList, payload);
      const responseCount = yield call(autoReplyCount, payload);
      yield put({
        type: 'autoReplyList',
        payload: {list:response.obj,total:responseCount.obj},
      });
    },
    *ActiveButton({ payload }, { call, put }) {
      const response = yield call (activityList, payload);
      const responseCount = yield call(activityCount, payload);
      yield put({
        type: 'activityListNews',
        payload: {list:response.obj,total:responseCount.obj},
      });
    },
    *activityGetButton({ payload }, { call, put }) {
      const response = yield call(activityGet, payload);
      if(response.code==="200"){
        yield put({
          type: 'activityGet',
          payload:response.obj,
        });
      }
      return response;
    },
    /*
    文章评论抽奖
     */
    *commentGetarticlesummaryButton({ payload }, { call, put }) {
      const response = yield call(activityGetarticlesummary, payload);
      yield put({
        type: 'commentGetarticlesummary',
        payload: {list:response.obj,total:""},
      });
    },

    *editData({ payload }, { call, put }) {
      yield put({
        type: 'editData',
        payload,
      });
    },
    *posterAssistanceSituationButton({ payload }, { call, put }) {
      const response = yield call(posterAssistanceSituation, payload);
      const responseCount = yield call(posterAssistanceSituationCount, payload);
      yield put({
        type: 'posterAssistanceSituation',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *posterGETButton({ payload }, { call, put }) {
      const response = yield call(posterGET, payload);
      yield put({
        type: 'posterGET',
        payload: response.obj,
      });
      return response;
    },
    *posterParticipationButton({ payload }, { call, put }) {
      const response = yield call(activityUserList, payload);
      const responseCount = yield call(activityUserCount, payload);
      yield put({
        type: 'posterParticipation',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *activityDeleteSubjectButton({ payload }, { call, put }) {
      const response = yield call(activityDeleteSubject, payload);
      return response;
    },
    *posterAddButton({ payload }, { call, put }) {
      const response = yield call(posterAdd, payload);
      return response;
    },
    *posterUpdateButton({ payload }, { call, put }) {
      const response = yield call(posterUpdate, payload);
      return response;
    },
    *posterOpenAPrizeButton({ payload }, { call, put }) {
      const response = yield call(openAPrize, payload);
      return response;
    },
    *addNewActivityButton({ payload }, { call, put }) {
      const response = yield call(addNewActivity, payload);
      return response;
    },
    *posterDeleteButton({ payload }, { call, put }) {
      const response = yield call(deleteNewActivity, payload);
      return response;
    },

    // 保存题目
    *activitySaveSubjectButton({ payload }, { call, put }) {
      const response = yield call(activitySaveSubject, payload);
      return response;
    },
    *addKon({ payload }, { call, put }) {

    },
    // 题目列表
    *activitySelectSubjectListButton({ payload }, { call, put }) {
      const response = yield call(activitySelectSubjectList, payload);
      const responseCount = yield call(activitySelectSubjectCount, payload);
      yield put({
        type: 'activitySelectSubjectList',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },

  },
  reducers: {
    cardList(state, action) {
      return {
        ...state,
        saveCardList:{
          list:action.payload.list,
          pagination:{
            total:action.payload.total,
          },
        },
      };
    },
    commentList(state, action) {
      return {
        ...state,
        commentList:{
          list:action.payload.list,
          pagination:{
            total:action.payload.total,
          },
        },
      };
    },
    qrcodeList(state, action){
      return {
        ...state,
        qrcodeList:{list:action.payload.list,pagination:{total:action.payload.total}},
      };
    },
    commentUserList(state, action) {
      return {
        ...state,
        commentUserList:
          {
            list:action.payload.list,
            pagination:{total:action.payload.total},
          },
      };
    },
    guessSelectSubjectListByGuessId(state, action) {
      return {
        ...state,
        guessSelectSubjectListByGuessId:{list:action.payload},
      };
    },
    commentUserAllCount(state, action) {
      return {
        ...state,
        commentUserAllCount:action.payload,
      };
    },
    activityHelpList(state, action) {
      return {
        ...state,
        activityHelpList:{
          list:action.payload.list,
          pagination:{
            total:action.payload.total,
          },
        },
      };
    },
    editData(state, action) {
      return {
        ...state,
        editData:action.payload,
      };
    },
    activityGet(state, action) {
      return {
        ...state,
        activityGetInfo:action.payload,
      };
    },
    activityListNews(state, action) {
      return {
        ...state,
        activityListNews:{
          list:action.payload.list,
          pagination:{
            total:action.payload.total,
          },
        },
      };
    },
    activityListButton(state, action) {
      return {
        ...state,
        activityList:{
          list:action.payload.list,
          pagination:{total:action.payload.total},
        },
      };
    },
    activitySelectSubjectList(state, action) {
      return {
        ...state,
        activitySelectSubjectListSave:{
          list:action.payload.list,
          pagination:{total:action.payload.total},
        },
      };
    },
    posterAssistanceSituation(state, action) {
      return {
        ...state,
        posterAssistance:{
          list:action.payload.list,
          pagination:{total:action.payload.total},
        },
      };
    },
    autoReplyList(state, action) {
      return {
        ...state,
        autoReplyList:{
          list:action.payload.list,
          pagination:{
            total:action.payload.total,
          },
        },
      };
    },
    posterGET(state, action) {
      return {
        ...state,
        posterGET:action.payload,
      };
    },
    /*
    文章评论抽奖
     */
    commentGetarticlesummary(state, action) {
      return {
        ...state,
        commentGetarticlesummary:action.payload,
      };
    },
    posterParticipation(state, action) {
      return {
        ...state,
        posterParticipation:{
          list:action.payload.list,
          pagination:{total:action.payload.total},
        },
      };
    },
  },
};
