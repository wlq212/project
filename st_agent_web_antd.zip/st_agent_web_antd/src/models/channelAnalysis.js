/* eslint-disable import/named */
import { activityCount, dataCountChannelAnalysisExportExcel,activityList, qrcodeCount, qrcodeList, shop,dataCountChannelAnalysis} from '../services/api';


export default {
  namespace: 'channelAnalysis',

  state: {
    visitData: [],
    visitData2: [],
    salesData: [],
    searchData: [],
    offlineData: [],
    offlineChartData: [],
    salesTypeData: [],
    channelList:{
      list:[],
      pagination: {
        total:0,
      },
    },
    shopList:[],
    activityList:{
      list:[],
      pagination: {
        total:0,
      },
    },
    channelAnalysisList:{
      list:[],
      pagination: {
        total:0,
      },
    },
    salesTypeDataOnline: [],
    salesTypeDataOffline: [],
    radarData: [],
    loading: false,
  },

  effects: {
    *fetch(_, { call, put }) {
      const response = yield call(fakeChartData);
      yield put({
        type: 'save',
        payload: response,
      });
    },
    *dataCountChannelAnalysisList({ payload }, { call, put }) {
      const response = yield call(dataCountChannelAnalysis, payload);
      if(response.code==="200"){
        yield put({
          type: 'dataCountChannelAnalysis',
          payload:{list:response.obj.data,total:response.obj.total},
        });
      }
    },
    *shopList({ payload }, { call, put }) {
      const response = yield call(shop, payload);
      if(response.code==="200"){
        yield put({
          type: 'saveShopList',
          payload:{list:response.obj},
        });
      }
    },
    *fetchActivity({ payload }, { call, put }){
      const response = yield call (activityList, payload);
      const responseCount = yield call(activityCount, payload);
      if(response.code==="200"){
        yield put({
          type: 'activityListNews',
          payload: {list:response.obj,total:responseCount.obj},
        });
      }
    },
    *qrcodeListFetch({ payload }, { call, put }) {
      const response = yield call(qrcodeList, payload);
      const responseCount = yield call(qrcodeCount, payload);
      if(response.code==="200"){
        yield put({
          type: 'qrcodeList',
          payload:{list:response.obj,total:responseCount.obj},
        });
      }
    },
    *dataExportExcel({ payload }, { call, put }){
      const response = yield call(dataCountChannelAnalysisExportExcel,payload);
      return response;
    },
    *fetchSalesData(_, { call, put }) {
      const response = yield call(fakeChartData);
      yield put({
        type: 'save',
        payload: {
          salesData: response.salesData,
        },
      });
    },
  },

  reducers: {
    save(state, { payload }) {
      return {
        ...state,
        ...payload,
      };
    },
    saveShopList(state, action) {
      return {
        ...state,
        shopList:action.payload.list,
      };
    },
    activityListNews(state, action) {
      return {
        ...state,
        activityList:{
          list:action.payload.list,
          pagination:{
            total:action.payload.total,
          },
        },
      };
    },
    qrcodeList(state, action){
      return {
        ...state,
        channelList:{list:action.payload.list,pagination:{total:action.payload.total}},
      };
    },
    dataCountChannelAnalysis(state, action){
      return {
        ...state,
        channelAnalysisList:{list:action.payload.list,pagination:{total:action.payload.total}},
      };
    },
    clear() {
      return {
        visitData: [],
        visitData2: [],
        salesData: [],
        searchData: [],
        offlineData: [],
        offlineChartData: [],
        salesTypeData: [],
        salesTypeDataOnline: [],
        salesTypeDataOffline: [],
        radarData: [],
      };
    },
  },
};
