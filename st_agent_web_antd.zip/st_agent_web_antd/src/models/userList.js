import { userList, userCount, adminUsermodiPwd, addManage, userActionList } from '../services/api';

export default {
  namespace: 'userList',
  state: {
    result:{

    },
    saveAddresult:{},
    data: {
      list: [],
      result:{},


      pagination: {

      },
    },
    userActionList: {},
  },

  effects: {
    *fetch({ payload }, { call, put }) {
      const response = yield call(userList, payload);
      const responseCount = yield call(userCount, payload);
      yield put({
        type: 'save',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *userDetail({ payload,callback}, { call, put }) {
      yield put({
        type: 'saveAddCount',
        payload,
      });
      if (callback) callback();
    },
    *userActionListFetch({ payload }, { call, put }) {
      const response = yield call(userActionList, payload);
      yield put({
        type: 'userActionList',
        payload:{list:response.obj},
      });
    },
    *passwordReset({ payload }, { call, put }) {
      const response = yield call(adminUsermodiPwd, payload);
      yield put({
        type: 'saveReset',
        payload: response,
      });
    },
    *add({ payload, callback }, { call, put }) {
      const response = yield call(addManage, payload);
      yield put({
        type: 'saveAddCount',
        payload: response,
      });
      if (callback) callback();
    },
    *remove({ payload, callback }, { call, put }) {
      const response = yield call(removeRule, payload);
      yield put({
        type: 'save',
        payload: response,
      });
      if (callback) callback();
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data:{
          list:action.payload.list,
          pagination:{
            total:action.payload.total,
          },
        },
      };
    },
    saveReset(state, action) {
      return {
        ...state,
        result:action.payload,
      };
    },
    saveAddCount(state, action) {
      return {
        ...state,
        saveAddresult:action.payload,
      };
    },
    userActionList(state, action) {
      return {
        ...state,
        userActionList:action.payload.list,
      }
    },
  },
};
