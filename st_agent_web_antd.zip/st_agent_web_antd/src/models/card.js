import {
  cardList,
  cardCount,
  cardDelete,
  userCardList,
  userCardCount,
  cardAdd,
  cardGet,
  shop,
  shopcount,
  cardUpdate,
  cardStatList,
} from '../services/api';

export default {
  namespace: 'card',
  state: {
    step: {
          title: 'ant-design@alipay.com',
          receiverAccount: 'test@example.com',
          receiverName: 'Alex',
          data:"",
          amount: '500',
        },
    cardGet:{

    },
    savecardtatList:{
      list: [],
      pagination: {
        total:0,
      },
    },
    cardUpdateParams:{},
    saveshop:{
     list: [],
          pagination: {
           total:0,
          },
    },
    userCardList:{
      list: [],
      pagination: {
       total:0,
      },
    },
    saveCardStatList:{
          list: [],
          pagination: {
            total:0,
          },
    },
    cardList: {
      list: [],
      pagination: {
        total:0,
      },
    },
  },

  effects: {
    *fetch({ payload }, { call, put }) {
        const response = yield call(shop, payload);
        const responseCount = yield call(shopcount, payload);
        yield put({
          type: 'saveshop',
          payload:{list:response.obj,total:responseCount.obj},
        });
      },
      *cardStatListButton({ payload }, { call, put }) {
         const response = yield call(cardStatList, payload);
           yield put({
            type: 'saveCardStatList',
             payload:{list:response.obj.data,total:response.obj.total},
              });
          },
      *submitRegularForm({ payload }, { call }) {
        yield call(fakeSubmitForm, payload);
        message.success('提交成功');
      },
      *submitStepForm({ payload }, { call, put }) {
        yield put({
          type: 'saveStepFormData',
          payload,
        });
      },
      *submitAdvancedForm({ payload }, { call }) {
        yield call(fakeSubmitForm, payload);
        message.success('提交成功');
      },
   *cardListButton({ payload }, { call, put }) {
      const response = yield call(cardList, payload);
      const responseCount = yield call(cardCount, payload);
     yield put({
       type: 'cardList',
       payload: {list:response.obj,total:responseCount.obj},
     });
   },
    *cardDeleteButton({ payload }, { call, put }) {
      const response = yield call(cardDelete, payload);
      return response;
    },
    *userCardListButton({ payload }, { call, put }) {
      const response = yield call(userCardList, payload);
      const responseCount = yield call(userCardCount, payload);
      yield put({
        type: 'userCardList',
        payload: {list:response.obj,total:responseCount.obj},
      });
    },
    *cardAdd({ payload }, { call, put }) {
      const response = yield call(cardAdd, payload);
      return response;
    },
    *cardGetButton({ payload }, { call, put }) {
      const response = yield call(cardGet, payload);
      yield put({
        type: 'cardGet',
        payload: response.obj,
      });
      return response;
    },
    *cardUpdateParams({ payload }, { call, put }) {
      yield put({
        type: 'cardUpdateParams',
        payload,
      });
    },
    *cardUpdateButton({ payload }, { call, put }) {
      const response = yield call(cardUpdate, payload);
      return response;
    },

  },
  reducers: {
   saveshop(state, action) {
        return {
          ...state,
          saveshop:{
            list:action.payload.list,
            total:action.payload.total,
          },
        };
      },
   saveStepFormData(state, { payload }) {
        return {
          ...state,
          step: {
            ...state.step,
            ...payload,
          },
        };
      },
    cardList(state, action) {
      return {
        ...state,
        cardList:{
          list:action.payload.list,
           pagination:{
                      total:action.payload.total,
             },
        },
      };
    },
    saveCardStatList(state, action) {
                      return {
                        ...state,
                        saveCardStatList:{
                          list:action.payload.list,
                           pagination:{
                                      total:action.payload.total,
                             },
                        },
                      };
       },
    userCardList(state, action) {
      return {
        ...state,
        userCardList:{
           list:action.payload.list,
           pagination:{total:action.payload}.total,
        },
      };
    },
    cardUpdateParams(state, action) {
      return {
        ...state,
        cardUpdateParams:action.payload,
      };
    },
    cardGet(state, action) {
      return {
        ...state,
        cardGet:action.payload,
      };
    },
  },
};
