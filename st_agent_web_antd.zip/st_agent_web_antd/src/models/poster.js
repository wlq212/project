import {
  posterList,
  posterCount,
  posterAdd,
  posterOpenAPrize,
  posterDelete,
  posterGET,
  posterUpdate,
  posterAssistanceSituationCount,
  posterAssistanceSituation,
  posterParticipation,
  posterParticipationCount,
  cardList,
  cardCount,
} from '../services/api';

export default {
  namespace: 'poster',
  state: {
    posterGET:{

    },
    posterList:{
      list: [],
      pagination: {
      total:0,
      },
    },
    saveCardList:{
      list: [],
      pagination: {
        total:0,
      },
    },
    posterAssistance:{
      list: [],
      pagination: {
        total:0,
      },
    },
    posterParticipation: {
      list: [],
      pagination: {
       total:0,
      },
    },
  },

  effects: {
    *cardListButton({ payload }, { call, put }) {
      const response = yield call(cardList, payload);
      const responseCount = yield call(cardCount, payload);
      yield put({
        type: 'cardList',
        payload: {list:response.obj,total:responseCount.obj},
      });
    },
    *posterListButton({ payload }, { call, put }) {
      const response = yield call(posterList, payload);
      const responseCount = yield call(posterCount, payload);
      yield put({
        type: 'posterList',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *posterAssistanceSituationButton({ payload }, { call, put }) {
      const response = yield call(posterAssistanceSituation, payload);
      const responseCount = yield call(posterAssistanceSituationCount, payload);
      yield put({
        type: 'posterAssistanceSituation',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *posterGETButton({ payload }, { call, put }) {
      const response = yield call(posterGET, payload);
      yield put({
        type: 'posterGET',
        payload: response.obj,
      });
      return response;
    },
    *posterParticipationButton({ payload }, { call, put }) {
      const response = yield call(posterParticipation, payload);
      const responseCount = yield call(posterParticipationCount, payload);
      yield put({
        type: 'posterParticipation',
        payload:{list:response.obj,total:responseCount.obj},
      });
    },
    *posterAddButton({ payload }, { call, put }) {
      const response = yield call(posterAdd, payload);
      return response;
    },
    *posterUpdateButton({ payload }, { call, put }) {
      const response = yield call(posterUpdate, payload);
      return response;
    },
    *posterOpenAPrizeButton({ payload }, { call, put }) {
      const response = yield call(posterOpenAPrize, payload);
      return response;
    },
    *posterDeleteButton({ payload }, { call, put }) {
      const response = yield call(posterDelete, payload);
      return response;
    },
  },
  reducers: {
    cardList(state, action) {
      return {
        ...state,
        saveCardList:{
          list:action.payload.list,
          pagination:{
            total:action.payload.total,
          },
        },
      };
    },
    posterList(state, action) {
      return {
        ...state,
        posterList:{
          list:action.payload.list,
          pagination:{total:action.payload.total},
        },
      };
    },

    posterAssistanceSituation(state, action) {
      return {
        ...state,
        posterAssistance:{
          list:action.payload.list,
          pagination:{total:action.payload.total},
        },
      };
    },
    posterGET(state, action) {
      return {
        ...state,
        posterGET:action.payload,
      };
    },
    posterParticipation(state, action) {
      return {
        ...state,
        posterParticipation:{
          list:action.payload.list,
          pagination:{total:action.payload.total},
        },
      };
    },
  },
};
