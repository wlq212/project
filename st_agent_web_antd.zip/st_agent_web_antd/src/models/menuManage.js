/* eslint-disable no-param-reassign */
import {
  menuList,
  menuAdd,
  menuDelete,
  menuListSave,
} from '../services/api';

export default {
  namespace: 'menuManage',

  state: {
    menuList: {},
  },

  effects: {
    *fetchMenuList({ payload }, { call, put }) {
      const response = yield call(menuList, payload);
      yield put({
        type: 'menuArr',
        payload: response.obj,
      });
    },
    *menuAddFetch({ payload }, { call }) {
      const response = yield call(menuAdd, payload);
      return response;
    },
    *menuDeleteFetch({ payload }, { call }) {
      const response = yield call(menuDelete, payload);
      return response;
    },
    *menuListSaveFetch({ payload }, { call }) {
      const response = yield call(menuListSave, payload);
      return response;
    },
    *changeState({ payload }, { call }) {


    },
  },

  reducers: {
    menuArr(state, action) {
      return {
        ...state,
        menuList: action.payload,
      };
    },
  },
};
