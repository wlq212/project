import React, { createElement } from 'react';
import { Spin } from 'antd';
import pathToRegexp from 'path-to-regexp';
import Loadable from 'react-loadable';
import { getMenuData } from './menu';

let routerDataCache;
const modelNotExisted = (app, model) =>
  // eslint-disable-next-line
  !app._models.some(({ namespace }) => {
    return namespace === model.substring(model.lastIndexOf('/') + 1);
  });

// wrapper of dynamic
const dynamicWrapper = (app, models, component) => {
  // register models
  models.forEach(model => {
    if (modelNotExisted(app, model)) {
      // eslint-disable-next-line
      app.model(require(`../models/${model}`).default);
    }
  });

  // () => require('module')
  // transformed by babel-plugin-dynamic-import-node-sync
  if (component.toString().indexOf('.then(') < 0) {
    return props => {
      if (!routerDataCache) {
        routerDataCache = getRouterData(app);
      }
      return createElement(component().default, {
        ...props,
        routerData: routerDataCache,
      });
    };
  }
  // () => import('module')
  return Loadable({
    loader: () => {
      if (!routerDataCache) {
        routerDataCache = getRouterData(app);
      }
      return component().then(raw => {
        const Component = raw.default || raw;
        return props =>
          createElement(Component, {
            ...props,
            routerData: routerDataCache,
          });
      });
    },
    loading: () => {
      return <Spin size="large" className="global-spin" />;
    },
  });
};

function getFlatMenuData(menus) {
  let keys = {};
  menus.forEach(item => {
    if (item.children) {
      keys[item.path] = { ...item };
      keys = { ...keys, ...getFlatMenuData(item.children) };
    } else {
      keys[item.path] = { ...item };
    }
  });
  return keys;
}

export const getRouterData = app => {
  const routerConfig = {
    '/': {
      component: dynamicWrapper(app, ['user', 'login'], () => import('../layouts/BasicLayout')),
    },
    '/home':{
      name:"",
      component: dynamicWrapper(app, ['home'], () => import('../routes/home/index')),
    },
    '/wxAccounts/selfMenu':{
      component: dynamicWrapper(app, ['selfMenu'], () => import('../routes/selfMenu/selfMenu')),
    },
    '/customerService/mpMessage':{
      component: dynamicWrapper(app, ['mpMessage'], () => import('../routes/mpMessage/mpMessage')),
    },
    '/wxAccounts/autoReply/':{
      component: dynamicWrapper(app, ['autoReply'], () => import('../routes/autoReply/autoReply')),
    },
    '/wxAccounts/autoReply/autoReplyAdd':{
      name:"关键词添加",
      component: dynamicWrapper(app, ['autoReply'], () => import('../routes/autoReply/autoReplyAdd')),
    },
    '/wxAccounts/autoReply/autoReplyEdit':{
      name:"关键词编辑",
      component: dynamicWrapper(app, ['autoReply'], () => import('../routes/autoReply/autoReplyEdit')),
    },
    '/wxAccounts/material':{
      component: dynamicWrapper(app, ['material'], () => import('../routes/material/material')),
    },
    '/setting/menuManage':{
      component: dynamicWrapper(app, ['menuManage'], () => import('../routes/menuManage/menuManage')),
    },
    '/setting/roleList/':{
      component: dynamicWrapper(app, ['roleManage'], () => import('../routes/roleManage/roleList')),
    },
    '/setting/roleList/roleManage':{
      name:"配置菜单",
      component: dynamicWrapper(app, ['roleManage'], () => import('../routes/roleManage/roleManage')),
    },
    '/setting/roleList/roleAdd':{
      name:"新增角色",
      component: dynamicWrapper(app, ['roleManage'], () => import('../routes/roleManage/roleAdd')),
    },
    '/Data/channelAnalysis':{
      component: dynamicWrapper(app, ['channelAnalysis'], () => import('../routes/channelAnalysis/channelAnalysis')),
    },
    '/Data/userAnalysis':{
    component: dynamicWrapper(app, ['userAnalysis'], () => import('../routes/userAnalysis/userAnalysis')),
    },
    '/Data/tweetsAnalysis':{
      component: dynamicWrapper(app, ['tweetsAnalysis'], () => import('../routes/tweetsAnalysis/tweetsAnalysis')),
    },
    '/Data/shopDataList/':{
      component: dynamicWrapper(app, ['shop'], () => import('../routes/shop/shopDataList')),
    },
    '/Data/shopDataList/addShopData':{
      name:"录入数据",
      component: dynamicWrapper(app, ['shop'], () => import('../routes/shop/shopDataAdd')),
    },
    '/wxAccounts/channel':{
      component: dynamicWrapper(app, ['channel'], () => import('../routes/channel/channel')),
    },
    '/wxAccounts/channelAdd':{
      name:"编辑关注渠道",
      component: dynamicWrapper(app, ['channel'], () => import('../routes/channel/channelAdd')),
    },
    '/wxAccounts/channelListAdd':{
      name:"批量新增关注渠道",
      component: dynamicWrapper(app, ['channel'], () => import('../routes/channel/channelListAdd')),
    },
    '/wxAccounts/shop/':{
      component: dynamicWrapper(app, ['shop'], () => import('../routes/shop/shop')),
    },
    '/wxAccounts/shop/shopAdd':{
      name:"门店添加",
      component: dynamicWrapper(app, ['shop'], () => import('../routes/shop/shopAdd')),
    },
    '/wxAccounts/shop/shopEdit':{
      name:"门店编辑",
      component: dynamicWrapper(app, ['shop'], () => import('../routes/shop/shopDataEdit')),
    },
    '/Data/qrcode/':{
      component: dynamicWrapper(app, ['qrcode'], () => import('../routes/qrCode/qrcode')),
    },
    '/Data/qrcode/qrcodeAdd':{
      name:"二维码添加",
      component: dynamicWrapper(app, ['qrcode'], () => import('../routes/qrCode/qrcodeAdd')),
    },
    '/Data/qrcode/qrCodeTj':{
      name:"二维码数据统计",
      component: dynamicWrapper(app, ['qrcode'], () => import('../routes/qrCode/qrCodeTj')),
    },
    '/Data/qrcode/qrcodeUpdate':{
      name:"二维码修改",
      component: dynamicWrapper(app, ['qrcode'], () => import('../routes/qrCode/qrcodeUpdate')),
    },
    '/userManage/userList/':{
      component: dynamicWrapper(app, ['userList'], () => import('../routes/user/userList')),
    },
    '/userManage/userAction':{
      component: dynamicWrapper(app, ['userAction'], () => import('../routes/userAction/userAction')),
    },
    '/userManage/userList/userDetail':{
      name:"粉丝详情",
      component: dynamicWrapper(app, ['userList'], () => import('../routes/user/userDetail')),
    },
    '/userManage/userList/userAction':{
      name:"用户行为",
      component: dynamicWrapper(app, ['userList'], () => import('../routes/user/userAction')),
    },
    '/wxAccounts/wxAccountsManage':{
      component: dynamicWrapper(app, ['user', 'login'], () => import('../routes/Exception/403')),
    },
    '/setting/version':{
      component: dynamicWrapper(app, ['version'], () => import('../routes/miniProgram/version/version')),
    },
    '/setting/pageManage/':{
      component: dynamicWrapper(app, ['pageManage'], () => import('../routes/miniProgram/pageManage/pageManage')),
    },
    '/setting/pageManage/pageManageAdd':{
      name:"小程序页面添加",
      component: dynamicWrapper(app, ['pageManage'], () => import('../routes/miniProgram/pageManage/pageManageAdd')),
    },
    '/setting/pageManage/pageManageEidt':{
      name:"小程序页面更新",
      component: dynamicWrapper(app, ['pageManage'], () => import('../routes/miniProgram/pageManage/pageManageEdit')),
    },
    '/marketingManage/newActivity/newActivityCommentUser':{
      name:"文章留言列表",
      component: dynamicWrapper(app, ['newActivity'], () => import('../routes/newActivity/newActivityCommentUser')),
    },

    '/marketingManage/newActivity/newActivityDetailList':{
      name:"助力明细",
      component: dynamicWrapper(app, ['newActivity'], () => import('../routes/newActivity/newActivityDetailList')),
    },
    '/setting/miniWx':{
      component: dynamicWrapper(app, ['user', 'login'], () => import('../routes/Exception/403')),
    },
    '/marketingManage/card/':{
      component: dynamicWrapper(app, ['card'], () => import('../routes/card/card')),
    },
    '/marketingManage/schedule':{
      component: dynamicWrapper(app, ['schedule'], () => import('../routes/schedule/schedule')),
    },
    '/marketingManage/card/cardUsage':{
      name:"使用情况",
      component: dynamicWrapper(app, ['card'], () => import('../routes/card/cardUsage')),
    },
    '/marketingManage/activity/guess/':{
      component: dynamicWrapper(app, ['guess'], () => import('../routes/activity/guess/guess')),
    },
    '/marketingManage/activity/guess/guessResultList':{
      name:"查看答案",
      component: dynamicWrapper(app, ['guess'], () => import('../routes/activity/guess/guessResultList')),
    },
    '/marketingManage/newActivity/guessResultList':{
      name:"查看答案",
      component: dynamicWrapper(app, ['newActivity'], () => import('../routes/newActivity/guessResultList')),
    },
    '/marketingManage/activity/guess/guessAdd':{
      name:"竞猜添加",
      component: dynamicWrapper(app, ['guess'], () => import('../routes/activity/guess/guessAdd')),
    },
    '/marketingManage/activity/guess/guessEdit':{
      name:"竞猜编辑",
      component: dynamicWrapper(app, ['guess'], () => import('../routes/activity/guess/guessEdit')),
    },
    '/marketingManage/activity/guess/guessPartakeList':{
      name:"参与情况",
      component: dynamicWrapper(app, ['guess'], () => import('../routes/activity/guess/guessPartakeList')),
    },
    '/marketingManage/activity/moments/friendsPartakeList':{
      name:"参与情况",
      component: dynamicWrapper(app, ['moments'], () => import('../routes/activity/moments/friendsPartakeList')),
    },

    '/marketingManage/activity/moments/':{
      component: dynamicWrapper(app, ['moments'], () => import('../routes/activity/moments/moments')),
    },
    '/marketingManage/activity/moments/friendsAdd':{
      name:"抽奖活动添加",
      component: dynamicWrapper(app, ['moments'], () => import('../routes/activity/moments/momentsAdd')),
    },
    '/marketingManage/activity/moments/friendsEdit':{
      name:"抽奖活动编辑",
      component: dynamicWrapper(app, ['moments'], () => import('../routes/activity/moments/momentsEdit')),
    },
    '/wxAccounts/desk':{
      component: dynamicWrapper(app, ['desk'], () => import('../routes/desk/desk')),
    },
    '/marketingManage/activity/comment/':{
      component: dynamicWrapper(app, ['comment'], () => import('../routes/activity/comment/comment')),
    },
    '/marketingManage/activity/comment/commentAdd':{
      name:"文章评论添加",
      component: dynamicWrapper(app, ['comment'], () => import('../routes/activity/comment/commentAdd')),
    },
    '/marketingManage/activity/comment/commentEdit':{
      name:"文章评论编辑",
      component: dynamicWrapper(app, ['comment'], () => import('../routes/activity/comment/commentEdit')),
    },
    '/marketingManage/activity/comment/commentUserList':{
      name:"评论列表",
      component: dynamicWrapper(app, ['comment'], () => import('../routes/activity/comment/commentUserList')),
    },
    '/marketingManage/activity/poster/':{
      component: dynamicWrapper(app, ['poster'], () => import('../routes/activity/poster/poster')),
    },
    '/marketingManage/activity/poster/posterPartakeList':{
      name:"参与情况",
      component: dynamicWrapper(app, ['poster'], () => import('../routes/activity/poster/posterPartakeList')),
    },

    '/marketingManage/activity/poster/posterDetailList':{
      name:"助力明细",
      component: dynamicWrapper(app, ['poster'], () => import('../routes/activity/poster/posterDetailList')),
    },
    '/marketingManage/newActivity/activityHelpList':{
      name:"助力明细",
      component: dynamicWrapper(app, ['newActivity'], () => import('../routes/newActivity/activityHelpList')),
    },
    '/marketingManage/activity/poster/posterAdd':{
      name:"积分海报添加",
      component: dynamicWrapper(app, ['poster'], () => import('../routes/activity/poster/posterAdd')),
    },
    '/marketingManage/activity/poster/posterEdit':{
      name:"积分海报编辑",
      component: dynamicWrapper(app, ['poster'], () => import('../routes/activity/poster/posterEdit')),
    },
    '/setting/tplSetting/':{
      name:"小程序模板设置",
      component: dynamicWrapper(app, ['tplSetting'], () => import('../routes/miniProgram/tplSetting/tplSetting')),
    },
    '/setting/manage/':{
      name:"账号管理",
      component: dynamicWrapper(app, ['manage'], () => import('../routes/manage/manage')),
    },
    '/setting/manage/accountAdd':{
      name:"管理员添加",
      component: dynamicWrapper(app, ['manage'], () => import('../routes/manage/manageAdd')),
    },
    '/setting/manage/accountEdit':{
      name:"管理员编辑",
      component: dynamicWrapper(app, ['manage'], () => import('../routes/manage/manageEdit')),
    },
    '/marketingManage/newActivity/':{
      component: dynamicWrapper(app, ['newActivity'], () => import('../routes/newActivity/newActivity')),
     },
    '/marketingManage/newActivity/newActivityAdd':{
      name:"活动添加",
      component: dynamicWrapper(app, ['newActivity'], () => import('../routes/newActivity/newActivityAdd')),
    },
    '/marketingManage/newActivity/newActivityEdit':{
      name:"活动编辑",
      component: dynamicWrapper(app, ['newActivity'], () => import('../routes/newActivity/newActivityEdit')),
    },
    '/marketingManage/newActivity/newActivityPartakeList':{
      name:"活动参与列表",
      component: dynamicWrapper(app, ['newActivity'], () => import('../routes/newActivity/newActivityPartakeList')),
    },
    '/marketingManage/newActivity/friendsPartakeList':{
      name:"活动参与列表",
      component: dynamicWrapper(app, ['newActivity'], () => import('../routes/newActivity/friendsPartakeList')),
    },

    '/marketingManage/newActivity/answerPartakeList':{
      name:"答题参与列表",
      component: dynamicWrapper(app, ['newActivity'], () => import('../routes/newActivity/answerPartakeList')),
    },
    '/marketingManage/newActivity/deskLuckPartakeList':{
      name:"同桌拼手气活动参与列表",
      component: dynamicWrapper(app, ['newActivity'], () => import('../routes/newActivity/deskLuckPartakeList')),
    },
    '/marketingManage/newActivity/activitySelectSubjectList':{
      name:"题目列表",
      component: dynamicWrapper(app, ['newActivity'], () => import('../routes/newActivity/activitySelectSubjectList')),
    },
    '/marketingManage/card/cardEdit': {
      component: dynamicWrapper(app, ['card'], () => import('../routes/card/cardEdit')),
    },
    '/marketingManage/card/cardEdit/baseinfo': {
      name: '卡券基本信息(添加）',
      component: dynamicWrapper(app, ['card'], () => import('../routes/card/cardEdit/Step1')),
    },
    '/marketingManage/card/cardCount': {
      name: '优惠券统计',
      component: dynamicWrapper(app, ['card'], () => import('../routes/card/cardCount')),
    },
    '/marketingManage/card/cardEdit/carinfo': {
      name: '券面信息(添加）',
      component: dynamicWrapper(app, ['card'], () => import('../routes/card/cardEdit/Step2')),
    },
    '/marketingManage/card/cardEdit/result': {
      name: '卡券信息（完成）',
      component: dynamicWrapper(app, ['card'], () => import('../routes/card/cardEdit/Step3')),
    },
     '/setting/auth': {
       component: dynamicWrapper(app, ['auth'], () => import('../routes/auth/auth')),
     },
    '/marketingManage/card/cardUpdate': {
      component: dynamicWrapper(app, ['card'], () => import('../routes/card/cardUpdate')),
    },
    '/marketingManage/card/cardUpdate/baseinfo': {
      name: '卡券基本信息(更新）',
      component: dynamicWrapper(app, ['card'], () => import('../routes/card/cardUpdate/Step1')),
    },
    '/marketingManage/card/cardUpdate/carinfo': {
      name: '券面信息(更新）',
      component: dynamicWrapper(app, ['card'], () => import('../routes/card/cardUpdate/Step2')),
    },
    '/marketingManage/card/cardUpdate/result': {
      name: '卡券信息（完成）',
      component: dynamicWrapper(app, ['card'], () => import('../routes/card/cardUpdate/Step3')),
    },
    '/user': {
      component: dynamicWrapper(app, [], () => import('../layouts/UserLayout')),
    },
    '/user/login': {
      component: dynamicWrapper(app, ['login'], () => import('../routes/user/Login')),
    },
    '/user/register': {
      component: dynamicWrapper(app, ['register'], () => import('../routes/user/Register')),
    },
    '/user/register-result': {
      component: dynamicWrapper(app, [], () => import('../routes/user/RegisterResult')),
    },
    '/exception/403': {
      component: dynamicWrapper(app, [], () => import('../routes/Exception/403')),
    },
    '/exception/404': {
      component: dynamicWrapper(app, [], () => import('../routes/Exception/404')),
    },
    '/exception/500': {
      component: dynamicWrapper(app, [], () => import('../routes/Exception/500')),
    },
    '/exception/trigger': {
      component: dynamicWrapper(app, ['error'], () =>
        import('../routes/Exception/triggerException')
      ),
    },

  };
  // Get name from ./menu.js or just set it in the router data.
  const menuData = getFlatMenuData(getMenuData());

  // Route configuration data
  // eg. {name,authority ...routerConfig }
  const routerData = {};
  // The route matches the menu
  Object.keys(routerConfig).forEach(path => {
    // Regular match item name
    // eg.  router /user/:id === /user/chen
    const pathRegexp = pathToRegexp(path);
    const menuKey = Object.keys(menuData).find(key => pathRegexp.test(`${key}`));
    let menuItem = {};
    // If menuKey is not empty
    if (menuKey) {
      menuItem = menuData[menuKey];
    }
    let router = routerConfig[path];
    // If you need to configure complex parameter routing,
    // https://github.com/ant-design/ant-design-pro-site/blob/master/docs/router-and-nav.md#%E5%B8%A6%E5%8F%82%E6%95%B0%E7%9A%84%E8%B7%AF%E7%94%B1%E8%8F%9C%E5%8D%95
    // eg . /list/:type/user/info/:id
    router = {
      ...router,
      name: router.name || menuItem.name,
      authority: router.authority || menuItem.authority,
      hideInBreadcrumb: router.hideInBreadcrumb || menuItem.hideInBreadcrumb,
    };
    routerData[path] = router;
  });
  return routerData;
};
