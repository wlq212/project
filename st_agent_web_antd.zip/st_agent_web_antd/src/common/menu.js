import { isUrl } from '../utils/utils';
import { getStore } from '../assets/js/mUtils';
/*
获取菜单
*/
// const menuData = [
//   {
//     name:'首页',
//     icon: 'dashboard',
//     path:'/',
//   },
//   {
//     name:'营销管理',
//     icon: 'dashboard',
//     path: 'marketingManage',
//     children:[
//       // {
//       //   name: '营销活动',
//       //   path: 'activity',
//       //   children: [
//       //     {
//       //       name: '竞猜',
//       //       path: 'guess',
//       //     },
//       //     {
//       //       name: '朋友圈转发抽奖',
//       //       path: 'moments',
//       //     },
//       //     {
//       //       name: '文章评论抽奖',
//       //       path: 'comment',
//       //     },
//       //     {
//       //       name: '积分海报活动',
//       //       path: 'poster',
//       //     },
//       //     ],
//       //  },
//       {
//         name:'活动',
//         path:"newActivity",
//       },
//       {
//         name: '卡券管理',
//         path: 'card',
//       },
//     ],
//   },
//   {
//     name: '公众号设置',
//     icon: 'dashboard',
//     path:'wxAccounts',
//     children: [
//       {
//         name: '自定义菜单',
//         path: 'selfMenu',
//       },
//       {
//         name: '自动回复',
//         path: 'autoReply',
//       },
//       {
//         name: '素材管理',
//         path: 'material',
//       },
//     ],
//   },
//   {
//     name:'用户管理',
//     icon: 'form',
//     path: 'userManage',
//     children:[
//       {
//         name: '用户列表',
//         path: 'userList',
//       },
//     ],
//   },
//   {
//     name:'客服',
//     icon: 'form',
//     path: 'customerService',
//     children:[
//       {
//         name: '公众号消息',
//         path: 'mpMessage',
//       },
//     ],
//   },
//   {
//     name:'数据统计',
//     icon: 'form',
//     path: 'Data',
//     children:[
//       {
//         name: '二维码',
//         path: 'qrcode',
//       },
//     ],
//   },
//   {
//     name:'设置',
//     icon: 'form',
//     path: 'setting',
//     children:[
//       {
//         name: '小程序模版配置',
//         path: 'tplSetting',
//       },
//       {
//         name: '小程序版本管理',
//         path: 'version',
//       },
//       {
//         name: '小程序页面管理',
//         path: 'pageManage',
//       },
//       {
//         name: '账号管理',
//         path: 'manage',
//       },
//       {
//         name: '菜单管理',
//         path: 'menuManage',
//       },{
//         name: '角色管理',
//         path: 'roleList',
//       },
//       {
//         name: '门店设置',
//         path: 'shop',
//       },
//       {
//         name: '授权管理',
//         path: 'auth',
//       },
//     ],
//   },
//   {
//     name: '账户',
//     icon: 'user',
//     path: 'user',
//     authority: 'guest',
//     children: [
//       {
//         name: '登录',
//         path: 'login',
//       },
//       {
//         name: '注册',
//         path: 'register',
//       },
//       {
//         name: '注册结果',
//         path: 'register-result',
//       },
//     ],
//   },
// ];

function formatter(data, parentPath = '/', parentAuthority) {
  return data.map(item => {
    let { path } = item;
    if (!isUrl(path)) {
      path = parentPath + item.path;
    }
    const result = {
      ...item,
      path,
      authority: item.authority || parentAuthority,
    };
    if (item.children) {
      result.children = formatter(item.children, `${parentPath}${item.path}/`, item.authority);
    }
    return result;
  });
}
export const getMenuData = () => formatter(JSON.parse(getStore("userInfo"))?JSON.parse(getStore("userInfo")).menuList?JSON.parse(getStore("userInfo")).menuList:[]:[]);

