const gulp = require('gulp');
const sftp = require('gulp-sftp');

gulp.task('prod', () => {
    return gulp.src("dist/**/*",{base:'./dist'})
      .pipe(sftp({
        host: "120.24.83.17",
        port: 22,
        user: "root",
        pass: "6688FoOd4st1103!@#",
        remotePath: "/ROOT/webapp-80/admin",
      }))
      .pipe(sftp({
        host: "120.24.83.17",
        port: 22,
        user: "root",
        pass: "6688FoOd4st1103!@#",
        remotePath: "/ROOT/source/st_agent_web_antd",
      }));
});

gulp.task('test', () => {
    return gulp.src("dist/**/*",{base:'./dist'})
        .pipe(sftp({
            host: "39.108.245.250",
            port: 22,
            user: "root",
            pass: "6688FoOd4st1103!@#",
            remotePath: "/ROOT/webapp-80/admin",
        }))
        .pipe(sftp({
            host: "39.108.245.250",
            port: 22,
            user: "root",
            pass: "6688FoOd4st1103!@#",
            remotePath: "/ROOT/source/st_agent_web_antd",
        }));
});
